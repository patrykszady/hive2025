<?php

namespace SsSystems\Platform\Seo\KeywordResearch;

use SsSystems\Platform\Seo\Contracts\SeoSiteProfile;

/**
 * The town x service phrase seeds gs.construction's SeoKeywordResearch
 * hardcoded as `$services` x `AreaServed::query()->pluck('city')` — here
 * generalised to any site's own `$profile->services()` x `$profile->towns()`,
 * both directions ("kitchen remodeling Barrington" and "Barrington kitchen
 * remodeling"), since different sites phrase their town-service searches
 * differently. Returns no seeds when either list is empty: a site with no
 * services configured, or no served towns, has no town x service universe to
 * seed — SsSystems\Platform\Seo\KeywordResearch\Console\KeywordResearchCommand
 * falls back to the site's own top Search Console queries instead (see
 * OwnQueryMetrics::topQueries()).
 */
final class KeywordSeedBuilder
{
    public function __construct(private readonly SeoSiteProfile $profile)
    {
    }

    /** @return list<string> */
    public function seeds(): array
    {
        $services = $this->profile->services();
        $towns = $this->profile->towns();

        if ($services === [] || $towns === []) {
            return [];
        }

        $seeds = [];
        foreach ($towns as $town) {
            foreach ($services as $service) {
                $seeds[] = "{$service} {$town}";
                $seeds[] = "{$town} {$service}";
            }
        }

        return array_values(array_unique($seeds));
    }
}
