<?php

namespace SsSystems\Platform\Seo\Visibility;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Carbon;
use Illuminate\Support\Str;

/**
 * seo_ai_mentions — one row per (platform, town, service) question asked of
 * an AI answer engine, written by AiMentionsCommand and read back by
 * VisibilitySnapshot. Tenant-scoped the same way
 * SsSystems\Platform\Traffic\Collectors\TrackedEventsCollector is.
 */
final class AiMentionStore
{
    public function __construct(
        private readonly ConnectionInterface $connection,
        private readonly string $table = 'seo_ai_mentions',
        private readonly ?string $tenantColumn = null,
        private readonly ?\Closure $tenantId = null,
    ) {}

    public function exists(): bool
    {
        return $this->connection->getSchemaBuilder()->hasTable($this->table);
    }

    /**
     * @param  list<string>  $businessesNamed
     */
    public function insert(
        string $platform,
        string $model,
        string $prompt,
        ?string $town,
        ?string $service,
        bool $mentioned,
        ?int $mentionRank,
        array $businessesNamed,
        ?string $answerExcerpt,
        string $askedOn,
    ): void {
        $row = [
            'platform' => $platform,
            'model' => $model,
            'prompt' => mb_substr($prompt, 0, 255),
            'town' => $town,
            'service' => $service,
            'mentioned' => $mentioned,
            'mention_rank' => $mentionRank,
            'businesses_named' => json_encode(array_slice($businessesNamed, 0, 12)),
            'answer_excerpt' => $answerExcerpt !== null ? Str::limit($answerExcerpt, 1500) : null,
            'asked_on' => $askedOn,
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now(),
        ];
        if ($this->tenantColumn !== null) {
            $row[$this->tenantColumn] = ($this->tenantId)();
        }

        $this->connection->table($this->table)->insert($row);
    }

    public function latestAskedOn(): ?string
    {
        if (! $this->exists()) {
            return null;
        }

        return $this->connection->table($this->table)
            ->when($this->tenantColumn !== null, fn ($q) => $q->where($this->tenantColumn, ($this->tenantId)()))
            ->max('asked_on');
    }

    public function priorAskedOnBefore(string $day): ?string
    {
        return $this->connection->table($this->table)
            ->when($this->tenantColumn !== null, fn ($q) => $q->where($this->tenantColumn, ($this->tenantId)()))
            ->where('asked_on', '<', $day)
            ->max('asked_on');
    }

    /** @return list<array<string, mixed>> */
    public function rowsForDay(string $day): array
    {
        if (! $this->exists()) {
            return [];
        }

        return $this->connection->table($this->table)
            ->when($this->tenantColumn !== null, fn ($q) => $q->where($this->tenantColumn, ($this->tenantId)()))
            ->where('asked_on', $day)
            ->get()
            ->map(fn ($row) => (array) $row)
            ->all();
    }
}
