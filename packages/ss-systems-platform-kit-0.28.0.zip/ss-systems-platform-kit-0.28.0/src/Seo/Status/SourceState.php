<?php

namespace SsSystems\Platform\Seo\Status;

use Carbon\CarbonInterface;
use Illuminate\Support\Carbon;

/**
 * The one word for how a source is doing — the vocabulary the kit and the
 * hub share, decided here and nowhere else:
 *
 *   fresh           the last attempt did not fail and the last success is within late-after
 *   late            no success within late-after, and the last attempt did not fail
 *                   (the job is not running, or keeps finding nothing to do)
 *   failing         the last attempt failed, whatever its age
 *   not_connected   the source needs a key, grant or setup this site does not have
 *   not_applicable  this site never has this source
 *   never_ran       connected and applicable, no attempt recorded yet
 *
 * `fresh` is worded "did not fail" where the hub contract says "succeeded":
 * the two differ only for a run that was SKIPPED (today's allowance already
 * spent, say) after a recent success, which the contract's wording leaves
 * in no state at all — its data is recent and nothing went wrong, so it is
 * fresh until the late-after passes.
 *
 * Staleness is measured from the last SUCCESS. Measuring it from the last
 * attempt, as the Search Console "stale" rule did until 2026-11-12, lets a
 * sync that fails every three hours read as up to date for ever.
 *
 * Worst first for a roll-up: failing > late > never_ran > fresh.
 * not_connected and not_applicable never make a roll-up worse.
 */
final class SourceState
{
    public const FRESH = 'fresh';

    public const LATE = 'late';

    public const FAILING = 'failing';

    public const NOT_CONNECTED = 'not_connected';

    public const NOT_APPLICABLE = 'not_applicable';

    public const NEVER_RAN = 'never_ran';

    /** Three missed 15-minute beats: the scheduler is late. */
    public const SCHEDULER_LATE_AFTER_SECONDS = 2700;

    /** @var array<string, int> how bad each state is in a roll-up */
    private const SEVERITY = [
        self::FAILING => 3,
        self::LATE => 2,
        self::NEVER_RAN => 1,
        self::FRESH => 0,
    ];

    /**
     * @param  array{last_attempt_at?: ?string, last_success_at?: ?string, last_status?: ?string}|null  $heartbeat  null when nothing has run
     */
    public static function of(bool $connected, bool $applicable, ?array $heartbeat, int $lateAfterSeconds, ?CarbonInterface $now = null): string
    {
        if (! $applicable) {
            return self::NOT_APPLICABLE;
        }

        if (! $connected) {
            return self::NOT_CONNECTED;
        }

        return self::ofRuns($heartbeat, $lateAfterSeconds, $now);
    }

    /**
     * The state of the runs alone, for a source already known to be
     * connected and applicable: never_ran, failing, late or fresh.
     *
     * @param  array{last_attempt_at?: ?string, last_success_at?: ?string, last_status?: ?string}|null  $heartbeat
     */
    public static function ofRuns(?array $heartbeat, int $lateAfterSeconds, ?CarbonInterface $now = null): string
    {
        if (self::age($heartbeat['last_attempt_at'] ?? null, $now) === null) {
            return self::NEVER_RAN;
        }

        if (($heartbeat['last_status'] ?? null) === HeartbeatRecord::FAILED) {
            return self::FAILING;
        }

        $sinceSuccess = self::age($heartbeat['last_success_at'] ?? null, $now);

        return $sinceSuccess !== null && $sinceSuccess <= $lateAfterSeconds ? self::FRESH : self::LATE;
    }

    /**
     * The scheduler's own state from its last beat: fresh within 45
     * minutes, late after, never_ran when there has been none.
     */
    public static function scheduler(?string $lastBeatAt, ?CarbonInterface $now = null): string
    {
        $age = self::age($lastBeatAt, $now);

        return match (true) {
            $age === null => self::NEVER_RAN,
            $age <= self::SCHEDULER_LATE_AFTER_SECONDS => self::FRESH,
            default => self::LATE,
        };
    }

    /**
     * The worst of several states; `fresh` for none that count.
     *
     * @param  iterable<string>  $states
     */
    public static function worst(iterable $states): string
    {
        $worst = self::FRESH;

        foreach ($states as $state) {
            if ((self::SEVERITY[$state] ?? -1) > self::SEVERITY[$worst]) {
                $worst = $state;
            }
        }

        return $worst;
    }

    /** Whether a state takes part in a roll-up at all. */
    public static function counts(string $state): bool
    {
        return isset(self::SEVERITY[$state]);
    }

    public static function severity(string $state): int
    {
        return self::SEVERITY[$state] ?? -1;
    }

    /** Seconds since $at, never negative; null when $at is empty or not a time. */
    public static function age(?string $at, ?CarbonInterface $now = null): ?int
    {
        if ($at === null || trim($at) === '') {
            return null;
        }

        try {
            return max(0, (int) Carbon::parse($at)->diffInSeconds($now ?? Carbon::now(), false));
        } catch (\Throwable) {
            return null;
        }
    }
}
