<?php

namespace SsSystems\Platform\Seo\Status;

/**
 * A raw failure as one sentence a non-technical owner can act on. The raw
 * text stays beside it (`last_error`) for whoever has to look closer; this
 * only sorts it into the handful of things that actually go wrong with a
 * collector and says which, naming the vendor.
 *
 * The order of the rules is the order of the questions: did the run die,
 * was it over its spending cap, is it money, is it the daily limit, is the
 * key missing, were we refused, did the vendor not answer, was there
 * nothing to collect, is the site's own setup short. First match wins, so
 * an AI provider's "You exceeded your current quota, check your billing"
 * is money before its "quota" can read as a daily limit, and Clarity's
 * "HTTP 429 (check token and API permissions)" is the daily limit before
 * its "permissions" can read as a refusal — the mistake its own message
 * made until now.
 */
final class PlainError
{
    public const UNFINISHED = 'unfinished';

    public const BUDGET = 'budget';

    public const BALANCE = 'balance';

    public const QUOTA = 'quota';

    public const KEY_MISSING = 'key_missing';

    public const ACCESS = 'access';

    public const NOT_ANSWERING = 'not_answering';

    public const NOTHING_TO_COLLECT = 'nothing_to_collect';

    public const SETUP = 'setup';

    public const NO_REASON = 'no_reason';

    public const OTHER = 'other';

    /** @var array<string, string> kind → pattern, asked in this order */
    private const PATTERNS = [
        self::UNFINISHED => '/stopped before it finished|did not finish/i',
        self::BUDGET => '/exceeds --budget|budget reached/i',
        self::BALANCE => '/balance .{0,40}(cannot cover|too low)|insufficient (funds|balance|credit)|payment required|\b402\b|credit balance|out of credit|billing (is )?(not|disabled|hard limit)|exceeded your current quota/i',
        self::QUOTA => '/\b429\b|quota|rate.?limit|throttle|too many requests|allowance .{0,40}(spent|used up)|resource_exhausted|daily limit/i',
        self::KEY_MISSING => '/not configured|is not connected|not connected (on|for)|\bno\b.{0,30}\b(key|token|credentials?)\b|(key|token|login|password|credentials?) (is |are )?(missing|not set|empty)|missing (api )?(key|token|login|password|credentials?)|has no (api )?(key|project id)/i',
        self::ACCESS => '/\b40[13]\b|permission|forbidden|unauthori[sz]ed|not authori[sz]ed|access denied|invalid[ _](grant|credentials?|token|api key)|token (has )?(expired|been revoked)|revoked|insufficient.{0,20}scope|does not have (sufficient )?(access|permission)|notauthorized|invalidapikey/i',
        self::NOT_ANSWERING => '/timed? ?out|timeout|could not resolve|connection (refused|reset|timed)|curl error|(http|status|code)[ :]*5\d\d\b|internal server error|bad gateway|service unavailable|temporarily unavailable|did not answer|answered nothing|no response|balance unknown/i',
        self::NOTHING_TO_COLLECT => '/nothing to (inspect|collect|ask)|no (sitemap )?(urls?|pages?) (found|to)|no tracked quer|empty (sitemap|page list)|\b0 urls\b/i',
        self::SETUP => '/tables? (is |are )?missing|missing .{0,40}table|no such table|doesn\'t exist|run migrations|unknown family|needs latitude/i',
        self::NO_REASON => '/exited with code \d+\.?( Last line: .*)?$/i',
    ];

    /**
     * The sentence for a raw reason, or null when there is none.
     *
     * @param  string  $vendor  who the collector was asking — "Google", "DataForSEO" (SourceRegistry's `vendor`)
     */
    public static function sentence(?string $raw, string $vendor): ?string
    {
        if ($raw === null || trim($raw) === '') {
            return null;
        }

        return match (self::kind($raw)) {
            self::UNFINISHED => 'The last run stopped partway and never finished. It needs a developer if it happens again.',
            self::BUDGET => 'This run would have cost more than the spending cap set for it, so it did not start. The cap is a developer\'s setting.',
            self::BALANCE => "The {$vendor} account does not have enough credit for this run. Add credit and the next run picks up where this one stopped.",
            self::QUOTA => "{$vendor} said today's limit is used up. Nothing is wrong on the site; collection carries on with the next run.",
            self::KEY_MISSING => "{$vendor} is not set up for this site yet. Add its key under Connect Services.",
            self::ACCESS => "{$vendor} refused us access to this site's data. Its key or sign-in has expired or lacks permission: reconnect it under Connect Services.",
            self::NOT_ANSWERING => "{$vendor} did not answer. This usually clears by itself on the next run.",
            self::NOTHING_TO_COLLECT => 'There was nothing to collect: the list of pages or searches to ask about came back empty.',
            self::SETUP => 'The site is missing part of its own setup for this (a database table or a setting). It needs a developer.',
            self::NO_REASON => 'The last run ended with an error and did not say why. It needs a developer if it happens again.',
            default => "The last run failed for a reason we do not recognise. The technical detail is kept beside this line.",
        };
    }

    /** Which of the kinds a raw reason is; OTHER when none. */
    public static function kind(string $raw): string
    {
        foreach (self::PATTERNS as $kind => $pattern) {
            if (preg_match($pattern, $raw) === 1) {
                return $kind;
            }
        }

        return self::OTHER;
    }
}
