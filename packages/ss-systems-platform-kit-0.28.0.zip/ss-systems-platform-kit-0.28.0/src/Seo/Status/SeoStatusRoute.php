<?php

namespace SsSystems\Platform\Seo\Status;

use Illuminate\Container\Container;

/**
 * Routes GET …/seo/status on a site without a line of site code, the way
 * the `site_checks` block reached every site's snapshot in 0.27.0: by
 * finding something the site already has. Here it is the site's own
 * `GET …/seo/summary` route (every site has routed it since 0.26.0) — the
 * new route is added beside it, same path prefix, same domain, the same
 * middleware in the same order (the bearer-token guard, the throttle, a
 * multi-tenant site's tenant resolver), so the endpoint is exactly as
 * reachable and exactly as guarded as the summary the hub already reads.
 *
 * Never guesses: a site with no `seo/summary` route gets no route (an
 * unguarded one would be worse than none), and a site that routes
 * `seo/status` itself keeps its own.
 *
 * Looking through every route costs a fraction of a millisecond, which is
 * still too much to spend on each page view of a public site. So in a web
 * request the route is only added when this very path is being asked for;
 * a console (route:list, route:cache, a test suite) always gets it, as
 * does a long-lived worker that boots once for many requests. With routes
 * cached nothing is added: `route:cache` ran in a console, so the cache
 * already holds the route.
 */
final class SeoStatusRoute
{
    public const PATH = 'seo/status';

    public const SIBLING = 'seo/summary';

    /** The URI the route was added under, or null when none was added. */
    public static function register(Container $app): ?string
    {
        try {
            if (! $app->bound('router') || ! self::wanted($app)) {
                return null;
            }

            $router = $app->make('router');
            $sibling = null;

            foreach ($router->getRoutes() as $route) {
                if (! in_array('GET', $route->methods(), true)) {
                    continue;
                }

                if (str_ends_with($route->uri(), self::PATH)) {
                    return null;
                }

                if ($sibling === null && str_ends_with($route->uri(), self::SIBLING)) {
                    $sibling = $route;
                }
            }

            if ($sibling === null) {
                return null;
            }

            $uri = substr($sibling->uri(), 0, -strlen(self::SIBLING)).self::PATH;
            $route = $router->get($uri, [SeoStatusController::class, 'status'])->middleware($sibling->middleware());

            if ($sibling->excludedMiddleware() !== []) {
                $route->withoutMiddleware($sibling->excludedMiddleware());
            }

            if ($sibling->getDomain() !== null) {
                $route->domain($sibling->getDomain());
            }

            $name = (string) $sibling->getName();

            if (str_ends_with($name, 'summary')) {
                $route->name(substr($name, 0, -strlen('summary')).'status');
                $router->getRoutes()->refreshNameLookups();
            }

            return $uri;
        } catch (\Throwable $e) {
            if (function_exists('report')) {
                report($e);
            }

            return null;
        }
    }

    private static function wanted(Container $app): bool
    {
        if (method_exists($app, 'routesAreCached') && $app->routesAreCached()) {
            return false;
        }

        if (! method_exists($app, 'runningInConsole') || $app->runningInConsole() || isset($_SERVER['LARAVEL_OCTANE'])) {
            return true;
        }

        return $app->bound('request') && str_ends_with(trim((string) $app->make('request')->path(), '/'), self::PATH);
    }
}
