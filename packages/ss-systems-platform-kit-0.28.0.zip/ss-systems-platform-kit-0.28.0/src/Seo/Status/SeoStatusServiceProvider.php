<?php

namespace SsSystems\Platform\Seo\Status;

use Illuminate\Console\Events\CommandFinished;
use Illuminate\Console\Events\CommandStarting;
use Illuminate\Console\Events\ScheduledTaskSkipped;
use Illuminate\Console\Events\ScheduledTaskStarting;
use Illuminate\Queue\Events\JobExceptionOccurred;
use Illuminate\Support\ServiceProvider;

/**
 * Everything the data-status heartbeat needs at boot, on every site, with
 * no site code: the kit's first service provider, found by Laravel's
 * package discovery (composer.json → extra.laravel.providers) the moment
 * a site installs the kit version that carries it.
 *
 * Why a provider now, when 27 versions went without one: a listener has to
 * be registered in EVERY process — the scheduler's, each scheduled
 * command's, each queue worker's — before anything runs, and the only
 * other way to get that is the same three lines pasted into six
 * AppServiceProviders (one of them through a pull request on a repo that
 * is not ours), which is precisely how collectors came to differ from site
 * to site.
 *
 * It does three things and binds nothing a site could be surprised by:
 *
 *   - listens for artisan commands starting and finishing
 *     ({@see CommandHeartbeat}), and for the exception a failed one threw
 *     (a queued job failing with it, the handler logging it) — so a run
 *     that throws is recorded with its reason, not just an exit code;
 *   - listens for the scheduler reaching its 15-minute snapshot task
 *     ({@see SchedulerBeat});
 *   - routes GET …/seo/status beside the site's own `seo/summary`
 *     ({@see SeoStatusRoute}).
 *
 * Each handler swallows its own errors. A site that wants none of it lists
 * the provider under `extra.laravel.dont-discover` in its composer.json.
 */
final class SeoStatusServiceProvider extends ServiceProvider
{
    /** The levels at which a logged message is taken for the reason a run died. */
    private const ERROR_LEVELS = ['error', 'critical', 'alert', 'emergency'];

    public function boot(): void
    {
        $events = $this->app->make('events');
        $commands = new CommandHeartbeat;
        $scheduler = new SchedulerBeat;

        $events->listen(CommandStarting::class, static fn (object $event) => $commands->starting($event));
        $events->listen(CommandFinished::class, static fn (object $event) => $commands->finished($event));
        $events->listen(ScheduledTaskStarting::class, static fn (object $event) => $scheduler->handle($event));
        $events->listen(ScheduledTaskSkipped::class, static fn (object $event) => $scheduler->handle($event));

        // A command that throws finishes with a failure exit first; why it
        // threw arrives right after — handed to the queue when a job ran
        // it, logged by the exception handler otherwise.
        $events->listen(JobExceptionOccurred::class, static function (object $event): void {
            if (($event->exception ?? null) instanceof \Throwable) {
                Heartbeat::explain($event->exception->getMessage());
            }
        });

        // By name: illuminate/log is the site's dependency, not the kit's.
        // Laravel's exception handler logs what it reports with the
        // exception itself in the context, which tells a thrown exception
        // from a line some code chose to log at error level.
        $events->listen('Illuminate\Log\Events\MessageLogged', static function (object $event): void {
            if (in_array($event->level ?? null, self::ERROR_LEVELS, true)) {
                Heartbeat::logged((string) ($event->message ?? ''), (($event->context ?? [])['exception'] ?? null) instanceof \Throwable);
            }
        });

        if (method_exists($this->app, 'booted')) {
            $this->app->booted(fn () => SeoStatusRoute::register($this->app));
        }
    }
}
