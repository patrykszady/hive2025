<?php

namespace SsSystems\Platform\Seo\Status;

use Symfony\Component\Console\Input\InputInterface;

/**
 * One artisan invocation as the status registry needs it: the command's
 * name, the plain words after it and the names of the options that were
 * given. `seo:intel serp --budget=1` is name `seo:intel`, arguments
 * [`serp`], options [`budget`].
 *
 * Built from the input Laravel hands its CommandStarting/CommandFinished
 * events, or from a typed line where no such event exists — a command a
 * site runs inside another one (`$this->call()` fires no event), which
 * reports through {@see CommandHeartbeat::ran()}.
 */
final class CommandLine
{
    /**
     * @param  list<string>  $arguments
     * @param  list<string>  $options  names without the dashes
     */
    public function __construct(
        public readonly string $name,
        public readonly array $arguments = [],
        public readonly array $options = [],
    ) {}

    /**
     * From a console event. Once the command has bound its input (it has by
     * the time it runs, so always at CommandFinished) the arguments and the
     * options come from the input itself, an option counting as given when
     * its value is not empty — `Artisan::call('x', ['--dry-run' => false])`
     * did not ask for a dry run. An input that was never bound (the command
     * threw first) is read from its typed form instead.
     */
    public static function fromInput(string $name, ?InputInterface $input): self
    {
        if ($input === null) {
            return new self($name);
        }

        try {
            $arguments = [];
            $declaredArguments = $input->getArguments();
            $declaredOptions = $input->getOptions();

            foreach ($declaredArguments as $key => $value) {
                // `Artisan::call('x', [...])` hands the name in as an unnamed
                // argument too, which the input keeps beside `command`.
                if ($key === 'command' || (is_int($key) && $value === $name)) {
                    continue;
                }

                foreach ((array) $value as $word) {
                    if (is_scalar($word) && (string) $word !== '') {
                        $arguments[] = (string) $word;
                    }
                }
            }

            $options = [];

            foreach ($declaredOptions as $key => $value) {
                if ($value !== null && $value !== false && $value !== '' && $value !== []) {
                    $options[] = (string) $key;
                }
            }

            // Anything declared at all means the input was bound to the
            // command's definition; an unbound input declares nothing.
            if ($declaredArguments !== [] || $declaredOptions !== []) {
                return new self($name, $arguments, $options);
            }

            $typed = self::parse(method_exists($input, '__toString') ? (string) $input : '');
        } catch (\Throwable) {
            return new self($name);
        }

        $arguments = $typed->name === $name ? $typed->arguments : array_merge([$typed->name], $typed->arguments);

        return new self($name, array_values(array_filter($arguments, static fn (string $word): bool => $word !== '' && $word !== $name)), $typed->options);
    }

    /** From a typed line: `seo:intel serp --budget=1`, or `tenants:run "seo:snapshot-store" --site=gsc`. */
    public static function parse(string $line): self
    {
        $tokens = str_getcsv(trim($line), ' ', "'", '\\');
        $words = [];
        $options = [];

        foreach ($tokens as $token) {
            $token = trim((string) $token, " \t\"'");

            if ($token === '' || $token === '--') {
                continue;
            }

            if (str_starts_with($token, '--')) {
                $options[] = explode('=', substr($token, 2), 2)[0];

                continue;
            }

            if (str_starts_with($token, '-')) {
                continue;
            }

            $words[] = $token;
        }

        $name = (string) array_shift($words);

        return new self($name, $words, array_values(array_unique($options)));
    }

    public function has(string $option): bool
    {
        return in_array(ltrim($option, '-'), $this->options, true);
    }

    public function __toString(): string
    {
        return trim($this->name.' '.implode(' ', $this->arguments));
    }
}
