<?php

namespace SsSystems\Platform\Seo\Status;

use Illuminate\Container\Container;
use Illuminate\Support\Carbon;

/**
 * The scheduler's own heartbeat. A site whose cron entry has stopped is
 * otherwise indistinguishable from a healthy one: nothing fails, the hub
 * keeps asking it for a Search Console sync every three hours, each of
 * those rebuilds the stored snapshot, and a snapshot built on request is
 * stamped with the moment it was asked for.
 *
 * The beat is the scheduler reaching its 15-minute `seo:snapshot-store`
 * task — every site schedules it. It is taken from Laravel's own scheduler
 * events (ScheduledTaskStarting, and ScheduledTaskSkipped: a scheduler
 * that skips the task because the last one is still running is alive),
 * which only `schedule:run` ever fires. So nothing else can beat: not a
 * snapshot built by a request, not the `seo:snapshot-store --fresh` a
 * Search Console sync ends with (also told apart by its flag, should a
 * site ever schedule that), not a run typed into a shell.
 *
 * Kept under its own key in the heartbeat store, beside the sources.
 */
final class SchedulerBeat
{
    public const KEY = 'scheduler';

    public const COMMAND = 'seo:snapshot-store';

    /** @param  object  $event  Illuminate\Console\Events\ScheduledTaskStarting or ScheduledTaskSkipped */
    public function handle(object $event): void
    {
        try {
            if (self::isBeat((string) ($event->task->command ?? ''))) {
                self::record();
            }
        } catch (\Throwable) {
            // The scheduler must run its task whether or not the beat was kept.
        }
    }

    /** Whether a scheduled task's command line is the 15-minute snapshot run. */
    public static function isBeat(string $commandLine): bool
    {
        return str_contains($commandLine, self::COMMAND) && ! str_contains($commandLine, '--fresh');
    }

    public static function record(?Container $container = null): void
    {
        try {
            $store = HeartbeatStores::current($container);

            $store?->write(self::KEY, array_replace($store->read(self::KEY) ?? [], [
                'last_beat_at' => Carbon::now()->toIso8601String(),
            ]));
        } catch (\Throwable) {
            // Same rule as every heartbeat: never an exception.
        }
    }

    /** @param  array<string, mixed>|null  $row  what the store holds under KEY */
    public static function lastBeatAt(?array $row): ?string
    {
        $at = $row['last_beat_at'] ?? null;

        return is_string($at) && $at !== '' ? $at : null;
    }
}
