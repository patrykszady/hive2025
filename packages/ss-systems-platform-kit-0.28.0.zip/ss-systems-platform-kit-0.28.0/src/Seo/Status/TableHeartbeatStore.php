<?php

namespace SsSystems\Platform\Seo\Status;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Database\Query\Builder;
use Illuminate\Database\QueryException;
use Illuminate\Support\Carbon;
use SsSystems\Platform\Seo\Status\Contracts\HeartbeatStore;

/**
 * The default {@see HeartbeatStore}: the site's `seo_sync_runs` table (the
 * kit's create_seo_sync_runs_table stub — `sync_key` unique, `summary` as
 * JSON), over a plain query builder so the kit names no site model. It is
 * the same row a site's own `SeoSyncRun` model reads and writes through
 * {@see \SsSystems\Platform\Seo\Concerns\RecordsSyncRuns}: the Search
 * Console row keeps every field `platforms/status` reads today and gains
 * the heartbeat fields beside them. No schema change.
 *
 * A site without the table (gs.construction keeps its sync bookkeeping on
 * `oauth_tokens.metadata`) reads null and writes nothing — it never
 * throws. Whether the table exists is asked once per instance.
 *
 * Tenant-scoped like PsiSnapshotStore: a single-tenant site passes neither
 * `$tenantColumn` nor `$tenantId`; a multi-tenant site whose table carries
 * the stub's optional `site_id` passes the column and a closure reading
 * the current tenant at call time.
 */
final class TableHeartbeatStore implements HeartbeatStore
{
    private ?bool $hasTable = null;

    public function __construct(
        private readonly ConnectionInterface $connection,
        private readonly string $table = 'seo_sync_runs',
        private readonly ?string $tenantColumn = null,
        private readonly ?\Closure $tenantId = null,
    ) {}

    public function read(string $key): ?array
    {
        if (! $this->hasTable()) {
            return null;
        }

        $summary = $this->row($key)->value('summary');
        $summary = is_string($summary) ? json_decode($summary, true) : $summary;

        return is_array($summary) ? $summary : null;
    }

    /**
     * Every summary in the table by its key, in one query — what
     * `seo/status` reads instead of asking for the keys one at a time.
     *
     * @return array<string, array<string, mixed>>
     */
    public function all(): array
    {
        if (! $this->hasTable()) {
            return [];
        }

        $query = $this->connection->table($this->table);

        if ($this->tenantColumn !== null) {
            $query->where($this->tenantColumn, ($this->tenantId)());
        }

        $rows = [];

        foreach ($query->get(['sync_key', 'summary']) as $row) {
            $summary = is_string($row->summary) ? json_decode($row->summary, true) : $row->summary;

            if (is_array($summary)) {
                $rows[(string) $row->sync_key] = $summary;
            }
        }

        return $rows;
    }

    public function write(string $key, array $summary): void
    {
        if (! $this->hasTable()) {
            return;
        }

        $now = Carbon::now();
        $json = (string) json_encode($summary, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        if ($this->row($key)->update(['summary' => $json, 'updated_at' => $now]) > 0 || $this->row($key)->exists()) {
            return;
        }

        $row = ['sync_key' => $key, 'summary' => $json, 'created_at' => $now, 'updated_at' => $now];

        if ($this->tenantColumn !== null) {
            $row[$this->tenantColumn] = ($this->tenantId)();
        }

        try {
            $this->connection->table($this->table)->insert($row);
        } catch (QueryException) {
            // Another process inserted the row between the update and here.
            $this->row($key)->update(['summary' => $json, 'updated_at' => $now]);
        }
    }

    public function hasTable(): bool
    {
        if ($this->hasTable === null) {
            try {
                $this->hasTable = $this->connection->getSchemaBuilder()->hasTable($this->table);
            } catch (\Throwable) {
                $this->hasTable = false;
            }
        }

        return $this->hasTable;
    }

    private function row(string $key): Builder
    {
        $query = $this->connection->table($this->table)->where('sync_key', $key);

        if ($this->tenantColumn !== null) {
            $query->where($this->tenantColumn, ($this->tenantId)());
        }

        return $query;
    }
}
