<?php

namespace SsSystems\Platform\Seo\Status;

use Illuminate\Container\Container;
use SsSystems\Platform\Reports\ReportRegistry;

/**
 * Every source of SEO/GEO data a site collects: key → the words an owner
 * reads → the vendor behind it → the artisan jobs that feed it, how often
 * each runs and when it counts as late → how "connected" and "applicable"
 * are decided → which table says how recent the data is. `GET seo/status`
 * is this table read against the heartbeat store; the hub keys its own
 * table on these keys, so a key is never renamed.
 *
 * Modelled on {@see ReportRegistry}: one constant, read through static
 * methods, so "which collectors exist" is answered in one file instead of
 * being inferred from six `routes/console.php`.
 *
 * JOBS. A source is fed by one or more jobs, each an artisan command and,
 * where one command does several things, the word or flag that tells them
 * apart: `traffic:collect` is the daily five-day re-read and
 * `traffic:collect --date` the hourly look at today; `seo:intel serp` and
 * `seo:intel trends` are separate collectors that share a command. Each
 * job keeps its own heartbeat, because a later success of a sibling must
 * not hide a failure: the hourly traffic run succeeding at 08:00 says
 * nothing about the daily run that failed at 07:30.
 *
 *   - An EXPECTED job (the default) is one every site schedules. It is
 *     `never_ran` until it reports, `late` when its last success is older
 *     than its late-after, `failing` when its last attempt failed.
 *   - A job marked `expected => false` is a helper not every site runs
 *     (a pick-up pass, a single report). It can only make its source
 *     `failing`, and only while that failure is recent (within its own
 *     late-after): a helper nobody schedules must not read late for ever.
 *
 * A flag in a job's name must be one with no default (`--date`,
 * `--collect`), since an option left at its default is not "given".
 *
 * CADENCES are how the six sites schedule each job today (2026-11-12,
 * their routes/console.php): where they agree the number is theirs, where
 * they differ it is the commonest and the odd site says so in its config.
 * Late-after is one missed run plus slack ({@see lateAfter()}).
 *
 * A SITE'S OWN SAY, `config/seo-status.php`, all optional:
 *
 * ```php
 * return ['sources' => [
 *     // this site never has the source: leave the key out of the payload
 *     'map_pack' => false,
 *     // the main job runs on another cadence here
 *     'rankings' => ['cadence_seconds' => 86400, 'late_after_seconds' => 129600],
 *     'traffic' => ['jobs' => [
 *         // a job this site does not schedule
 *         'traffic:collect --date' => false,
 *         // a command of the site's own that feeds the source
 *         'traffic:import-callrail' => ['cadence_seconds' => 86400],
 *     ]],
 *     // the table is called something else here (or false: no date to read)
 *     'pagespeed' => ['data_through' => ['page_speed_runs', 'measured_on']],
 * ]];
 * ```
 */
final class SourceRegistry
{
    public const HOUR = 3600;

    public const DAY = 86400;

    public const WEEK = 604800;

    /** A monthly job's longest gap: the 2nd of a 31-day month to the 2nd of the next. */
    public const MONTH = 2678400;

    /** Given any of these, a run collects nothing — it is not an attempt and leaves no heartbeat. */
    public const NOT_A_RUN = ['dry-run', 'list', 'help', 'findings', 'rescore'];

    /**
     * `connected` and `applicable` name a rule of {@see SourceConnections};
     * `feed` says who reports the run — `explicit` (the collector hands in
     * its own summary), `listener` (the command's exit, see
     * {@see CommandHeartbeat}) or `both` (the listener, with counts or the
     * refusal reason handed in by the collector).
     *
     * @var array<string, array{
     *     label: string,
     *     detail_label: string,
     *     vendor: string,
     *     jobs: array<string, array{cadence: int, late_after?: int, expected?: bool, each_argument?: bool}>,
     *     connected: string,
     *     applicable: string,
     *     feed: string,
     *     data_through: array{0: string, 1: string}|null,
     * }>
     */
    private const SOURCES = [
        'search_console' => [
            'label' => 'Search results (Google)',
            'detail_label' => 'Google Search Console',
            'vendor' => 'Google',
            // gs.construction runs it every three hours itself; the other
            // five daily, with ss.systems' seo:gsc-reconcile asking each for
            // a sync every three hours (SearchConsoleSyncRule::CADENCE).
            'jobs' => ['seo:gsc-sync' => ['cadence' => 3 * self::HOUR, 'late_after' => 6 * self::HOUR]],
            'connected' => 'search_console',
            'applicable' => 'always',
            'feed' => 'explicit',
            'data_through' => ['gsc_daily_totals', 'date'],
        ],
        'page_inspection' => [
            'label' => 'Which pages Google has listed',
            'detail_label' => 'Google URL Inspection',
            'vendor' => 'Google',
            'jobs' => ['seo:gsc-inspect-bulk' => ['cadence' => self::DAY]],
            'connected' => 'page_inspection',
            'applicable' => 'always',
            'feed' => 'explicit',
            'data_through' => ['gsc_coverage_states', 'inspected_at'],
        ],
        'bing' => [
            'label' => 'Search results (Bing)',
            'detail_label' => 'Bing Webmaster Tools',
            'vendor' => 'Bing',
            'jobs' => [
                'seo:bing-sync' => ['cadence' => self::DAY],
                'seo:bing-submit-sitemaps' => ['cadence' => self::DAY, 'expected' => false],
            ],
            'connected' => 'bing',
            'applicable' => 'always',
            'feed' => 'explicit',
            'data_through' => ['bing_daily_totals', 'date'],
        ],
        'bing_coverage' => [
            'label' => 'Which pages Bing has listed',
            'detail_label' => 'Bing Webmaster Tools (crawl and page history)',
            'vendor' => 'Bing',
            'jobs' => ['seo:bing-coverage' => ['cadence' => self::DAY]],
            'connected' => 'bing_coverage',
            'applicable' => 'always',
            'feed' => 'explicit',
            'data_through' => ['bing_crawl_stats', 'date'],
        ],
        'pagespeed' => [
            'label' => 'Page speed',
            'detail_label' => 'Google PageSpeed Insights',
            'vendor' => 'Google PageSpeed',
            'jobs' => ['seo:psi-sync' => ['cadence' => self::DAY]],
            'connected' => 'pagespeed',
            'applicable' => 'always',
            'feed' => 'both',
            'data_through' => ['psi_snapshots', 'date'],
        ],
        'clarity' => [
            'label' => 'How visitors use the pages',
            'detail_label' => 'Microsoft Clarity',
            'vendor' => 'Microsoft Clarity',
            'jobs' => ['seo:clarity-sync' => ['cadence' => self::DAY]],
            'connected' => 'clarity',
            'applicable' => 'always',
            'feed' => 'both',
            'data_through' => ['clarity_daily_metrics', 'date'],
        ],
        'traffic' => [
            'label' => 'Where visitors come from',
            'detail_label' => 'Traffic sources (site beacon, Search Console, Bing, Clarity, leads)',
            'vendor' => 'The traffic collector',
            'jobs' => [
                'traffic:collect' => ['cadence' => self::DAY],
                // Five sites also look at today every hour; mozaika.haus does not.
                'traffic:collect --date' => ['cadence' => self::HOUR, 'expected' => false],
            ],
            'connected' => 'always',
            'applicable' => 'always',
            'feed' => 'listener',
            'data_through' => ['traffic_source_days', 'date'],
        ],
        'indexnow' => [
            'label' => 'New and changed pages sent to Bing',
            'detail_label' => 'IndexNow',
            'vendor' => 'IndexNow',
            'jobs' => ['seo:indexnow' => ['cadence' => self::HOUR]],
            'connected' => 'indexnow',
            'applicable' => 'always',
            'feed' => 'listener',
            'data_through' => ['indexnow_submissions', 'submitted_at'],
        ],
        'rankings' => [
            'label' => 'Where you rank',
            'detail_label' => 'DataForSEO rank tracking',
            'vendor' => 'DataForSEO',
            'jobs' => [
                'seo:track-rankings' => ['cadence' => self::WEEK],
                // The free pick-up of late answers: daily on five sites, weekly on gs.construction.
                'seo:track-rankings --collect' => ['cadence' => self::DAY, 'expected' => false],
            ],
            'connected' => 'dataforseo',
            'applicable' => 'always',
            'feed' => 'listener',
            'data_through' => ['seo_rank_snapshots', 'fetched_at'],
        ],
        'keyword_research' => [
            'label' => 'Keyword ideas',
            'detail_label' => 'DataForSEO keyword research',
            'vendor' => 'DataForSEO',
            'jobs' => ['seo:keyword-research' => ['cadence' => self::WEEK]],
            'connected' => 'dataforseo',
            'applicable' => 'always',
            'feed' => 'listener',
            'data_through' => ['seo_keywords', 'researched_at'],
        ],
        'ai_mentions' => [
            'label' => 'Mentions in AI answers',
            'detail_label' => 'DataForSEO AI mentions (ChatGPT, Gemini, Perplexity, Claude)',
            'vendor' => 'DataForSEO',
            'jobs' => ['seo:ai-mentions' => ['cadence' => self::WEEK]],
            'connected' => 'dataforseo',
            'applicable' => 'always',
            'feed' => 'both',
            'data_through' => ['seo_ai_mentions', 'asked_on'],
        ],
        'domain_overview' => [
            'label' => 'You and your competitors at a glance',
            'detail_label' => 'DataForSEO domain overview',
            'vendor' => 'DataForSEO',
            'jobs' => ['seo:domain-overview' => ['cadence' => self::WEEK]],
            'connected' => 'dataforseo',
            'applicable' => 'always',
            'feed' => 'both',
            'data_through' => ['seo_domain_overviews', 'date'],
        ],
        'backlink_gap' => [
            'label' => 'Sites that link to competitors',
            'detail_label' => 'DataForSEO backlink gap',
            'vendor' => 'DataForSEO',
            'jobs' => ['seo:backlink-gap' => ['cadence' => self::MONTH, 'late_after' => self::MONTH + 2 * self::DAY]],
            'connected' => 'dataforseo',
            'applicable' => 'always',
            'feed' => 'both',
            'data_through' => ['seo_backlink_prospects', 'seen_at'],
        ],
        'map_pack' => [
            'label' => 'Local map results',
            'detail_label' => 'DataForSEO Google Maps grid',
            'vendor' => 'DataForSEO',
            'jobs' => [
                'seo:map-pack-grid' => ['cadence' => self::WEEK],
                'seo:map-pack-competitors' => ['cadence' => self::DAY, 'expected' => false],
            ],
            'connected' => 'dataforseo',
            'applicable' => 'map_pack',
            'feed' => 'listener',
            'data_through' => ['map_pack_scans', 'scanned_at'],
        ],
        'intel' => [
            'label' => 'Changes in your market',
            'detail_label' => 'DataForSEO change intel',
            'vendor' => 'DataForSEO',
            // One family per slot on every site; a family a site adds is
            // tracked from its first run through the bare entry.
            'jobs' => [
                'seo:intel serp' => ['cadence' => self::WEEK],
                'seo:intel trends' => ['cadence' => self::WEEK],
                'seo:intel onpage' => ['cadence' => self::WEEK],
                'seo:intel labs' => ['cadence' => self::WEEK],
                'seo:intel backlinks' => ['cadence' => self::WEEK],
                'seo:intel domain_analytics' => ['cadence' => self::MONTH, 'late_after' => self::MONTH + 2 * self::DAY],
                'seo:intel content_analysis' => ['cadence' => self::WEEK],
                'seo:intel ai_optimization' => ['cadence' => self::WEEK],
                // Weekdays only: Friday's run to Monday's is three days.
                'seo:intel business_data' => ['cadence' => self::DAY, 'late_after' => 4 * self::DAY],
                'seo:intel' => ['cadence' => self::WEEK, 'expected' => false, 'each_argument' => true],
            ],
            'connected' => 'dataforseo',
            'applicable' => 'always',
            'feed' => 'listener',
            'data_through' => ['seo_intel_runs', 'taken_on'],
        ],
        'faq_bank' => [
            'label' => 'Questions and answers for AI assistants',
            'detail_label' => 'FAQ bank (written by an AI provider from the site\'s own pages)',
            'vendor' => 'The AI provider',
            'jobs' => ['seo:faq-bank' => ['cadence' => self::DAY]],
            'connected' => 'faq_bank',
            'applicable' => 'faq_bank',
            'feed' => 'explicit',
            'data_through' => ['geo_faq_bank_pages', 'checked_at'],
        ],
        'reports' => [
            'label' => 'SEO reports',
            'detail_label' => 'Report library (seo:reports-refresh)',
            'vendor' => 'The report library',
            // The hourly refresh is the job; the reports of ReportRegistry,
            // run one by one on some sites, are added by jobs().
            'jobs' => [
                'seo:reports-refresh' => ['cadence' => self::HOUR],
                'seo:competitor-brand-track' => ['cadence' => self::DAY, 'expected' => false],
            ],
            'connected' => 'always',
            'applicable' => 'always',
            'feed' => 'listener',
            'data_through' => null,
        ],
        'snapshot' => [
            'label' => 'The figures on the SEO page',
            'detail_label' => 'Stored SEO snapshot (seo:snapshot-store)',
            'vendor' => 'The stored snapshot',
            'jobs' => ['seo:snapshot-store' => ['cadence' => 900, 'late_after' => 2700]],
            'connected' => 'always',
            'applicable' => 'snapshot',
            'feed' => 'listener',
            'data_through' => null,
        ],
    ];

    /** @var array<string, array<string, mixed>>|null resolved kit defaults, built once */
    private static ?array $defaults = null;

    /** @return list<string> */
    public static function keys(): array
    {
        return array_keys(self::SOURCES);
    }

    /**
     * One source as the kit defines it, its jobs spelled out.
     *
     * @return array{key: string, label: string, detail_label: string, vendor: string, connected: string, applicable: string, feed: string, data_through: array{0: string, 1: string}|null, primary: string, jobs: array<string, array{key: string, command: string, arguments: list<string>, options: list<string>, cadence_seconds: int, late_after_seconds: int, expected: bool, each_argument: bool}>}
     *
     * @throws \InvalidArgumentException when $key is not a source
     */
    public static function get(string $key): array
    {
        return self::defaults()[$key]
            ?? throw new \InvalidArgumentException("Unknown SEO data source [{$key}]. Known keys: ".implode(', ', self::keys()));
    }

    /**
     * Every source this site has, in the contract's order, with the site's
     * own `config('seo-status.sources')` applied.
     *
     * @return array<string, array<string, mixed>>
     */
    public static function all(?Container $container = null): array
    {
        $overrides = self::overrides($container);

        if ($overrides === []) {
            return self::defaults();
        }

        $sources = [];

        foreach (self::defaults() as $key => $source) {
            $override = $overrides[$key] ?? [];

            if ($override === false) {
                continue;
            }

            $sources[$key] = is_array($override) && $override !== [] ? self::override($source, $override) : $source;
        }

        return $sources;
    }

    /**
     * The jobs one invocation feeds: source key → job keys. Empty for a
     * command no source knows, and for a run that collects nothing
     * ({@see NOT_A_RUN}).
     *
     * @return array<string, list<string>>
     */
    public static function match(CommandLine $line, ?Container $container = null): array
    {
        foreach (self::NOT_A_RUN as $option) {
            if ($line->has($option)) {
                return [];
            }
        }

        $matches = [];

        foreach (self::all($container) as $key => $source) {
            $jobs = self::jobsFor($line, $source['jobs']);

            if ($jobs !== []) {
                $matches[$key] = $jobs;
            }
        }

        return $matches;
    }

    /**
     * The sources a command feeds, by its name alone — asked when a run
     * starts, before its arguments are known.
     *
     * @return list<string>
     */
    public static function sourcesOf(string $command, ?Container $container = null): array
    {
        $keys = [];

        foreach (self::all($container) as $key => $source) {
            foreach ($source['jobs'] as $job) {
                if ($job['command'] === $command) {
                    $keys[] = $key;

                    break;
                }
            }
        }

        return $keys;
    }

    /**
     * When a job on this cadence counts as late: one missed run plus slack.
     * Twice a short cadence (the rule SearchConsoleSyncRule already states
     * for the three-hourly sync), half a day past a daily one, a day or two
     * past a weekly or monthly one.
     */
    public static function lateAfter(int $cadenceSeconds): int
    {
        return match (true) {
            $cadenceSeconds <= self::HOUR => 3 * $cadenceSeconds,
            $cadenceSeconds < self::DAY => 2 * $cadenceSeconds,
            $cadenceSeconds === self::DAY => $cadenceSeconds + 12 * self::HOUR,
            $cadenceSeconds <= self::WEEK => $cadenceSeconds + self::DAY,
            default => $cadenceSeconds + 2 * self::DAY,
        };
    }

    /** @return array<string, array<string, mixed>> */
    private static function defaults(): array
    {
        if (self::$defaults !== null) {
            return self::$defaults;
        }

        $sources = [];

        foreach (self::SOURCES as $key => $source) {
            $jobs = [];

            foreach ($source['jobs'] as $name => $spec) {
                $jobs[$name] = self::job($name, $spec);
            }

            if ($key === 'reports') {
                foreach (ReportRegistry::all() as $report) {
                    $name = CommandLine::parse((string) $report['command'])->name;
                    $jobs[$name] ??= self::job($name, ['cadence' => self::DAY, 'expected' => false]);
                }
            }

            $sources[$key] = ['key' => $key] + array_diff_key($source, ['jobs' => true]) + [
                'primary' => self::primary($jobs),
                'jobs' => $jobs,
            ];
        }

        return self::$defaults = $sources;
    }

    /**
     * @param  array<string, mixed>  $source
     * @param  array<string, mixed>  $override
     * @return array<string, mixed>
     */
    private static function override(array $source, array $override): array
    {
        foreach (['label', 'detail_label', 'vendor'] as $text) {
            if (is_string($override[$text] ?? null) && $override[$text] !== '') {
                $source[$text] = $override[$text];
            }
        }

        if (array_key_exists('data_through', $override)) {
            $table = $override['data_through'];
            $source['data_through'] = is_array($table) && count($table) === 2 ? array_values(array_map('strval', $table)) : null;
        }

        foreach ((array) ($override['jobs'] ?? []) as $name => $spec) {
            if ($spec === false) {
                unset($source['jobs'][$name]);

                continue;
            }

            if (is_array($spec)) {
                $source['jobs'][$name] = self::respec((string) $name, $source['jobs'][$name] ?? null, $spec);
            }
        }

        $source['primary'] = self::primary($source['jobs']);

        // The shorthand: a cadence given on the source itself is its main job's.
        if (self::spec($override) !== [] && isset($source['jobs'][$source['primary']])) {
            $source['jobs'][$source['primary']] = self::respec($source['primary'], $source['jobs'][$source['primary']], $override);
        }

        return $source;
    }

    /**
     * A job with a site's settings laid over the kit's. A new cadence given
     * without a late-after gets the late-after that goes with it, not the
     * one that went with the old cadence.
     *
     * @param  array<string, mixed>|null  $current
     * @param  array<string, mixed>  $given
     * @return array<string, mixed>
     */
    private static function respec(string $name, ?array $current, array $given): array
    {
        $given = self::spec($given);
        $base = [];

        if ($current !== null) {
            $base = ['cadence' => $current['cadence_seconds'], 'expected' => $current['expected'], 'each_argument' => $current['each_argument']];

            if (! isset($given['cadence'])) {
                $base['late_after'] = $current['late_after_seconds'];
            }
        }

        return self::job($name, $given + $base);
    }

    /**
     * A job's settings in the registry's own short spelling, from either
     * spelling (`cadence` / `cadence_seconds`).
     *
     * @param  array<string, mixed>  $spec
     * @return array{cadence?: int, late_after?: int, expected?: bool, each_argument?: bool}
     */
    private static function spec(array $spec): array
    {
        $out = [];

        foreach (['cadence' => 'cadence_seconds', 'late_after' => 'late_after_seconds'] as $short => $long) {
            $value = $spec[$long] ?? $spec[$short] ?? null;

            if (is_numeric($value) && (int) $value > 0) {
                $out[$short] = (int) $value;
            }
        }

        foreach (['expected', 'each_argument'] as $flag) {
            if (array_key_exists($flag, $spec)) {
                $out[$flag] = (bool) $spec[$flag];
            }
        }

        return $out;
    }

    /**
     * @param  array{cadence?: int, late_after?: int, expected?: bool, each_argument?: bool}  $spec
     * @return array{key: string, command: string, arguments: list<string>, options: list<string>, cadence_seconds: int, late_after_seconds: int, expected: bool, each_argument: bool}
     */
    private static function job(string $name, array $spec): array
    {
        $line = CommandLine::parse($name);
        $cadence = (int) ($spec['cadence'] ?? self::DAY);

        return [
            'key' => $name,
            'command' => $line->name,
            'arguments' => $line->arguments,
            'options' => $line->options,
            'cadence_seconds' => $cadence,
            'late_after_seconds' => (int) ($spec['late_after'] ?? self::lateAfter($cadence)),
            'expected' => (bool) ($spec['expected'] ?? true),
            'each_argument' => (bool) ($spec['each_argument'] ?? false),
        ];
    }

    /** @param  array<string, array<string, mixed>>  $jobs */
    private static function primary(array $jobs): string
    {
        foreach ($jobs as $name => $job) {
            if ($job['expected']) {
                return (string) $name;
            }
        }

        return (string) (array_key_first($jobs) ?? '');
    }

    /**
     * The most specific of a source's jobs this invocation is: every word
     * and flag in the job's name must be on the line, and the job naming
     * the most of them wins (`traffic:collect --date=today` is the hourly
     * job, not the daily one). An `each_argument` job stands for one job
     * per word on the line, and for all of its named siblings when the
     * line has no word at all (`seo:intel` alone runs every family).
     *
     * @param  array<string, array<string, mixed>>  $jobs
     * @return list<string>
     */
    private static function jobsFor(CommandLine $line, array $jobs): array
    {
        $best = [];
        $score = -1;
        $bare = null;
        $named = [];

        foreach ($jobs as $name => $job) {
            if ($job['command'] !== $line->name) {
                continue;
            }

            if ($job['arguments'] === [] && $job['options'] === []) {
                $bare = $job;
            } elseif ($job['options'] === []) {
                $named[] = (string) $name;
            }

            if (array_diff($job['arguments'], $line->arguments) !== [] || array_diff($job['options'], $line->options) !== []) {
                continue;
            }

            $specificity = count($job['arguments']) + count($job['options']);

            if ($specificity > $score) {
                $best = [];
                $score = $specificity;
            }

            if ($specificity === $score) {
                $best[] = (string) $name;
            }
        }

        if ($bare === null || ! $bare['each_argument']) {
            return $best;
        }

        if ($line->arguments === []) {
            return $named !== [] ? $named : [$bare['key']];
        }

        return array_map(static fn (string $word): string => $bare['key'].' '.$word, $line->arguments);
    }

    /** @return array<string, mixed> */
    private static function overrides(?Container $container): array
    {
        $container ??= Container::getInstance();

        try {
            $config = $container->bound('config') ? $container->make('config')->get('seo-status.sources', []) : [];
        } catch (\Throwable) {
            return [];
        }

        return is_array($config) ? $config : [];
    }
}
