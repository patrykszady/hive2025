<?php

namespace SsSystems\Platform\Seo\Status\Contracts;

/**
 * Where a site keeps one summary per data source — the row every collector
 * reports into and `GET seo/status` reads back.
 *
 * Deliberately two dumb methods. What a run means (when the last success
 * was, how many failures in a row) is worked out in one place,
 * {@see \SsSystems\Platform\Seo\Status\HeartbeatRecord}; a store only
 * keeps the array it is handed and gives it back, so a site that keeps its
 * bookkeeping somewhere else writes ten lines, not a second copy of the
 * rule.
 *
 * OPTIONAL to bind. A site that binds nothing gets
 * {@see \SsSystems\Platform\Seo\Status\TableHeartbeatStore} over its
 * `seo_sync_runs` table (one row per key, `summary` as JSON — the table
 * hive.contractors, dawnsellshomes.com, J. Peterson Design, mozaika.haus
 * and ss.systems already have). Bind this to keep the summaries elsewhere:
 * gs.construction, whose sync bookkeeping is per tenant, binds a
 * tenant-scoped store.
 *
 * Neither method may throw for a store that is merely absent (no table
 * yet): `read()` answers null and `write()` does nothing. A collector must
 * never fail because its heartbeat could not be kept.
 *
 * Besides the source keys of {@see \SsSystems\Platform\Seo\Status\SourceRegistry},
 * one more key is written: {@see \SsSystems\Platform\Seo\Status\SchedulerBeat::KEY}.
 */
interface HeartbeatStore
{
    /**
     * The summary stored under $key, or null when there is none.
     *
     * @return array<string, mixed>|null
     */
    public function read(string $key): ?array;

    /**
     * Replaces the summary stored under $key. The caller has already merged
     * what was there (see HeartbeatRecord), so the store keeps exactly this.
     *
     * @param  array<string, mixed>  $summary
     */
    public function write(string $key, array $summary): void;
}
