<?php

namespace SsSystems\Platform\Seo\Status;

use Symfony\Component\Console\Formatter\OutputFormatterInterface;
use Symfony\Component\Console\Formatter\OutputFormatterStyleInterface;
use Symfony\Component\Console\Formatter\WrappableOutputFormatterInterface;

/**
 * Remembers the last thing a command printed, and the last error it
 * printed, so a run that ends with a failure exit can be recorded with the
 * reason the command itself gave ("DataForSEO balance $0.42 cannot cover
 * this run ($1.00).") instead of "exited with code 1".
 *
 * Laravel's CommandFinished event carries the exit code and nothing of
 * what was printed, and a scheduled command writes straight to its log
 * file, so the text cannot be read back afterwards. Every line a command
 * prints does pass through its output's formatter, though; this stands in
 * front of the real one for the length of a run ({@see CommandHeartbeat})
 * and hands every call on unchanged. A failure in its own note-taking is
 * swallowed.
 *
 * It is only ever put in front of PLAIN output (a cron run, a buffer),
 * where it changes nothing that is printed. It is kept off a coloured
 * terminal because Symfony's Table re-opens a style across a line break
 * only for its own concrete formatter class, which a stand-in is not.
 */
final class OutputTail implements WrappableOutputFormatterInterface
{
    private ?string $last = null;

    private ?string $lastError = null;

    public function __construct(private OutputFormatterInterface $inner) {}

    /**
     * A copy stands in front of a copy. Laravel's output style clones the
     * formatter for a scratch buffer and switches that clone's colours off;
     * were the real formatter shared with it, every command this watches
     * would lose its colours on a terminal.
     */
    public function __clone()
    {
        $this->inner = clone $this->inner;
    }

    /** The formatter this one stands in front of — put back when the run ends. */
    public function inner(): OutputFormatterInterface
    {
        return $this->inner;
    }

    /** The last error line the command printed (`$this->error()`), or null. */
    public function error(): ?string
    {
        return $this->lastError;
    }

    /** The last line the command printed, or null. */
    public function last(): ?string
    {
        return $this->last;
    }

    public function format(?string $message): ?string
    {
        $this->note($message);

        return $this->inner->format($message);
    }

    public function formatAndWrap(?string $message, int $width): string
    {
        return $this->inner instanceof WrappableOutputFormatterInterface
            ? $this->inner->formatAndWrap($message, $width)
            : (string) $this->inner->format($message);
    }

    public function setDecorated(bool $decorated): void
    {
        $this->inner->setDecorated($decorated);
    }

    public function isDecorated(): bool
    {
        return $this->inner->isDecorated();
    }

    public function setStyle(string $name, OutputFormatterStyleInterface $style): void
    {
        $this->inner->setStyle($name, $style);
    }

    public function hasStyle(string $name): bool
    {
        return $this->inner->hasStyle($name);
    }

    public function getStyle(string $name): OutputFormatterStyleInterface
    {
        return $this->inner->getStyle($name);
    }

    private function note(?string $message): void
    {
        try {
            if ($message === null || trim($message) === '') {
                return;
            }

            $isError = preg_match('/<error>|<bg=red[^>]*>\s*ERROR\s*<\/>/i', $message) === 1;
            $plain = trim((string) preg_replace('/\s+/u', ' ', (string) preg_replace('/<\/?(?:[a-z][a-z0-9_=;,#-]*)?>/i', '', $message)));

            if ($plain === '') {
                return;
            }

            $this->last = mb_substr($plain, 0, HeartbeatRecord::ERROR_LENGTH);

            if ($isError) {
                $this->lastError = $this->last;
            }
        } catch (\Throwable) {
            // Taking a note must never cost the command its output.
        }
    }
}
