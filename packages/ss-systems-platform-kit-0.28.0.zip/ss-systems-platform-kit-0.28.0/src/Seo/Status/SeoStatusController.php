<?php

namespace SsSystems\Platform\Seo\Status;

use SsSystems\Platform\Seo\Http\Concerns\ServesSeoStatus;

/**
 * The kit's own answer to GET seo/status, routed by
 * {@see SeoStatusServiceProvider} on every site that has not routed the
 * endpoint itself. A plain class: the route carries the admin API's
 * middleware, copied from the site's `seo/summary`.
 */
final class SeoStatusController
{
    use ServesSeoStatus;
}
