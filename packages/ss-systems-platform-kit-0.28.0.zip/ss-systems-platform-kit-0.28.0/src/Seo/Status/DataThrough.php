<?php

namespace SsSystems\Platform\Seo\Status;

use Illuminate\Container\Container;
use Illuminate\Database\ConnectionInterface;

/**
 * How recent a source's DATA is, as opposed to how recently its collector
 * ran: the newest date in the table the collector fills. A Search Console
 * sync can succeed every three hours and still have nothing newer than
 * four days ago — Google's own lag, or a window that stopped moving — and
 * only this says so.
 *
 * One `MAX()` on the table and column {@see SourceRegistry} names for the
 * source, where the table exists; null where it does not, where the source
 * names none, or where the read fails. Never more than that: `seo/status`
 * must stay cheap.
 *
 * Tenant-scoped like PsiSnapshotStore: a single-tenant site needs no
 * binding at all; a multi-tenant site binds this class with its tenant
 * column and a closure reading the current tenant at call time.
 */
final class DataThrough
{
    public function __construct(
        private readonly ConnectionInterface $connection,
        private readonly ?string $tenantColumn = null,
        private readonly ?\Closure $tenantId = null,
    ) {}

    /** The reader this site uses: the one it bound, else one over its database connection, else none. */
    public static function current(?Container $container = null): ?self
    {
        $container ??= Container::getInstance();

        if ($container->bound(self::class)) {
            return $container->make(self::class);
        }

        return $container->bound(ConnectionInterface::class) ? new self($container->make(ConnectionInterface::class)) : null;
    }

    /**
     * The newest day in $where (table, column) as Y-m-d, or null.
     *
     * @param  array{0: string, 1: string}|null  $where
     */
    public function date(?array $where): ?string
    {
        if ($where === null) {
            return null;
        }

        [$table, $column] = $where;

        try {
            if (! $this->connection->getSchemaBuilder()->hasTable($table)) {
                return null;
            }

            $query = $this->connection->table($table);

            if ($this->tenantColumn !== null) {
                $query->where($this->tenantColumn, ($this->tenantId)());
            }

            $newest = $query->max($column);
        } catch (\Throwable) {
            return null;
        }

        $day = substr((string) $newest, 0, 10);

        return preg_match('/^\d{4}-\d{2}-\d{2}$/', $day) === 1 ? $day : null;
    }
}
