<?php

namespace SsSystems\Platform\Seo\Status;

use Carbon\CarbonInterface;
use Illuminate\Container\Container;
use Illuminate\Support\Carbon;
use SsSystems\Platform\Seo\Status\Contracts\HeartbeatStore;

/**
 * `GET seo/status` and the `status` block of `GET seo/summary`: the
 * registry read against the heartbeat store. It reads what the collectors
 * left behind and nothing else — no vendor is ever called from here, so
 * the hub can ask every site every half hour.
 *
 * ONE ROW PER SOURCE, even when several jobs feed it. Each job is judged
 * on its own cadence ({@see SourceRegistry}); the row then shows the job
 * that is worst off — the failing one, else the one most overdue, else
 * the one closest to being late — with THAT job's cadence, times, status
 * and error, so the row's own numbers always add up to its `state` by the
 * contract's definitions. `detail.job` names it and `detail.jobs` lists
 * the rest. A helper job (`expected => false`) only ever puts its source
 * in `failing`, and only while that failure is recent.
 */
final class SeoStatus
{
    /**
     * The `data` of GET seo/status.
     *
     * @return array{generated_at: string, scheduler: array{last_beat_at: ?string, state: string}, sources: list<array<string, mixed>>}
     */
    public static function payload(?Container $container = null, ?CarbonInterface $now = null): array
    {
        $container ??= Container::getInstance();
        $now ??= Carbon::now();
        $registry = SourceRegistry::all($container);
        $rows = self::rows(HeartbeatStores::current($container), array_keys($registry));
        $dates = DataThrough::current($container);
        $sources = [];

        foreach ($registry as $key => $definition) {
            $source = self::source($definition, $rows[$key] ?? null, $container, $now);
            $source['data_through'] = $source['applicable'] ? $dates?->date($definition['data_through']) : null;

            // The contract's order: data_through, detail, state.
            $sources[] = array_diff_key($source, ['detail' => true, 'state' => true]) + [
                'detail' => $source['detail'] === [] ? new \stdClass : $source['detail'],
                'state' => $source['state'],
            ];
        }

        $beat = SchedulerBeat::lastBeatAt($rows[SchedulerBeat::KEY] ?? null);

        return [
            'generated_at' => $now->toIso8601String(),
            'scheduler' => ['last_beat_at' => $beat, 'state' => SourceState::scheduler($beat, $now)],
            'sources' => $sources,
        ];
    }

    /**
     * The `status` block of GET seo/summary: the worst state among the
     * sources that count (connected and applicable), how many of them are
     * failing and late, how many count at all, and the scheduler's state.
     * No table but the heartbeat store is read.
     *
     * @return array{worst: string, failing: int, late: int, sources: int, scheduler: string}
     */
    public static function summary(?Container $container = null, ?CarbonInterface $now = null): array
    {
        $container ??= Container::getInstance();
        $now ??= Carbon::now();
        $registry = SourceRegistry::all($container);
        $rows = self::rows(HeartbeatStores::current($container), array_keys($registry));
        $states = [];

        foreach ($registry as $key => $definition) {
            $state = self::source($definition, $rows[$key] ?? null, $container, $now)['state'];

            if (SourceState::counts($state)) {
                $states[] = $state;
            }
        }

        $tally = array_count_values($states);

        return [
            'worst' => SourceState::worst($states),
            'failing' => $tally[SourceState::FAILING] ?? 0,
            'late' => $tally[SourceState::LATE] ?? 0,
            'sources' => count($states),
            'scheduler' => SourceState::scheduler(SchedulerBeat::lastBeatAt($rows[SchedulerBeat::KEY] ?? null), $now),
        ];
    }

    /**
     * One source's row, without `data_through`.
     *
     * @param  array<string, mixed>  $definition  one entry of SourceRegistry::all()
     * @param  array<string, mixed>|null  $row  what the store holds for it
     * @return array<string, mixed>
     */
    public static function source(array $definition, ?array $row, ?Container $container = null, ?CarbonInterface $now = null): array
    {
        $now ??= Carbon::now();
        $connected = SourceConnections::connected($definition, $container);
        $applicable = SourceConnections::applicable($definition, $container);
        $jobs = self::jobs($definition, $row, $now);
        $shown = self::worstOff($jobs, (string) $definition['primary']);
        $heartbeat = $shown['heartbeat'];
        $failed = $heartbeat !== null && $heartbeat['last_status'] !== HeartbeatRecord::OK;
        $error = $failed ? $heartbeat['last_error'] : null;
        $detail = $heartbeat['detail'] ?? [];
        $listed = array_filter($jobs, static fn (array $job): bool => $job['expected'] || $job['heartbeat'] !== null);

        if (count($listed) > 1) {
            $detail['job'] = $shown['key'];
            $detail['jobs'] = array_map(static fn (array $job): array => array_filter([
                'state' => $job['state'],
                'cadence_seconds' => $job['cadence_seconds'],
                'late_after_seconds' => $job['late_after_seconds'],
                'last_attempt_at' => $job['heartbeat']['last_attempt_at'] ?? null,
                'last_success_at' => $job['heartbeat']['last_success_at'] ?? null,
                'last_status' => $job['heartbeat']['last_status'] ?? null,
                'consecutive_failures' => $job['heartbeat']['consecutive_failures'] ?? 0,
                'last_error' => ($job['heartbeat']['last_status'] ?? null) === HeartbeatRecord::OK ? null : ($job['heartbeat']['last_error'] ?? null),
            ], static fn (mixed $value): bool => $value !== null), $listed);
        }

        return [
            'key' => $definition['key'],
            'label' => $definition['label'],
            'detail_label' => $definition['detail_label'],
            'connected' => $connected,
            'applicable' => $applicable,
            'cadence_seconds' => $shown['cadence_seconds'],
            'late_after_seconds' => $shown['late_after_seconds'],
            'last_attempt_at' => $heartbeat['last_attempt_at'] ?? null,
            'last_success_at' => $heartbeat['last_success_at'] ?? null,
            'last_status' => $heartbeat['last_status'] ?? null,
            'consecutive_failures' => $heartbeat['consecutive_failures'] ?? 0,
            'last_error_plain' => PlainError::sentence($error, (string) $definition['vendor']),
            'last_error' => $error,
            'detail' => $detail,
            'state' => match (true) {
                ! $applicable => SourceState::NOT_APPLICABLE,
                ! $connected => SourceState::NOT_CONNECTED,
                default => $shown['state'],
            },
        ];
    }

    /**
     * Every job of a source with its own heartbeat and state: the
     * registry's, then any that reported without being in it (an intel
     * family a site added), which are helpers on their command's cadence.
     *
     * @param  array<string, mixed>  $definition
     * @param  array<string, mixed>|null  $row
     * @return array<string, array{key: string, expected: bool, cadence_seconds: int, late_after_seconds: int, heartbeat: ?array<string, mixed>, state: string, counts: bool, slack: float}>
     */
    private static function jobs(array $definition, ?array $row, CarbonInterface $now): array
    {
        $perJob = is_array($row['jobs'] ?? null) ? $row['jobs'] : null;
        $primary = (string) $definition['primary'];
        $jobs = [];

        foreach ($definition['jobs'] as $name => $job) {
            // A row with no jobs of its own is the main job's: a source
            // with one job, or a Search Console row from before this.
            $heartbeat = $perJob !== null
                ? HeartbeatRecord::of($row, (string) $name)
                : ((string) $name === $primary ? HeartbeatRecord::of($row) : null);

            $jobs[(string) $name] = self::job((string) $name, $job, $heartbeat, $now);
        }

        foreach (array_keys($perJob ?? []) as $name) {
            if (isset($jobs[(string) $name])) {
                continue;
            }

            $like = $definition['jobs'][CommandLine::parse((string) $name)->name] ?? $definition['jobs'][$primary];
            $jobs[(string) $name] = self::job((string) $name, ['expected' => false] + $like, HeartbeatRecord::of($row, (string) $name), $now);
        }

        return $jobs;
    }

    /**
     * @param  array<string, mixed>  $job
     * @param  array<string, mixed>|null  $heartbeat
     * @return array{key: string, expected: bool, cadence_seconds: int, late_after_seconds: int, heartbeat: ?array<string, mixed>, state: string, counts: bool, slack: float}
     */
    private static function job(string $name, array $job, ?array $heartbeat, CarbonInterface $now): array
    {
        $lateAfter = (int) $job['late_after_seconds'];
        $state = SourceState::ofRuns($heartbeat, $lateAfter, $now);
        $sinceAttempt = SourceState::age($heartbeat['last_attempt_at'] ?? null, $now);
        $sinceSuccess = SourceState::age($heartbeat['last_success_at'] ?? null, $now);

        return [
            'key' => $name,
            'expected' => (bool) $job['expected'],
            'cadence_seconds' => (int) $job['cadence_seconds'],
            'late_after_seconds' => $lateAfter,
            'heartbeat' => $heartbeat,
            'state' => $state,
            // A helper only counts while it is failing, and only while that failure is recent.
            'counts' => $job['expected'] || ($state === SourceState::FAILING && $sinceAttempt !== null && $sinceAttempt <= $lateAfter),
            // How much of its late-after a job has used up: the higher, the sooner (or longer ago) it went late.
            'slack' => $sinceSuccess === null ? INF : $sinceSuccess / max(1, $lateAfter),
        ];
    }

    /**
     * The job a source's row shows: the worst state first; among failing
     * jobs the one that failed last; otherwise the one that has used up
     * most of its late-after.
     *
     * @param  array<string, array<string, mixed>>  $jobs
     * @return array<string, mixed>
     */
    private static function worstOff(array $jobs, string $primary): array
    {
        $counted = array_filter($jobs, static fn (array $job): bool => $job['counts']);

        if ($counted === []) {
            return $jobs[$primary] ?? reset($jobs);
        }

        usort($counted, static function (array $a, array $b): int {
            $bySeverity = SourceState::severity($b['state']) <=> SourceState::severity($a['state']);

            if ($bySeverity !== 0) {
                return $bySeverity;
            }

            if ($a['state'] === SourceState::FAILING) {
                return strcmp((string) ($b['heartbeat']['last_attempt_at'] ?? ''), (string) ($a['heartbeat']['last_attempt_at'] ?? ''));
            }

            return $b['slack'] <=> $a['slack'];
        });

        return $counted[0];
    }

    /**
     * What the store holds for these keys and the scheduler's.
     *
     * @param  list<string>  $keys
     * @return array<string, array<string, mixed>>
     */
    private static function rows(?HeartbeatStore $store, array $keys): array
    {
        if ($store === null) {
            return [];
        }

        try {
            if ($store instanceof TableHeartbeatStore) {
                return $store->all();
            }

            $rows = [];

            foreach ([...$keys, SchedulerBeat::KEY] as $key) {
                $row = $store->read($key);

                if ($row !== null) {
                    $rows[$key] = $row;
                }
            }

            return $rows;
        } catch (\Throwable) {
            return [];
        }
    }
}
