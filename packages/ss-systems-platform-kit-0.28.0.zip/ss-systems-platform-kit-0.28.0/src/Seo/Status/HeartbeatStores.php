<?php

namespace SsSystems\Platform\Seo\Status;

use Illuminate\Container\Container;
use Illuminate\Database\ConnectionInterface;
use SsSystems\Platform\Seo\Status\Contracts\HeartbeatStore;

/**
 * Which {@see HeartbeatStore} this site uses — asked by every collector
 * that reports in and by `GET seo/status` when it reads, so the two can
 * never look in different places (the rule Seo\Checks\SiteCheckStores
 * follows for the site checks).
 *
 * In order: the store the site bound; else a {@see TableHeartbeatStore}
 * the site bound with its own table or tenant column; else the default
 * table store over the site's database connection, built once and kept in
 * the container; else nothing — an app with no database, which is only
 * ever the kit's own bare-container unit tests.
 */
final class HeartbeatStores
{
    public static function current(?Container $container = null): ?HeartbeatStore
    {
        $container ??= Container::getInstance();

        if ($container->bound(HeartbeatStore::class)) {
            return $container->make(HeartbeatStore::class);
        }

        if ($container->bound(TableHeartbeatStore::class)) {
            return $container->make(TableHeartbeatStore::class);
        }

        if (! $container->bound(ConnectionInterface::class)) {
            return null;
        }

        $store = new TableHeartbeatStore($container->make(ConnectionInterface::class));
        $container->instance(TableHeartbeatStore::class, $store);

        return $store;
    }
}
