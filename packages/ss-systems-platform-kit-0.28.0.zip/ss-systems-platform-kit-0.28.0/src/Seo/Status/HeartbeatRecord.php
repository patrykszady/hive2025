<?php

namespace SsSystems\Platform\Seo\Status;

/**
 * What one run does to a source's stored summary — the one place the rule
 * lives, pure arrays in and out.
 *
 * Until this existed (2026-11-12) a run REPLACED the row
 * (RecordsSyncRuns::record()), so the last success was gone the moment a
 * run failed and "stale" could only be computed from the last attempt: a
 * sync failing every three hours never read stale. A run is now MERGED:
 *
 *   last_attempt_at       when the newest run finished, whatever its outcome
 *   last_success_at       when the newest successful run finished — kept through failures
 *   last_status           ok | failed | skipped
 *   last_error            the raw reason of a failed or skipped run, at most 500 characters; null after a success
 *   consecutive_failures  failed runs since the last success
 *   detail                the last run's own counts, when it handed any in
 *   jobs                  the same fields per job, for a source fed by more than one (see SourceRegistry)
 *
 * Every other key in the row is left exactly as it was: the Search Console
 * row still carries the sync's own summary (`status`, `finished_at`,
 * `error`, …) that each site's `platforms/status` reads.
 */
final class HeartbeatRecord
{
    public const OK = 'ok';

    public const FAILED = 'failed';

    public const SKIPPED = 'skipped';

    /** The keys a heartbeat owns in a row; everything else is the collector's. */
    public const FIELDS = ['last_attempt_at', 'last_success_at', 'last_status', 'last_error', 'consecutive_failures', 'detail', 'jobs'];

    public const ERROR_LENGTH = 500;

    /**
     * $existing with one finished run folded in — on the row itself and,
     * when the source has several jobs, on that job's own entry.
     *
     * @param  array<string, mixed>|null  $existing
     * @param  array<string, mixed>  $detail
     * @return array<string, mixed>
     */
    public static function apply(?array $existing, string $status, string $at, ?string $error = null, array $detail = [], ?string $job = null): array
    {
        // of() rather than the raw row: a row written before these fields
        // existed still gives up its last success.
        $summary = array_replace(
            array_diff_key($existing ?? [], ['detail' => true]),
            self::fold(self::of($existing) ?? [], $status, $at, $error, $detail),
        );

        if ($job !== null) {
            $jobs = is_array($summary['jobs'] ?? null) ? $summary['jobs'] : [];
            $jobs[$job] = self::fold(self::of($existing, $job) ?? [], $status, $at, $error, $detail);
            $summary['jobs'] = $jobs;
        }

        return $summary;
    }

    /**
     * A collector's own summary written over the row, the heartbeat fields
     * already there carried across — what RecordsSyncRuns::record() does
     * now instead of replacing the row whole.
     *
     * @param  array<string, mixed>|null  $existing
     * @param  array<string, mixed>  $summary
     * @return array<string, mixed>
     */
    public static function carry(?array $existing, array $summary): array
    {
        return $summary + array_intersect_key($existing ?? [], array_flip(self::FIELDS));
    }

    /**
     * The heartbeat of a row, or of one of its jobs: the five fields and
     * `detail`. A Search Console row written before the fields existed is
     * read from the sync's own `status` / `finished_at` / `error`, so the
     * day a site updates it already shows its last run. Null when nothing
     * has run.
     *
     * @param  array<string, mixed>|null  $summary
     * @return array{last_attempt_at: string, last_success_at: ?string, last_status: ?string, last_error: ?string, consecutive_failures: int, detail: array<string, mixed>}|null
     */
    public static function of(?array $summary, ?string $job = null): ?array
    {
        if ($job !== null) {
            $summary = is_array($summary['jobs'][$job] ?? null) ? $summary['jobs'][$job] : null;
        }

        if ($summary === null) {
            return null;
        }

        if (! is_string($summary['last_attempt_at'] ?? null) || $summary['last_attempt_at'] === '') {
            return self::fromOwnSummary($summary);
        }

        return [
            'last_attempt_at' => $summary['last_attempt_at'],
            'last_success_at' => is_string($summary['last_success_at'] ?? null) ? $summary['last_success_at'] : null,
            'last_status' => is_string($summary['last_status'] ?? null) ? $summary['last_status'] : null,
            'last_error' => is_string($summary['last_error'] ?? null) ? $summary['last_error'] : null,
            'consecutive_failures' => (int) ($summary['consecutive_failures'] ?? 0),
            'detail' => is_array($summary['detail'] ?? null) ? $summary['detail'] : [],
        ];
    }

    /**
     * A collector's own status word as a heartbeat status: `ok`; `failed`
     * for error / failed / stopped; `skipped`. Null for anything else — a
     * dry run is not an attempt.
     */
    public static function status(mixed $own): ?string
    {
        return match (is_string($own) ? strtolower($own) : null) {
            'ok', 'success' => self::OK,
            'error', 'failed', 'stopped' => self::FAILED,
            'skipped' => self::SKIPPED,
            default => null,
        };
    }

    /** A raw reason as it is stored: one line, at most ERROR_LENGTH characters, null when empty. */
    public static function error(mixed $raw): ?string
    {
        if (is_array($raw)) {
            $raw = json_encode($raw, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        }

        $raw = is_scalar($raw) ? trim((string) preg_replace('/\s+/u', ' ', (string) $raw)) : '';

        return $raw === '' ? null : mb_substr($raw, 0, self::ERROR_LENGTH);
    }

    /**
     * @param  array<string, mixed>  $current
     * @param  array<string, mixed>  $detail
     * @return array<string, mixed>
     */
    private static function fold(array $current, string $status, string $at, ?string $error, array $detail): array
    {
        // The same run handed in twice (a site's writer and the collector
        // both report it) is one run, not two failures.
        $sameRun = ($current['last_attempt_at'] ?? null) === $at && ($current['last_status'] ?? null) === $status;
        $failures = (int) ($current['consecutive_failures'] ?? 0);

        $next = [
            'last_attempt_at' => $at,
            'last_success_at' => $status === self::OK ? $at : (is_string($current['last_success_at'] ?? null) ? $current['last_success_at'] : null),
            'last_status' => $status,
            'last_error' => $status === self::OK ? null : self::error($error),
            'consecutive_failures' => match ($status) {
                self::OK => 0,
                self::FAILED => $sameRun ? max(1, $failures) : $failures + 1,
                default => $failures,
            },
        ];

        if ($detail === [] && $sameRun && is_array($current['detail'] ?? null)) {
            $detail = $current['detail'];
        }

        if ($detail !== []) {
            $next['detail'] = $detail;
        }

        return $next;
    }

    /**
     * @param  array<string, mixed>  $summary
     * @return array{last_attempt_at: string, last_success_at: ?string, last_status: ?string, last_error: ?string, consecutive_failures: int, detail: array<string, mixed>}|null
     */
    private static function fromOwnSummary(array $summary): ?array
    {
        $status = self::status($summary['status'] ?? null);
        $at = $summary['finished_at'] ?? $summary['started_at'] ?? null;

        if ($status === null || ! is_string($at) || $at === '') {
            return null;
        }

        return [
            'last_attempt_at' => $at,
            'last_success_at' => $status === self::OK ? $at : null,
            'last_status' => $status,
            'last_error' => $status === self::OK ? null : self::error($summary['error'] ?? null),
            'consecutive_failures' => $status === self::FAILED ? 1 : 0,
            'detail' => [],
        ];
    }
}
