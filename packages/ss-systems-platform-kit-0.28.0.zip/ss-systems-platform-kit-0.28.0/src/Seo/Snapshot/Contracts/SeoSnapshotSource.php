<?php

namespace SsSystems\Platform\Seo\Snapshot\Contracts;

use Illuminate\Http\Request;

/**
 * The site's own `GET seo/snapshot` controller, as `seo:snapshot-store`
 * sees it (kit 0.26.0). Each site's snapshot is its own shape, so the kit
 * never builds one itself: the site's controller does, through
 * {@see \SsSystems\Platform\Seo\Http\Concerns\ServesStoredSeoSnapshot},
 * and the site binds it in `AppServiceProvider`:
 *
 * ```php
 * $this->app->bind(SeoSnapshotSource::class, SeoSnapshotController::class);
 * ```
 */
interface SeoSnapshotSource
{
    /**
     * The whole snapshot `data` for this request's query, built from the
     * site's tables now — what GET seo/snapshot answered before it was
     * stored.
     *
     * @return array<string, mixed>
     */
    public function buildSnapshot(Request $request): array;

    /**
     * Forgets the caches the snapshot's blocks keep for themselves (health,
     * search, pulse, the SEO-tool blocks, ...), so a build that must be
     * fresh — the schedule's, the Refresh button's — reads the tables
     * instead of a block cached up to half an hour earlier.
     */
    public function forgetSnapshotCaches(Request $request): void;
}
