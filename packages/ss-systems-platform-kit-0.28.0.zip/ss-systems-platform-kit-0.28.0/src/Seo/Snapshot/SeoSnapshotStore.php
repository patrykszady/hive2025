<?php

namespace SsSystems\Platform\Seo\Snapshot;

use Closure;
use Illuminate\Contracts\Cache\LockProvider;
use Illuminate\Contracts\Cache\LockTimeoutException;
use Illuminate\Contracts\Cache\Repository;
use Illuminate\Support\Carbon;

/**
 * The stored `GET seo/snapshot` (kit 0.26.0, 2026-11-11). Building the
 * snapshot on demand took gs.construction 4.7 s at the median and up to
 * 11 s (dawnsellshomes up to 12.7 s) on every look at the ss.systems SEO
 * screen, so each site now builds it ahead of time — every 15 minutes and
 * right after its Search Console sync (`seo:snapshot-store`, see
 * {@see Console\StoreSeoSnapshotCommand}) — and the endpoint hands out the
 * stored copy with the moment it was built as `computed_at`. Patryk
 * accepted a SEO page up to 15 minutes old: Search Console itself syncs
 * every three hours.
 *
 * Only the query-parameter combinations the hub actually sends are stored
 * ({@see HUB_PARAMS}); any other combination is built on demand exactly
 * as before. Two queries are the same combination when they agree once
 * the snapshot's own defaults ({@see DEFAULT_PARAMS}) are filled in, so
 * `?trend_days=14` and no query at all share one stored copy. A query
 * carrying a key outside the defaults (gs.construction's
 * `top_queries_sort`, say) never matches a stored combination.
 *
 * A stored copy lives {@see TTL_SECONDS}: a site whose scheduler stopped
 * goes back to building on the next request rather than serving an old
 * page for ever. A request that finds nothing stored (the first one after
 * a deploy) builds it once under a lock and stores it; requests arriving
 * meanwhile wait for that build and read it, rather than each building
 * their own. `fresh` (the Refresh button) builds now and stores it.
 *
 * Kept in the site's default cache store under {@see $prefix}; a
 * multi-tenant site binds this class with a tenant-scoped prefix.
 */
final class SeoSnapshotStore
{
    /**
     * What ss.systems asks every site for: its SEO screen as it opens
     * (App\Livewire\Admin\SeoReports::DEFAULT_WINDOWS — the Refresh
     * button's POST seo/snapshot/refresh with that trend window is the same
     * combination once the defaults are filled in) and
     * `seo:record-coverage-totals`, which asks once a day with no query.
     * The platform dashboard's card reads `seo/summary` instead.
     *
     * @var list<array<string, int|string>>
     */
    public const HUB_PARAMS = [
        ['trend_days' => 60, 'top_days' => 28, 'clarity_days' => 7, 'rank_days' => 7],
        [],
    ];

    /**
     * The defaults every site's snapshot applies to a missing parameter.
     *
     * @var array<string, int|string>
     */
    public const DEFAULT_PARAMS = [
        'trend_days' => 14,
        'top_days' => 28,
        'clarity_days' => 7,
        'rank_days' => 7,
        'prior_days' => 7,
        'appearance_days' => 28,
    ];

    /** A stored copy older than this is not served; the schedule rewrites it every 15 minutes. */
    public const TTL_SECONDS = 3600;

    /** How long one build may hold the lock before another may take it. */
    public const LOCK_SECONDS = 180;

    /** How long a request waits for a build already running before building its own. */
    public const LOCK_WAIT_SECONDS = 60;

    /**
     * @param  list<array<string, int|string>>  $precomputed
     * @param  array<string, int|string>  $defaults
     */
    public function __construct(
        private readonly Repository $cache,
        private readonly string $prefix = 'admin.seo-snapshot',
        private readonly array $precomputed = self::HUB_PARAMS,
        private readonly array $defaults = self::DEFAULT_PARAMS,
    ) {}

    /**
     * The combinations seo:snapshot-store builds.
     *
     * @return list<array<string, int|string>>
     */
    public function precomputed(): array
    {
        return $this->precomputed;
    }

    /**
     * A query as the combination it stands for: the defaults filled in,
     * every value as text, keys sorted.
     *
     * @param  array<string, mixed>  $query
     * @return array<string, string>
     */
    public function normalize(array $query): array
    {
        $params = array_map(
            static fn (mixed $value): string => is_scalar($value) || $value === null ? (string) $value : (string) json_encode($value),
            array_replace($this->defaults, $query),
        );
        ksort($params);

        return $params;
    }

    /** @param  array<string, mixed>  $query */
    public function isPrecomputed(array $query): bool
    {
        $params = $this->normalize($query);

        foreach ($this->precomputed as $combination) {
            if ($this->normalize($combination) === $params) {
                return true;
            }
        }

        return false;
    }

    /** @param  array<string, mixed>  $query */
    public function key(array $query): string
    {
        return $this->prefix.':'.http_build_query($this->normalize($query));
    }

    /**
     * The stored copy for this combination, or null when none is.
     *
     * @param  array<string, mixed>  $query
     * @return array<string, mixed>|null
     */
    public function get(array $query): ?array
    {
        $stored = $this->cache->get($this->key($query));

        return is_array($stored) ? $stored : null;
    }

    /**
     * Stores a freshly built snapshot, stamped with `computed_at`. Stored as
     * the plain arrays its JSON reads back to — exactly what the endpoint
     * answered when it built on demand — so no object ever goes into the
     * cache: a site whose cache refuses to unserialize classes
     * (`cache.serializable_classes => false`, ss.systems, J. Peterson,
     * dawnsellshomes) would read one back broken.
     *
     * @param  array<string, mixed>  $query
     * @param  array<string, mixed>  $data
     * @return array<string, mixed> the data as stored
     */
    public function put(array $query, array $data): array
    {
        $data = json_decode((string) json_encode(self::stamp($data), JSON_THROW_ON_ERROR), true, flags: JSON_THROW_ON_ERROR);
        $this->cache->put($this->key($query), $data, self::TTL_SECONDS);

        return $data;
    }

    /**
     * The most recently built of the stored combinations — where
     * `seo/summary` reads the health score from instead of computing it.
     *
     * @return array<string, mixed>|null
     */
    public function newest(): ?array
    {
        $newest = null;

        foreach ($this->precomputed as $combination) {
            $stored = $this->get($combination);

            if ($stored !== null && ($newest === null || strcmp((string) ($stored['computed_at'] ?? ''), (string) ($newest['computed_at'] ?? '')) > 0)) {
                $newest = $stored;
            }
        }

        return $newest;
    }

    /**
     * What GET seo/snapshot answers: on demand for a combination that is
     * not stored; built now and stored when $fresh; otherwise the stored
     * copy, built once under the lock when there is none yet.
     *
     * @param  array<string, mixed>  $query
     * @param  Closure(): array<string, mixed>  $build
     * @return array<string, mixed>
     */
    public function serve(array $query, bool $fresh, Closure $build): array
    {
        if (! $this->isPrecomputed($query)) {
            return self::stamp($build());
        }

        if ($fresh) {
            return $this->rebuild($query, $build);
        }

        return $this->get($query)
            ?? $this->locked($query, fn (): array => $this->get($query) ?? $this->put($query, $build()));
    }

    /**
     * Builds the combination now and stores it, under the same lock a
     * request finding nothing stored waits on.
     *
     * @param  array<string, mixed>  $query
     * @param  Closure(): array<string, mixed>  $build
     * @return array<string, mixed>
     */
    public function rebuild(array $query, Closure $build): array
    {
        return $this->locked($query, fn (): array => $this->put($query, $build()));
    }

    /**
     * @param  array<string, mixed>  $data
     * @return array<string, mixed>
     */
    public static function stamp(array $data): array
    {
        $data['computed_at'] = Carbon::now()->toIso8601String();

        return $data;
    }

    /**
     * Runs $callback holding this combination's lock. A store that cannot
     * lock runs it straight away; a wait that runs out builds anyway, so a
     * stuck lock never leaves the screen without its snapshot.
     *
     * @param  array<string, mixed>  $query
     * @param  Closure(): array<string, mixed>  $callback
     * @return array<string, mixed>
     */
    private function locked(array $query, Closure $callback): array
    {
        $store = $this->cache->getStore();

        if (! $store instanceof LockProvider) {
            return $callback();
        }

        try {
            return $store->lock($this->key($query).':lock', self::LOCK_SECONDS)->block(self::LOCK_WAIT_SECONDS, $callback);
        } catch (LockTimeoutException) {
            return $callback();
        }
    }
}
