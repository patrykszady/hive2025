<?php

namespace SsSystems\Platform\Seo\Snapshot\Console;

use Closure;
use Illuminate\Console\Command;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Facade;
use SsSystems\Platform\Seo\Checks\SiteCheckBlock;
use SsSystems\Platform\Seo\Snapshot\Contracts\SeoSnapshotSource;
use SsSystems\Platform\Seo\Snapshot\SeoSnapshotStore;
use Throwable;

/**
 * `seo:snapshot-store` (kit 0.26.0, 2026-11-11) — builds the SEO snapshot
 * for every combination ss.systems asks for and stores it, so GET
 * seo/snapshot answers from the stored copy instead of building it while
 * the hub waits (see {@see SeoSnapshotStore}). Each site schedules it
 * every 15 minutes and runs it right after its Search Console sync, and
 * binds {@see SeoSnapshotSource} to its snapshot controller.
 *
 * A plain run (the 15-minute schedule) builds from the blocks' own caches
 * (health, search, pulse, the SEO-tool blocks) as they stand: a block whose
 * cache has run out is computed here instead of while the hub waits, and
 * nothing else is recomputed — forgetting them every 15 minutes would ask
 * Google for the sitemap list ~96 times a day and record a health score
 * every quarter hour. `--fresh` (the end of a Search Console sync, where
 * the tables just changed) forgets them once for every combination before
 * any is built, so the stored copy is as fresh as the tables and the second
 * combination reuses what the first one just computed. Each combination is
 * built under the same lock a request finding nothing stored waits on.
 *
 * Each stored copy carries the kit's `site_checks` block
 * ({@see SiteCheckBlock}), exactly as a copy built by a request does.
 *
 * Exit codes: SUCCESS when every combination was stored, FAILURE when any
 * build threw (the others are still stored).
 */
final class StoreSeoSnapshotCommand extends Command
{
    protected $signature = 'seo:snapshot-store
        {--fresh : Forget the blocks\' own caches first (after a Search Console sync)}';

    protected $description = 'Build the SEO snapshot ss.systems asks for and store it, so seo/snapshot answers at once';

    public function handle(SeoSnapshotSource $source, SeoSnapshotStore $store): int
    {
        $combinations = $store->precomputed();

        if ($this->option('fresh')) {
            foreach ($combinations as $params) {
                $this->asRequest($params, static function (Request $request) use ($source): void {
                    $source->forgetSnapshotCaches($request);
                });
            }
        }

        $failed = false;

        foreach ($combinations as $params) {
            $label = $params === [] ? 'no query' : http_build_query($params);
            $started = microtime(true);

            try {
                $store->rebuild($params, fn (): array => $this->asRequest(
                    $params,
                    static fn (Request $request): array => SiteCheckBlock::attach($source->buildSnapshot($request)),
                ));

                $this->line(sprintf('Stored the SEO snapshot for %s in %d ms.', $label, (int) round((microtime(true) - $started) * 1000)));
            } catch (Throwable $e) {
                $failed = true;
                $this->error(sprintf('Could not build the SEO snapshot for %s: %s', $label, $e->getMessage()));
            }
        }

        return $failed ? self::FAILURE : self::SUCCESS;
    }

    /**
     * Runs $callback with a GET request carrying $params as the
     * container's current request — the snapshot reads its windows from
     * the request it is handed and, in places, from `request()` — and puts
     * the previous request back afterwards. The new request copies the
     * current one (the console's, rooted on APP_URL), so links the
     * snapshot builds keep the site's own host; a JSON body the current
     * request may carry (this command run from inside an admin request)
     * is dropped. Values go in as text, as they arrive over HTTP.
     *
     * @template T
     *
     * @param  array<string, int|string>  $params
     * @param  Closure(Request): T  $callback
     * @return T
     */
    private function asRequest(array $params, Closure $callback): mixed
    {
        $container = $this->laravel;
        $previous = $container->bound('request') ? $container->make('request') : null;
        $params = array_map('strval', $params);

        $request = $previous instanceof Request
            ? $previous->duplicate($params, [])
            : Request::create('/', 'GET', $params);
        $request->setMethod('GET');
        $request->headers->remove('CONTENT_TYPE');
        $request->server->remove('CONTENT_TYPE');

        $container->instance('request', $request);
        Facade::clearResolvedInstance('request');

        try {
            return $callback($request);
        } finally {
            if ($previous !== null) {
                $container->instance('request', $previous);
            } else {
                $container->forgetInstance('request');
            }

            Facade::clearResolvedInstance('request');
        }
    }
}
