<?php

namespace SsSystems\Platform\Seo\Rankings\Console;

use Illuminate\Console\Command;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Carbon;
use Illuminate\Support\Str;
use SsSystems\Platform\Seo\Concerns\ExplainsFailure;
use SsSystems\Platform\Seo\Contracts\SeoSiteProfile;
use SsSystems\Platform\Seo\DataForSeo\Contracts\DataForSeoApi;
use SsSystems\Platform\Seo\Rankings\RankSnapshotStore;
use SsSystems\Platform\Seo\Rankings\TrackedQueries;

/**
 * `seo:track-rankings` — ported from gs.construction's own
 * App\Console\Commands\TrackRankings. Two independent passes, both into
 * seo_rank_snapshots:
 *
 *  1. 'gsc' engine: the impression-weighted position TrackedQueries::
 *     weightedPosition() derives from synced Search Console data — free, no
 *     scraping, no paid SERP API. A query with zero recent impressions
 *     records a null position (we're not surfacing for it).
 *  2. 'google' engine: a real SERP check via DataForSeoApi, when
 *     isConfigured() — the DataForSEO standard queue by default (~10x
 *     cheaper than the Live endpoint), with an automatic Live fallback when
 *     the queue itself fails to post. `--budget` (default $1.00/run) caps
 *     this pass; an unknown account balance means refusing to spend at all
 *     rather than assuming there's room.
 *
 * Every tracked query's position — whichever pass is being run resolves it
 * — is who on the SERP matches the site's own SeoSiteProfile::
 * brandPatterns(), not a plain domain-contains check: a listing can carry
 * the brand name under a different host (a directory profile, a mapped
 * subdomain) a bare domain match would miss.
 *
 * The standard queue sometimes answers after a run's own wait window has
 * elapsed; every run first collects what an earlier one left behind
 * (collectLateResults(), tagged by the keyword each task was posted with —
 * see DataForSeoApi::googleOrganicReadyTasks()'s `tag`) before the GSC
 * snapshot below, which a `--collect`-only run must not repeat.
 *
 * Queued is not failed (2026-11). A standard-queue task that has not
 * finished when the wait runs out is asked about once more by its id, and
 * what is still queued then is recorded as PENDING — a row carrying its
 * task id, `meta.pending` and `meta.fetch_failed` (so collectLateResults()
 * finds it and RankingsSnapshot keeps it out of the buckets) — not as a
 * failure. A run whose tasks were merely slow used to end "Every DataForSEO
 * SERP check failed this run", exit 1, and be filled in by the next
 * `--collect`. The run now exits 1 only when every check that got an
 * answer failed, and its last line says why ({@see ExplainsFailure}).
 *
 * One deliberate behaviour change from gs.construction's original:
 * `--dry-run` here also skips the paid DataForSEO pass entirely (gsc's
 * version let it spend real money during a dry run, gating only
 * persistence) — spending while "computing but not persisting" contradicts
 * what a dry run is for.
 */
class TrackRankingsCommand extends Command
{
    use ExplainsFailure;

    private const STANDARD_PRICE_PER_QUERY = 0.0006;

    private const QUEUED_NOTE = 'queued at DataForSEO — not ready inside this run';

    private const DEFAULT_BUDGET = 1.0;

    private const STANDARD_WAIT_SECONDS = 600;

    private const TOP_RESULTS_LIMIT = 10;

    private const GSC_WINDOW_DAYS = 7;

    private const LATE_COLLECT_WINDOW_DAYS = 30;

    /** @var string */
    protected $signature = 'seo:track-rankings
        {--query= : Run only queries containing this substring}
        {--dry-run : Compute but do not persist (and skip the paid DataForSEO pass)}
        {--budget= : Max USD for the DataForSEO SERP pass this run (default $1.00)}
        {--collect : Only collect standard-queue results that finished after an earlier run stopped waiting, then exit}';

    /** @var string */
    protected $description = 'Snapshot Google rankings for tracked queries from synced Search Console data, then real SERP checks via DataForSEO.';

    public function handle(): int
    {
        /** @var ConnectionInterface $connection */
        $connection = $this->laravel->make(ConnectionInterface::class);
        /** @var RankSnapshotStore $store */
        $store = $this->laravel->make(RankSnapshotStore::class);
        /** @var DataForSeoApi $api */
        $api = $this->laravel->make(DataForSeoApi::class);
        /** @var SeoSiteProfile $profile */
        $profile = $this->laravel->make(SeoSiteProfile::class);
        /** @var TrackedQueries $trackedQueries */
        $trackedQueries = $this->laravel->make(TrackedQueries::class);

        if (! $this->gscQueryMetricsExists($connection)) {
            return $this->failBecause(self::REASON_NOT_CONFIGURED, 'gsc_query_metrics table missing — run the Search Console sync first.');
        }

        $filter = (string) ($this->option('query') ?? '');
        $dryRun = (bool) $this->option('dry-run');

        if (! $dryRun && $api->isConfigured()) {
            $this->collectLateResults($store, $api, $profile);
        }
        if ($this->option('collect')) {
            return self::SUCCESS;
        }

        $queries = $trackedQueries->resolve($profile);
        if ($filter !== '') {
            $queries = array_values(array_filter($queries, fn (array $cfg) => stripos((string) $cfg['q'], $filter) !== false));
        }

        $found = $missed = 0;

        foreach ($queries as $cfg) {
            $query = (string) $cfg['q'];
            $gsc = $trackedQueries->weightedPosition($query, self::GSC_WINDOW_DAYS);
            $pos = $gsc['position'];

            if (! $dryRun) {
                $store->record([
                    'engine' => 'gsc',
                    'query' => $query,
                    'location' => null,
                    'city_slug' => (string) ($cfg['city_slug'] ?? '') ?: null,
                    'gsc_position' => $pos,
                    'gsc_match_title' => null,
                    'result_count' => null,
                    'top_results' => [],
                    'meta' => [
                        'source' => 'gsc_query_metrics',
                        'window_days' => self::GSC_WINDOW_DAYS,
                        'impressions' => $gsc['impressions'],
                        'clicks' => $gsc['clicks'],
                    ],
                    'fetched_at' => Carbon::now(),
                ]);
            }

            $pos !== null ? $found++ : $missed++;
            $this->line(sprintf(
                '  [gsc] %-50s %s  impr=%d',
                Str::limit($query, 50, ''),
                $pos === null ? '—' : "#{$pos}",
                $gsc['impressions'],
            ));
        }

        $this->newLine();
        $this->info("Done. found={$found}  no-data={$missed}".($dryRun ? '  (dry-run)' : ''));

        if (! $api->isConfigured()) {
            $this->comment('DataForSEO not configured — real SERP pass skipped.');

            return self::SUCCESS;
        }

        if ($queries === []) {
            $this->comment('No tracked queries match --query — DataForSEO pass skipped.');

            return self::SUCCESS;
        }

        return $this->runSerpPass($queries, $dryRun, $store, $api, $profile);
    }

    /**
     * @param  list<array{q: string, location?: string, city_slug?: string}>  $queries
     */
    private function runSerpPass(array $queries, bool $dryRun, RankSnapshotStore $store, DataForSeoApi $api, SeoSiteProfile $profile): int
    {
        $this->newLine();
        $this->info('DataForSEO SERP checks (engine=google):');

        // Task ids come back one per posted task, in order, and are paired
        // with the queries by position below — so the positions must be 0..n-1.
        $queries = array_values($queries);
        $estimate = round(count($queries) * self::STANDARD_PRICE_PER_QUERY, 4);
        $budgetOption = $this->option('budget');
        $budget = $budgetOption !== null ? (float) $budgetOption : self::DEFAULT_BUDGET;
        $balance = $api->balance();

        $this->line(sprintf(
            '%d queries via standard — estimated $%.4f · balance %s · budget $%.2f',
            count($queries),
            $estimate,
            $balance === null ? '?' : '$'.number_format($balance, 2),
            $budget,
        ));

        if ($dryRun) {
            $this->comment('Dry run — DataForSEO pass skipped (nothing would be spent or persisted).');

            return self::SUCCESS;
        }

        if ($balance === null) {
            return $this->failBecause(self::reasonForError($api->getLastError(), self::REASON_VENDOR_ERROR), sprintf(
                'DataForSEO balance check failed (%s) — refusing to spend without a known balance.',
                $api->getLastError() ?? 'no answer',
            ));
        }
        if ($estimate > $budget) {
            return $this->failBecause(self::REASON_OVER_BUDGET, sprintf('the estimated $%.4f exceeds --budget $%.2f — DataForSEO pass skipped.', $estimate, $budget));
        }
        if ($balance < $estimate) {
            return $this->failBecause(self::REASON_BALANCE_TOO_LOW, sprintf('the DataForSEO balance $%.2f cannot cover the estimated $%.4f — DataForSEO pass skipped.', $balance, $estimate));
        }

        $brandPatterns = $profile->brandPatterns();
        $observations = [];
        $usedStandard = false;
        $taskIds = [];
        $queued = [];
        $errors = [];

        $tasks = array_map(fn (array $cfg) => [
            'keyword' => (string) $cfg['q'],
            'location_name' => (string) ($cfg['location'] ?? $profile->locationName()),
            'depth' => 100,
            'tag' => mb_strtolower((string) $cfg['q']),
        ], $queries);

        $batch = $api->googleOrganicStandardBatch($tasks, self::STANDARD_WAIT_SECONDS);

        if ($batch !== null) {
            $usedStandard = true;
            $taskIds = $api->lastStandardTaskIds();
            foreach ($queries as $i => $cfg) {
                $id = $taskIds[$i] ?? null;
                $result = $id !== null ? ($batch[$id] ?? null) : null;

                // Not answered inside the wait: ask about this one task by
                // its id before calling it anything. Ready now is a result;
                // still queued is pending; only an error is a failure.
                if (! is_array($result) && $id !== null) {
                    $answer = $api->googleOrganicTaskResult($id);
                    $status = $answer['status'] ?? null;

                    if ($status === 'ready' && is_array($answer['result'] ?? null)) {
                        $result = $answer['result'];
                    } elseif ($status === 'pending') {
                        $queued[$i] = true;
                    } else {
                        $errors[$i] = $api->getLastError() ?? 'the task came back with no result';
                    }
                } elseif (! is_array($result)) {
                    $errors[$i] = 'DataForSEO did not accept the task';
                }

                $observations[$i] = is_array($result) ? $this->parseResult($result, $brandPatterns) : null;
            }
        } else {
            $this->warn('Standard queue failed to post — falling back to Live for this run: '.($api->getLastError() ?? 'unknown error'));
        }

        if (! $usedStandard) {
            foreach ($queries as $i => $cfg) {
                if ($api->spent() >= $budget) {
                    $this->warn('Budget reached mid-run — remaining queries skipped.');
                    break;
                }

                $obs = $api->googleOrganicPosition((string) $cfg['q'], $profile->domain(), (string) ($cfg['location'] ?? $profile->locationName()));
                $error = $api->getLastError();
                $observations[$i] = $error === null ? $this->matchLiveResult($obs, $brandPatterns) : null;
                if ($error !== null) {
                    $errors[$i] = $error;
                }
                usleep(400_000); // stay polite on the live endpoint
            }
        }

        return $this->persistSerpObservations($queries, $observations, $dryRun, $store, $usedStandard, $taskIds, $queued, $errors);
    }

    /**
     * @param  list<array{q: string, location?: string, city_slug?: string}>  $queries
     * @param  array<int, array{position: ?int, url: ?string, local_pack: bool, top_domains: list<string>}|null>  $observations
     * @param  list<string>  $taskIds
     * @param  array<int, true>  $queued  query index => its standard-queue task is still queued (pending, not failed)
     * @param  array<int, string>  $errors  query index => why its check failed
     */
    private function persistSerpObservations(array $queries, array $observations, bool $dryRun, RankSnapshotStore $store, bool $usedStandard, array $taskIds, array $queued, array $errors): int
    {
        $sourceLabel = $usedStandard ? 'dataforseo_standard_advanced' : 'dataforseo_live_advanced';
        $rf = $rm = $failed = $pending = $attempted = 0;
        $lastError = null;

        foreach ($queries as $i => $cfg) {
            if (! array_key_exists($i, $observations)) {
                continue; // budget cutoff stopped the live loop before this one ran
            }

            $attempted++;
            $query = (string) $cfg['q'];
            $obs = $observations[$i];

            if ($obs === null) {
                $isQueued = isset($queued[$i]);
                $error = $isQueued ? self::QUEUED_NOTE : ($errors[$i] ?? 'failed');

                if ($isQueued) {
                    $pending++;
                    $this->line(sprintf('  [google] %-48s queued — a later run collects it', Str::limit($query, 48, '')));
                } else {
                    $failed++;
                    $lastError = $error;
                    $this->warn("  [google] {$query}: {$error}");
                }

                if (! $dryRun) {
                    $store->record([
                        'engine' => 'google',
                        'query' => $query,
                        'location' => (string) ($cfg['location'] ?? '') ?: null,
                        'city_slug' => (string) ($cfg['city_slug'] ?? '') ?: null,
                        'gsc_position' => null,
                        'gsc_match_title' => null,
                        'result_count' => null,
                        'top_results' => [],
                        'meta' => ['source' => $sourceLabel, 'fetch_failed' => true, 'error' => $error]
                            + ($isQueued ? ['pending' => true] : [])
                            + (isset($taskIds[$i]) ? ['dataforseo_task_id' => $taskIds[$i]] : []),
                        'fetched_at' => Carbon::now(),
                    ]);
                }

                continue;
            }

            if (! $dryRun) {
                $store->record([
                    'engine' => 'google',
                    'query' => $query,
                    'location' => (string) ($cfg['location'] ?? '') ?: null,
                    'city_slug' => (string) ($cfg['city_slug'] ?? '') ?: null,
                    'gsc_position' => $obs['position'],
                    'gsc_match_title' => null,
                    'result_count' => null,
                    'top_results' => array_slice($obs['top_domains'], 0, self::TOP_RESULTS_LIMIT),
                    'meta' => [
                        'source' => $sourceLabel,
                        'matched_url' => $obs['url'],
                        'local_pack_present' => $obs['local_pack'],
                    ],
                    'fetched_at' => Carbon::now(),
                ]);
            }

            $obs['position'] !== null ? $rf++ : $rm++;
            $this->line(sprintf(
                '  [google] %-48s %s%s',
                Str::limit($query, 48, ''),
                $obs['position'] === null ? 'not in top 100' : '#'.$obs['position'],
                $obs['local_pack'] ? '  (local pack on SERP)' : '',
            ));
        }

        $this->info("Real SERP done. ranked={$rf}  not-in-top-100={$rm}  pending={$pending}  failed={$failed}".($dryRun ? '  (dry-run)' : ''));

        if ($pending > 0) {
            $this->comment("{$pending} checks are still queued at DataForSEO — not failed; the next run or `seo:track-rankings --collect` fills them in.");
        }

        // Pending checks have no answer yet, so they decide nothing: the run
        // failed only when every check that DID get an answer failed.
        $answered = $attempted - $pending;
        if ($answered > 0 && $failed === $answered) {
            return $this->failBecause(self::reasonForError($lastError, self::REASON_NOTHING_SUCCEEDED), sprintf(
                'every DataForSEO SERP check that got an answer failed (%d of %d%s; last error: %s)',
                $failed,
                $answered,
                $pending > 0 ? ", {$pending} more still queued" : '',
                $lastError ?? 'unknown',
            ));
        }

        return self::SUCCESS;
    }

    /**
     * Fill in "failed" standard-queue rows whose task finished after an
     * earlier run stopped waiting for it. Every row this command writes for
     * a failed standard-queue check carries its own `dataforseo_task_id`
     * (tagged at task_post time, see runSerpPass()); rows without one never
     * had a task to ask about and are left alone.
     */
    private function collectLateResults(RankSnapshotStore $store, DataForSeoApi $api, SeoSiteProfile $profile): void
    {
        $open = $store->openFailedRows(self::LATE_COLLECT_WINDOW_DAYS);
        if ($open === []) {
            return;
        }

        $filled = $pending = $gone = 0;

        foreach ($open as $row) {
            $taskId = $row['meta']['dataforseo_task_id'] ?? null;
            if ($taskId === null) {
                continue;
            }

            $answer = $api->googleOrganicTaskResult((string) $taskId);
            $status = $answer['status'] ?? null;

            if ($status === 'ready' && is_array($answer['result'] ?? null)) {
                $this->fillLateRow($store, $row, (array) $answer['result'], $profile);
                $filled++;
            } elseif ($status === 'pending') {
                $pending++;
            } else {
                $meta = $row['meta'];
                unset($meta['dataforseo_task_id'], $meta['pending']);
                $meta['error'] = $api->getLastError() ?? 'collect failed';
                $store->update((int) $row['id'], ['meta' => $meta]);
                $gone++;
            }
        }

        $this->info("Late standard-queue results: filled={$filled}  still pending={$pending}  given up={$gone}");
    }

    /**
     * @param  array<string, mixed>  $row
     * @param  array<string, mixed>  $result
     */
    private function fillLateRow(RankSnapshotStore $store, array $row, array $result, SeoSiteProfile $profile): void
    {
        $obs = $this->parseResult($result, $profile->brandPatterns());
        $meta = $row['meta'];
        unset($meta['fetch_failed'], $meta['error'], $meta['pending']);
        $meta['matched_url'] = $obs['url'];
        $meta['local_pack_present'] = $obs['local_pack'];
        $meta['collected_late'] = ['at' => Carbon::now()->toIso8601String()];

        $store->update((int) $row['id'], [
            'gsc_position' => $obs['position'],
            'top_results' => array_slice($obs['top_domains'], 0, self::TOP_RESULTS_LIMIT),
            'meta' => $meta,
        ]);

        $this->line(sprintf(
            '  [google] %-48s %s  (collected late)',
            Str::limit((string) $row['query'], 48, ''),
            $obs['position'] === null ? 'not in top 100' : '#'.$obs['position'],
        ));
    }

    /**
     * Parse one Google Organic result envelope's `items` (the standard
     * queue's task_get/advanced result) into position/url/local-pack/top-
     * domains — identity is decided by brandPatterns() against every
     * organic item's domain and title, not a plain domain match.
     *
     * @param  array<string, mixed>  $result
     * @param  list<string>  $brandPatterns
     * @return array{position: ?int, url: ?string, local_pack: bool, top_domains: list<string>}
     */
    private function parseResult(array $result, array $brandPatterns): array
    {
        $items = [];
        $localPack = false;

        foreach ((array) ($result['items'] ?? []) as $item) {
            $type = (string) ($item['type'] ?? '');
            if ($type === 'local_pack' || $type === 'map') {
                $localPack = true;
            }
            if ($type !== 'organic') {
                continue;
            }
            $items[] = [
                'position' => (int) ($item['rank_absolute'] ?? 0),
                'domain' => (string) ($item['domain'] ?? ''),
                'title' => (string) ($item['title'] ?? ''),
                'url' => (string) ($item['url'] ?? ''),
            ];
        }

        $match = $this->matchBrand($items, $brandPatterns);

        return [
            'position' => $match['position'],
            'url' => $match['url'],
            'local_pack' => $localPack,
            'top_domains' => array_values(array_column($items, 'domain')),
        ];
    }

    /**
     * Same identity rule as parseResult(), applied to the already-parsed
     * `results` list DataForSeoApi::googleOrganicPosition() returns for the
     * Live endpoint — its own built-in `position`/`matched` (a plain
     * $targetDomain match) are deliberately not trusted here.
     *
     * @param  array{position: ?int, matched: ?string, results: list<array{position: int, url: string, domain: string, title: string}>, local_pack: bool, result_count: ?int}  $obs
     * @param  list<string>  $brandPatterns
     * @return array{position: ?int, url: ?string, local_pack: bool, top_domains: list<string>}
     */
    private function matchLiveResult(array $obs, array $brandPatterns): array
    {
        $match = $this->matchBrand($obs['results'], $brandPatterns);

        return [
            'position' => $match['position'],
            'url' => $match['url'],
            'local_pack' => (bool) $obs['local_pack'],
            'top_domains' => array_values(array_column($obs['results'], 'domain')),
        ];
    }

    /**
     * @param  list<array{position: int, domain: string, title: string, url: string}>  $items
     * @param  list<string>  $brandPatterns
     * @return array{position: ?int, url: ?string}
     */
    private function matchBrand(array $items, array $brandPatterns): array
    {
        foreach ($items as $item) {
            foreach ($brandPatterns as $pattern) {
                if (@preg_match('/'.$pattern.'/i', $item['domain'].' '.$item['title']) === 1) {
                    return ['position' => $item['position'], 'url' => $item['url']];
                }
            }
        }

        return ['position' => null, 'url' => null];
    }

    private function gscQueryMetricsExists(ConnectionInterface $connection): bool
    {
        try {
            return $connection->getSchemaBuilder()->hasTable('gsc_query_metrics');
        } catch (\Throwable) {
            return false;
        }
    }
}
