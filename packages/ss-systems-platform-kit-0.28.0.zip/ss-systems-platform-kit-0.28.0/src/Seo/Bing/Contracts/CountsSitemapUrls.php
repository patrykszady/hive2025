<?php

namespace SsSystems\Platform\Seo\Bing\Contracts;

/**
 * A {@see BingCoverageWriter} that can also say how many of its stored URLs
 * are marked as in the sitemap — the one figure
 * {@see \SsSystems\Platform\Seo\Bing\SitemapShrinkGuard} needs to tell a
 * sitemap that really lost pages from a sitemap source that came back
 * broken.
 *
 * Optional, and a separate interface, because every site carries its own
 * writer: a new method on BingCoverageWriter itself would break each of
 * them on the day the kit is updated. A writer without it is still guarded
 * against an empty list; it only cannot be guarded against a sharp shrink.
 * Implementing it is one line over the site's own model —
 * `BingUrlInfo::where('in_sitemap', true)->count()`.
 */
interface CountsSitemapUrls
{
    /** Stored URLs currently marked in_sitemap, tenant-scoped like every other read. */
    public function sitemapUrlCount(): int;
}
