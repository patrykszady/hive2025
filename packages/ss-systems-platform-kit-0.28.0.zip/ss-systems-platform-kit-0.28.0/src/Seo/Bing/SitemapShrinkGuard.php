<?php

namespace SsSystems\Platform\Seo\Bing;

/**
 * Why BingCoverageSync must not mark the stored URLs against this sitemap
 * list, or null when it may — the Bing coverage's twin of
 * {@see \SsSystems\Platform\Seo\Faq\Bank\FaqBankBuilder::forgetRefusal()}.
 *
 * The sync marks every stored URL the site no longer lists as out of the
 * sitemap. Handed an empty list — a sitemap source that reads empty in a
 * bare console, a sitemap that failed to build — it marked every one of
 * them and the run still ended 'ok' (2026-11): the hub's Bing card then
 * showed a site with no pages in its sitemap. Nothing is deleted, so the
 * damage undoes itself on the next good run, but a day's card is wrong and
 * nobody is told.
 *
 * Refused, and nothing marked:
 *
 *   - an empty list, unless the writer can say it holds no URL at all;
 *   - a list under {@see MIN_SHARE} of the stored in-sitemap URLs, once
 *     there are {@see MIN_STORED} of them — more than half of the site
 *     leaving its sitemap in one run is a broken source far more often
 *     than a smaller site. This half needs the stored count, which only a
 *     writer implementing {@see Contracts\CountsSitemapUrls} can give.
 *
 * A site that really shrank passes `accept_shrink` once
 * (`seo:bing-coverage --accept-shrink`).
 */
final class SitemapShrinkGuard
{
    /** Fewer stored URLs than this is too few to judge a shrink by; only an empty list is refused. */
    public const MIN_STORED = 10;

    /** A list under this share of the stored in-sitemap URLs is taken for a broken source. */
    public const MIN_SHARE = 0.5;

    /**
     * @param  int  $listed  URLs in the list the site handed over
     * @param  ?int  $stored  stored URLs marked as in the sitemap (the listed ones among them); null when the writer cannot count
     */
    public static function refusal(int $listed, ?int $stored): ?string
    {
        if ($stored === 0) {
            return null;
        }

        if ($listed <= 0) {
            return 'The site listed no sitemap URLs, so no stored URL was marked as out of the sitemap'
                .($stored !== null ? sprintf(' (%d stay marked as in it)', $stored) : '')
                .'. An empty list means the sitemap source is broken, not that the site has no pages.';
        }

        if ($stored !== null && $stored >= self::MIN_STORED && $listed < $stored * self::MIN_SHARE) {
            return sprintf(
                'The site listed %d sitemap URLs and %d are stored as in the sitemap — fewer than half, so nothing was marked and no page was asked about. If the sitemap really shrank, run seo:bing-coverage --accept-shrink once.',
                $listed,
                $stored,
            );
        }

        return null;
    }
}
