<?php

namespace SsSystems\Platform\Seo\Faq\Bank\Generators;

use SsSystems\Platform\Seo\Faq\Bank\Contracts\ReportsProviders;
use SsSystems\Platform\Seo\Faq\Bank\Contracts\TextGenerator;

/**
 * The generators a site holds keys for, tried in order — so one binding in
 * `AppServiceProvider` covers "Gemini if we have a key, else OpenAI, else
 * Anthropic", and a provider outage falls through to the next key instead
 * of failing the night's run (2026-11-10).
 *
 * Configured when any of them is. A generate() asks each configured one in
 * turn and returns the first text; when every one fails, lastError() joins
 * their reasons so the page's `last_error` says what each provider said.
 * label() names the generator that answered last, or, before any answer,
 * the first configured one — the summary line's "via {provider}" is read
 * after the run, so it names what actually wrote the bank.
 *
 * A fallback that works hides the provider that stopped working: a success
 * clears the error, so a key with no credit left was invisible for as long
 * as the next provider answered (2026-11). Two things make it visible. The
 * first time a provider fails and is passed over, one warning is logged —
 * provider, HTTP status, reason, never a key — once per provider per
 * process, not once per page. And {@see providerReport()} keeps the count
 * of who answered and who was skipped, which the FAQ run summary carries.
 */
final class FirstConfiguredTextGenerator implements ReportsProviders, TextGenerator
{
    /** @var list<TextGenerator> */
    private readonly array $generators;

    private ?string $lastError = null;

    private ?TextGenerator $answered = null;

    /** @var array<string, int> provider label => texts it wrote */
    private array $answers = [];

    /** @var array<string, array{times: int, status: ?int, reason: string}> provider label => its failures */
    private array $skipped = [];

    /** @param  list<TextGenerator>  $generators  in the order to try them */
    public function __construct(array $generators)
    {
        $this->generators = array_values($generators);
    }

    public function isConfigured(): bool
    {
        foreach ($this->generators as $generator) {
            if ($generator->isConfigured()) {
                return true;
            }
        }

        return false;
    }

    public function generate(string $prompt, int $maxOutputTokens = 2000): ?string
    {
        $failures = [];

        foreach ($this->generators as $generator) {
            if (! $generator->isConfigured()) {
                continue;
            }

            $text = $generator->generate($prompt, $maxOutputTokens);

            if ($text !== null) {
                $this->answered = $generator;
                $this->answers[$generator->label()] = ($this->answers[$generator->label()] ?? 0) + 1;
                $this->lastError = null;

                return $text;
            }

            $reason = $generator->lastError() ?? $generator->label().' answered nothing.';
            $failures[] = $reason;
            $this->noteSkipped($generator->label(), $reason);
        }

        $this->lastError = $failures === [] ? 'No text generator is configured.' : implode('; ', $failures);

        return null;
    }

    public function lastError(): ?string
    {
        return $this->lastError;
    }

    public function providerReport(): array
    {
        return ['answered' => $this->answers, 'skipped' => $this->skipped];
    }

    /**
     * One provider failed and the next is about to be tried: count it, and
     * the first time say so in the log.
     */
    private function noteSkipped(string $provider, string $reason): void
    {
        $reason = mb_substr(self::withoutSecrets($reason), 0, 300);
        $status = preg_match('/\banswered (\d{3})\b/', $reason, $m) === 1 ? (int) $m[1] : null;
        $first = ! isset($this->skipped[$provider]);

        $this->skipped[$provider] = [
            'times' => ($this->skipped[$provider]['times'] ?? 0) + 1,
            'status' => $status,
            'reason' => $reason,
        ];

        if ($first) {
            logger()->warning('AI text provider failed and was skipped; the next configured provider is tried.', [
                'provider' => $provider,
                'status' => $status,
                'reason' => $reason,
            ]);
        }
    }

    /**
     * A provider's own error text with anything key-shaped taken out. The
     * kit's generators already keep keys out of their errors; this is for
     * the ones a site wrote itself, since this text goes to the log.
     */
    private static function withoutSecrets(string $text): string
    {
        return (string) preg_replace(
            ['/([?&](?:api_?)?key=)[^&\s"\']+/i', '/\b(Bearer\s+)[\w.\-]+/i', '/\b(?:sk|pk)-[A-Za-z0-9_\-]{12,}/', '/\bAIza[0-9A-Za-z_\-]{20,}/'],
            ['$1[key]', '$1[key]', '[key]', '[key]'],
            $text,
        );
    }

    public function label(): string
    {
        if ($this->answered !== null) {
            return $this->answered->label();
        }

        foreach ($this->generators as $generator) {
            if ($generator->isConfigured()) {
                return $generator->label();
            }
        }

        return 'no provider';
    }
}
