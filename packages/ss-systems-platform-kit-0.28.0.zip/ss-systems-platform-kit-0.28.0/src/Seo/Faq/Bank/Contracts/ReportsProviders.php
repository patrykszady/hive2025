<?php

namespace SsSystems\Platform\Seo\Faq\Bank\Contracts;

/**
 * A {@see TextGenerator} that stands for several providers and can say,
 * after a run, which of them actually answered and which were passed over
 * after an error — what `Seo\Faq\Bank\Generators\FirstConfiguredTextGenerator`
 * does. The FAQ bank's run summary carries it (`providers`), because a
 * fallback that works hides the provider that stopped working: a Gemini key
 * with no credit left answered nothing for days while OpenAI quietly wrote
 * the bank (2026-11).
 *
 * Optional: a generator for one provider has nothing to report and does not
 * implement this; its failures already reach the page's `last_error` and
 * stop the run.
 */
interface ReportsProviders
{
    /**
     * `answered`: provider label => texts it wrote this process. `skipped`:
     * provider label => how often it failed and was passed over, with the
     * HTTP status (when its error names one) and the reason of the latest
     * failure — never a key.
     *
     * @return array{answered: array<string, int>, skipped: array<string, array{times: int, status: ?int, reason: string}>}
     */
    public function providerReport(): array;
}
