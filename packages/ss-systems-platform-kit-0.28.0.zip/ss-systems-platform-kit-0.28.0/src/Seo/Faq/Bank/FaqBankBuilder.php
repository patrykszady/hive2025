<?php

namespace SsSystems\Platform\Seo\Faq\Bank;

use Illuminate\Container\Container;
use Illuminate\Support\Carbon;
use SsSystems\Platform\Seo\Faq\Bank\Contracts\FaqBankSource;
use SsSystems\Platform\Seo\Faq\Bank\Contracts\ReportsProviders;
use SsSystems\Platform\Seo\Faq\Bank\Contracts\TextGenerator;
use SsSystems\Platform\Seo\Status\Heartbeat;

/**
 * The FAQ bank: many, many questions and answers about the business,
 * every one derived from one of the site's own pages, for the AI answer
 * engines reading `/geo/answers.json` and llms-full.txt (Patryk,
 * 2026-11-10). One implementation, run by every site through its own
 * {@see FaqBankSource}, {@see TextGenerator} and {@see FaqBankStore}, the
 * way BingCoverageSync runs the Bing coverage.
 *
 * One run, `limit` pages at a time (pages never seen first, then the
 * longest ago checked, so a site of 1,800 pages is covered in twelve
 * nightly runs at the default and a changed page is picked up within as
 * many), each page:
 *
 *   1. Its text: the source's own words when it supplies them, else the
 *      page rendered in-process ({@see InProcessPageRenderer}) and read by
 *      {@see PageTextExtractor}. Shorter than `min_chars` is too thin to
 *      mine: its answers are cleared and it is marked checked.
 *   2. Unchanged since it was last built (same sha1 of the text) and not
 *      `force`: marked checked, nothing generated — a nightly run over a
 *      site that did not change costs nothing.
 *   3. Otherwise {@see prompt()} goes to the generator, the answer is parsed
 *      ({@see parseItems()}), every pair goes through {@see FaqAnswerGuard}
 *      (the "derived" rule), the survivors get their {@see FaqKeys}, and a
 *      pair whose keys another page already holds — the same answer said
 *      about another town — or that this page already produced is dropped
 *      as a duplicate. Up to `per_page` are kept and the page is replaced
 *      whole in the store.
 *
 * A failed generation or an answer that is not the JSON asked for is
 * recorded on the page (last_error) and counted; `max_failures` of them in
 * a row stop the run with status 'stopped' — a dead key or a provider
 * outage must not burn through the night. A `dry_run` visits the pages,
 * generates nothing, writes nothing, and reports what it would build.
 * `only` narrows the run to pages whose URL contains the text, every one
 * of them whatever `limit` says — for rebuilding one page by hand.
 *
 * Pages the site no longer lists are forgotten at the start of a run —
 * unless the list itself looks broken ({@see forgetRefusal()}), in which
 * case the run fails and the bank is left exactly as it was.
 *
 * A nightly run (not a dry run, not an `only` rebuild) reports into the
 * `faq_bank` heartbeat (Seo\Status\Heartbeat, read by GET seo/status):
 * ok with its counts; skipped when no AI provider has a key; failed when
 * it was stopped, when the tables are missing, and when it asked the
 * provider for pages and got none back — fewer than `max_failures` pages
 * all failing used to end as a quiet 'ok', which is how an AI account
 * that ran out of credit went unnoticed.
 */
final class FaqBankBuilder
{
    public const DEFAULT_LIMIT = 150;

    public const DEFAULT_PER_PAGE = 5;

    public const DEFAULT_PAUSE_MS = 1000;

    public const DEFAULT_MIN_CHARS = 400;

    public const DEFAULT_MAX_FAILURES = 5;

    /** Page text longer than this is cut on a word boundary before it goes into the prompt. */
    public const MAX_TEXT_CHARS = PageTextExtractor::DEFAULT_MAX_CHARS;

    /** URLs a dry run lists. */
    public const SAMPLE_ROWS = 20;

    /** A bank of fewer stored pages than this is too small to judge a shrink by; only an empty list is refused. */
    public const FORGET_GUARD_MIN_STORED = 10;

    /** A page list under this share of the stored pages is taken for a broken source, not a smaller site. */
    public const FORGET_GUARD_MIN_SHARE = 0.5;

    /**
     * @param  array{limit?: int, per_page?: int, pause_ms?: int, min_chars?: int, max_failures?: int, force?: bool, dry_run?: bool, accept_shrink?: bool, only?: ?string, sleep?: callable(int): void, render?: callable(string): ?string}  $options
     * @return array{status: string, business: string, provider: string, pages_total: int, visited: int, built: int, unchanged: int, thin: int, failed: int, would_build: int, answers_kept: int, rejected: array<string, int>, duplicates: int, bank_answers: int, bank_pages: int, started_at: string, finished_at: ?string, error: ?string, sample: list<string>, providers: ?array{answered: array<string, int>, skipped: array<string, array{times: int, status: ?int, reason: string}>}}
     *
     * `provider` names who answered last; `providers` — null unless the
     * generator is a chain ({@see ReportsProviders}) — says how many texts
     * each provider wrote and which were skipped after an error, so a run
     * that succeeded on its fallback still shows the provider that failed.
     */
    public static function run(FaqBankSource $source, TextGenerator $generator, FaqBankStore $store, array $options = []): array
    {
        $lastFailure = null;
        $summary = self::build($source, $generator, $store, $options, $lastFailure);

        if (trim((string) ($options['only'] ?? '')) !== '') {
            return $summary;
        }

        $detail = [
            'provider' => $summary['provider'],
            'pages_total' => $summary['pages_total'],
            'visited' => $summary['visited'],
            'built' => $summary['built'],
            'unchanged' => $summary['unchanged'],
            'thin' => $summary['thin'],
            'failed' => $summary['failed'],
            'answers_kept' => $summary['answers_kept'],
            'bank_answers' => $summary['bank_answers'],
            'bank_pages' => $summary['bank_pages'],
        ];

        if ($summary['status'] === 'ok' && $summary['failed'] > 0 && $summary['built'] === 0) {
            Heartbeat::failed('faq_bank', sprintf('All %d generations failed; the last one: %s', $summary['failed'], $lastFailure ?? 'no reason given'), $detail, $summary['finished_at']);
        } else {
            Heartbeat::fromSummary(
                'faq_bank',
                $summary['status'] === 'skipped' ? ['error' => 'No AI provider is configured for '.$summary['business'].'.'] + $summary : $summary,
                $detail,
            );
        }

        return $summary;
    }

    /**
     * @param  array<string, mixed>  $options  {@see run()}
     * @param  ?string  $lastFailure  set to the reason of the last generation that failed
     * @return array<string, mixed>  {@see run()}
     */
    private static function build(FaqBankSource $source, TextGenerator $generator, FaqBankStore $store, array $options, ?string &$lastFailure): array
    {
        $limit = max(0, (int) ($options['limit'] ?? self::DEFAULT_LIMIT));
        $perPage = max(1, (int) ($options['per_page'] ?? self::DEFAULT_PER_PAGE));
        $pauseMs = max(0, (int) ($options['pause_ms'] ?? self::DEFAULT_PAUSE_MS));
        $minChars = max(0, (int) ($options['min_chars'] ?? self::DEFAULT_MIN_CHARS));
        $maxFailures = max(1, (int) ($options['max_failures'] ?? self::DEFAULT_MAX_FAILURES));
        $force = (bool) ($options['force'] ?? false);
        $dryRun = (bool) ($options['dry_run'] ?? false);
        $only = trim((string) ($options['only'] ?? ''));
        $sleep = $options['sleep'] ?? static function (int $ms): void {
            usleep($ms * 1000);
        };
        $render = $options['render'] ?? static fn (string $url): ?string => (new InProcessPageRenderer(Container::getInstance()))->render($url);

        $summary = [
            'status' => 'ok',
            'business' => $source->businessName(),
            'provider' => $generator->label(),
            'pages_total' => 0,
            'visited' => 0,
            'built' => 0,
            'unchanged' => 0,
            'thin' => 0,
            'failed' => 0,
            'would_build' => 0,
            'answers_kept' => 0,
            'rejected' => [],
            'duplicates' => 0,
            'bank_answers' => 0,
            'bank_pages' => 0,
            'started_at' => Carbon::now('UTC')->toIso8601String(),
            'finished_at' => null,
            'error' => null,
            'sample' => [],
            'providers' => null,
        ];

        if (! $store->exists()) {
            $summary['status'] = 'failed';
            $summary['error'] = 'The FAQ bank tables are missing — copy resources/stubs/seo/create_geo_faq_bank_tables.php.stub into database/migrations and migrate.';
            $summary['finished_at'] = Carbon::now('UTC')->toIso8601String();

            return $summary;
        }

        if (! $generator->isConfigured()) {
            $summary['status'] = 'skipped';
            $summary['finished_at'] = Carbon::now('UTC')->toIso8601String();

            return $summary;
        }

        $pages = self::uniquePages($source->pages());
        $summary['pages_total'] = count($pages);

        $refusal = ($options['accept_shrink'] ?? false) ? null : self::forgetRefusal(count($pages), $store->summary()['pages']);

        if ($refusal !== null) {
            $bank = $store->summary();
            $summary['status'] = 'failed';
            $summary['error'] = $refusal;
            $summary['bank_answers'] = $bank['answers'];
            $summary['bank_pages'] = $bank['pages'];
            $summary['finished_at'] = Carbon::now('UTC')->toIso8601String();

            return $summary;
        }

        if (! $dryRun) {
            $store->forgetPagesNotIn(array_column($pages, 'url'));
        }

        $toVisit = $only !== ''
            ? array_values(array_filter($pages, static fn (array $page): bool => str_contains(mb_strtolower($page['url']), mb_strtolower($only))))
            : $store->pagesToVisit($pages, $limit);

        $business = $source->businessName();
        $language = $source->language();
        $towns = $source->towns();
        $banned = $source->bannedTerms();
        $generations = 0;
        $failuresInARow = 0;

        foreach ($toVisit as $page) {
            $url = $page['url'];
            $kind = $page['kind'];
            $summary['visited']++;

            $own = $source->textFor($url);
            $text = $own !== null
                ? PageTextExtractor::truncate(trim($own), self::MAX_TEXT_CHARS)
                : PageTextExtractor::extract($render($url) ?? '', self::MAX_TEXT_CHARS);

            if (mb_strlen($text) < $minChars) {
                $summary['thin']++;

                if (! $dryRun) {
                    $store->clearPage($url);
                    $store->markChecked($url, $kind, sha1($text), sprintf('Too thin to mine: %d characters of text.', mb_strlen($text)));
                }

                continue;
            }

            $hash = sha1($text);
            $state = $store->pageState($url);

            if (! $force && $state !== null && $state['source_hash'] === $hash) {
                $summary['unchanged']++;

                if (! $dryRun) {
                    $store->markChecked($url, $kind, $hash);
                }

                continue;
            }

            if ($dryRun) {
                $summary['would_build']++;

                if (count($summary['sample']) < self::SAMPLE_ROWS) {
                    $summary['sample'][] = $url;
                }

                continue;
            }

            if ($generations > 0 && $pauseMs > 0) {
                $sleep($pauseMs);
            }

            $generations++;
            $raw = $generator->generate(self::prompt($business, $language, $kind, $url, $text, $perPage), self::outputTokensFor($perPage));
            $items = $raw === null ? null : self::parseItems($raw);

            if ($items === null) {
                $error = $raw === null
                    ? ($generator->lastError() ?? $generator->label().' answered nothing.')
                    : $generator->label().' did not answer with the JSON asked for: '.mb_substr(trim($raw), 0, 120);
                $summary['failed']++;
                $lastFailure = $error;
                $store->markChecked($url, $kind, null, $error);

                if (++$failuresInARow >= $maxFailures) {
                    $summary['status'] = 'stopped';
                    $summary['error'] = sprintf('%d generations failed in a row; the last one: %s', $failuresInARow, $error);

                    break;
                }

                continue;
            }

            $failuresInARow = 0;
            $taken = $store->takenKeys($url);
            $seen = [];
            $kept = [];

            foreach ($items as $item) {
                $reason = FaqAnswerGuard::rejectReason($item, $text, $banned);

                if ($reason !== null) {
                    $summary['rejected'][$reason] = ($summary['rejected'][$reason] ?? 0) + 1;

                    continue;
                }

                $qKey = FaqKeys::question($item['q'], $towns);
                $aKey = FaqKeys::answer($item['a'], $towns);
                $key = $qKey.'|'.$aKey;

                if (isset($taken[$key]) || isset($seen[$key])) {
                    $summary['duplicates']++;

                    continue;
                }

                $seen[$key] = true;
                $kept[] = ['q' => $item['q'], 'a' => $item['a'], 'q_key' => $qKey, 'a_key' => $aKey];

                if (count($kept) >= $perPage) {
                    break;
                }
            }

            $store->replacePage($url, $kind, $hash, $kept);
            $summary['built']++;
            $summary['answers_kept'] += count($kept);
        }

        $bank = $store->summary();
        $summary['bank_answers'] = $bank['answers'];
        $summary['bank_pages'] = $bank['pages'];
        $summary['provider'] = $generator->label();
        $summary['providers'] = $generator instanceof ReportsProviders ? $generator->providerReport() : null;

        if ($dryRun) {
            $summary['status'] = 'dry-run';
        }

        $summary['finished_at'] = Carbon::now('UTC')->toIso8601String();

        return $summary;
    }

    /**
     * Why a run must not mirror this page list into the bank, or null when
     * it may. The bank forgets every stored page the site no longer lists,
     * so a page source that comes back empty — a per-site config that reads
     * empty in a bare console (2026-11) — or sharply shorter would delete
     * the bank and its answers in one run that still ended 'ok'. A list
     * that is empty, or under {@see FORGET_GUARD_MIN_SHARE} of a bank of at
     * least {@see FORGET_GUARD_MIN_STORED} pages, is refused: nothing is
     * forgotten, nothing is built, the run fails with this sentence. A site
     * that really shrank passes `accept_shrink` once.
     */
    public static function forgetRefusal(int $listed, int $stored): ?string
    {
        if ($stored <= 0) {
            return null;
        }

        if ($listed <= 0) {
            return sprintf(
                'The site listed no pages to mine, so nothing was forgotten and the bank keeps its %d pages. An empty list means the page source is broken, not that the site is empty.',
                $stored,
            );
        }

        if ($stored >= self::FORGET_GUARD_MIN_STORED && $listed < $stored * self::FORGET_GUARD_MIN_SHARE) {
            return sprintf(
                'The site listed %d pages and the bank holds %d — fewer than half, so nothing was forgotten or built. If the site really shrank, run seo:faq-bank --accept-shrink once.',
                $listed,
                $stored,
            );
        }

        return null;
    }

    /**
     * The one prompt every provider gets — a kit constant, so every site's
     * bank is written to the same rule and a change to the rule is one
     * release. The page text follows between delimiters the model cannot
     * mistake for instructions.
     */
    public static function prompt(string $business, string $language, string $kind, string $url, string $text, int $perPage): string
    {
        return sprintf(
            'You write the questions and answers an AI assistant would use about %s. Below is the text of one %s page of their website (%s). '
            .'Write up to %d questions a real customer would ask that this page answers, and answer each in one to three plain sentences, using only facts stated on the page. '
            .'Keep every price, number, timeline and place name exactly as the page states it. '
            ."No facts that are not on the page, no links, no other companies' names, no mention of 'this page' or 'the website'. "
            ."Write in %s, in the business's own voice (we, our). If the page answers fewer questions, return fewer. "
            .'Return only JSON: {"items": [{"q": "...", "a": "..."}]}',
            $business,
            $kind,
            $url,
            $perPage,
            $language,
        )."\n\n=== PAGE TEXT START ===\n".$text."\n=== PAGE TEXT END ===";
    }

    /**
     * The pairs in a generator's answer: `{"items": [...]}`, a bare list, a
     * single pair, with or without a ```json fence, `q`/`a` or
     * `question`/`answer` keys, whitespace collapsed. Null when the answer
     * is not JSON at all; an empty list when it is JSON with no usable pair
     * (the page answers nothing — the page is recorded as built with no
     * answers, so it is not asked again until it changes).
     *
     * @return list<array{q: string, a: string}>|null
     */
    public static function parseItems(string $raw): ?array
    {
        $raw = trim($raw);

        if (preg_match('/^```[a-zA-Z]*\s*(.*?)\s*```$/s', $raw, $fenced) === 1) {
            $raw = $fenced[1];
        }

        $decoded = json_decode($raw, true);

        if (! is_array($decoded) && preg_match('/[\[{].*[\]}]/s', $raw, $embedded) === 1) {
            $decoded = json_decode($embedded[0], true);
        }

        if (! is_array($decoded)) {
            return null;
        }

        if (array_key_exists('items', $decoded)) {
            $list = $decoded['items'];
        } elseif (isset($decoded['q']) || isset($decoded['question'])) {
            $list = [$decoded];
        } else {
            $list = $decoded;
        }

        if (! is_array($list)) {
            return null;
        }

        $items = [];

        foreach ($list as $row) {
            if (! is_array($row)) {
                continue;
            }

            $q = self::text($row, ['q', 'question']);
            $a = self::text($row, ['a', 'answer']);

            if ($q === '' || $a === '') {
                continue;
            }

            $items[] = ['q' => $q, 'a' => $a];
        }

        return $items;
    }

    /** Room for `$perPage` pairs plus a provider's thinking — a cap, not a spend. */
    public static function outputTokensFor(int $perPage): int
    {
        return min(16000, 2000 + max(1, $perPage) * 400);
    }

    /**
     * @param  list<array{url: string, kind: string}>  $pages
     * @return list<array{url: string, kind: string}>
     */
    private static function uniquePages(array $pages): array
    {
        $seen = [];
        $out = [];

        foreach ($pages as $page) {
            $url = trim((string) ($page['url'] ?? ''));

            if ($url === '' || isset($seen[$url])) {
                continue;
            }

            $seen[$url] = true;
            $out[] = ['url' => $url, 'kind' => trim((string) ($page['kind'] ?? 'page')) ?: 'page'];
        }

        return $out;
    }

    /** @param  array<string, mixed>  $row @param  list<string>  $keys */
    private static function text(array $row, array $keys): string
    {
        foreach ($keys as $key) {
            if (is_scalar($row[$key] ?? null)) {
                return trim((string) preg_replace('/\s+/u', ' ', (string) $row[$key]));
            }
        }

        return '';
    }
}
