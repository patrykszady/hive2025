<?php

namespace SsSystems\Platform\Seo\Faq\Bank\Console;

use Illuminate\Console\Command;
use SsSystems\Platform\Seo\Concerns\ExplainsFailure;
use SsSystems\Platform\Seo\Faq\Bank\Contracts\FaqBankSource;
use SsSystems\Platform\Seo\Faq\Bank\Contracts\TextGenerator;
use SsSystems\Platform\Seo\Faq\Bank\FaqBankBuilder;
use SsSystems\Platform\Seo\Faq\Bank\FaqBankStore;
use SsSystems\Platform\Seo\Faq\Bank\InProcessPageRenderer;

/**
 * `seo:faq-bank` — the FAQ bank behind `/geo/answers.json`, derived from
 * the site's own pages through whichever AI provider the site holds a key
 * for. Nightly on every site; see {@see FaqBankBuilder} for the flow and
 * the limits. A site binds its {@see FaqBankSource}, a {@see TextGenerator}
 * and a {@see FaqBankStore} in `AppServiceProvider` and registers this
 * command as it registers any other kit console command (2026-11-10).
 *
 * Exit codes: SUCCESS for a run, a dry run, and a site with no provider
 * configured (skipped, nothing to do); FAILURE when the tables are missing,
 * when the site's page list came back empty or under half of what the bank
 * holds (nothing is forgotten — see {@see FaqBankBuilder::forgetRefusal()}),
 * or when the run stopped after too many failed generations in a row.
 */
final class FaqBankCommand extends Command
{
    use ExplainsFailure;

    protected $signature = 'seo:faq-bank
        {--limit=150 : Pages to visit this run — never-seen pages first, then the longest ago checked}
        {--per-page=5 : Answers kept per page}
        {--pause=1000 : Milliseconds between generations}
        {--only= : Only pages whose URL contains this text — every one of them, whatever --limit says}
        {--force : Rebuild pages whose text has not changed}
        {--accept-shrink : Forget the pages that left even though the site now lists under half of what the bank holds}
        {--dry-run : Visit the pages, generate nothing, write nothing, list what would be built}';

    protected $description = 'Derive the FAQ bank behind /geo/answers.json from the site\'s own pages through the configured AI provider';

    public function handle(FaqBankSource $source, TextGenerator $generator, FaqBankStore $store): int
    {
        $renderer = new InProcessPageRenderer($this->laravel);

        $summary = FaqBankBuilder::run($source, $generator, $store, [
            'limit' => max(0, (int) $this->option('limit')),
            'per_page' => max(1, (int) $this->option('per-page')),
            'pause_ms' => max(0, (int) $this->option('pause')),
            'only' => (string) $this->option('only'),
            'force' => (bool) $this->option('force'),
            'accept_shrink' => (bool) $this->option('accept-shrink'),
            'dry_run' => (bool) $this->option('dry-run'),
            'render' => static fn (string $url): ?string => $renderer->render($url),
        ]);

        if ($summary['status'] === 'skipped') {
            $this->info(sprintf('No AI provider is configured for %s — skipping.', $summary['business']));

            return self::SUCCESS;
        }

        if ($summary['status'] === 'failed') {
            // Two things fail a run before a page is visited: the tables are
            // missing (nothing stored yet), or the site's page list was
            // refused to protect a bank that does hold pages.
            return $this->failBecause(
                $summary['bank_pages'] > 0 ? self::REASON_NOTHING_SUCCEEDED : self::REASON_NOT_CONFIGURED,
                sprintf('FAQ bank failed for %s: %s', $summary['business'], $summary['error']),
            );
        }

        $this->line(sprintf(
            'FAQ bank for %s via %s: %d pages written, %d answers kept, %d duplicates dropped, %d unchanged, %d too thin, %d failed.',
            $summary['business'],
            $summary['provider'],
            $summary['built'],
            $summary['answers_kept'],
            $summary['duplicates'],
            $summary['unchanged'],
            $summary['thin'],
            $summary['failed'],
        ));

        if ($summary['rejected'] !== []) {
            $reasons = [];

            foreach ($summary['rejected'] as $reason => $count) {
                $reasons[] = $reason.' '.$count;
            }

            $this->line('Rejected: '.implode(', ', $reasons));
        }

        foreach ($summary['providers']['skipped'] ?? [] as $provider => $skip) {
            $this->warn(sprintf(
                '%s failed %d time%s and was skipped%s: %s',
                $provider,
                $skip['times'],
                $skip['times'] === 1 ? '' : 's',
                $skip['status'] !== null ? ' (HTTP '.$skip['status'].')' : '',
                $skip['reason'],
            ));
        }

        $this->line(sprintf('The bank holds %d answers from %d pages.', $summary['bank_answers'], $summary['bank_pages']));

        if ($summary['status'] === 'dry-run') {
            $this->line(sprintf('Dry run — nothing generated, nothing written. %d pages would be built:', $summary['would_build']));

            foreach ($summary['sample'] as $url) {
                $this->line('  '.$url);
            }

            if ($summary['would_build'] > count($summary['sample'])) {
                $this->line(sprintf('  … and %d more', $summary['would_build'] - count($summary['sample'])));
            }
        }

        if ($summary['status'] === 'stopped') {
            return $this->failBecause(
                self::reasonForError($summary['error'], $summary['built'] > 0 ? self::REASON_VENDOR_ERROR : self::REASON_NOTHING_SUCCEEDED),
                'Stopped: '.$summary['error'],
            );
        }

        return self::SUCCESS;
    }
}
