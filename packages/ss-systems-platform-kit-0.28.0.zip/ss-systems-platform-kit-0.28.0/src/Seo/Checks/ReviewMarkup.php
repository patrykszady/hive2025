<?php

namespace SsSystems\Platform\Seo\Checks;

use SsSystems\Platform\Reports\JsonLd;

/**
 * Which entity a page's review markup is about.
 *
 * Google shows review stars for ratings of a product, a service, a recipe,
 * a course and the like. It does not show them for a rating a business
 * publishes about itself: review markup on the site's own
 * `LocalBusiness`/`Organization` is "self-serving" in Google's review
 * snippet guidelines, never earns stars, and markup Google judges
 * misleading can cost a site its rich results. So the question this
 * answers is not "is there a rating" but "what is being rated":
 *
 *   - `own`   — the rating or the reviews sit on a business entity that is
 *               this site's own: nested in it (`aggregateRating`, `review`)
 *               or pointing at it (`itemReviewed`).
 *   - `other` — they sit on anything else: a Product, a Service, another
 *               organisation's listing. Left alone; reported only so a page
 *               that carries both can say so.
 *
 * Deliberately conservative, because gs.construction and J. Peterson keep a
 * rating on their business node ON PURPOSE (schema.org requires an
 * aggregate when a node carries several reviews, and AI answer surfaces
 * read it): the check states what it found and where, and never says to
 * remove anything.
 *
 *   - A business entity counts as this site's own when its `url` — or,
 *     when it gives no url, its `@id` — is on the site's host. With
 *     neither, it is taken to be the site's own (a business describing
 *     itself on its own pages is the ordinary case) and the entry says
 *     `assumed`. With a `url` on ANOTHER host it is somebody else's
 *     business and is not reported, whatever its `@id`.
 *   - A rated entity given only as a bare `{"@id": …}` is looked up among
 *     the page's own nodes; one that cannot be found has no type to judge
 *     and is not reported.
 *   - A `Review`/`AggregateRating` with nothing saying what it rates is not
 *     reported either.
 *
 * Reads the page through {@see JsonLd}, the parser SchemaAuditReport uses.
 */
final class ReviewMarkup
{
    /**
     * schema.org's Organization family — Organization, LocalBusiness and
     * the subtypes a site in this estate (or one like it) would use. A type
     * outside this list is treated as "something else", never as the
     * business, so an unknown type can only ever cost a finding, not
     * invent one.
     *
     * @var list<string>
     */
    public const BUSINESS_TYPES = [
        'Organization', 'Corporation', 'LocalBusiness', 'OnlineBusiness', 'OnlineStore', 'NGO', 'Cooperative',
        'EducationalOrganization', 'GovernmentOrganization', 'MedicalOrganization', 'NewsMediaOrganization',
        'PerformingGroup', 'SportsOrganization', 'ResearchOrganization', 'Consortium', 'WorkersUnion',
        // Home and construction
        'HomeAndConstructionBusiness', 'GeneralContractor', 'Electrician', 'HVACBusiness', 'HousePainter',
        'Locksmith', 'MovingCompany', 'Plumber', 'RoofingContractor',
        // Professional, property, money, law
        'ProfessionalService', 'RealEstateAgent', 'FinancialService', 'AccountingService', 'BankOrCreditUnion',
        'InsuranceAgency', 'LegalService', 'Attorney', 'Notary', 'EmploymentAgency', 'TravelAgency',
        // Shops
        'Store', 'FurnitureStore', 'HomeGoodsStore', 'HardwareStore', 'GardenStore', 'ElectronicsStore',
        'ClothingStore', 'ShoeStore', 'JewelryStore', 'BookStore', 'ToyStore', 'PetStore', 'Florist',
        'GroceryStore', 'ConvenienceStore', 'DepartmentStore', 'SportingGoodsStore', 'BikeStore', 'MusicStore',
        'OfficeEquipmentStore', 'MobilePhoneStore', 'ComputerStore', 'LiquorStore', 'HobbyShop', 'OutletStore',
        'PawnShop', 'TireShop', 'WholesaleStore', 'AutoPartsStore', 'ShoppingCenter',
        // Cars
        'AutomotiveBusiness', 'AutoBodyShop', 'AutoDealer', 'AutoRental', 'AutoRepair', 'AutoWash', 'GasStation',
        'MotorcycleDealer', 'MotorcycleRepair',
        // Food and lodging
        'FoodEstablishment', 'Restaurant', 'Bakery', 'BarOrPub', 'Brewery', 'CafeOrCoffeeShop', 'FastFoodRestaurant',
        'IceCreamShop', 'Winery', 'Distillery', 'LodgingBusiness', 'Hotel', 'Motel', 'BedAndBreakfast', 'Hostel',
        'Resort', 'Campground',
        // Health and care
        'MedicalBusiness', 'Dentist', 'Physician', 'Pharmacy', 'Optician', 'MedicalClinic', 'Hospital',
        'VeterinaryCare', 'HealthAndBeautyBusiness', 'BeautySalon', 'DaySpa', 'HairSalon', 'HealthClub',
        'NailSalon', 'TattooParlor', 'ChildCare', 'AnimalShelter',
        // The rest of LocalBusiness
        'EntertainmentBusiness', 'SportsActivityLocation', 'DryCleaningOrLaundry', 'EmergencyService',
        'GovernmentOffice', 'InternetCafe', 'Library', 'RadioStation', 'TelevisionStation', 'RecyclingCenter',
        'SelfStorage', 'TouristInformationCenter', 'ArchiveOrganization',
    ];

    /** The properties a rating hangs from on the entity it rates. */
    private const RATING_PROPERTIES = ['aggregateRating', 'review', 'reviews'];

    /**
     * @param  list<array<string|int, mixed>>  $documents  the page's decoded JSON-LD blocks
     * @return array{
     *     own: list<array{type: string, name: ?string, rating: bool, reviews: int, assumed: bool}>,
     *     other: list<array{type: string, name: ?string, rating: bool, reviews: int, assumed: bool}>,
     * }
     */
    public static function classify(array $documents, string $siteHost): array
    {
        $definitions = self::definitions($documents);
        $found = ['own' => [], 'other' => []];

        $record = function (?array $subject, bool $rating, int $reviews) use (&$found, $definitions, $siteHost): void {
            $subject = self::resolve($subject, $definitions);
            $types = self::types($subject);

            if ($types === []) {
                return;
            }

            $business = array_values(array_intersect($types, self::BUSINESS_TYPES));
            $ownership = $business === [] ? null : self::ownership($subject, $siteHost);

            if ($ownership === 'other') {
                return;
            }

            $group = $business === [] ? 'other' : 'own';
            $type = $business[0] ?? $types[0];
            $name = is_string($subject['name'] ?? null) ? trim($subject['name']) : null;
            $key = $type.'|'.(is_string($subject['@id'] ?? null) ? $subject['@id'] : ($name ?? ''));

            $entry = $found[$group][$key] ?? ['type' => $type, 'name' => $name !== '' ? $name : null, 'rating' => false, 'reviews' => 0, 'assumed' => $ownership === 'assumed'];
            $entry['rating'] = $entry['rating'] || $rating;
            $entry['reviews'] += $reviews;
            $found[$group][$key] = $entry;
        };

        foreach ($documents as $document) {
            JsonLd::walk($document, function (array $node, ?array $parent, ?string $property) use ($record): void {
                if (is_array($node['aggregateRating'] ?? null) && $node['aggregateRating'] !== []) {
                    $record($node, true, 0);
                }

                foreach (['review', 'reviews'] as $reviews) {
                    if (is_array($node[$reviews] ?? null) && $node[$reviews] !== []) {
                        $record($node, false, array_is_list($node[$reviews]) ? count($node[$reviews]) : 1);
                    }
                }

                // A rating written on its own, saying what it rates. One
                // nested in the entity it rates was counted with that entity.
                if (in_array($property, self::RATING_PROPERTIES, true) || ! is_array($node['itemReviewed'] ?? null)) {
                    return;
                }

                $types = self::types($node);
                $rated = array_is_list($node['itemReviewed']) ? $node['itemReviewed'] : [$node['itemReviewed']];

                foreach ($rated as $subject) {
                    if (! is_array($subject)) {
                        continue;
                    }

                    if (in_array('AggregateRating', $types, true)) {
                        $record($subject, true, 0);
                    } elseif (in_array('Review', $types, true)) {
                        $record($subject, false, 1);
                    }
                }
            });
        }

        return ['own' => array_values($found['own']), 'other' => array_values($found['other'])];
    }

    /**
     * Every fully written node on the page by its @id, so a bare
     * `{"@id": …}` reference can be read as the entity it names.
     *
     * @param  list<array<string|int, mixed>>  $documents
     * @return array<string, array<string, mixed>>
     */
    private static function definitions(array $documents): array
    {
        $definitions = [];

        foreach ($documents as $document) {
            JsonLd::walk($document, function (array $node) use (&$definitions): void {
                if (is_string($node['@id'] ?? null) && count($node) > 2) {
                    $definitions[$node['@id']] ??= $node;
                }
            });
        }

        return $definitions;
    }

    /**
     * @param  array<string, mixed>|null  $subject
     * @param  array<string, array<string, mixed>>  $definitions
     * @return array<string, mixed>
     */
    private static function resolve(?array $subject, array $definitions): array
    {
        if ($subject === null) {
            return [];
        }

        if (! isset($subject['@type']) && is_string($subject['@id'] ?? null)) {
            return $definitions[$subject['@id']] ?? $subject;
        }

        return $subject;
    }

    /**
     * A node's types as bare names: "https://schema.org/LocalBusiness" and
     * "schema:LocalBusiness" both read "LocalBusiness".
     *
     * @param  array<string, mixed>  $node
     * @return list<string>
     */
    private static function types(array $node): array
    {
        $types = [];

        foreach ((array) ($node['@type'] ?? []) as $type) {
            if (is_string($type) && $type !== '') {
                $types[] = (string) preg_replace('#^(https?://schema\.org/|schema:)#i', '', $type);
            }
        }

        return $types;
    }

    /**
     * Whose business this is: 'own' when its url (or, with no url, its
     * @id) is on the site's host, 'other' when it is on another, 'assumed'
     * when it gives neither (or the site's host is not known).
     *
     * @param  array<string, mixed>  $business
     */
    private static function ownership(array $business, string $siteHost): string
    {
        $site = self::host($siteHost);

        // The url says whose business it is; the @id only where there is
        // no url, since a page about ANOTHER business may well give it an
        // @id on this site ("https://this.site/partners/acme#business")
        // beside that business's own url.
        foreach (['url', '@id'] as $key) {
            if (is_string($business[$key] ?? null) && ($host = parse_url($business[$key], PHP_URL_HOST))) {
                if ($site === '') {
                    return 'assumed';
                }

                return self::host((string) $host) === $site ? 'own' : 'other';
            }
        }

        return 'assumed';
    }

    private static function host(string $host): string
    {
        $host = strtolower(trim($host));

        return str_starts_with($host, 'www.') ? substr($host, 4) : $host;
    }
}
