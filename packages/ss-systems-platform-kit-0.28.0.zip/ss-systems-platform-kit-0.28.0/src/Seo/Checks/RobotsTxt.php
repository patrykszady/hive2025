<?php

namespace SsSystems\Platform\Seo\Checks;

/**
 * A site's robots.txt, read for one question only: is this crawler told to
 * stay out of the WHOLE site?
 *
 * That narrow question is on purpose. Every site here closes parts of
 * itself by rule — /admin and /api everywhere, the MLS listing and sold
 * pages to AI model crawlers on dawnsellshomes.com, a list of scrapers
 * that only harvest pages — and none of that is a fault. A crawler counts
 * as shut out only when the rules that apply to it disallow "/" and open
 * nothing back up with an Allow line. Anything narrower is the site's own
 * decision and is never reported.
 *
 * Which rules apply to a crawler follows the robots.txt standard: the
 * groups naming it, or the "*" groups when none does. Consecutive
 * User-agent lines share the rules that follow them.
 *
 * One place this reads a file more cautiously than Google's own parser
 * does: a line such as Crawl-delay ends the run of User-agent names
 * before it. Google ignores that line, so for Google the names carry on
 * into the next group; Bing reads it as that group's rule.
 * dawnsellshomes.com's file is exactly this — "User-agent: bingbot /
 * Crawl-delay: 2", then further down "User-agent: Yandex / User-agent:
 * Baiduspider / Disallow: /" — and read Google's way it would say Bing is
 * shut out of the whole site, which it is not. A whole-site block is the
 * one thing this class reports, in red, so where two readings disagree it
 * takes the one that does not raise the alarm.
 */
final class RobotsTxt
{
    /**
     * @param  list<array{agents: list<string>, rules: list<array{allow: bool, path: string}>}>  $groups
     */
    private function __construct(private readonly array $groups) {}

    public static function parse(string $body): self
    {
        $groups = [];
        $current = null;
        $lastWasAgent = false;

        // A file saved with a byte-order mark would otherwise lose its first line.
        $body = (string) preg_replace('/^\xEF\xBB\xBF/', '', $body);

        foreach (preg_split('/\r\n|\r|\n/', $body) ?: [] as $line) {
            $line = trim((string) preg_replace('/#.*$/', '', $line));

            if ($line === '' || ! str_contains($line, ':')) {
                continue;
            }

            [$field, $value] = array_map('trim', explode(':', $line, 2));
            $field = strtolower($field);

            if ($field === 'user-agent') {
                if (! $lastWasAgent) {
                    $groups[] = ['agents' => [], 'rules' => []];
                    $current = array_key_last($groups);
                }

                $groups[$current]['agents'][] = strtolower($value);
                $lastWasAgent = true;

                continue;
            }

            // A Sitemap line belongs to the whole file and to no group.
            if ($field === 'sitemap') {
                continue;
            }

            // Any other line is the group's own — Allow, Disallow, and the
            // ones only some crawlers read, Crawl-delay above all — so the
            // names before it are complete and the next User-agent line
            // starts a new group.
            $lastWasAgent = false;

            if (($field === 'allow' || $field === 'disallow') && $current !== null) {
                $groups[$current]['rules'][] = ['allow' => $field === 'allow', 'path' => $value];
            }
        }

        return new self($groups);
    }

    /**
     * Whether the rules that apply to $agent (its product token, e.g.
     * "Googlebot") close the whole site to it.
     */
    public function blocksWholeSite(string $agent): bool
    {
        $rules = $this->rulesFor(strtolower($agent));
        $closed = false;

        foreach ($rules as $rule) {
            if ($rule['path'] === '') {
                continue;
            }

            if ($rule['allow']) {
                return false;
            }

            if ($rule['path'] === '/' || $rule['path'] === '/*') {
                $closed = true;
            }
        }

        return $closed;
    }

    /**
     * @return list<array{allow: bool, path: string}>
     */
    private function rulesFor(string $agent): array
    {
        foreach ([$agent, '*'] as $name) {
            $rules = [];
            $named = false;

            foreach ($this->groups as $group) {
                if (in_array($name, $group['agents'], true)) {
                    $named = true;
                    $rules = [...$rules, ...$group['rules']];
                }
            }

            if ($named) {
                return $rules;
            }
        }

        return [];
    }
}
