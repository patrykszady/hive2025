<?php

namespace SsSystems\Platform\Seo\Checks;

use Illuminate\Container\Container;
use Illuminate\Support\Carbon;
use SsSystems\Platform\Reports\Contracts\PsiSnapshotReader;

/**
 * Puts the `site_checks` block on a site's SEO snapshot — the one step
 * between a site's own `buildSnapshot()` and the copy that is stored and
 * served, taken by {@see \SsSystems\Platform\Seo\Http\Concerns\ServesStoredSeoSnapshot}
 * and by `seo:snapshot-store`. A site's controller is not touched: the
 * block arrives with the kit.
 *
 * Everything it reads is already on the site, so the snapshot never waits
 * on a fetch:
 *
 *   - the findings the last `seo:health-check` stored ({@see SiteCheckStores});
 *   - Bing's counts, from the site's own Bing coverage controller — found
 *     by its route (`GET …/seo/bing-coverage`, the path the hub calls on
 *     every site), because that controller alone knows the site's models
 *     and the kit must not name an `App\` class;
 *   - the phone-speed measurements, when the site binds a PsiSnapshotReader.
 *
 * A source that is missing or throws reads as "not measured yet" for its
 * check. A site that sets `site_checks` itself keeps what it set — `false`
 * to show no card at all, the way `automated_actions: false` hides the
 * autopilot. And should building the block itself fail, the snapshot goes
 * out without it (the hub then shows no card) and the failure is reported
 * to the site's log: this block must never cost a site its SEO page.
 */
final class SiteCheckBlock
{
    public const KEY = 'site_checks';

    /**
     * @param  array<string, mixed>  $snapshot
     * @return array<string, mixed>
     */
    public static function attach(array $snapshot, ?Container $container = null): array
    {
        if (array_key_exists(self::KEY, $snapshot)) {
            return $snapshot;
        }

        $container ??= Container::getInstance();

        try {
            $snapshot[self::KEY] = SiteCheckSummary::build(
                $snapshot,
                self::quietly(fn (): ?array => SiteCheckStores::current($container)?->get()),
                self::quietly(fn (): ?array => self::bingCoverage($container)),
                self::quietly(fn (): ?array => self::phoneSpeed($container)),
            );
        } catch (\Throwable $e) {
            self::report($e);
        }

        return $snapshot;
    }

    /**
     * The counts the site's Bing coverage controller serves
     * (ServesBingCoverage::bingCoverageTotals()), or null on a site with
     * no such route.
     *
     * @return array<string, mixed>|null
     */
    private static function bingCoverage(Container $container): ?array
    {
        if (! $container->bound('router')) {
            return null;
        }

        foreach ($container->make('router')->getRoutes() as $route) {
            if (! in_array('GET', $route->methods(), true) || ! str_ends_with($route->uri(), 'seo/bing-coverage')) {
                continue;
            }

            $controller = $route->getControllerClass();

            if (is_string($controller) && method_exists($controller, 'bingCoverageTotals')) {
                return $container->make($controller)->bingCoverageTotals();
            }
        }

        return null;
    }

    /**
     * @return list<array<string, mixed>>|null
     */
    private static function phoneSpeed(Container $container): ?array
    {
        if (! $container->bound(PsiSnapshotReader::class)) {
            return null;
        }

        return $container->make(PsiSnapshotReader::class)->snapshots(
            Carbon::today()->subDays(SiteCheckThresholds::SPEED_WINDOW_DAYS - 1)->toDateString(),
            Carbon::today()->toDateString(),
        );
    }

    /**
     * @param  callable(): ?array<mixed>  $read
     * @return array<mixed>|null
     */
    private static function quietly(callable $read): ?array
    {
        try {
            return $read();
        } catch (\Throwable $e) {
            self::report($e);

            return null;
        }
    }

    /** Into the site's own log when there is one; the kit carries no logger of its own. */
    private static function report(\Throwable $e): void
    {
        if (function_exists('report')) {
            report($e);
        }
    }
}
