<?php

namespace SsSystems\Platform\Seo\Checks;

/**
 * The little HTML reading the page checks need: a page's meta tags, its
 * links and its footer. Regular expressions over the fetched body, the way
 * HealthCheckReport already reads the title and the description — these
 * pages are the sites' own Blade output, not arbitrary markup, and the kit
 * carries no DOM dependency.
 */
final class PageMarkup
{
    /**
     * A tag's attributes up to its closing ">", stepping over quoted
     * values: a Tailwind class such as "[&>svg]:size-4" or a description
     * reading "3 > 2" holds a ">" that does not end the tag.
     */
    private const ATTRIBUTES = '(?:[^>"\']++|"[^"]*+"|\'[^\']*+\')*+';

    /**
     * The markup a browser acts on: comments, scripts, styles, templates
     * and <noscript> fallbacks taken out, so a tag that is commented out,
     * or quoted inside a script's text, is never read as the page's own.
     */
    private static function live(string $html): string
    {
        $html = preg_replace('/<!--.*?-->/s', ' ', $html) ?? $html;

        return preg_replace('#<(script|style|template|noscript)\b[^>]*>.*?</\1>#is', ' ', $html) ?? $html;
    }

    /**
     * Every `<meta>` tag as its attributes, names lowercased, values
     * entity-decoded and trimmed.
     *
     * @return list<array<string, string>>
     */
    public static function metaTags(string $html): array
    {
        if (! preg_match_all('#<meta\b('.self::ATTRIBUTES.')>#i', self::live($html), $matches)) {
            return [];
        }

        return array_map(self::attributes(...), $matches[1]);
    }

    /**
     * The content of the first meta tag named $name — by `name` or by
     * `property`, since Open Graph tags are written both ways — or null
     * when there is none or it is empty.
     *
     * @param  list<array<string, string>>  $metas
     */
    public static function metaContent(array $metas, string $name): ?string
    {
        foreach ($metas as $meta) {
            $key = strtolower($meta['property'] ?? $meta['name'] ?? '');

            if ($key === strtolower($name) && ($meta['content'] ?? '') !== '') {
                return $meta['content'];
            }
        }

        return null;
    }

    /**
     * Every link with somewhere to go: its href and the words a person
     * reads on it (its text, or its aria-label/title when it is an icon).
     *
     * @return list<array{href: string, text: string}>
     */
    public static function anchors(string $html): array
    {
        if (! preg_match_all('#<a\b('.self::ATTRIBUTES.')>(.*?)</a>#is', self::live($html), $matches, PREG_SET_ORDER)) {
            return [];
        }

        $anchors = [];

        foreach ($matches as $match) {
            $attributes = self::attributes($match[1]);
            $href = $attributes['href'] ?? '';

            if ($href === '') {
                continue;
            }

            $text = trim((string) preg_replace('/\s+/u', ' ', html_entity_decode(strip_tags($match[2]), ENT_QUOTES | ENT_HTML5, 'UTF-8')));

            $anchors[] = [
                'href' => $href,
                'text' => $text !== '' ? $text : ($attributes['aria-label'] ?? $attributes['title'] ?? ''),
            ];
        }

        return $anchors;
    }

    /** What sits inside the page's `<footer>` elements, or null when it has none. */
    public static function footer(string $html): ?string
    {
        if (! preg_match_all('#<footer\b'.self::ATTRIBUTES.'>(.*?)</footer>#is', self::live($html), $matches)) {
            return null;
        }

        return implode(' ', $matches[1]);
    }

    /**
     * A response header's values whatever case the server sent its name in
     * (PageFetchResult keeps Laravel's own name => list of values shape).
     *
     * @param  array<string, array<int, string>|string>  $headers
     * @return list<string>
     */
    public static function header(array $headers, string $name): array
    {
        $values = [];

        foreach ($headers as $key => $value) {
            if (strcasecmp((string) $key, $name) === 0) {
                foreach ((array) $value as $line) {
                    $values[] = (string) $line;
                }
            }
        }

        return $values;
    }

    /**
     * @return array<string, string>
     */
    private static function attributes(string $tag): array
    {
        if (! preg_match_all('/([a-zA-Z_:][-a-zA-Z0-9_:.]*)\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s"\'>]+))/', $tag, $matches, PREG_SET_ORDER)) {
            return [];
        }

        $attributes = [];

        foreach ($matches as $match) {
            $value = $match[2] !== '' ? $match[2] : ($match[3] ?? '');
            if ($value === '' && isset($match[4])) {
                $value = $match[4];
            }

            $attributes[strtolower($match[1])] ??= trim(html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
        }

        return $attributes;
    }
}
