<?php

namespace SsSystems\Platform\Seo\Checks;

use SsSystems\Platform\Reports\JsonLd;

/**
 * What a visitor — and Google — expects to find from a business's home
 * page: a privacy policy, a phone number that can be tapped, a way to the
 * contact page, and markup saying who the business is. Read from the home
 * page's HTML alone; nothing here fetches anything.
 *
 * Each reading says where it found the thing, so a finding can state
 * exactly what was (or was not) on the page:
 *
 *   - Privacy: a link whose address or wording says "privacy". Looked for
 *     in the page's `<footer>` first ("footer"); a page with the link only
 *     elsewhere still passes ("page") — it is reachable from the home page,
 *     and a layout whose footer is not a `<footer>` element must not read
 *     as a missing policy.
 *   - Phone: any `tel:` link. Its digits are NOT compared with the site's
 *     configured number: a call-tracking number is a different number on
 *     purpose. Only asked of a site that has a phone number at all.
 *   - Contact: a link to a page whose address or wording says "contact"
 *     (or "get in touch"). A link to a contact section of the home page
 *     itself counts ("section"); a mailto: or tel: link is not a page.
 *   - Business details: an Organization/LocalBusiness-family node
 *     ({@see ReviewMarkup::BUSINESS_TYPES}) with a name — and, for a local
 *     business, a phone or an address. A plain Organization (a software
 *     product's maker, say) needs only its name.
 */
final class SiteBasics
{
    /** Business types that describe a company rather than a place customers call or visit. */
    private const NOT_LOCAL = [
        'Organization', 'Corporation', 'OnlineBusiness', 'OnlineStore', 'NGO', 'Cooperative',
        'EducationalOrganization', 'GovernmentOrganization', 'NewsMediaOrganization', 'PerformingGroup',
        'SportsOrganization', 'ResearchOrganization', 'Consortium', 'WorkersUnion',
    ];

    /**
     * @return array{
     *     privacy: array{found: bool, where: ?string, href: ?string},
     *     phone: array{found: bool, href: ?string},
     *     contact: array{found: bool, kind: ?string, href: ?string},
     *     business: array{found: bool, type: ?string, missing: list<string>},
     * }
     */
    public static function inspect(string $html): array
    {
        $anchors = PageMarkup::anchors($html);
        $footer = PageMarkup::footer($html);

        return [
            'privacy' => self::privacy($anchors, $footer !== null ? PageMarkup::anchors($footer) : []),
            'phone' => self::phone($anchors),
            'contact' => self::contact($anchors),
            'business' => self::business($html),
        ];
    }

    /**
     * @param  list<array{href: string, text: string}>  $anchors
     * @param  list<array{href: string, text: string}>  $footerAnchors
     * @return array{found: bool, where: ?string, href: ?string}
     */
    private static function privacy(array $anchors, array $footerAnchors): array
    {
        $isPrivacy = fn (array $a): bool => preg_match('/privacy|prywatno/i', $a['href'].' '.$a['text']) === 1;

        foreach (['footer' => $footerAnchors, 'page' => $anchors] as $where => $list) {
            foreach ($list as $anchor) {
                if ($isPrivacy($anchor)) {
                    return ['found' => true, 'where' => $where, 'href' => $anchor['href']];
                }
            }
        }

        return ['found' => false, 'where' => null, 'href' => null];
    }

    /**
     * @param  list<array{href: string, text: string}>  $anchors
     * @return array{found: bool, href: ?string}
     */
    private static function phone(array $anchors): array
    {
        foreach ($anchors as $anchor) {
            if (stripos(trim($anchor['href']), 'tel:') === 0 && preg_match('/\d/', $anchor['href'])) {
                return ['found' => true, 'href' => $anchor['href']];
            }
        }

        return ['found' => false, 'href' => null];
    }

    /**
     * @param  list<array{href: string, text: string}>  $anchors
     * @return array{found: bool, kind: ?string, href: ?string}
     */
    private static function contact(array $anchors): array
    {
        $section = null;

        foreach ($anchors as $anchor) {
            $href = trim($anchor['href']);

            if (preg_match('/^(mailto|tel|sms|javascript):/i', $href)) {
                continue;
            }

            $path = (string) parse_url($href, PHP_URL_PATH);
            $fragment = (string) parse_url($href, PHP_URL_FRAGMENT);
            $worded = preg_match('/\bcontact|get in touch|kontakt/i', $anchor['text']) === 1;

            if (preg_match('/contact|kontakt/i', $path) || ($worded && $path !== '' && $path !== '/')) {
                return ['found' => true, 'kind' => 'page', 'href' => $href];
            }

            if ($section === null && (preg_match('/contact|kontakt/i', $fragment) || ($worded && $fragment !== ''))) {
                $section = $href;
            }
        }

        return $section !== null
            ? ['found' => true, 'kind' => 'section', 'href' => $section]
            : ['found' => false, 'kind' => null, 'href' => null];
    }

    /**
     * The home page's most complete business node and what it leaves out.
     *
     * @return array{found: bool, type: ?string, missing: list<string>}
     */
    private static function business(string $html): array
    {
        $best = null;

        foreach (JsonLd::blocks($html) as $raw) {
            $data = json_decode($raw, true);

            if (! is_array($data)) {
                continue;
            }

            JsonLd::walk($data, function (array $node) use (&$best): void {
                $types = array_map(
                    fn ($type): string => is_string($type) ? (string) preg_replace('#^(https?://schema\.org/|schema:)#i', '', $type) : '',
                    (array) $node['@type'],
                );
                $business = array_values(array_intersect($types, ReviewMarkup::BUSINESS_TYPES));

                if ($business === []) {
                    return;
                }

                $missing = [];

                if (! self::filled($node['name'] ?? null)) {
                    $missing[] = 'name';
                }

                $local = array_diff($business, self::NOT_LOCAL) !== [];
                $phone = self::filled($node['telephone'] ?? null) || self::filled(self::contactPointPhone($node));

                if ($local && ! $phone && ! self::filled($node['address'] ?? null)) {
                    $missing[] = 'phone or address';
                }

                if ($best === null || count($missing) < count($best['missing'])) {
                    $best = ['found' => true, 'type' => $business[0], 'missing' => $missing];
                }
            });
        }

        return $best ?? ['found' => false, 'type' => null, 'missing' => []];
    }

    /** @param  array<string, mixed>  $node */
    private static function contactPointPhone(array $node): mixed
    {
        $points = $node['contactPoint'] ?? null;

        if (! is_array($points)) {
            return null;
        }

        foreach (array_is_list($points) ? $points : [$points] as $point) {
            if (is_array($point) && self::filled($point['telephone'] ?? null)) {
                return $point['telephone'];
            }
        }

        return null;
    }

    private static function filled(mixed $value): bool
    {
        return is_array($value) ? $value !== [] : trim((string) $value) !== '';
    }
}
