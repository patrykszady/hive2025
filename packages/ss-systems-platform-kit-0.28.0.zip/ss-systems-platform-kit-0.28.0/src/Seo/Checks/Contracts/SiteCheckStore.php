<?php

namespace SsSystems\Platform\Seo\Checks\Contracts;

/**
 * Where the site checks' findings are kept between the health-check that
 * produces them and the SEO snapshot that reads them.
 *
 * The findings ride on the health-check's page fetches, and that report
 * runs on a schedule (about once a day, see each site's
 * `seo:reports-refresh`); the snapshot is built every 15 minutes and on
 * every Refresh click and must never fetch a page while the hub waits. So
 * the report writes what it found here and the snapshot only ever reads
 * it.
 *
 * OPTIONAL to bind. A site that binds nothing gets
 * {@see \SsSystems\Platform\Seo\Checks\LocalSiteCheckStore} — one JSON
 * file beside the report's own markdown, under the site's
 * `Reports\Contracts\ReportStorage` path, so a multi-tenant site's
 * findings are scoped exactly as its reports already are
 * ({@see \SsSystems\Platform\Seo\Checks\SiteCheckStores::current()}). Bind
 * this only to keep them somewhere else.
 *
 * Capability key: n/a — infrastructure, like ReportStorage.
 */
interface SiteCheckStore
{
    /**
     * Replaces the stored findings with this run's.
     *
     * @param  array<string, mixed>  $checks  what SiteCheckRun::result() returned
     */
    public function put(array $checks): void;

    /**
     * The findings of the last run, or null when none has been stored.
     *
     * @return array<string, mixed>|null
     */
    public function get(): ?array;
}
