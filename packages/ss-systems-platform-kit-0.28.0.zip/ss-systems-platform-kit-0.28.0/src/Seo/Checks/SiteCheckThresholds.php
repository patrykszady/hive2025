<?php

namespace SsSystems\Platform\Seo\Checks;

/**
 * Where a site check turns amber and where it turns red — the one place
 * these numbers live. The health-check's findings and the snapshot's
 * `site_checks` summary both ask this class, so the report and the hub's
 * card can never grade the same fact differently.
 *
 * Red means "this is costing you visitors now", amber means "worth
 * fixing", green means every measured check in the group passed. A group
 * with nothing measured is "not measured yet": never green, never red.
 * Wherever the data already had a threshold of its own, that threshold is
 * used unchanged; the column on the right says where each comes from.
 *
 * | Check                              | Amber                                             | Red                                               | The threshold comes from |
 * |------------------------------------|---------------------------------------------------|---------------------------------------------------|--------------------------|
 * | Sitemap                            | Google's state is warnings, stale or none         | Google's state is errors                          | SitemapStatus::state(), the words the Sitemap card already shows |
 * | Pages Google has checked           | any page it could not open or may not read; half or more of the checked pages read but not shown | never                | the trouble card's own buckets; NOT_SHOWN_SHARE |
 * | Pages Bing has checked             | any page it could not open; half or more of the answered pages never read | never                     | the Bing card's own statuses; BING_UNREAD_SHARE |
 * | Search engine access               | never                                             | Google or Bing shut out of the whole site         | robots.txt, whole-site rule only (RobotsTxt) |
 * | Sitemap pages hidden from Google   | any sitemap page marked noindex                   | the home page, or half or more of the pages       | SITE_WIDE_SHARE |
 * | Page titles                        | any page outside 30–60 characters                 | never                                             | HealthCheckReport's own gate |
 * | Search descriptions                | any page outside 70–160 characters                | never                                             | HealthCheckReport's own gate |
 * | Main headings                      | any page without exactly one H1                   | never                                             | HealthCheckReport's own gate |
 * | Link previews                      | any page missing a share title, description or image | never                                          | presence only |
 * | Structured data                    | any page with none, or with a block that cannot be read; a detail missing is a note | never           | HealthCheckReport's own gate; SchemaAuditReport's rules mix required and recommended |
 * | Review markup                      | never — a note, it does not colour the group      | never                                             | kept on purpose on some sites |
 * | Business details on the home page  | no business markup, or its name (or phone and address) missing | never                                | presence only |
 * | Google Business Profile activity   | the health pillar scores 60–79                    | the pillar scores under 60                        | the pillar colours in BuildsSeoSnapshot::healthSnapshot() |
 * | Site summary for AI assistants     | a feed is stale                                   | a feed is missing                                 | the feeds' own ok/stale flags, the dots the AI card shows |
 * | AI assistant access                | an assistant's crawler shut out of the whole site | never                                             | robots.txt, whole-site rule only |
 * | Privacy policy link                | no link on the home page                          | never                                             | presence only |
 * | Tap-to-call phone number           | the site has a number and no tel: link            | never                                             | presence only |
 * | Contact page link                  | no link on the home page                          | never                                             | presence only |
 * | Speed on phones                    | the typical page is not "good", or any page is "poor" | the typical page is "poor"                    | Google's own bands: score 90 / 50, largest paint 2.5 s / 4 s |
 * | Fit on phone screens               | any page without the viewport tag                 | the home page, or half or more of the pages       | SITE_WIDE_SHARE |
 *
 * "Typical" is the median of the pages measured in the last
 * SPEED_WINDOW_DAYS days, each page taken at its own median over those
 * days, on the mobile strategy.
 */
final class SiteCheckThresholds
{
    public const RED = 'red';

    public const AMBER = 'amber';

    /** A finding worth knowing that does not change a group's colour. */
    public const NOTE = 'note';

    /** A page-level fault found on this share of the checked pages is the template's, not a stray page's. */
    public const SITE_WIDE_SHARE = 0.5;

    /** Google has read this share of the pages it checked and shows none of them. */
    public const NOT_SHOWN_SHARE = 0.5;

    /** Bing answered for this share of the sitemap and has never read them. */
    public const BING_UNREAD_SHARE = 0.5;

    /** The health pillars' own bands: 80 and up green, 60–79 amber, under 60 red. */
    public const PILLAR_GREEN = 80;

    public const PILLAR_AMBER = 60;

    /** Google's speed test: a score of 90 and up is good, under 50 poor. */
    public const SPEED_GOOD_SCORE = 90;

    public const SPEED_POOR_SCORE = 50;

    /** Largest contentful paint: up to 2.5 s is good, over 4 s poor. */
    public const LCP_GOOD_MS = 2500;

    public const LCP_POOR_MS = 4000;

    /** How far back phone-speed measurements count. */
    public const SPEED_WINDOW_DAYS = 14;

    /**
     * A page-level check: nothing when no page fails, amber when any does.
     * Red only for a check that takes pages out of reach ($canBeRed) and
     * only when the home page fails or the fault is site-wide.
     */
    public static function pages(int $failed, int $checked, bool $canBeRed = false, bool $homePageFails = false): ?string
    {
        if ($failed <= 0) {
            return null;
        }

        if ($canBeRed && ($homePageFails || self::share($failed, $checked, self::SITE_WIDE_SHARE))) {
            return self::RED;
        }

        return self::AMBER;
    }

    /** Whether $part is at least $threshold of $whole. */
    public static function share(int $part, int $whole, float $threshold): bool
    {
        return $whole > 0 && $part / $whole >= $threshold;
    }

    /** A health pillar's score: nothing at 80 and up, amber from 60, red below. */
    public static function pillar(int $score): ?string
    {
        return match (true) {
            $score >= self::PILLAR_GREEN => null,
            $score >= self::PILLAR_AMBER => self::AMBER,
            default => self::RED,
        };
    }

    /**
     * One page's (or the typical page's) phone speed in Google's bands:
     * 'good', 'slow' (needs improvement) or 'poor'. The worse of the score
     * and the largest paint decides; a missing one is left out, and null
     * means neither was measured.
     */
    public static function speedBand(?int $score, ?int $lcpMs): ?string
    {
        $bands = [];

        if ($score !== null) {
            $bands[] = $score >= self::SPEED_GOOD_SCORE ? 'good' : ($score >= self::SPEED_POOR_SCORE ? 'slow' : 'poor');
        }

        if ($lcpMs !== null) {
            $bands[] = $lcpMs <= self::LCP_GOOD_MS ? 'good' : ($lcpMs <= self::LCP_POOR_MS ? 'slow' : 'poor');
        }

        return match (true) {
            $bands === [] => null,
            in_array('poor', $bands, true) => 'poor',
            in_array('slow', $bands, true) => 'slow',
            default => 'good',
        };
    }
}
