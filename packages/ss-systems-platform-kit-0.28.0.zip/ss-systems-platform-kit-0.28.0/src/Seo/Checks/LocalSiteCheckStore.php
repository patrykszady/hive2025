<?php

namespace SsSystems\Platform\Seo\Checks;

use Illuminate\Contracts\Filesystem\Filesystem;
use SsSystems\Platform\Reports\Contracts\ReportStorage;
use SsSystems\Platform\Seo\Checks\Contracts\SiteCheckStore;

/**
 * The site checks' findings as one JSON file on the site's local disk, at
 * `reports/site-checks.json` — next to `reports/health-check.md`, the
 * markdown of the run that produced them, and through the same
 * {@see ReportStorage} path, so gs.construction's tenant-scoped storage
 * keeps one tenant's findings out of another's exactly as it does their
 * reports. The default every site gets without binding anything.
 *
 * A file that is missing, empty or not the JSON this class wrote reads as
 * "no findings stored": the summary then says "not measured yet".
 */
final class LocalSiteCheckStore implements SiteCheckStore
{
    public const PATH = 'reports/site-checks.json';

    public function __construct(
        private readonly Filesystem $disk,
        private readonly ReportStorage $storage,
    ) {}

    public function put(array $checks): void
    {
        $this->disk->put(
            $this->storage->path(self::PATH),
            (string) json_encode($checks, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
        );
    }

    public function get(): ?array
    {
        $path = $this->storage->path(self::PATH);

        if (! $this->disk->exists($path)) {
            return null;
        }

        $checks = json_decode((string) $this->disk->get($path), true);

        return is_array($checks) && isset($checks['findings']) ? $checks : null;
    }
}
