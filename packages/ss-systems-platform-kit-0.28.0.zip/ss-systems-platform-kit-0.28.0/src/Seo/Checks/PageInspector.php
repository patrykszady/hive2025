<?php

namespace SsSystems\Platform\Seo\Checks;

use SsSystems\Platform\Reports\JsonLd;
use SsSystems\Platform\Reports\PageFetchResult;

/**
 * What one fetched page says about itself, beyond the eight scored checks
 * of the health-check: whether it asks Google not to list it, what a link
 * to it looks like when it is texted or shared, whether a phone will fit
 * it to its screen, whether its structured data can be read, and what its
 * review markup is about. Pure reading of a response the health-check
 * already has — it never fetches, so a page is still requested once.
 *
 * Only the facts live here; whether a fact is a fault (a noindex page is
 * one only when the sitemap lists it) is {@see SiteCheckRun}'s call.
 */
final class PageInspector
{
    /** X-Robots-Tag directives that take a value after a colon — not a crawler's name. */
    private const VALUED_DIRECTIVES = ['unavailable_after', 'max-snippet', 'max-image-preview', 'max-video-preview'];

    public function __construct(private readonly string $siteHost) {}

    /**
     * @return array{
     *     noindex: list<string>,
     *     preview: list<string>,
     *     viewport: bool,
     *     schema: array{blocks: int, unreadable: int, issues: list<string>},
     *     reviews: array{own: list<array<string, mixed>>, other: list<array<string, mixed>>},
     * }
     */
    public function inspect(PageFetchResult $fetch): array
    {
        $metas = PageMarkup::metaTags($fetch->body);
        $documents = [];
        $unreadable = 0;
        $issues = [];
        $blocks = JsonLd::blocks($fetch->body);

        foreach ($blocks as $raw) {
            $data = json_decode($raw, true);

            if (! is_array($data)) {
                $unreadable++;

                continue;
            }

            $documents[] = $data;
            JsonLd::validateNode($data, $issues);
        }

        return [
            'noindex' => $this->noindex($metas, $fetch->headers),
            'preview' => $this->previewGaps($metas),
            'viewport' => $this->fitsPhones($metas),
            'schema' => ['blocks' => count($blocks), 'unreadable' => $unreadable, 'issues' => array_values(array_unique($issues))],
            'reviews' => ReviewMarkup::classify($documents, $this->siteHost),
        ];
    }

    /**
     * Where the page tells Google not to list it: a `robots` or
     * `googlebot` meta tag, or an `X-Robots-Tag` response header, saying
     * `noindex` (or `none`, which means noindex and nofollow). A tag or a
     * header addressed to another crawler — `bingbot`, say — is not
     * Google's business and is left out.
     *
     * @param  list<array<string, string>>  $metas
     * @param  array<string, array<int, string>>  $headers
     * @return list<string> e.g. ["robots meta tag", "X-Robots-Tag header"]; [] when the page may be listed
     */
    private function noindex(array $metas, array $headers): array
    {
        $sources = [];

        foreach ($metas as $meta) {
            $name = strtolower($meta['name'] ?? '');

            if (in_array($name, ['robots', 'googlebot'], true) && $this->saysNoindex($meta['content'] ?? '')) {
                $sources[] = $name.' meta tag';
            }
        }

        foreach (PageMarkup::header($headers, 'X-Robots-Tag') as $value) {
            $value = trim($value);

            if (preg_match('/^([a-z0-9_\-]+)\s*:\s*(.*)$/i', $value, $m) && ! in_array(strtolower($m[1]), self::VALUED_DIRECTIVES, true)) {
                if (strtolower($m[1]) !== 'googlebot') {
                    continue;
                }

                $value = $m[2];
            }

            if ($this->saysNoindex($value)) {
                $sources[] = 'X-Robots-Tag header';
            }
        }

        return array_values(array_unique($sources));
    }

    private function saysNoindex(string $directives): bool
    {
        $tokens = array_map(fn (string $token): string => strtolower(trim($token)), explode(',', $directives));

        return in_array('noindex', $tokens, true) || in_array('none', $tokens, true);
    }

    /**
     * What a shared link to this page would lack: a title (`og:title`), a
     * description (`og:description`, or the page's own meta description to
     * fall back on) and a picture (`og:image`) given as a full web address
     * — a relative one cannot be loaded by the app drawing the preview.
     * The picture itself is never requested.
     *
     * @param  list<array<string, string>>  $metas
     * @return list<string> [] when the preview is complete
     */
    private function previewGaps(array $metas): array
    {
        $gaps = [];

        if (PageMarkup::metaContent($metas, 'og:title') === null) {
            $gaps[] = 'no share title';
        }

        if (PageMarkup::metaContent($metas, 'og:description') === null && PageMarkup::metaContent($metas, 'description') === null) {
            $gaps[] = 'no share description';
        }

        $image = PageMarkup::metaContent($metas, 'og:image')
            ?? PageMarkup::metaContent($metas, 'og:image:secure_url')
            ?? PageMarkup::metaContent($metas, 'og:image:url');

        if ($image === null) {
            $gaps[] = 'no share image';
        } elseif (! $this->isFullWebAddress($image)) {
            $gaps[] = 'share image is not a full web address';
        }

        return $gaps;
    }

    private function isFullWebAddress(string $url): bool
    {
        $parts = parse_url(trim($url));

        return is_array($parts)
            && in_array(strtolower($parts['scheme'] ?? ''), ['http', 'https'], true)
            && ($parts['host'] ?? '') !== ''
            && ! preg_match('/\s/', trim($url));
    }

    /**
     * The viewport meta tag — the line that tells a phone to fit the page
     * to its screen instead of drawing a shrunken desktop page.
     *
     * @param  list<array<string, string>>  $metas
     */
    private function fitsPhones(array $metas): bool
    {
        $viewport = strtolower((string) PageMarkup::metaContent($metas, 'viewport'));

        return str_contains($viewport, 'width=device-width') || str_contains($viewport, 'initial-scale');
    }
}
