<?php

namespace SsSystems\Platform\Seo\Checks;

/**
 * Every word the site checks say to an owner: the five groups of the
 * summary, the name of each check, and for each fault its one-line title
 * and its one-sentence fix. One file, so the health-check report's
 * findings, its markdown and the snapshot's `site_checks` block read the
 * same everywhere, and so the wording can be reviewed in one sitting.
 *
 * Written for a contractor or a realtor, not for an SEO: sentence case, no
 * exclamation marks, no grades, and no term of the trade without the plain
 * words beside it ("the “do not list” tag (noindex)"). The ss.systems SEO
 * page keeps vendor and pipeline names out of what an owner reads first,
 * so none appears here either — the AI summary files are never called by
 * their file names, and Google's speed test is "Google's phone speed test".
 *
 * `group` places a check in the summary; `check` is its name in a "not
 * measured yet" list and in the report's table; `title` and `fix` are
 * shown when it fails.
 */
final class SiteCheckCatalog
{
    /** @var array<string, array{title: string, about: string}> in the order the summary shows them */
    public const GROUPS = [
        'findable' => [
            'title' => 'Can Google find you',
            'about' => 'Whether search engines can reach your pages and are allowed to list them.',
        ],
        'appearance' => [
            'title' => 'How you look in Google',
            'about' => 'What people see when one of your pages comes up in a search or is shared.',
        ],
        'business' => [
            'title' => 'Business information',
            'about' => 'The facts Google and AI assistants read about your business.',
        ],
        'trust' => [
            'title' => 'Trust and getting in touch',
            'about' => 'Whether a visitor can see you are a real business and reach you.',
        ],
        'speed' => [
            'title' => 'Speed and phones',
            'about' => 'How fast your pages open on a phone and whether they fit its screen.',
        ],
    ];

    /** @var array<string, array{group: string, check: string, title: string, fix: string}> */
    public const ISSUES = [
        // Can Google find you
        'sitemap_errors' => [
            'group' => 'findable', 'check' => 'Sitemap',
            'title' => 'Google found errors in your sitemap',
            'fix' => 'Fix the pages Google flagged in your sitemap, the list of pages you hand it, then send the sitemap again.',
        ],
        'sitemap_warnings' => [
            'group' => 'findable', 'check' => 'Sitemap',
            'title' => 'Google flagged some pages in your sitemap',
            'fix' => 'Check the flagged pages in your sitemap, the list of pages you hand Google, and fix or remove them.',
        ],
        'sitemap_stale' => [
            'group' => 'findable', 'check' => 'Sitemap',
            'title' => 'Google has not re-read your sitemap in over a week',
            'fix' => 'Send your sitemap, the list of pages you hand Google, again so it picks up new and changed pages.',
        ],
        'sitemap_none' => [
            'group' => 'findable', 'check' => 'Sitemap',
            'title' => 'No sitemap has been handed to Google yet',
            'fix' => 'Send Google your sitemap, the list of pages you want it to read.',
        ],
        'google_cannot_open' => [
            'group' => 'findable', 'check' => 'Pages Google has checked',
            'title' => 'Pages Google could not open',
            'fix' => 'Fix or redirect these pages so they open normally, then ask Google to look again.',
        ],
        'google_blocked' => [
            'group' => 'findable', 'check' => 'Pages Google has checked',
            'title' => 'Pages Google is not allowed to read',
            'fix' => 'If these pages should be found in a search, remove the rule that blocks Google from them.',
        ],
        'google_not_showing' => [
            'group' => 'findable', 'check' => 'Pages Google has checked',
            'title' => 'Pages Google has read but is not showing',
            'fix' => 'Add detail people cannot find elsewhere to these pages and link to them from your main pages, so Google sees them as worth showing.',
        ],
        'bing_cannot_open' => [
            'group' => 'findable', 'check' => 'Pages Bing has checked',
            'title' => 'Pages Bing could not open',
            'fix' => 'Fix or redirect these pages so they open normally; Bing checks them again by itself.',
        ],
        'bing_not_read' => [
            'group' => 'findable', 'check' => 'Pages Bing has checked',
            'title' => 'Pages Bing has not read yet',
            'fix' => 'Link to these pages from your main pages and send your sitemap to Bing, so it knows to come and read them.',
        ],
        'search_engine_access' => [
            'group' => 'findable', 'check' => 'Search engine access',
            'title' => 'Search engines are told to stay out of your whole site',
            'fix' => 'Change the site\'s crawler rules file (robots.txt) so Google and Bing are allowed in.',
        ],
        'noindex_in_sitemap' => [
            'group' => 'findable', 'check' => 'Sitemap pages hidden from Google',
            'title' => 'Pages in your sitemap that tell Google not to list them',
            'fix' => 'Take the “do not list” tag (noindex) off these pages, or take them out of the sitemap; a page should say one thing to Google.',
        ],

        // How you look in Google
        'titles' => [
            'group' => 'appearance', 'check' => 'Page titles',
            'title' => 'Page titles that are too short or too long',
            'fix' => 'Rewrite these titles to between 30 and 60 characters so Google shows them in full.',
        ],
        'descriptions' => [
            'group' => 'appearance', 'check' => 'Search descriptions',
            'title' => 'Search descriptions that are missing, too short or too long',
            'fix' => 'Give each of these pages a description of 70 to 160 characters; it is the text under your link in Google.',
        ],
        'headings' => [
            'group' => 'appearance', 'check' => 'Main headings',
            'title' => 'Pages without one clear main heading',
            'fix' => 'Give each of these pages exactly one main heading (the H1) that says what the page is about.',
        ],
        'link_preview' => [
            'group' => 'appearance', 'check' => 'Link previews',
            'title' => 'Pages that look bare when their link is texted or shared',
            'fix' => 'Add a share title, a description and a picture (the Open Graph tags) to these pages, with the picture given as a full web address.',
        ],
        'structured_data_missing' => [
            'group' => 'appearance', 'check' => 'Structured data',
            'title' => 'Pages with no structured data',
            'fix' => 'Add structured data, the labels that tell Google what a page is about, to these pages.',
        ],
        'structured_data_unreadable' => [
            'group' => 'appearance', 'check' => 'Readable structured data',
            'title' => 'Structured data Google cannot read',
            'fix' => 'Correct the broken structured data on these pages; Google ignores a block it cannot read.',
        ],
        'structured_data_incomplete' => [
            'group' => 'appearance', 'check' => 'Complete structured data',
            'title' => 'Structured data with details missing',
            'fix' => 'Check the details listed for each of these pages and fill in the ones that apply; not every one is required.',
        ],
        'review_markup' => [
            'group' => 'appearance', 'check' => 'Review markup',
            'title' => 'Ratings placed on your own business',
            'fix' => 'Google does not show stars for a rating a business publishes about itself, so review whether to keep it there; a rating on a particular service or product can still earn stars.',
        ],

        // Business information
        'business_details_missing' => [
            'group' => 'business', 'check' => 'Business details on the home page',
            'title' => 'Your home page does not tell Google who the business is',
            'fix' => 'Add your business name, phone and address to the home page as structured data, the labels Google and AI assistants read.',
        ],
        'business_details_incomplete' => [
            'group' => 'business', 'check' => 'Business details on the home page',
            'title' => 'The business details on your home page are incomplete',
            'fix' => 'Fill in what is missing from the business details on the home page so Google and AI assistants read them correctly.',
        ],
        'gbp_activity' => [
            'group' => 'business', 'check' => 'Google Business Profile activity',
            'title' => 'Your Google Business Profile has gone quiet',
            'fix' => 'Post an update or add recent photos to your Google Business Profile, and reply to new reviews.',
        ],
        'ai_summary_missing' => [
            'group' => 'business', 'check' => 'Site summary for AI assistants',
            'title' => 'The summary of your site that AI assistants read is missing',
            'fix' => 'Rebuild the plain-text summary of your site that AI assistants read; it should be rewritten every night.',
        ],
        'ai_summary_stale' => [
            'group' => 'business', 'check' => 'Site summary for AI assistants',
            'title' => 'The summary of your site that AI assistants read is out of date',
            'fix' => 'Find out why the nightly rewrite of your site\'s summary for AI assistants stopped, and run it again.',
        ],
        'ai_assistant_access' => [
            'group' => 'business', 'check' => 'AI assistant access',
            'title' => 'AI assistants are told to stay out of your whole site',
            'fix' => 'If you want ChatGPT, Claude and similar assistants to be able to recommend you, allow them in the site\'s crawler rules file (robots.txt).',
        ],

        // Trust and getting in touch
        'privacy_link' => [
            'group' => 'trust', 'check' => 'Privacy policy link',
            'title' => 'No privacy policy link on your home page',
            'fix' => 'Add a link to your privacy policy in the footer of every page.',
        ],
        'phone_link' => [
            'group' => 'trust', 'check' => 'Tap-to-call phone number',
            'title' => 'Your phone number cannot be tapped to call',
            'fix' => 'Make the phone number on your home page a tap-to-call link, so someone on a phone can ring you in one tap.',
        ],
        'contact_link' => [
            'group' => 'trust', 'check' => 'Contact page link',
            'title' => 'No link to a contact page on your home page',
            'fix' => 'Link to your contact page from the home page\'s menu or footer.',
        ],

        // Speed and phones
        'phone_speed' => [
            'group' => 'speed', 'check' => 'Speed on phones',
            'title' => 'Pages open slowly on phones',
            'fix' => 'Shrink large photos and drop scripts the pages do not need, starting with the slowest pages.',
        ],
        'phone_layout' => [
            'group' => 'speed', 'check' => 'Fit on phone screens',
            'title' => 'Pages that do not fit a phone screen',
            'fix' => 'Add the line that tells a phone to fit the page to its screen (the viewport tag) to these pages.',
        ],
    ];

    /** The name of the check an issue belongs to, e.g. "Sitemap". */
    public static function check(string $issue): string
    {
        return self::ISSUES[$issue]['check'];
    }
}
