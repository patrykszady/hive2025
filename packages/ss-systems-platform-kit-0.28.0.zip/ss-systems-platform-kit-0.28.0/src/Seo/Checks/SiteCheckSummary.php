<?php

namespace SsSystems\Platform\Seo\Checks;

/**
 * The site checks as five plain-language groups — the `site_checks` block
 * of GET seo/snapshot and the card at the top of the ss.systems SEO page:
 *
 *   - Can Google find you          the sitemap, the pages Google and Bing
 *                                  have checked, whether search engines are
 *                                  allowed in, sitemap pages marked noindex
 *   - How you look in Google       titles, descriptions, headings, the link
 *                                  preview, structured data, review markup
 *   - Business information         the business's markup on the home page,
 *                                  Google Business Profile activity, the
 *                                  site summary AI assistants read, whether
 *                                  AI assistants are allowed in
 *   - Trust and getting in touch   the privacy, phone and contact links
 *   - Speed and phones             Google's phone speed test, the viewport
 *
 * A pure function of what the site already holds: the snapshot's own
 * blocks (`sitemaps`, `gsc_errors`, `health`, `geo`), the findings the last
 * health-check stored ({@see SiteCheckRun}), Bing's counts and the stored
 * phone-speed measurements. It fetches nothing and runs no report, so it
 * costs the snapshot a file read and two small queries
 * ({@see SiteCheckBlock} gathers them).
 *
 * Each group is green, amber or red by its worst issue — the thresholds
 * are {@see SiteCheckThresholds}', documented there and nowhere else — or
 * "not measured yet" when none of its checks has anything to read: never
 * green on no evidence, never red. A group with some checks measured is
 * graded on those and lists the others by name under `not_measured`. A
 * check that does not apply to the site (the phone link on a site with no
 * phone number) is left out altogether. A note is listed with the issues
 * and never changes a group's colour.
 *
 * The wording is {@see SiteCheckCatalog}'s. The hub prints the block as
 * sent and holds no rule of its own.
 */
final class SiteCheckSummary
{
    public const VERSION = 1;

    /** How many example pages an issue carries to the hub. */
    public const EXAMPLES = 3;

    /**
     * @param  array<string, mixed>  $snapshot  the site's seo/snapshot data
     * @param  array<string, mixed>|null  $checks  the stored findings, null when no health-check has stored any
     * @param  array<string, mixed>|null  $bing  ServesBingCoverage::bingCoverageTotals(), null when the site has no Bing coverage
     * @param  list<array<string, mixed>>|null  $speed  PsiSnapshotReader rows of the last SPEED_WINDOW_DAYS days, null when the site keeps none
     * @return array{version: int, checked_at: ?string, pages_checked: ?int, headline: string, groups: list<array<string, mixed>>}
     */
    public static function build(array $snapshot, ?array $checks, ?array $bing = null, ?array $speed = null): array
    {
        // Findings written in another shape (an older or newer kit's) are not read as this one's.
        if ($checks !== null && ($checks['version'] ?? null) !== SiteCheckRun::VERSION) {
            $checks = null;
        }

        $readings = [
            'findable' => [
                self::sitemap($snapshot),
                self::googlePages($snapshot),
                self::bingPages($bing),
                self::finding($checks, 'search_engine_access'),
                self::finding($checks, 'noindex_in_sitemap'),
            ],
            'appearance' => [
                self::scored($checks, 'title', 'titles'),
                self::scored($checks, 'description', 'descriptions'),
                self::scored($checks, 'h1', 'headings'),
                self::finding($checks, 'link_preview'),
                self::structuredData($checks),
                self::finding($checks, 'review_markup'),
            ],
            'business' => [
                self::finding($checks, 'business_details', 'business_details_missing'),
                self::businessProfile($snapshot),
                self::aiSummary($snapshot),
                self::finding($checks, 'ai_assistant_access'),
            ],
            'trust' => [
                self::finding($checks, 'privacy_link'),
                self::finding($checks, 'phone_link'),
                self::finding($checks, 'contact_link'),
            ],
            'speed' => [
                self::phoneSpeed($speed),
                self::finding($checks, 'phone_layout'),
            ],
        ];

        $groups = [];
        foreach (SiteCheckCatalog::GROUPS as $key => $copy) {
            $groups[] = self::group($key, $copy, $readings[$key]);
        }

        return [
            'version' => self::VERSION,
            'checked_at' => is_string($checks['generated_at'] ?? null) ? $checks['generated_at'] : null,
            'pages_checked' => isset($checks['pages_checked']) ? (int) $checks['pages_checked'] : null,
            'headline' => self::headline($groups),
            'groups' => $groups,
        ];
    }

    /**
     * One group: its colour, its counts and its issues, worst first.
     *
     * @param  array{title: string, about: string}  $copy
     * @param  list<array{check: string, measured: ?bool, issues: list<array<string, mixed>>}>  $readings
     * @return array<string, mixed>
     */
    private static function group(string $key, array $copy, array $readings): array
    {
        $issues = [];
        $passed = [];
        $notMeasured = [];

        foreach ($readings as $reading) {
            if ($reading['measured'] === null) {
                continue;
            }

            if ($reading['measured'] === false) {
                $notMeasured[$reading['check']] = true;

                continue;
            }

            if (array_filter($reading['issues'], fn (array $issue): bool => $issue['severity'] !== SiteCheckThresholds::NOTE) === []) {
                $passed[$reading['check']] = true;
            }

            $issues = [...$issues, ...$reading['issues']];
        }

        $rank = [SiteCheckThresholds::RED => 0, SiteCheckThresholds::AMBER => 1, SiteCheckThresholds::NOTE => 2];
        usort($issues, fn (array $a, array $b): int => $rank[$a['severity']] <=> $rank[$b['severity']]);

        $severities = array_column($issues, 'severity');
        $faults = count(array_filter($severities, fn (string $s): bool => $s !== SiteCheckThresholds::NOTE));
        $notes = count($severities) - $faults;
        $measured = $passed !== [] || $issues !== [];

        $status = match (true) {
            ! $measured => 'not_measured',
            in_array(SiteCheckThresholds::RED, $severities, true) => 'red',
            in_array(SiteCheckThresholds::AMBER, $severities, true) => 'amber',
            default => 'green',
        };

        // A check with a fault is not also "not measured", whatever another reading of it said.
        $notMeasured = array_diff_key($notMeasured, $passed, array_flip(array_column($issues, 'check')));

        return [
            'key' => $key,
            'title' => $copy['title'],
            'about' => $copy['about'],
            'status' => $status,
            'headline' => match (true) {
                $status === 'not_measured' => 'Not measured yet.',
                $faults === 0 && $notes === 0 => 'Nothing to fix.',
                $faults === 0 => 'Nothing to fix, '.$notes.' '.($notes === 1 ? 'thing' : 'things').' worth knowing.',
                default => $faults.' '.($faults === 1 ? 'thing' : 'things').' to fix.',
            },
            'issue_count' => $faults,
            'note_count' => $notes,
            'passed' => count($passed),
            'not_measured' => array_keys($notMeasured),
            'issues' => array_map(fn (array $issue): array => array_diff_key($issue, ['check' => true]), $issues),
        ];
    }

    /** @param  list<array<string, mixed>>  $groups */
    private static function headline(array $groups): string
    {
        $statuses = array_column($groups, 'status');
        $measured = count(array_filter($statuses, fn (string $s): bool => $s !== 'not_measured'));
        $attention = count(array_filter($statuses, fn (string $s): bool => $s === 'red' || $s === 'amber'));

        return match (true) {
            $measured === 0 => 'Nothing has been measured yet.',
            $attention === 0 && $measured === count($groups) => 'Nothing to fix in any of the '.count($groups).' areas.',
            $attention === 0 => 'Nothing to fix in the '.$measured.' '.($measured === 1 ? 'area' : 'areas').' measured so far.',
            default => $attention.' of '.count($groups).' areas '.($attention === 1 ? 'has' : 'have').' something to fix.',
        };
    }

    /**
     * Google's own word on the sitemap (SitemapStatus::state()). A site
     * not connected to Google, or a Google that did not answer, is not a
     * measurement.
     *
     * @param  array<string, mixed>  $snapshot
     */
    private static function sitemap(array $snapshot): array
    {
        $sitemaps = is_array($snapshot['sitemaps'] ?? null) ? $snapshot['sitemaps'] : [];
        $entries = array_values(array_filter((array) ($sitemaps['entries'] ?? []), 'is_array'));
        $count = fn (string $key): int => (int) array_sum(array_map(fn (array $entry): int => (int) ($entry[$key] ?? 0), $entries));

        [$issue, $severity, $found] = match ((string) ($sitemaps['state'] ?? '')) {
            'ok' => [null, null, null],
            'errors' => ['sitemap_errors', SiteCheckThresholds::RED, self::counted($count('errors'), 'error', 'reported by Google.')],
            'warnings' => ['sitemap_warnings', SiteCheckThresholds::AMBER, self::counted($count('warnings'), 'warning', 'reported by Google.')],
            'stale' => ['sitemap_stale', SiteCheckThresholds::AMBER, null],
            'none' => ['sitemap_none', SiteCheckThresholds::AMBER, null],
            default => [false, null, null],
        };

        if ($issue === false) {
            return self::reading('sitemap_errors', false);
        }

        return self::reading('sitemap_errors', true, $issue === null ? [] : [self::issue($issue, $severity, found: $found)]);
    }

    /**
     * The pages Google has inspected: the ones it could not open, the ones
     * it may not read, and — only when they are half or more of what it
     * checked — the ones it read and does not show.
     *
     * @param  array<string, mixed>  $snapshot
     */
    private static function googlePages(array $snapshot): array
    {
        $errors = is_array($snapshot['gsc_errors'] ?? null) ? $snapshot['gsc_errors'] : [];
        $tracked = (int) ($errors['totals']['tracked'] ?? 0);

        if (empty($errors['available']) || $tracked === 0) {
            return self::reading('google_cannot_open', false);
        }

        $bucket = function (string ...$needles) use ($errors): int {
            $total = 0;
            foreach ((array) ($errors['buckets'] ?? []) as $bucket) {
                foreach ($needles as $needle) {
                    if (is_array($bucket) && stripos((string) ($bucket['label'] ?? ''), $needle) !== false) {
                        $total += (int) ($bucket['count'] ?? 0);

                        break;
                    }
                }
            }

            return $total;
        };
        $examples = function (string ...$needles) use ($errors): array {
            $examples = [];
            foreach ((array) ($errors['rows'] ?? []) as $row) {
                foreach ($needles as $needle) {
                    if (is_array($row) && stripos((string) ($row['issue'] ?? ''), $needle) !== false) {
                        $examples[] = ['url' => (string) ($row['url'] ?? ''), 'found' => (string) (($row['coverage_state'] ?? '') ?: ($row['issue'] ?? ''))];

                        break;
                    }
                }
            }

            return $examples;
        };

        $issues = [];

        if (($cannotOpen = $bucket('crawl', 'fetch', 'soft 404')) > 0) {
            $issues[] = self::issue('google_cannot_open', SiteCheckThresholds::AMBER, $cannotOpen, $examples('fetch', 'soft 404'));
        }

        if (($blocked = $bucket('blocked')) > 0) {
            $issues[] = self::issue('google_blocked', SiteCheckThresholds::AMBER, $blocked, $examples('blocked'));
        }

        $notShown = (int) ($errors['totals']['not_indexed'] ?? 0);
        if (SiteCheckThresholds::share($notShown, $tracked, SiteCheckThresholds::NOT_SHOWN_SHARE)) {
            $issues[] = self::issue(
                'google_not_showing',
                SiteCheckThresholds::AMBER,
                $notShown,
                $examples('not indexed'),
                number_format($notShown).' of the '.number_format($tracked).' pages Google has checked.',
            );
        }

        return self::reading('google_cannot_open', true, $issues);
    }

    /**
     * Bing's counts for the sitemap's pages. Nothing asked yet, or nothing
     * answered, is not a measurement.
     *
     * @param  array<string, mixed>|null  $bing
     */
    private static function bingPages(?array $bing): array
    {
        $total = (int) ($bing['total'] ?? 0);
        $errors = (int) ($bing['errors'] ?? 0);
        $answered = $total - (int) ($bing['pending'] ?? 0);

        if ($bing === null || $total === 0 || $answered <= 0) {
            return self::reading('bing_cannot_open', false);
        }

        $issues = [];

        if ($errors > 0) {
            $issues[] = self::issue('bing_cannot_open', SiteCheckThresholds::AMBER, $errors);
        }

        $unread = (int) ($bing['never_crawled'] ?? 0);
        if (SiteCheckThresholds::share($unread, $answered, SiteCheckThresholds::BING_UNREAD_SHARE)) {
            $issues[] = self::issue(
                'bing_not_read',
                SiteCheckThresholds::AMBER,
                $unread,
                found: number_format($unread).' of the '.number_format($answered).' sitemap pages Bing has answered for.',
            );
        }

        return self::reading('bing_cannot_open', true, $issues);
    }

    /**
     * One stored finding as a reading: its own severity, title and fix,
     * with up to EXAMPLES of its pages.
     *
     * @param  array<string, mixed>|null  $checks
     */
    private static function finding(?array $checks, string $key, ?string $issue = null): array
    {
        $issue ??= $key;
        $finding = null;

        foreach ((array) ($checks['findings'] ?? []) as $candidate) {
            if (is_array($candidate) && ($candidate['key'] ?? null) === $key) {
                $finding = $candidate;

                break;
            }
        }

        return match ($finding['status'] ?? 'not_measured') {
            'pass' => self::reading($issue, true),
            'not_applicable' => self::reading($issue, null),
            'fail' => self::reading($issue, true, [[
                'check' => SiteCheckCatalog::check($issue),
                'key' => (string) ($finding['issue'] ?? $key),
                'severity' => in_array($finding['severity'] ?? null, [SiteCheckThresholds::RED, SiteCheckThresholds::NOTE], true) ? $finding['severity'] : SiteCheckThresholds::AMBER,
                'title' => (string) ($finding['title'] ?? SiteCheckCatalog::ISSUES[$issue]['title']),
                'pages' => isset($finding['pages']) ? (int) $finding['pages'] : null,
                'examples' => array_slice(array_values((array) ($finding['examples'] ?? [])), 0, self::EXAMPLES),
                'found' => $finding['found'] ?? null,
                'fix' => (string) ($finding['fix'] ?? SiteCheckCatalog::ISSUES[$issue]['fix']),
            ]]),
            default => self::reading($issue, false),
        };
    }

    /**
     * One of the health-check's own scored checks, retold as a count of
     * the pages that fail it. Its gate is the report's (title 30–60
     * characters, description 70–160, exactly one H1, any JSON-LD at all);
     * nothing here re-measures a page.
     *
     * @param  array<string, mixed>|null  $checks
     */
    private static function scored(?array $checks, string $scoredKey, string $issue): array
    {
        $count = is_array($checks['scored'][$scoredKey] ?? null) ? $checks['scored'][$scoredKey] : null;
        $checked = (int) ($count['checked'] ?? 0);

        if ($count === null || $checked === 0) {
            return self::reading($issue, false);
        }

        $failed = (int) ($count['failed'] ?? 0);
        $severity = SiteCheckThresholds::pages($failed, $checked);

        return self::reading($issue, true, $severity === null ? [] : [
            self::issue($issue, $severity, $failed, array_slice(array_values((array) ($count['examples'] ?? [])), 0, self::EXAMPLES)),
        ]);
    }

    /**
     * Structured data, three things to say about it: none on the page (the
     * health-check's own `jsonld` check), a block that cannot be read, and
     * — a note, never a fault — a detail SchemaAuditReport's rules expect
     * that is not there.
     *
     * @param  array<string, mixed>|null  $checks
     */
    private static function structuredData(?array $checks): array
    {
        $parts = [
            self::scored($checks, 'jsonld', 'structured_data_missing'),
            self::finding($checks, 'structured_data_unreadable'),
            self::finding($checks, 'structured_data_incomplete'),
        ];

        $measured = array_filter($parts, fn (array $part): bool => $part['measured'] === true);

        return self::reading('structured_data_missing', $measured !== [], array_merge(...array_column($parts, 'issues')));
    }

    /**
     * The health report's Google Business Profile pillar, in the pillar's
     * own bands. A pillar with no score was not measured.
     *
     * @param  array<string, mixed>  $snapshot
     */
    private static function businessProfile(array $snapshot): array
    {
        foreach ((array) ($snapshot['health']['pillars'] ?? []) as $pillar) {
            if (! is_array($pillar) || stripos((string) ($pillar['name'] ?? ''), 'GBP') === false) {
                continue;
            }

            if (! is_numeric($pillar['score'] ?? null)) {
                break;
            }

            $score = (int) $pillar['score'];
            $severity = SiteCheckThresholds::pillar($score);

            return self::reading('gbp_activity', true, $severity === null ? [] : [
                self::issue('gbp_activity', $severity, found: "Activity scores {$score} out of 100."),
            ]);
        }

        return self::reading('gbp_activity', false);
    }

    /**
     * The files AI assistants read in place of the pages, by the flags the
     * site already sends for each: missing is red, stale is amber — the
     * dots the AI card shows.
     *
     * @param  array<string, mixed>  $snapshot
     */
    private static function aiSummary(array $snapshot): array
    {
        $feeds = array_values(array_filter((array) ($snapshot['geo']['feeds'] ?? []), 'is_array'));

        if ($feeds === []) {
            return self::reading('ai_summary_missing', false);
        }

        $missing = count(array_filter($feeds, fn (array $feed): bool => empty($feed['ok'])));
        $stale = count(array_filter($feeds, fn (array $feed): bool => ! empty($feed['ok']) && ! empty($feed['stale'])));
        $of = ' of the '.count($feeds).' files AI assistants read ';
        $issues = [];

        if ($missing > 0) {
            $issues[] = self::issue('ai_summary_missing', SiteCheckThresholds::RED, found: $missing.$of.($missing === 1 ? 'is' : 'are').' missing.');
        }

        if ($stale > 0) {
            $issues[] = self::issue('ai_summary_stale', SiteCheckThresholds::AMBER, found: $stale.$of.($stale === 1 ? 'has' : 'have').' not been rewritten lately.');
        }

        return self::reading('ai_summary_missing', true, $issues);
    }

    /**
     * Google's phone speed test over the last SPEED_WINDOW_DAYS days, on
     * the mobile strategy: each page at its own median, the site at the
     * median page, in Google's own bands (SiteCheckThresholds::speedBand()).
     * The largest paint is the real-visitor figure when Google has one for
     * the page and the lab figure when it does not.
     *
     * @param  list<array<string, mixed>>|null  $rows
     */
    private static function phoneSpeed(?array $rows): array
    {
        $scores = [];
        $paints = [];

        foreach ($rows ?? [] as $row) {
            if (! is_array($row) || strtolower((string) ($row['strategy'] ?? '')) !== 'mobile') {
                continue;
            }

            $url = (string) ($row['url'] ?? '');
            $paint = $row['field_lcp_ms'] ?? $row['lab_lcp_ms'] ?? null;

            if (is_numeric($row['performance'] ?? null)) {
                $scores[$url][] = (int) $row['performance'];
            }

            if (is_numeric($paint)) {
                $paints[$url][] = (int) $paint;
            }
        }

        $pages = [];
        foreach (array_unique([...array_keys($scores), ...array_keys($paints)]) as $url) {
            $score = self::median($scores[$url] ?? []);
            $paint = self::median($paints[$url] ?? []);
            $pages[] = ['url' => $url, 'score' => $score, 'paint' => $paint, 'band' => SiteCheckThresholds::speedBand($score, $paint)];
        }

        if ($pages === []) {
            return self::reading('phone_speed', false);
        }

        $typicalScore = self::median(array_values(array_filter(array_column($pages, 'score'), 'is_int')));
        $typicalPaint = self::median(array_values(array_filter(array_column($pages, 'paint'), 'is_int')));
        $typical = SiteCheckThresholds::speedBand($typicalScore, $typicalPaint);
        $notGood = array_values(array_filter($pages, fn (array $page): bool => $page['band'] !== 'good'));
        $anyPoor = in_array('poor', array_column($pages, 'band'), true);

        $severity = match (true) {
            $typical === 'poor' => SiteCheckThresholds::RED,
            $typical === 'slow' || $anyPoor => SiteCheckThresholds::AMBER,
            default => null,
        };

        if ($severity === null) {
            return self::reading('phone_speed', true);
        }

        usort($notGood, fn (array $a, array $b): int => [$a['score'] ?? 101, -($a['paint'] ?? 0)] <=> [$b['score'] ?? 101, -($b['paint'] ?? 0)]);

        return self::reading('phone_speed', true, [self::issue(
            'phone_speed',
            $severity,
            count($notGood),
            array_map(fn (array $page): array => ['url' => $page['url'], 'found' => self::speedWords($page['score'], $page['paint'])], array_slice($notGood, 0, self::EXAMPLES)),
            'On Google\'s phone speed test the typical page '.implode(' and ', array_filter([
                $typicalScore !== null ? "scores {$typicalScore} out of 100" : null,
                $typicalPaint !== null ? 'shows its main content after '.number_format($typicalPaint / 1000, 1).' seconds' : null,
            ])).'. Google calls 90 or more, and 2.5 seconds or less, good.',
        )]);
    }

    private static function speedWords(?int $score, ?int $paintMs): string
    {
        return implode(', ', array_filter([
            $score !== null ? "scores {$score} out of 100" : null,
            $paintMs !== null ? 'main content after '.number_format($paintMs / 1000, 1).' seconds' : null,
        ]));
    }

    /** @param  list<int>  $values */
    private static function median(array $values): ?int
    {
        if ($values === []) {
            return null;
        }

        sort($values);
        $middle = intdiv(count($values), 2);

        return count($values) % 2 === 1 ? $values[$middle] : (int) round(($values[$middle - 1] + $values[$middle]) / 2);
    }

    private static function counted(int $count, string $noun, string $rest): ?string
    {
        return $count > 0 ? number_format($count).' '.$noun.($count === 1 ? '' : 's').' '.$rest : null;
    }

    /**
     * @param  list<array{url: string, found: string}>  $examples
     * @return array<string, mixed>
     */
    private static function issue(string $key, string $severity, ?int $pages = null, array $examples = [], ?string $found = null): array
    {
        return [
            'check' => SiteCheckCatalog::check($key),
            'key' => $key,
            'severity' => $severity,
            'title' => SiteCheckCatalog::ISSUES[$key]['title'],
            'pages' => $pages,
            'examples' => array_slice($examples, 0, self::EXAMPLES),
            'found' => $found,
            'fix' => SiteCheckCatalog::ISSUES[$key]['fix'],
        ];
    }

    /**
     * What one check has to say. `measured`: true when it had something to
     * read, false when it did not ("not measured yet"), null when it does
     * not apply to this site.
     *
     * @param  list<array<string, mixed>>  $issues
     * @return array{check: string, measured: ?bool, issues: list<array<string, mixed>>}
     */
    private static function reading(string $issue, ?bool $measured, array $issues = []): array
    {
        return ['check' => SiteCheckCatalog::check($issue), 'measured' => $measured, 'issues' => $issues];
    }
}
