<?php

namespace SsSystems\Platform\Seo\Checks;

use Illuminate\Container\Container;
use Illuminate\Contracts\Filesystem\Factory as Filesystems;
use SsSystems\Platform\Reports\Contracts\ReportStorage;
use SsSystems\Platform\Reports\IdentityReportStorage;
use SsSystems\Platform\Seo\Checks\Contracts\SiteCheckStore;

/**
 * Which {@see SiteCheckStore} this site uses — asked by the health-check
 * when it writes its findings and by the snapshot when it reads them, so
 * the two can never look in different places.
 *
 * In order: the store the site bound; else the local-disk default, under
 * the site's own ReportStorage binding when it has one and the identity
 * path when it does not (the rule Reports\Console\ReportRun follows for
 * the report files); else nothing — an app with no filesystem, which is
 * only ever the kit's own bare-container unit tests.
 *
 * Why the report resolves its store here instead of being handed one:
 * every site resolves HealthCheckReport from its container, but
 * gs.construction's and dawnsellshomes.com's own report commands never
 * pass through the kit's KitReportCommand afterwards, so the report is the
 * one piece of kit code that runs on all six sites — and no site has to
 * bind anything new for its findings to be kept.
 */
final class SiteCheckStores
{
    public static function current(?Container $container = null): ?SiteCheckStore
    {
        $container ??= Container::getInstance();

        if ($container->bound(SiteCheckStore::class)) {
            return $container->make(SiteCheckStore::class);
        }

        if (! $container->bound(Filesystems::class)) {
            return null;
        }

        return new LocalSiteCheckStore(
            $container->make(Filesystems::class)->disk('local'),
            $container->bound(ReportStorage::class) ? $container->make(ReportStorage::class) : new IdentityReportStorage,
        );
    }
}
