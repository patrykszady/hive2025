<?php

namespace SsSystems\Platform\Seo\Checks;

use Illuminate\Support\Carbon;
use SsSystems\Platform\Reports\PageFetchResult;

/**
 * One pass of the site checks: the health-check hands it each page as it
 * is fetched, then the home page and robots.txt, and gets back findings —
 * each its own pass or fail with a severity and a one-sentence fix. They
 * sit BESIDE the health-check's 100 points, never in them: nothing here
 * reads or changes a page's score, its weights or the average, so the
 * score history on the dashboard compares the same thing it always has.
 *
 * What counts as a fault, where the facts alone do not say:
 *
 *   - A noindex page is a fault only when the sitemap lists it. Sites
 *     noindex pages by rule and leave those same pages out of the sitemap
 *     (gs.construction's AreaSeoPolicy feeds both its page and its sitemap
 *     generator; dawnsellshomes.com's thin neighbourhood pages carry a
 *     googlebot noindex and are listed only in its Bing-only sitemap, which
 *     SiteCatalog::sitemapUrls() does not read). The fault is the mismatch:
 *     a page handed to Google in the sitemap that also tells Google not to
 *     list it. A noindex page outside the sitemap is counted and said to
 *     be as intended.
 *   - Review markup on the site's own business is a NOTE, not a fault:
 *     the finding says where the rating sits and that Google shows no
 *     stars for it. See {@see ReviewMarkup}.
 *   - The phone check is only asked of a site that has a phone number.
 *
 * Page-level findings count the pages that answered 2xx; a page that could
 * not be fetched is left out of every count (the health-check already
 * scores it 0 and names it), and so is a page the reading itself choked
 * on, which is named under `pages_skipped`. Up to EXAMPLES pages are kept
 * per finding, each with exactly what was found on it.
 */
final class SiteCheckRun
{
    public const VERSION = 1;

    /** How many example pages a finding keeps. */
    public const EXAMPLES = 5;

    /** Search engines whose whole-site block is a fault: robots.txt token => the name an owner knows. */
    private const SEARCH_ENGINES = ['Googlebot' => 'Google', 'Bingbot' => 'Bing'];

    /**
     * The crawlers AI assistants read a site with (the estate allows every
     * one of them; dawnsellshomes.com closes only its MLS listing pages,
     * which is not a whole-site rule and is never reported).
     */
    private const AI_CRAWLERS = [
        'GPTBot' => 'ChatGPT', 'OAI-SearchBot' => 'ChatGPT', 'ChatGPT-User' => 'ChatGPT',
        'ClaudeBot' => 'Claude', 'Claude-SearchBot' => 'Claude',
        'PerplexityBot' => 'Perplexity', 'Google-Extended' => 'Gemini',
    ];

    /** The health-check's own checks the summary retells, by breakdown key. */
    private const SCORED = ['title', 'description', 'h1', 'jsonld'];

    /** The catalog wording of a check whose key is not itself an issue. */
    private const ISSUE = ['business_details' => 'business_details_missing'];

    private readonly PageInspector $inspector;

    private int $checked = 0;

    private int $unreachable = 0;

    /** @var array<string, string> url => why the checks could not read the page */
    private array $skipped = [];

    /** @var array<string, array<string, string>> finding key => url => what was found there */
    private array $hits = [];

    /** @var array<string, string> url => where its noindex comes from */
    private array $noindexed = [];

    /** @var array<string, array<string, string>> breakdown key => url => the health-check's own note */
    private array $scored = [];

    /** @var array<string, int> breakdown key => pages that carried the check */
    private array $scoredPages = [];

    /** @var array<string, mixed>|null SiteBasics::inspect() of the home page */
    private ?array $home = null;

    private bool $homeSeen = false;

    /** @var array{search: list<string>, assistants: list<string>}|null who robots.txt shuts out of the whole site */
    private ?array $robots = null;

    /**
     * @param  string  $baseUrl  the site's own address, no trailing slash
     * @param  ?string  $phone  the site's phone number, null when it has none
     * @param  bool  $phoneKnown  false when nothing can say whether the site has a number (no SiteIdentity)
     */
    public function __construct(
        private readonly string $baseUrl,
        string $host,
        private readonly ?string $phone = null,
        private readonly bool $phoneKnown = false,
    ) {
        $this->inspector = new PageInspector($host);
    }

    /**
     * One page the health-check fetched, with the breakdown it scored.
     *
     * @param  array<string, array{ok: bool, note: string}>  $breakdown
     */
    public function page(string $url, PageFetchResult $fetch, array $breakdown): void
    {
        $isHome = $this->isHomePage($url);
        $this->homeSeen = $this->homeSeen || $isHome;

        if (! $fetch->successful) {
            $this->unreachable++;

            return;
        }

        // A page whose markup the reading chokes on (structured data in a
        // shape nobody writes on purpose) is set aside and named; it must
        // not cost the other pages their findings.
        try {
            $facts = $this->inspector->inspect($fetch);
            $home = $isHome ? SiteBasics::inspect($fetch->body) : null;
        } catch (\Throwable $e) {
            $this->skipped[$url] = $e->getMessage();

            return;
        }

        $this->checked++;

        if ($facts['noindex'] !== []) {
            $this->noindexed[$url] = implode(' and ', $facts['noindex']).' '.(count($facts['noindex']) === 1 ? 'says' : 'say').' noindex';
        }

        if ($facts['preview'] !== []) {
            $this->hits['link_preview'][$url] = implode(', ', $facts['preview']);
        }

        if (! $facts['viewport']) {
            $this->hits['phone_layout'][$url] = 'no viewport tag';
        }

        if ($facts['schema']['unreadable'] > 0) {
            $this->hits['structured_data_unreadable'][$url] = $facts['schema']['unreadable'].' of '.$facts['schema']['blocks'].' block(s) cannot be read';
        }

        if ($facts['schema']['issues'] !== []) {
            $this->hits['structured_data_incomplete'][$url] = implode('; ', array_map(self::plainly(...), array_slice($facts['schema']['issues'], 0, 4)));
        }

        if ($facts['reviews']['own'] !== []) {
            $this->hits['review_markup'][$url] = $this->describeReviews($facts['reviews']);
        }

        foreach (self::SCORED as $check) {
            if (! isset($breakdown[$check])) {
                continue;
            }

            $this->scoredPages[$check] = ($this->scoredPages[$check] ?? 0) + 1;

            if (! $breakdown[$check]['ok']) {
                $this->scored[$check][$url] = $breakdown[$check]['note'];
            }
        }

        if ($isHome) {
            $this->home = $home;
        }
    }

    /** Whether the home page still has to be fetched for the site-level readings. */
    public function needsHomePage(): bool
    {
        return ! $this->homeSeen;
    }

    public function homePageUrl(): string
    {
        return $this->baseUrl.'/';
    }

    public function robotsUrl(): string
    {
        return $this->baseUrl.'/robots.txt';
    }

    /**
     * The home page, fetched for the site-level readings because the
     * health-check's own list did not include it. Not one of the checked
     * pages: the page-level counts stay those of the health-check's list.
     */
    public function homePage(PageFetchResult $fetch): void
    {
        $this->homeSeen = true;

        if (! $fetch->successful) {
            return;
        }

        try {
            $this->home = SiteBasics::inspect($fetch->body);
        } catch (\Throwable $e) {
            $this->skipped[$this->homePageUrl()] = $e->getMessage();
        }
    }

    /**
     * The site's robots.txt. A 4xx means there is none, which shuts nobody
     * out; a 5xx or no answer leaves the two access checks unmeasured
     * rather than guessing; an HTML body (a soft 404) is no rules either.
     */
    public function robots(PageFetchResult $fetch): void
    {
        if ($fetch->status === null || $fetch->status >= 500) {
            return;
        }

        $rules = $fetch->successful && ! preg_match('/<\s*(!doctype|html)\b/i', $fetch->body)
            ? RobotsTxt::parse($fetch->body)
            : RobotsTxt::parse('');

        $search = [];
        foreach (self::SEARCH_ENGINES as $token => $name) {
            if ($rules->blocksWholeSite($token)) {
                $search[] = $name;
            }
        }

        $assistants = [];
        foreach (self::AI_CRAWLERS as $token => $name) {
            if ($rules->blocksWholeSite($token)) {
                $assistants[] = "{$token} ({$name})";
            }
        }

        $this->robots = ['search' => $search, 'assistants' => $assistants];
    }

    /**
     * The findings, as the health-check returns them in
     * `data['page_checks']` and stores them for the snapshot.
     *
     * @param  callable(): list<string>  $sitemapUrls  the site's sitemap, asked for only when a page is noindex
     * @return array{
     *     version: int, generated_at: string, base_url: string, pages_checked: int, pages_unreachable: int,
     *     pages_skipped: list<array{url: string, found: string}>,
     *     findings: list<array<string, mixed>>,
     *     scored: array<string, array{failed: int, checked: int, examples: list<array{url: string, found: string}>}>,
     * }
     */
    public function result(callable $sitemapUrls): array
    {
        return [
            'version' => self::VERSION,
            'generated_at' => Carbon::now()->toIso8601String(),
            'base_url' => $this->baseUrl,
            'pages_checked' => $this->checked,
            'pages_unreachable' => $this->unreachable,
            'pages_skipped' => $this->examples($this->skipped),
            'findings' => [
                $this->noindexFinding($sitemapUrls),
                $this->pageFinding('link_preview'),
                $this->pageFinding('review_markup', note: true),
                $this->pageFinding('structured_data_unreadable'),
                $this->pageFinding('structured_data_incomplete', note: true),
                $this->pageFinding('phone_layout', canBeRed: true),
                $this->privacyFinding(),
                $this->phoneFinding(),
                $this->contactFinding(),
                $this->businessFinding(),
                $this->accessFinding('search_engine_access', 'search', SiteCheckThresholds::RED),
                $this->accessFinding('ai_assistant_access', 'assistants', SiteCheckThresholds::AMBER),
            ],
            'scored' => $this->scoredCounts(),
        ];
    }

    /**
     * What the health-check returns in place of findings when the checks
     * themselves broke: no findings, nothing stored, and the reason. The
     * snapshot keeps reading the last run that did complete.
     *
     * @return array<string, mixed>
     */
    public static function failed(string $error): array
    {
        return [
            'version' => self::VERSION,
            'generated_at' => Carbon::now()->toIso8601String(),
            'pages_checked' => 0,
            'pages_unreachable' => 0,
            'pages_skipped' => [],
            'findings' => [],
            'scored' => [],
            'stored' => false,
            'error' => $error,
        ];
    }

    /**
     * The report's markdown section for the findings — after the scores,
     * under a heading that says they are not part of them.
     *
     * @param  array<string, mixed>  $checks  what result() returned
     */
    public static function markdown(array $checks): string
    {
        $md = "\n## Page checks (not part of the score)\n\n";

        if (($checks['error'] ?? null) !== null) {
            return $md.'The page checks could not be completed on this run: '.$checks['error']."\nThe scores above are not affected.\n";
        }

        $md .= 'Pages read: '.$checks['pages_checked'].". These findings are reported beside the score and never change it.\n";
        $md .= ($checks['stored'] ?? false)
            ? "Kept for the SEO page's summary.\n\n"
            : "Not kept for the SEO page's summary (only a run over the sitemap is).\n\n";
        foreach ($checks['pages_skipped'] ?? [] as $skipped) {
            $md .= "Not read by the checks: {$skipped['url']} ({$skipped['found']}).\n\n";
        }

        $md .= "| Check | Result | Pages | What to do |\n|---|---|---:|---|\n";

        foreach ($checks['findings'] as $finding) {
            $result = match ($finding['status']) {
                'pass' => 'Pass',
                'fail' => $finding['severity'] === SiteCheckThresholds::NOTE ? 'Note' : 'Fail ('.$finding['severity'].')',
                'not_applicable' => 'Does not apply',
                default => 'Not measured',
            };
            $pages = $finding['pages'] !== null && $finding['checked'] !== null ? $finding['pages'].' of '.$finding['checked'] : '—';

            $md .= sprintf("| %s | %s | %s | %s |\n", $finding['check'], $result, $pages, $finding['status'] === 'fail' ? $finding['fix'] : '—');
        }

        foreach ($checks['findings'] as $finding) {
            if ($finding['status'] !== 'fail' && $finding['found'] === null) {
                continue;
            }

            $md .= "\n### {$finding['check']}\n\n";

            if ($finding['status'] === 'fail') {
                $md .= $finding['title'].".\n";
            }

            if ($finding['found'] !== null) {
                $md .= $finding['found']."\n";
            }

            if ($finding['examples'] !== []) {
                $md .= "\n";
                foreach ($finding['examples'] as $example) {
                    $md .= "- {$example['url']} — {$example['found']}\n";
                }
            }
        }

        return $md;
    }

    /** @param  callable(): list<string>  $sitemapUrls */
    private function noindexFinding(callable $sitemapUrls): array
    {
        if ($this->checked === 0) {
            return $this->finding('noindex_in_sitemap', 'page', 'not_measured');
        }

        $listed = [];
        $homeListed = false;

        if ($this->noindexed !== []) {
            $sitemap = array_flip(array_map(self::address(...), $sitemapUrls()));

            foreach ($this->noindexed as $url => $found) {
                if (isset($sitemap[self::address($url)])) {
                    $listed[$url] = $found;
                    $homeListed = $homeListed || $this->isHomePage($url);
                }
            }
        }

        $outside = count($this->noindexed) - count($listed);
        $found = $outside > 0
            ? $outside.' other '.($outside === 1 ? 'page asks' : 'pages ask').' not to be listed and '.($outside === 1 ? 'is' : 'are').' left out of the sitemap, as intended.'
            : null;

        return $this->finding(
            'noindex_in_sitemap',
            'page',
            $listed === [] ? 'pass' : 'fail',
            SiteCheckThresholds::pages(count($listed), $this->checked, canBeRed: true, homePageFails: $homeListed),
            $listed,
            $found,
        );
    }

    /**
     * A page-level finding from the pages that hit it. $note makes it one
     * that is listed and never colours its group: review markup on the
     * business itself (kept on purpose on some sites), and structured
     * data with a detail missing — the schema audit's rules mix what
     * Google requires with what schema.org only recommends (a Service
     * listed in its own business's offer catalogue has no `provider` and
     * needs none), so a gap is worth knowing, not a fault to grade.
     */
    private function pageFinding(string $key, bool $canBeRed = false, bool $note = false): array
    {
        if ($this->checked === 0) {
            return $this->finding($key, 'page', 'not_measured');
        }

        $hits = $this->hits[$key] ?? [];
        $homeFails = false;

        foreach (array_keys($hits) as $url) {
            $homeFails = $homeFails || $this->isHomePage($url);
        }

        $severity = $note && $hits !== []
            ? SiteCheckThresholds::NOTE
            : SiteCheckThresholds::pages(count($hits), $this->checked, $canBeRed, $homeFails);

        return $this->finding($key, 'page', $hits === [] ? 'pass' : 'fail', $severity, $hits);
    }

    private function privacyFinding(): array
    {
        if ($this->home === null) {
            return $this->finding('privacy_link', 'site', 'not_measured');
        }

        $privacy = $this->home['privacy'];

        if (! $privacy['found']) {
            return $this->finding('privacy_link', 'site', 'fail', SiteCheckThresholds::AMBER, found: 'The home page has no link whose address or wording says "privacy".');
        }

        return $this->finding('privacy_link', 'site', 'pass', found: $privacy['where'] === 'footer'
            ? 'Linked from the home page\'s footer.'
            : 'Linked from the home page, outside its footer.');
    }

    private function phoneFinding(): array
    {
        if ($this->home === null) {
            return $this->finding('phone_link', 'site', 'not_measured');
        }

        $link = $this->home['phone'];

        if ($link['found']) {
            return $this->finding('phone_link', 'site', 'pass', found: 'The home page has a tap-to-call link.');
        }

        if (! $this->phoneKnown) {
            return $this->finding('phone_link', 'site', 'not_applicable', found: 'Whether this site has a phone number is not known here.');
        }

        if (trim((string) $this->phone) === '') {
            return $this->finding('phone_link', 'site', 'not_applicable', found: 'This site lists no phone number.');
        }

        return $this->finding('phone_link', 'site', 'fail', SiteCheckThresholds::AMBER, found: 'The site has a phone number, and the home page has no tap-to-call (tel:) link.');
    }

    private function contactFinding(): array
    {
        if ($this->home === null) {
            return $this->finding('contact_link', 'site', 'not_measured');
        }

        $contact = $this->home['contact'];

        if (! $contact['found']) {
            return $this->finding('contact_link', 'site', 'fail', SiteCheckThresholds::AMBER, found: 'The home page has no link to a contact page.');
        }

        return $this->finding('contact_link', 'site', 'pass', found: $contact['kind'] === 'section'
            ? 'The home page links to its own contact section.'
            : 'The home page links to a contact page.');
    }

    private function businessFinding(): array
    {
        if ($this->home === null) {
            return $this->finding('business_details', 'site', 'not_measured');
        }

        $business = $this->home['business'];

        if (! $business['found']) {
            return $this->finding('business_details', 'site', 'fail', SiteCheckThresholds::AMBER, found: 'The home page carries no Organization or LocalBusiness markup.');
        }

        if ($business['missing'] !== []) {
            return $this->finding(
                'business_details',
                'site',
                'fail',
                SiteCheckThresholds::AMBER,
                found: "The home page's {$business['type']} markup has no ".implode(' and no ', $business['missing']).'.',
                issue: 'business_details_incomplete',
            );
        }

        return $this->finding('business_details', 'site', 'pass', found: "The home page carries {$business['type']} markup with the business's details.");
    }

    private function accessFinding(string $key, string $who, string $severity): array
    {
        if ($this->robots === null) {
            return $this->finding($key, 'site', 'not_measured');
        }

        $shutOut = $this->robots[$who];

        if ($shutOut === []) {
            return $this->finding($key, 'site', 'pass');
        }

        return $this->finding($key, 'site', 'fail', $severity, found: 'Shut out of the whole site by robots.txt: '.implode(', ', $shutOut).'.');
    }

    /**
     * One finding. `key` names the check and never changes; `issue` names
     * the wording in SiteCheckCatalog a failure is told with, which for
     * one check (the business details) depends on what is wrong.
     *
     * @param  array<string, string>  $hits  url => what was found there
     * @return array<string, mixed>
     */
    private function finding(string $key, string $scope, string $status, ?string $severity = null, array $hits = [], ?string $found = null, ?string $issue = null): array
    {
        $issue ??= self::ISSUE[$key] ?? $key;
        $copy = SiteCheckCatalog::ISSUES[$issue];
        $failed = $status === 'fail';
        $examples = $this->examples($hits);

        return [
            'key' => $key,
            'issue' => $failed ? $issue : null,
            'check' => $copy['check'],
            'scope' => $scope,
            'status' => $status,
            'severity' => $failed ? $severity : null,
            'title' => $failed ? $copy['title'] : null,
            'fix' => $failed ? $copy['fix'] : null,
            'pages' => $scope === 'page' && $status !== 'not_measured' ? count($hits) : null,
            'checked' => $scope === 'page' && $status !== 'not_measured' ? $this->checked : null,
            'examples' => $examples,
            'found' => $found,
        ];
    }

    /**
     * The first EXAMPLES pages of a list, each with what was found there.
     *
     * @param  array<string, string>  $hits  url => what was found there
     * @return list<array{url: string, found: string}>
     */
    private function examples(array $hits): array
    {
        $examples = [];

        foreach (array_slice($hits, 0, self::EXAMPLES, true) as $url => $what) {
            $examples[] = ['url' => (string) $url, 'found' => $what];
        }

        return $examples;
    }

    /**
     * @return array<string, array{failed: int, checked: int, examples: list<array{url: string, found: string}>}>
     */
    private function scoredCounts(): array
    {
        $counts = [];

        foreach (self::SCORED as $check) {
            $failing = $this->scored[$check] ?? [];
            $examples = [];

            foreach (array_slice($failing, 0, self::EXAMPLES, true) as $url => $note) {
                $examples[] = ['url' => (string) $url, 'found' => self::scoredNote($check, $note)];
            }

            $counts[$check] = ['failed' => count($failing), 'checked' => $this->scoredPages[$check] ?? 0, 'examples' => $examples];
        }

        return $counts;
    }

    /**
     * The health-check's own note on a failed check, in an owner's words:
     * "67 chars (target 30–60)" reads "67 characters", "0 H1 (want exactly
     * 1)" reads "no main heading". The report's breakdown keeps its note;
     * only the example retold for the summary is reworded.
     */
    private static function scoredNote(string $check, string $note): string
    {
        $count = (int) $note;

        return match ($check) {
            'title' => $count === 0 ? 'no title' : $count.' characters',
            'description' => $count === 0 ? 'no description' : $count.' characters',
            'h1' => $count === 0 ? 'no main heading' : $count.' main headings',
            'jsonld' => 'no structured data',
            default => $note,
        };
    }

    /**
     * What the page's review markup is about, in the report's words:
     * "a rating and 3 reviews on the business itself (LocalBusiness); the
     * page also rates a Product".
     *
     * @param  array{own: list<array<string, mixed>>, other: list<array<string, mixed>>}  $reviews
     */
    private function describeReviews(array $reviews): string
    {
        $parts = [];

        foreach ($reviews['own'] as $entry) {
            $what = array_filter([
                $entry['rating'] ? 'a rating' : null,
                $entry['reviews'] > 0 ? $entry['reviews'].' '.($entry['reviews'] === 1 ? 'review' : 'reviews') : null,
            ]);

            $parts[] = implode(' and ', $what).' on the business itself ('.$entry['type']
                .($entry['assumed'] ? ', which gives no web address, so it is taken to be this business' : '').')';
        }

        $text = implode('; ', $parts);
        $others = array_values(array_unique(array_column($reviews['other'], 'type')));

        return $others === [] ? $text : $text.'; the page also rates a '.implode(' and a ', $others);
    }

    /**
     * A schema-audit issue in plain words: "Service: missing `provider`"
     * reads "Service has no provider", "FAQPage: empty `mainEntity`" reads
     * "FAQPage has an empty mainEntity".
     */
    private static function plainly(string $issue): string
    {
        return (string) preg_replace(
            ['/^(.+): missing `(.+)`$/', '/^(.+): empty `(.+)`$/'],
            ['$1 has no $2', '$1 has an empty $2'],
            $issue,
        );
    }

    private function isHomePage(string $url): bool
    {
        return self::address($url) === self::address($this->baseUrl);
    }

    /**
     * A URL as the page it names, so the sitemap's spelling and the
     * fetched one compare: scheme and "www." aside, host lowercased, no
     * trailing slash, no fragment.
     */
    private static function address(string $url): string
    {
        $parts = parse_url(trim($url));

        if (! is_array($parts) || ! isset($parts['host'])) {
            return rtrim(trim($url), '/');
        }

        $host = strtolower($parts['host']);
        $host = str_starts_with($host, 'www.') ? substr($host, 4) : $host;

        return $host.rtrim($parts['path'] ?? '', '/').(isset($parts['query']) ? '?'.$parts['query'] : '');
    }
}
