<?php

namespace SsSystems\Platform\Seo\Concerns;

/**
 * The one line a paid command's output ends with when it fails — what went
 * wrong, in one of five words a person scanning a log file can act on.
 *
 * Why (2026-11): every site's schedule answers a failed DataForSEO command
 * with the same hard-coded text, "failed (balance?)", whatever happened —
 * so a request field DataForSEO refused, a queue that was merely slow and a
 * missing table all read as "top up the account". The schedule line lives
 * in each site's own routes/console.php and cannot see why the command
 * exited 1; the command can, so it says so itself, last, in a fixed shape:
 *
 *   seo:intel failed — vendor error: content_analysis: 40501 Invalid Field: 'date_to'
 *
 * and the output file each schedule line appends to (`appendOutputTo`)
 * tells the truth even where the hook's own wording has not been reworded.
 *
 * The five reasons:
 *
 *   - balance too low   the prepaid account cannot cover the estimate
 *   - over budget       the estimate exceeds this run's own --budget
 *   - not configured    something the site must set up is missing (a table,
 *                       a grant, a family that is not registered)
 *   - vendor error      the vendor refused or could not be reached, and its
 *                       answer is the detail
 *   - nothing succeeded a pool of calls was made and none came back with
 *                       data
 *
 * A host command is any Illuminate\Console\Command; this only prints and
 * returns the FAILURE exit code, so `return $this->failBecause(...)` reads
 * like the `$this->error(...); return self::FAILURE;` pair it replaces.
 */
trait ExplainsFailure
{
    public const REASON_BALANCE_TOO_LOW = 'balance too low';

    public const REASON_OVER_BUDGET = 'over budget';

    public const REASON_NOT_CONFIGURED = 'not configured';

    public const REASON_VENDOR_ERROR = 'vendor error';

    public const REASON_NOTHING_SUCCEEDED = 'nothing succeeded';

    /** Prints the closing failure line and returns the FAILURE exit code. */
    protected function failBecause(string $reason, string $detail): int
    {
        $this->error(self::failureLine((string) $this->getName(), $reason, $detail));

        return 1;
    }

    /** "{command} failed — {reason}: {detail}", on one line whatever the detail holds. */
    public static function failureLine(string $command, string $reason, string $detail): string
    {
        $detail = trim((string) preg_replace('/\s+/u', ' ', $detail));

        return sprintf('%s failed — %s%s', $command, $reason, $detail !== '' ? ': '.$detail : '');
    }

    /**
     * Which of the two money reasons a refused precheck is — or, when the
     * balance itself could not be read, what the failed balance call says
     * ({@see reasonForError()}; a plain vendor error when it says nothing
     * more). Shared by every command that compares an estimate with
     * --budget and the balance before it spends.
     */
    public static function spendRefusalReason(float $estimate, float $budget, ?float $balance, ?string $balanceError = null): string
    {
        if ($estimate > $budget) {
            return self::REASON_OVER_BUDGET;
        }

        return $balance === null ? self::reasonForError($balanceError, self::REASON_VENDOR_ERROR) : self::REASON_BALANCE_TOO_LOW;
    }

    /**
     * What a vendor's own error text says the failure really was, or
     * `$otherwise` when it does not say. A pool of calls that all failed is
     * "nothing succeeded" — unless the last answer was DataForSEO's
     * "insufficient funds", in which case the honest word is the balance;
     * the same for its daily cost limit (over budget), rejected credentials
     * (not configured) and an AI provider's exhausted credit.
     *
     * DataForSEO's codes are from its own list (appendix/errors): 40200
     * payment required, 40210 insufficient funds, HTTP 402; 40203 the cost
     * limit has been exceeded; 40100 not authorized, 40104 account not
     * verified, 40207 IP not whitelisted, HTTP 401.
     */
    public static function reasonForError(?string $error, string $otherwise): string
    {
        if ($error === null || trim($error) === '') {
            return $otherwise;
        }

        if (preg_match('/\b402(?:00|10)\b|\bHTTP 402\b|insufficient funds|payment required|insufficient[_ ]quota|exceeded your current quota|credit balance is too low/i', $error) === 1) {
            return self::REASON_BALANCE_TOO_LOW;
        }

        if (preg_match('/\b40203\b|cost limit has been exceeded/i', $error) === 1) {
            return self::REASON_OVER_BUDGET;
        }

        if (preg_match('/\b401(?:00|04)\b|\b40207\b|\bHTTP 401\b|is not configured/i', $error) === 1) {
            return self::REASON_NOT_CONFIGURED;
        }

        return $otherwise;
    }
}
