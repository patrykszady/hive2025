<?php

namespace SsSystems\Platform\Seo\Visibility;

/**
 * How one AI answer treats the business, read the way a customer reads it
 * — four levels where `seo_ai_mentions.mentioned` only says yes or no
 * (Patryk, 2026-11-12). The whole rule is here, and only stored facts go
 * in, so the same answer always gets the same level and no engine is asked
 * again.
 *
 * What goes in: the answer text as stored (`answer_excerpt` — the whole
 * answer since 2026-11-12, the first 1,500 characters before), the pages
 * it cited (`cited_sources`), and the two things the recording run decided
 * from the whole answer: `mentioned` (the name or the domain was in it) and
 * `mention_rank` (the name was one of the businesses the answer set out as
 * names — bold, a link, "1. Name").
 *
 * RECOMMENDED — the business is one of the answer's picks. The name is a
 * pick where it
 *   1. leads a list entry or a line of its own, the way every engine lists
 *      its picks ("1. **Name** — …", "- Name", "**[Name](link)**" over an
 *      address and a description);
 *   2. in running text, opens a sentence or its main clause ("For Palatine
 *      homeowners, Name is a popular choice"), or is set as a name — bold
 *      or a link — with no word before it that ties it to something else
 *      ("a shortlist includes **A**, **Name** and **C**", but not "often
 *      compared with **Name**");
 *   3. follows a recommending word with nothing between them that ties it
 *      elsewhere ("I'd call Name", "top picks include A, Name and C",
 *      "Best overall: Name" — but not "I'd pick A over Name", "A, a
 *      spin-off of Name" or "I recommend Name's cost guide").
 * A line or list entry that leads with another name in bold or as a link
 * is about that business: nothing in it counts. In any other list entry
 * only 1 and 3 count. No place counts when what is said there is negative
 * ("avoid Name", "not recommended", "multiple complaints", "couldn't
 * find", a "not" next to the name — NEGATIVE below), and a list under a
 * heading that is ("Companies to avoid:") or that lists sources is no
 * list of picks.
 *
 * When the stored text never shows the name — an answer stored before
 * 2026-11-12 is cut at 1,500 characters and most picks sit further down —
 * `mention_rank` decides: the recording run read the whole answer and
 * found the name among the businesses it listed.
 *
 * LINKED — not a pick, and the answer cites a page of the site
 * (`cited_sources`) or its text contains the domain. An answer that cites
 * the site without ever naming the business is LINKED too, while its
 * stored `mentioned` stays false: that flag keeps meaning "named", so no
 * rate built on it moves.
 *
 * MENTIONED — `mentioned` is true and neither of the above: the name is
 * there in passing ("a former Name project manager"), or as the one to
 * avoid.
 *
 * NOT_MENTIONED — the rest. An answer the engine never returned is not
 * stored at all, so it has no level and is in no count.
 *
 * Where this reads wrong it is meant to read low (a pick shown as
 * MENTIONED, not the reverse): a plain comma list with no recommending
 * word before it, a pick described with a "not" beside its name ("Name
 * doesn't cut corners"), a pick inside an entry led by another name. The
 * known ways to read high: running text that sets the name in bold while
 * talking about someone else with no tying word, and a cut answer whose
 * hidden part says something negative about a listed name.
 */
final class AiMentionLevel
{
    public const RECOMMENDED = 'recommended';

    public const LINKED = 'linked';

    public const MENTIONED = 'mentioned';

    public const NOT_MENTIONED = 'not_mentioned';

    /** Every level, strongest first — the order counts are reported in. */
    public const ALL = [self::RECOMMENDED, self::LINKED, self::MENTIONED, self::NOT_MENTIONED];

    /** Words that recommend what follows them. */
    private const RECOMMENDING = 'recommend(?:s|ed|ing|ations?)?|suggest(?:s|ed|ing)?|call(?:ing)?|hir(?:e|ing)|contact(?:ing)?|choos(?:e|ing)|try(?:ing)?|go(?:ing)? with|go wrong with|work(?:ing)? with|opt(?:ing)? for|turn(?:ing)? to|talk(?:ing)? to|reach(?:ing)? out to|consider(?:ing)?|start(?:ing)? with|check(?:ing)? out|includ(?:e|es|ed|ing)|such as|picks?|choices?|options?|bets?|shortlist|standouts?|contenders|favou?rites?|candidates';

    /** "Best overall:", "Top pick for kitchens:" — a label that names what follows it. */
    private const LABEL = '(?:best|top|leading|winner|runner-up|also great|honou?rable mentions?)\b[^.!?,;:]{0,40}:';

    /** Between a recommending word and the name, any of these means the name belongs to something else. */
    private const TIES_ELSEWHERE = 'of|from|by|than|over|with|unlike|versus|vs|former|formerly|previously|according|compared|instead|rather|not|never|if|when|while|unless|until|after|before|because|although|though|but|whose|which|who|that';

    /** Directly before a bold or linked name, any of these means the sentence is about something else. */
    private const PASSING = 'of|from|by|than|over|with|unlike|versus|vs|former|formerly|to|against|like|at|for|as|about';

    /** How a sentence may open before its subject: "For Palatine homeowners, …", "Overall, …". */
    private const OPENERS = 'for|in|if|when|among|overall|according to|based on|around|near|on|at|across|within|also|additionally|finally|first|second|third|next|then|however|alternatively|similarly|notably|generally|typically|locally|here';

    /**
     * What makes a place not a pick, tested on lower-cased text in which
     * the business's own name is replaced by US. "avoid" counts only when
     * it is aimed at a business ("avoid them", "ones to avoid:"), never
     * "manages permits to avoid delays"; a "not" counts beside the name,
     * except the idioms that recommend ("can't go wrong with …", "can't
     * recommend … enough").
     */
    private const NEGATIVE = [
        'avoid(?:ing)?\s+(?:the\s+)?(?:\x04|(?:them|it|this|that|these|those|using|hiring|working|calling)\b)',
        '\bavoid(?:ed)?\s*(?:$|[.:;,!?)—–-])',
        '\b(?:be|been) avoided\b',
        '\bsteer(?:ing)? clear\b',
        '\bstay(?:ing)? away\b',
        '\bnot (?:be )?recommend',
        '(?:n[\'’]t|\bcannot) recommend(?![^.!?]*\benough\b)',
        '\x04[^.!?]{0,40}?(?:\b(?:is|was|are|were|does|do|did|has|have|could|can|would|should) not\b|n[\'’]t\b)',
        '(?:\bnot|\bnever|n[\'’]t)\s+(?!go wrong|hesitate|overlook|forget|miss|only|recommend)(?:\S+\s+){0,3}\x04',
        '\b(?:would|do|did|should|could|can)(?: not|n[\'’]t) (?:hire|use|call|choose|trust)\b',
        '\b(?:could|did|was|were)(?: not|n[\'’]t) (?:find|locate|verify|confirm)\b',
        '\bunable to (?:find|locate|verify|confirm)\b',
        '\bno (?:information|reviews|record|listing)\b',
        '\bbeware\b',
        '\bred flags?\b',
        '\bscams?\b',
        '\bunlicensed\b',
        '\bout of business\b',
        '\bpermanently closed\b',
        '\bclosed permanently\b',
        '\bno longer (?:in business|operating|open|serv)',
        '\b(?:poor|bad|negative|terrible|mixed) reviews\b',
        '\bpoorly (?:rated|reviewed)\b',
        '\b(?:unresolved|multiple|several|many|numerous|serious) complaints\b',
        '\bcomplaints (?:about|against)\b',
    ];

    /** A heading whose list is not a list of picks, besides a NEGATIVE one. */
    private const SOURCES_HEADING = '/^(?:sources?|references?|citations?|further reading|read more|learn more|related)\b/';

    /** Stands for the business's own name in NEGATIVE. */
    private const US = "\x04";

    /** Mark where a bold or linked run starts and ends once the markup is gone. */
    private const NAME_START = "\x02";

    private const NAME_END = "\x03";

    /**
     * @param  ?string  $answer  the answer text as stored — whole, cut, or missing
     * @param  bool  $mentioned  the stored flag: the name or the domain was in the whole answer
     * @param  ?int  $mentionRank  the stored rank: where the name stood among the businesses the whole answer listed
     * @param  list<array<string, mixed>>  $citedSources  the pages the answer cited, each with a `domain`
     * @param  list<string>  $brandPatterns  SeoSiteProfile::brandPatterns()
     * @param  string  $domain  SeoSiteProfile::domain()
     */
    public static function of(?string $answer, bool $mentioned, ?int $mentionRank, array $citedSources, array $brandPatterns, string $domain): string
    {
        $answer = (string) $answer;
        $linked = self::linksSite($answer, $citedSources, $domain);

        if (! $mentioned) {
            return $linked ? self::LINKED : self::NOT_MENTIONED;
        }

        if (self::namedAsPick($answer, $brandPatterns) ?? ($mentionRank !== null)) {
            return self::RECOMMENDED;
        }

        return $linked ? self::LINKED : self::MENTIONED;
    }

    /**
     * Whether the text names the business — the one name matcher:
     * `mentioned` is decided with it when an answer is recorded, and the
     * level finds the name in the text with the same patterns.
     *
     * @param  list<string>  $brandPatterns
     */
    public static function namesBrand(string $lowerText, array $brandPatterns): bool
    {
        foreach ($brandPatterns as $pattern) {
            if ($pattern !== '' && @preg_match(self::regex($pattern), $lowerText) === 1) {
                return true;
            }
        }

        return false;
    }

    /** Whether a cited page's host is the site's own domain or under it. */
    public static function onDomain(string $host, string $domain): bool
    {
        $host = self::bareHost($host);
        $domain = self::bareHost($domain);

        return $domain !== '' && ($host === $domain || str_ends_with($host, '.'.$domain));
    }

    /**
     * True when the text names the business as a pick, false when it names
     * it but never as one, null when the name is not in the text at all.
     *
     * @param  list<string>  $brandPatterns
     */
    public static function namedAsPick(string $answer, array $brandPatterns): ?bool
    {
        $lines = array_map(self::line(...), preg_split('/\R/', $answer) ?: []);
        $named = null;
        $notPicks = false;

        foreach ($lines as $i => $line) {
            if ($line['text'] === '') {
                continue;
            }

            foreach (self::sentences($line['text']) as $n => $sentence) {
                $sentence = mb_strtolower($sentence);
                foreach (self::nameSpans($sentence, $brandPatterns) as [$offset, $length]) {
                    $named = false;
                    $before = substr($sentence, 0, $offset);
                    $possessive = preg_match('/^[\'’]s\b/u', substr($sentence, $offset + $length)) === 1;
                    $lead = self::unmarked($before);
                    $opens = self::opens($lead);

                    if ($n === 0 && $opens) {
                        $pick = ! $notPicks && ! self::negative(self::entry($lines, $i), $brandPatterns);
                    } elseif ($line['led_by_name'] || self::negative($sentence, $brandPatterns)) {
                        $pick = false;
                    } else {
                        $pick = (! $possessive && self::followsRecommendingWord($lead))
                            || (! $line['entry'] && ($opens || self::followsOpener($lead) || self::setAsName($before)));
                    }

                    if ($pick) {
                        return true;
                    }
                }
            }

            if ($line['heading']) {
                $notPicks = self::notPicksHeading($line['text'], $brandPatterns);
            } elseif ($line['bold'] && self::notPicksHeading($line['text'], $brandPatterns)) {
                $notPicks = true;
            }
        }

        return $named;
    }

    /**
     * @param  list<array<string, mixed>>  $citedSources
     */
    private static function linksSite(string $answer, array $citedSources, string $domain): bool
    {
        $domain = self::bareHost($domain);
        if ($domain === '') {
            return false;
        }

        foreach ($citedSources as $source) {
            if (is_array($source) && is_string($source['domain'] ?? null) && self::onDomain($source['domain'], $domain)) {
                return true;
            }
        }

        return str_contains(mb_strtolower($answer), $domain);
    }

    /**
     * One line of the answer without its markup: whether a list marker led
     * it, whether it is a heading (a markdown one, or any line ending in a
     * colon: "**Top-rated companies:**", "Here are some options to
     * consider:"), whether the whole line was bold, whether it leads with
     * a bold or linked name (and not with a label such as "**Top picks**"
     * or "**Best overall:**"), and its text with every bold or linked run
     * kept between NAME_START and NAME_END. Web addresses are dropped — a
     * name inside a link's address is not the answer naming the business.
     *
     * @return array{text: string, entry: bool, heading: bool, bold: bool, led_by_name: bool}
     */
    private static function line(string $raw): array
    {
        $text = str_replace([self::NAME_START, self::NAME_END, self::US], '', $raw);
        $text = preg_replace('/^\s*(?:>\s*)+/', '', $text) ?? $text;
        $text = preg_replace('/^\s*#{1,6}\s+/', '', $text, 1, $hashes) ?? $text;
        $text = preg_replace('/^\s*(?:[-*•]|\d{1,2}[.)])(?:\s+|$)/u', '', $text, 1, $entry) ?? $text;
        $text = preg_replace('/\[([^\]]*)\]\((?:[^()]|\([^()]*\))*\)/', self::NAME_START.'$1'.self::NAME_END, $text) ?? $text;
        $text = preg_replace(['/https?:\/\/\S+/i', '/\[\d+\]/'], '', $text) ?? $text;
        $text = preg_replace('/(\*\*|__)(.+?)\1/', self::NAME_START.'$2'.self::NAME_END, $text) ?? $text;
        $text = preg_replace(['/[*`]+/', '/(?<![[:alnum:]])_+|_+(?![[:alnum:]])/'], '', $text) ?? $text;
        $text = trim(preg_replace('/\s+/', ' ', $text) ?? $text);
        $bare = mb_strtolower(self::unmarked($text));

        return [
            'text' => $text,
            'entry' => $entry === 1,
            'heading' => $entry !== 1 && ($hashes === 1 || str_ends_with($bare, ':')),
            'bold' => preg_match('/^\x02+[^\x02\x03]+\x03+$/', $text) === 1,
            'led_by_name' => preg_match('/^\x02+([^\x03]*)\x03/', $text, $run) === 1
                && preg_match('/\b(?:'.self::RECOMMENDING.')\b/', mb_strtolower($run[1])) !== 1
                && preg_match('/^'.self::LABEL.'/', $bare) !== 1,
        ];
    }

    /**
     * The sentences of one line. A stop after a single letter, a list
     * number or a company suffix ("J. Peterson", "1. Name", "Anix, Inc.
     * is") does not end one.
     *
     * @return list<string>
     */
    private static function sentences(string $text): array
    {
        $sentences = [];
        $start = 0;
        if (preg_match_all('/(\S*?)[.!?]+["”’)\]\x03]*\s+(?=["“(\[\x02]*[\p{Lu}\p{N}])/u', $text, $stops, PREG_OFFSET_CAPTURE | PREG_SET_ORDER)) {
            foreach ($stops as $stop) {
                if (preg_match('/^(?:[a-z]|\d{1,2}|inc|llc|ltd|co|corp|st|dr|mr|mrs|ms|jr|sr|vs|no)$/i', self::unmarked($stop[1][0])) === 1) {
                    continue;
                }
                $end = $stop[0][1] + strlen($stop[0][0]);
                $sentences[] = substr($text, $start, $end - $start);
                $start = $end;
            }
        }
        $sentences[] = substr($text, $start);

        return array_values(array_filter(array_map(trim(...), $sentences), fn (string $sentence): bool => $sentence !== ''));
    }

    /**
     * Where the name stands in the text — [offset, length] in bytes, in
     * reading order — by the same patterns namesBrand() tests.
     *
     * @param  list<string>  $brandPatterns
     * @return list<array{0: int, 1: int}>
     */
    private static function nameSpans(string $lowerText, array $brandPatterns): array
    {
        $spans = [];
        foreach ($brandPatterns as $pattern) {
            if ($pattern !== '' && @preg_match_all(self::regex($pattern), $lowerText, $found, PREG_OFFSET_CAPTURE)) {
                foreach ($found[0] as [$name, $offset]) {
                    $spans[$offset] = [$offset, max(strlen($name), $spans[$offset][1] ?? 0)];
                }
            }
        }
        ksort($spans);

        return array_values($spans);
    }

    /**
     * What the entry a line leads says: the line and what hangs under it
     * (an address, a rating, a description) up to the next blank line,
     * list entry or heading.
     *
     * @param  list<array{text: string, entry: bool, heading: bool, bold: bool, led_by_name: bool}>  $lines
     */
    private static function entry(array $lines, int $index): string
    {
        $text = $lines[$index]['text'];
        for ($i = $index + 1; isset($lines[$i]) && $lines[$i]['text'] !== '' && ! $lines[$i]['entry'] && ! $lines[$i]['heading']; $i++) {
            $text .= ' '.$lines[$i]['text'];
        }

        return $text;
    }

    /** @param  list<string>  $brandPatterns */
    private static function negative(string $text, array $brandPatterns): bool
    {
        $text = mb_strtolower(self::unmarked($text));
        foreach ($brandPatterns as $pattern) {
            if ($pattern !== '') {
                $text = @preg_replace(self::regex($pattern), self::US, $text) ?? $text;
            }
        }

        foreach (self::NEGATIVE as $cue) {
            if (preg_match('/'.$cue.'/u', $text) === 1) {
                return true;
            }
        }

        return false;
    }

    /** @param  list<string>  $brandPatterns */
    private static function notPicksHeading(string $text, array $brandPatterns): bool
    {
        return self::negative($text, $brandPatterns)
            || preg_match(self::SOURCES_HEADING, mb_strtolower(self::unmarked($text))) === 1;
    }

    /** Nothing stands before the name but a list number, symbols (a table bar, a tick) or "the". */
    private static function opens(string $lead): bool
    {
        return preg_match('/^\d{0,2}(?:the)?$/', preg_replace('/[^\p{L}\p{N}]+/u', '', $lead) ?? $lead) === 1;
    }

    /** A recommending word or label leads to the name, with nothing between them that ties the name elsewhere. */
    private static function followsRecommendingWord(string $lead): bool
    {
        return preg_match('/^.*(?:\b(?:'.self::RECOMMENDING.')\b|\b'.self::LABEL.')(.*)$/su', $lead, $found) === 1
            && preg_match('/\b(?:'.self::TIES_ELSEWHERE.')\b|;/', $found[1]) !== 1;
    }

    /** Only an opening phrase stands before the name: "For Palatine homeowners, ". */
    private static function followsOpener(string $lead): bool
    {
        return preg_match('/^(?:'.self::OPENERS.')\b[^,;:]*,(?: the)?$/', $lead) === 1;
    }

    /** The name starts a bold or linked run, and the word before that run does not tie it elsewhere. */
    private static function setAsName(string $before): bool
    {
        return preg_match('/^(.*)\x02\s*(?:the\s+)?$/s', $before, $found) === 1
            && preg_match('/\b(?:'.self::PASSING.')$/', self::unmarked($found[1])) !== 1;
    }

    /** The text without the bold/link marks and without the quotes or brackets it opens with. */
    private static function unmarked(string $text): string
    {
        $text = str_replace([self::NAME_START, self::NAME_END], '', $text);

        return trim(preg_replace('/^[\s"\'“‘(\[]+/u', '', $text) ?? $text);
    }

    private static function bareHost(string $host): string
    {
        return (string) preg_replace('/^www\./', '', mb_strtolower(trim($host)));
    }

    private static function regex(string $pattern): string
    {
        return '/'.$pattern.'/i';
    }
}
