<?php

namespace SsSystems\Platform\Seo\Visibility;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Carbon;

/**
 * seo_domain_overviews — one row per domain per week, written by
 * DomainOverviewCommand and read back by VisibilitySnapshot. Tenant-scoped
 * the same way SsSystems\Platform\Traffic\Collectors\TrackedEventsCollector
 * is: an injected ConnectionInterface plus an optional tenant column/id
 * pair, never a hardcoded App\Models\* reference.
 *
 * write() replaces created_at on every call, not only on first insert —
 * ported as-is from gs.construction's own updateOrInsert() call (its
 * $guard->record()/Cache::forget() bookkeeping happens in the command, not
 * here).
 */
final class DomainOverviewStore
{
    public function __construct(
        private readonly ConnectionInterface $connection,
        private readonly string $table = 'seo_domain_overviews',
        private readonly ?string $tenantColumn = null,
        private readonly ?\Closure $tenantId = null,
    ) {}

    public function exists(): bool
    {
        return $this->connection->getSchemaBuilder()->hasTable($this->table);
    }

    /**
     * Each half is what one DataForSEO call answered: an array (empty when
     * DataForSEO has nothing for the domain — a real zero) or NULL when the
     * call itself failed. A failed half is never written: its columns keep
     * what the day's row already holds, and a failed footprint on a day
     * with no row yet writes nothing at all — the footprint columns cannot
     * be blank, so a new row would be a row of zeros that reads as "the
     * site lost every keyword this week" (2026-11). Last week's row then
     * stays the latest.
     *
     * @param  array{pos_1?: int, pos_2_3?: int, pos_4_10?: int, pos_11_20?: int, count?: int, etv?: float, is_new?: int, is_lost?: int}|null  $overview
     * @param  array{backlinks?: int, referring_domains?: int, rank?: int}|null  $backlink
     * @return bool whether a row was written
     */
    public function write(string $domain, string $date, bool $isUs, ?array $overview, ?array $backlink): bool
    {
        $keys = ['domain' => mb_substr($domain, 0, 191), 'date' => $date];
        if ($this->tenantColumn !== null) {
            $keys[$this->tenantColumn] = ($this->tenantId)();
        }

        if ($overview === null && ($backlink === null || ! $this->connection->table($this->table)->where($keys)->exists())) {
            return false;
        }

        $values = ['is_us' => $isUs];

        if ($overview !== null) {
            $values += [
                'pos_1' => $overview['pos_1'] ?? 0,
                'pos_2_3' => $overview['pos_2_3'] ?? 0,
                'pos_4_10' => $overview['pos_4_10'] ?? 0,
                'pos_11_20' => $overview['pos_11_20'] ?? 0,
                'keywords_total' => $overview['count'] ?? 0,
                'etv' => $overview['etv'] ?? 0,
                'is_new' => $overview['is_new'] ?? 0,
                'is_lost' => $overview['is_lost'] ?? 0,
            ];
        }

        if ($backlink !== null) {
            $values += [
                'backlinks' => $backlink['backlinks'] ?? null,
                'referring_domains' => $backlink['referring_domains'] ?? null,
                'domain_rank' => $backlink['rank'] ?? null,
            ];
        }

        $this->connection->table($this->table)->updateOrInsert($keys, $values + [
            'updated_at' => Carbon::now(),
            'created_at' => Carbon::now(),
        ]);

        return true;
    }

    /**
     * Every row, newest date first — VisibilitySnapshot groups these by
     * domain itself (latest + previous run per domain).
     *
     * @return list<array<string, mixed>>
     */
    public function rows(): array
    {
        if (! $this->exists()) {
            return [];
        }

        return $this->connection->table($this->table)
            ->when($this->tenantColumn !== null, fn ($q) => $q->where($this->tenantColumn, ($this->tenantId)()))
            ->orderByDesc('date')
            ->orderByDesc('id')
            ->get()
            ->map(fn ($row) => (array) $row)
            ->all();
    }
}
