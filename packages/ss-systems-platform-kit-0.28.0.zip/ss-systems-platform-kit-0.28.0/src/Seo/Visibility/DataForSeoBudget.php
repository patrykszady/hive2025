<?php

namespace SsSystems\Platform\Seo\Visibility;

use SsSystems\Platform\Seo\Status\Heartbeat;

/**
 * Shared spend guard for the DataForSEO-spending commands in this module
 * (domain overview, backlink gap, AI mentions) — ported from
 * gs.construction's App\Support\Seo\DataForSeoBudget (pure PHP, no
 * config()/facade calls). Its rules are unchanged; since 2026-11-12 a
 * refusal and each item's outcome are also noted on the running command's
 * heartbeat.
 *
 * DataForSeoApi::balance() returns null when the balance CALL itself failed
 * — a network blip, an expired credential, a DataForSEO outage — not when
 * the account has no limit. Reading that as "if we couldn't check, go ahead
 * anyway" would let a run make real API calls that all fail the same way
 * and still exit SUCCESS having written zero rows. This fails closed
 * instead: no balance reading means no run.
 *
 * The caller fetches balance() (and getLastError()) itself and hands the
 * reading to precheck() — this class makes no HTTP calls of its own.
 */
final class DataForSeoBudget
{
    private int $attempted = 0;

    private int $failed = 0;

    /**
     * Refuses the run before any API call: first because the estimate
     * already exceeds --budget, then because the balance can't cover it —
     * including a failed balance() (null). Returns the message to print
     * and fail on, or null when the run may proceed.
     */
    public function precheck(float $estimate, float $budget, ?float $balance, ?string $balanceError = null): ?string
    {
        if ($estimate > $budget) {
            return self::refused(sprintf('Estimated cost $%.2f exceeds --budget $%.2f; narrow the run or raise --budget.', $estimate, $budget));
        }

        return $this->balanceCheck($estimate, $balance, $balanceError);
    }

    /** The balance half of precheck() alone, for a caller whose --budget is a soft per-item spending cap rather than a hard refusal. */
    public function balanceCheck(float $estimate, ?float $balance, ?string $balanceError = null): ?string
    {
        if ($balance === null) {
            return self::refused(sprintf('DataForSEO balance unknown (%s) — refusing to spend blind.', $balanceError ?? 'balance check failed'));
        }
        if ($balance < $estimate) {
            return self::refused(sprintf('DataForSEO balance $%.2f cannot cover this run ($%.2f).', $balance, $estimate));
        }

        return null;
    }

    /** Record one attempted item's outcome (a domain/prompt that did or didn't come back with data). */
    public function record(bool $ok): void
    {
        $this->attempted++;
        $this->failed += $ok ? 0 : 1;

        Heartbeat::counted($ok);
    }

    /**
     * A refusal, noted on the run it refuses before it is handed back: the
     * command prints it and exits, and until 2026-11-12 that was all — a
     * collector out of credit for a month had recorded nothing. The source
     * it belongs to is whichever the running command feeds
     * (Seo\Status\Heartbeat::refused()); outside a command it is only
     * returned.
     */
    private static function refused(string $message): string
    {
        Heartbeat::refused($message);

        return $message;
    }

    /** True once every attempted item failed — the run got past the precheck and still did nothing. */
    public function allFailed(): bool
    {
        return $this->attempted > 0 && $this->failed === $this->attempted;
    }

    public function attemptedCount(): int
    {
        return $this->attempted;
    }

    public function failedCount(): int
    {
        return $this->failed;
    }
}
