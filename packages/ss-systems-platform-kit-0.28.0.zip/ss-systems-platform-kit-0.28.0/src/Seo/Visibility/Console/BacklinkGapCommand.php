<?php

namespace SsSystems\Platform\Seo\Visibility\Console;

use Illuminate\Console\Command;
use Illuminate\Database\ConnectionInterface;
use SsSystems\Platform\Seo\Concerns\ExplainsFailure;
use SsSystems\Platform\Seo\Contracts\SeoSiteProfile;
use SsSystems\Platform\Seo\DataForSeo\Contracts\DataForSeoApi;
use SsSystems\Platform\Seo\Visibility\BacklinkProspectStore;
use SsSystems\Platform\Seo\Visibility\CompetitorDomains;
use SsSystems\Platform\Seo\Visibility\DataForSeoBudget;

/**
 * `seo:backlink-gap` — monthly link gap: the domains that link to the
 * tracked competitors but not to us, ranked by how many competitors they
 * link to and their own strength — the outreach list (directories, local
 * press, associations, suppliers). Also refreshes which domains link to us.
 * Ported from gs.construction's App\Console\Commands\SeoBacklinkGap;
 * ~$0.024 per 100 referring domains.
 */
final class BacklinkGapCommand extends Command
{
    use ExplainsFailure;

    protected $signature = 'seo:backlink-gap {--competitors=8} {--per-domain=100} {--budget=1}';

    protected $description = 'Domains linking to competitors but not to us (DataForSEO backlinks) into seo_backlink_prospects';

    /** Free-host spam networks ("housesbathroom.web.app", blogspot farms) are never prospects. */
    private const FREE_HOST_PATTERN = '/\.(web\.app|blogspot\.com|wordpress\.com|weebly\.com|wixsite\.com|github\.io|netlify\.app|vercel\.app|pages\.dev|firebaseapp\.com)$/';

    public function __construct(
        private readonly DataForSeoApi $api,
        private readonly SeoSiteProfile $profile,
        private readonly BacklinkProspectStore $store,
        private readonly ConnectionInterface $connection,
    ) {
        parent::__construct();
    }

    public function handle(): int
    {
        if (! $this->api->isConfigured() || ! $this->store->exists()) {
            $this->comment('DataForSEO not configured or table missing — skipping.');

            return self::SUCCESS;
        }

        $ours = $this->profile->domain();
        $competitors = CompetitorDomains::candidates($this->connection, $this->profile, (int) $this->option('competitors'));

        $estimate = (count($competitors) + 3) * 0.025;
        $guard = new DataForSeoBudget;
        $balance = $this->api->balance();
        $balanceError = $this->api->getLastError();
        if ($msg = $guard->precheck($estimate, (float) $this->option('budget'), $balance, $balanceError)) {
            return $this->failBecause(self::spendRefusalReason($estimate, (float) $this->option('budget'), $balance, $balanceError), $msg);
        }
        $lastError = null;

        $oursLinks = [];
        foreach ($this->api->referringDomains($ours, 300) as $r) {
            $oursLinks[$r['domain']] = true;
        }
        $this->line("  {$ours}: ".count($oursLinks).' referring domains');

        /** @var array<string, array{rank: int, links_to: array<string, mixed>, platform: ?string, spam: int}> $prospects */
        $prospects = [];
        foreach ($competitors as $c) {
            if ($this->api->spent() >= (float) $this->option('budget')) {
                $this->warn('Budget reached.');
                break;
            }
            $rows = $this->api->referringDomains($c, (int) $this->option('per-domain'));
            $guard->record($rows !== [] || $this->api->getLastError() === null);
            $lastError = ($rows === [] ? $this->api->getLastError() : null) ?? $lastError;
            $this->line("  {$c}: ".count($rows).' referring domains');
            foreach ($rows as $r) {
                $d = $r['domain'];
                if ($d === $ours || $d === $c || str_ends_with($d, '.'.$c)) {
                    continue;
                }
                if (preg_match(self::FREE_HOST_PATTERN, $d)) {
                    continue;
                }
                $p = $prospects[$d] ?? ['rank' => 0, 'links_to' => [], 'platform' => $r['platform'], 'spam' => 0];
                $p['rank'] = max($p['rank'], $r['rank']);
                $p['spam'] = max($p['spam'], (int) ($r['spam_score'] ?? 0));
                $p['links_to'][$c] = $r['backlinks'];
                $prospects[$d] = $p;
            }
        }

        $n = 0;
        foreach ($prospects as $d => $p) {
            $this->store->write($d, [
                'rank' => $p['rank'],
                'links_to' => $p['links_to'],
                'links_to_us' => isset($oursLinks[$d]),
                'platform_type' => $p['platform'],
                'spam_score' => $p['spam'],
            ]);
            $n++;
        }

        if ($guard->allFailed()) {
            return $this->failBecause(self::reasonForError($lastError, self::REASON_NOTHING_SUCCEEDED), sprintf(
                'every competitor failed (%d of %d; last error: %s)',
                $guard->failedCount(),
                $guard->attemptedCount(),
                $lastError ?? 'unknown',
            ));
        }
        $gap = 0;
        foreach ($prospects as $d => $p) {
            if (! isset($oursLinks[$d]) && count($p['links_to']) >= 2 && $p['spam'] < 30 && count($p['links_to']) < 6) {
                $gap++;
            }
        }
        $this->info(sprintf('%d prospect domains recorded; %d link to 2+ competitors and not to us. Spent $%.3f.', $n, $gap, $this->api->spent()));

        return self::SUCCESS;
    }
}
