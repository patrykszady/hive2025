<?php

namespace SsSystems\Platform\Seo\Visibility\Console;

use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Str;
use SsSystems\Platform\Seo\Concerns\ExplainsFailure;
use SsSystems\Platform\Seo\Contracts\SeoSiteProfile;
use SsSystems\Platform\Seo\DataForSeo\Contracts\DataForSeoApi;
use SsSystems\Platform\Seo\Visibility\AiMentionLevel;
use SsSystems\Platform\Seo\Visibility\AiMentionStore;
use SsSystems\Platform\Seo\Visibility\DataForSeoBudget;

/**
 * `seo:ai-mentions` — GEO measurement: ask the AI answer engines (ChatGPT,
 * Gemini, Perplexity, Claude — via DataForSEO, web search on) the questions
 * a homeowner asks, and record whether the business is named, where in the
 * list, and who is named instead. Ported from gs.construction's
 * App\Console\Commands\SeoAiMentions; twice a month, ~$1.50 a run for 6
 * towns x 2 services x 4 engines.
 *
 * Generalised per the kit's contracts: towns come from
 * profile->towns() (gs.construction's own default was "the six towns with
 * the most completed projects", AreaServed::coreTowns() — a gs.construction
 * table this kit has no equivalent of, so the site's profile binding is now
 * the only source; pass --towns to override it); services come from
 * profile->services() (a flat phrase list, slugged with Str::slug() —
 * gs.construction's config kept an explicit label=>slug map, this port
 * derives the slug instead so one list serves this command and
 * keyword-research alike); "is this us" matching is profile->brandPatterns()
 * (a regex match against the AI's answer text and each parsed business
 * name), replacing gs.construction's config('brand.name') "strip everything
 * after '&'" substring heuristic — brandPatterns() is built for exactly
 * this job and already handles a business's name variations.
 *
 * Each answer's cited pages (the engine's own source links, 2026-11-11)
 * are stored with it: which Houzz, Yelp, BBB or "best of" pages the
 * engines read decides who they name, so that list says where to be listed.
 *
 * The answer is stored whole (2026-11-12; cut at 1,500 characters
 * before): AiMentionLevel reads it back, with `mentioned` and
 * `mention_rank` as decided here, to tell a recommendation from a link
 * from a passing mention. `mentioned` keeps its meaning — the name or the
 * domain is in the answer — and is matched by AiMentionLevel::namesBrand(),
 * the one name matcher. An engine that returns no answer gets no row: it
 * is unavailable, never an answer that did not name us.
 *
 * The prompt template keeps gs.construction's wording but drops its
 * hardcoded ", Illinois" (gs.construction is Illinois-only; this kit is
 * not) in favour of the state segment of profile->locationName()
 * ('Palatine,Illinois,United States' -> ", Illinois"), when present.
 */
final class AiMentionsCommand extends Command
{
    use ExplainsFailure;

    protected $signature = 'seo:ai-mentions {--towns= : CSV of towns (default: profile->towns())} {--budget=2} {--platforms=chat_gpt,gemini,perplexity,claude}';

    protected $description = 'Ask AI answer engines for contractors per town/service and record whether we are named (DataForSEO AI Optimization)';

    private const MODELS = ['chat_gpt' => 'gpt-4o-mini', 'gemini' => 'gemini-2.5-flash', 'perplexity' => 'sonar', 'claude' => 'claude-sonnet-4-5'];

    private const COST = ['chat_gpt' => 0.03, 'gemini' => 0.04, 'perplexity' => 0.01, 'claude' => 0.055];

    public function __construct(
        private readonly DataForSeoApi $api,
        private readonly SeoSiteProfile $profile,
        private readonly AiMentionStore $store,
    ) {
        parent::__construct();
    }

    public function handle(): int
    {
        if (! $this->api->isConfigured() || ! $this->store->exists()) {
            $this->comment('DataForSEO not configured or table missing — skipping.');

            return self::SUCCESS;
        }

        $locationParts = array_map('trim', explode(',', $this->profile->locationName()));
        $state = $locationParts[1] ?? null;
        $city = $locationParts[0] ?? '';

        // A site with no served-town list still has a city (the profile's
        // location): hive, ss.systems, mozaika and J. Peterson all ran
        // "nothing to ask" on 2026-11-02 for want of towns. The city is the
        // one place asked about then.
        $towns = array_values(array_filter(array_map('trim', explode(',', (string) ($this->option('towns') ?: implode(',', $this->profile->towns()))))));
        if ($towns === [] && $city !== '') {
            $towns = [$city];
        }
        $services = $this->profile->services();
        $platforms = array_values(array_intersect(array_map('trim', explode(',', (string) $this->option('platforms'))), array_keys(self::MODELS)));

        if ($towns === [] || $services === [] || $platforms === []) {
            $this->comment('No towns, services or platforms configured — nothing to ask.');

            return self::SUCCESS;
        }

        $prompts = [];
        foreach ($towns as $town) {
            foreach ($services as $service) {
                $prompts[] = [
                    'town' => $town,
                    'service' => Str::slug($service),
                    // "companies for X", not "X contractors": the same prompt
                    // serves a remodeler, an interior designer and a software
                    // product (gs.construction's original said contractors).
                    'text' => sprintf('Who are the best companies for %s in %s%s? Name specific companies.', $service, $town, $state ? ", {$state}" : ''),
                ];
            }
        }

        $estimate = 0.0;
        foreach ($platforms as $pf) {
            $estimate += count($prompts) * self::COST[$pf];
        }
        $balance = $this->api->balance();
        $this->line(sprintf('%d prompts × %d engines — estimated $%.2f · balance %s', count($prompts), count($platforms), $estimate, $balance === null ? '?' : '$'.number_format($balance, 2)));

        $guard = new DataForSeoBudget;
        $balanceError = $this->api->getLastError();
        if ($msg = $guard->precheck($estimate, (float) $this->option('budget'), $balance, $balanceError)) {
            return $this->failBecause(self::spendRefusalReason($estimate, (float) $this->option('budget'), $balance, $balanceError), $msg);
        }

        $brandPatterns = $this->profile->brandPatterns();
        $lastError = null;
        $host = $this->profile->domain();
        $today = Carbon::now()->toDateString();
        $asked = 0;
        $mentioned = 0;
        foreach ($prompts as $p) {
            foreach ($platforms as $pf) {
                if ($this->api->spent() >= (float) $this->option('budget')) {
                    $this->warn('Budget reached.');
                    break 2;
                }
                $response = $this->api->llmResponse($pf, self::MODELS[$pf], $p['text']);
                $answer = $response['text'] ?? null;
                $sources = $response['sources'] ?? [];
                if ($answer === null) {
                    $lastError = $this->api->getLastError() ?? $lastError;
                    $this->line("  {$pf} / {$p['town']} {$p['service']}: no answer (".($this->api->getLastError() ?? '?').')');
                    $guard->record(false);

                    continue;
                }
                $guard->record(true);
                $names = self::businessesNamed($answer);
                $lower = mb_strtolower($answer);
                $isMentioned = AiMentionLevel::namesBrand($lower, $brandPatterns) || ($host !== '' && str_contains($lower, mb_strtolower($host)));
                $rank = null;
                foreach ($names as $i => $n) {
                    if (AiMentionLevel::namesBrand(mb_strtolower($n), $brandPatterns)) {
                        $rank = $i + 1;
                        break;
                    }
                }
                $this->store->insert($pf, self::MODELS[$pf], $p['text'], $p['town'], $p['service'], $isMentioned, $rank, $names, $answer, $today, $sources);
                $asked++;
                $mentioned += $isMentioned ? 1 : 0;
                $this->line(sprintf('  %-10s %-18s %-20s %s  named: %s  cited %d page%s', $pf, $p['town'], $p['service'], $isMentioned ? 'MENTIONED #'.($rank ?? '?') : 'not named', implode(', ', array_slice($names, 0, 3)), count($sources), count($sources) === 1 ? '' : 's'));
            }
        }

        if ($guard->allFailed()) {
            return $this->failBecause(self::reasonForError($lastError, self::REASON_NOTHING_SUCCEEDED), sprintf(
                'every prompt failed (%d of %d; last error: %s)',
                $guard->failedCount(),
                $guard->attemptedCount(),
                $lastError ?? 'the engines returned no answer',
            ));
        }
        $this->info(sprintf('%d answers, named in %d. Spent $%.3f.', $asked, $mentioned, $this->api->spent()));

        return self::SUCCESS;
    }

    /**
     * Business names as the engines format them — bold, markdown links, or
     * "1. Name" — in document order. Ported verbatim from
     * gs.construction's SeoAiMentions::businessesNamed() (pure string
     * parsing, no framework dependency).
     *
     * @return list<string>
     */
    public static function businessesNamed(string $answer): array
    {
        $found = [];
        foreach ([
            '/\*\*\[?([^*\]\n]{3,70})\]?(?:\([^)]*\))?\*\*/u',
            '/\[([^\]\n]{3,70})\]\(https?:[^)]+\)/u',
            '/^\s*\d+\.\s+\**([^*:\n,.]{3,70}?)(?=\s+[-–—]\s|[,.:*]|$)/mu',
        ] as $re) {
            preg_match_all($re, $answer, $m, PREG_OFFSET_CAPTURE);
            foreach ($m[1] as [$name, $offset]) {
                $found[] = [$offset, $name];
            }
        }
        usort($found, fn ($a, $b) => $a[0] <=> $b[0]);

        $names = [];
        foreach ($found as [, $n]) {
            $n = trim(preg_replace('/\s+/', ' ', $n) ?? '');
            $n = preg_replace('/^\d+\.\s*/', '', $n) ?? $n;
            $n = preg_replace('/\s*[:\-–—]\s*$/', '', $n) ?? $n;
            if ($n === ''
                || preg_match('/^(open now|closed|website|phone|address|rating|reviews?|note|top|best|specific|highly|well-known|several|here|these|other)\b/i', $n)
                || preg_match('/\b(illinois|companies|contractors|firms|options)\s*$/i', $n)
                || str_contains($n, '·') || preg_match('/\(\d+ reviews?\)/i', $n)) {
                continue;
            }
            if (! in_array($n, $names, true)) {
                $names[] = $n;
            }
        }

        return $names;
    }
}
