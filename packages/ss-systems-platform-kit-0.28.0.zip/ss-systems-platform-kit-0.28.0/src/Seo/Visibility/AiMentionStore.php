<?php

namespace SsSystems\Platform\Seo\Visibility;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Carbon;
use Illuminate\Support\Str;

/**
 * seo_ai_mentions — one row per (platform, town, service) question asked of
 * an AI answer engine, written by AiMentionsCommand and read back by
 * VisibilitySnapshot. Tenant-scoped the same way
 * SsSystems\Platform\Traffic\Collectors\TrackedEventsCollector is.
 *
 * Only an answer the engine returned is a row: a failed question is not
 * stored, so it is in no count and no rate.
 */
final class AiMentionStore
{
    /**
     * How much of an answer `answer_excerpt` keeps. It was 1,500 until
     * 2026-11-12, which cut about seven answers in ten, often above a
     * business named further down the list; AiMentionLevel reads this
     * text, so the whole answer is kept now. The column is a TEXT (65,535
     * bytes), and 12,000 characters stay under that at four bytes each.
     */
    public const ANSWER_CHARS = 12000;

    /** Whether the table has `cited_sources` yet (a site migrates it in its own time) — looked up once. */
    private ?bool $hasCitedSources = null;

    public function __construct(
        private readonly ConnectionInterface $connection,
        private readonly string $table = 'seo_ai_mentions',
        private readonly ?string $tenantColumn = null,
        private readonly ?\Closure $tenantId = null,
    ) {}

    public function exists(): bool
    {
        return $this->connection->getSchemaBuilder()->hasTable($this->table);
    }

    /**
     * @param  list<string>  $businessesNamed
     * @param  list<array{url: string, domain: string, title: ?string}>  $citedSources  the pages the answer cited; stored only when the table has the column
     */
    public function insert(
        string $platform,
        string $model,
        string $prompt,
        ?string $town,
        ?string $service,
        bool $mentioned,
        ?int $mentionRank,
        array $businessesNamed,
        ?string $answerExcerpt,
        string $askedOn,
        array $citedSources = [],
    ): void {
        $row = [
            'platform' => $platform,
            'model' => $model,
            'prompt' => mb_substr($prompt, 0, 255),
            'town' => $town,
            'service' => $service,
            'mentioned' => $mentioned,
            'mention_rank' => $mentionRank,
            'businesses_named' => json_encode(array_slice($businessesNamed, 0, 12)),
            'answer_excerpt' => $answerExcerpt !== null ? Str::limit($answerExcerpt, self::ANSWER_CHARS) : null,
            'asked_on' => $askedOn,
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now(),
        ];
        if ($this->tenantColumn !== null) {
            $row[$this->tenantColumn] = ($this->tenantId)();
        }
        if ($this->hasCitedSources()) {
            $row['cited_sources'] = json_encode(array_values(array_slice($citedSources, 0, 20)));
        }

        $this->connection->table($this->table)->insert($row);
    }

    public function hasCitedSources(): bool
    {
        return $this->hasCitedSources ??= $this->exists()
            && $this->connection->getSchemaBuilder()->hasColumn($this->table, 'cited_sources');
    }

    public function latestAskedOn(): ?string
    {
        if (! $this->exists()) {
            return null;
        }

        return $this->connection->table($this->table)
            ->when($this->tenantColumn !== null, fn ($q) => $q->where($this->tenantColumn, ($this->tenantId)()))
            ->max('asked_on');
    }

    public function priorAskedOnBefore(string $day): ?string
    {
        return $this->connection->table($this->table)
            ->when($this->tenantColumn !== null, fn ($q) => $q->where($this->tenantColumn, ($this->tenantId)()))
            ->where('asked_on', '<', $day)
            ->max('asked_on');
    }

    /** @return list<array<string, mixed>> */
    public function rowsForDay(string $day): array
    {
        if (! $this->exists()) {
            return [];
        }

        return $this->connection->table($this->table)
            ->when($this->tenantColumn !== null, fn ($q) => $q->where($this->tenantColumn, ($this->tenantId)()))
            ->where('asked_on', $day)
            ->get()
            ->map(fn ($row) => (array) $row)
            ->all();
    }
}
