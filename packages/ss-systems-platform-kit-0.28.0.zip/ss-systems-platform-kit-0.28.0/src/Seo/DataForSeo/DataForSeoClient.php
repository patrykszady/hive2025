<?php

namespace SsSystems\Platform\Seo\DataForSeo;

use Illuminate\Http\Client\Factory;
use SsSystems\Platform\Seo\DataForSeo\Contracts\DataForSeoApi;
use SsSystems\Platform\Seo\DataForSeo\Contracts\DataForSeoCredentials;

/**
 * DataForSEO HTTP client — the real-observation half of every site's
 * SEO rank/keyword/backlink tooling (ported from gs.construction's
 * App\Services\DataForSeoService, kept close to its original decisions):
 *
 *   - a rank tracker that only re-averages our own Search Console rows
 *     never actually looks at a search result, so a flood of new
 *     deep-position impressions reads as a ranking collapse (the exact
 *     false alarm gsc's Aug 2026 click-drop investigation spent a
 *     verification round unwinding) — this talks to the Live/Standard
 *     SERP endpoints instead;
 *   - every call is billed, so spent() accumulates each response's own
 *     cost field and a caller (a `--budget`-bounded command, via Budget
 *     below) can stop a run before it overspends.
 *
 * Unlike gsc's service, this never reads Tenancy/config()/the Log
 * facade: credentials arrive through the injected DataForSeoCredentials
 * contract (a site binds its own env/platform-setting adapter), HTTP
 * through the injected Factory (explicit timeouts, same pattern as
 * Seo\Bing\BingWebmasterApi), and the one thing worth logging — Labs/
 * Backlinks endpoints silently truncating `items` at `limit` even when
 * `total_count` says more exist — goes through the `logger()` global
 * instead of Log::warning().
 */
final class DataForSeoClient implements DataForSeoApi
{
    public const BASE = 'https://api.dataforseo.com/v3';

    public const DEFAULT_LOCATION = 'United States';

    private const LIVE_TIMEOUT_SECONDS = 120;

    private const SERP_TIMEOUT_SECONDS = 90;

    private const NOT_CONFIGURED_ERROR = 'DataForSEO is not configured (missing login or password).';

    /** @var callable(int): mixed */
    private $sleep;

    private ?string $lastError = null;

    private float $spent = 0.0;

    /** @var list<?string> one entry per task the last googleOrganicStandardBatch() call posted, in the order posted: its id, or null where DataForSEO refused the task */
    private array $lastStandardTaskIds = [];

    public function __construct(
        private readonly DataForSeoCredentials $credentials,
        private readonly Factory $http,
        private readonly float $minBalance = 10.0,
        ?callable $sleep = null,
    ) {
        $this->sleep = $sleep ?? sleep(...);
    }

    public function isConfigured(): bool
    {
        return $this->credentials->isConfigured();
    }

    public function getLastError(): ?string
    {
        return $this->lastError;
    }

    public function spent(): float
    {
        return round($this->spent, 4);
    }

    public function balance(): ?float
    {
        $data = $this->call('GET', '/appendix/user_data');
        $balance = $data['tasks'][0]['result'][0]['money']['balance'] ?? null;

        if (! is_numeric($balance)) {
            return null;
        }

        $balance = (float) $balance;

        if ($balance < $this->minBalance) {
            logger()->warning('DataForSeoClient: account balance is below the configured minimum.', [
                'balance' => $balance,
                'min_balance' => $this->minBalance,
            ]);
        }

        return $balance;
    }

    public function request(string $method, string $path, array $body = []): array
    {
        return $this->call($method, $path, $body);
    }

    public function postTask(string $path, array $task): ?string
    {
        $data = $this->call('POST', $path, [$task]);
        $first = (array) ($data['tasks'][0] ?? []);
        $id = $first['id'] ?? null;

        return is_string($id) && in_array((int) ($first['status_code'] ?? 0), [20000, 20100], true) ? $id : null;
    }

    public function pollUntil(callable $probe, int $maxSeconds = 600, int $interval = 15): mixed
    {
        $maxAttempts = max(1, (int) ceil($maxSeconds / max(1, $interval)));

        for ($attempt = 0; $attempt < $maxAttempts; $attempt++) {
            $value = $probe();
            if ($value !== null) {
                return $value;
            }
            if ($attempt < $maxAttempts - 1) {
                ($this->sleep)($interval);
            }
        }

        return null;
    }

    public function lastStandardTaskIds(): array
    {
        return $this->lastStandardTaskIds;
    }

    public function searchVolume(array $keywords, string $locationName = self::DEFAULT_LOCATION): array
    {
        $keywords = array_values(array_unique(array_filter(array_map(
            static fn (string $k): string => mb_strtolower(trim($k)),
            $keywords
        ))));

        if ($keywords === []) {
            return [];
        }

        $out = [];
        foreach (array_chunk($keywords, 1000) as $chunk) {
            $data = $this->call('POST', '/keywords_data/google_ads/search_volume/live', [[
                'keywords' => $chunk,
                'location_name' => self::locationName($locationName),
                'language_code' => 'en',
            ]]);

            foreach ((array) ($data['tasks'][0]['result'] ?? []) as $row) {
                $keyword = mb_strtolower((string) ($row['keyword'] ?? ''));
                if ($keyword === '') {
                    continue;
                }

                $out[$keyword] = [
                    'volume' => is_numeric($row['search_volume'] ?? null) ? (int) $row['search_volume'] : null,
                    'cpc' => is_numeric($row['cpc'] ?? null) ? (float) $row['cpc'] : null,
                    'competition' => is_numeric($row['competition_index'] ?? null)
                        ? (float) $row['competition_index'] / 100
                        : (is_numeric($row['competition'] ?? null) ? (float) $row['competition'] : null),
                ];
            }
        }

        return $out;
    }

    public function rankedKeywords(string $domain, int $limit = 300, string $locationName = self::DEFAULT_LOCATION): array
    {
        $data = $this->call('POST', '/dataforseo_labs/google/ranked_keywords/live', [[
            'target' => $domain,
            'location_name' => self::locationName($locationName),
            'language_code' => 'en',
            'limit' => $limit,
            'order_by' => ['keyword_data.keyword_info.search_volume,desc'],
            'filters' => [['keyword_data.keyword_info.search_volume', '>', 0]],
        ]]);

        $items = (array) ($data['tasks'][0]['result'][0]['items'] ?? []);
        $this->logIfTruncated('rankedKeywords', $domain, (int) ($data['tasks'][0]['result'][0]['total_count'] ?? 0), count($items));

        $out = [];
        foreach ($items as $item) {
            $keywordData = (array) ($item['keyword_data'] ?? []);
            $keyword = mb_strtolower((string) ($keywordData['keyword'] ?? ''));
            if ($keyword === '') {
                continue;
            }

            $out[] = [
                'keyword' => $keyword,
                'volume' => (int) ($keywordData['keyword_info']['search_volume'] ?? 0),
                'position' => (int) ($item['ranked_serp_element']['serp_item']['rank_absolute']
                    ?? $item['ranked_serp_element']['serp_item']['rank_group'] ?? 0),
                'difficulty' => is_numeric($keywordData['keyword_properties']['keyword_difficulty'] ?? null)
                    ? (int) $keywordData['keyword_properties']['keyword_difficulty']
                    : null,
                'url' => $item['ranked_serp_element']['serp_item']['url'] ?? null,
            ];
        }

        return $out;
    }

    public function keywordIdeas(array $seeds, int $limit = 200, string $locationName = self::DEFAULT_LOCATION): array
    {
        $seeds = array_values(array_filter(array_map('trim', $seeds)));
        if ($seeds === []) {
            return [];
        }

        $data = $this->call('POST', '/dataforseo_labs/google/keyword_ideas/live', [[
            'keywords' => array_slice($seeds, 0, 200),
            'location_name' => self::locationName($locationName),
            'language_code' => 'en',
            'limit' => $limit,
            'order_by' => ['keyword_info.search_volume,desc'],
        ]]);

        $items = (array) ($data['tasks'][0]['result'][0]['items'] ?? []);
        $this->logIfTruncated('keywordIdeas', implode(',', array_slice($seeds, 0, 3)), (int) ($data['tasks'][0]['result'][0]['total_count'] ?? 0), count($items));

        $out = [];
        foreach ($items as $item) {
            $keyword = mb_strtolower((string) ($item['keyword'] ?? ''));
            if ($keyword === '') {
                continue;
            }

            $out[] = [
                'keyword' => $keyword,
                'volume' => (int) ($item['keyword_info']['search_volume'] ?? 0),
                'difficulty' => is_numeric($item['keyword_properties']['keyword_difficulty'] ?? null)
                    ? (int) $item['keyword_properties']['keyword_difficulty']
                    : null,
            ];
        }

        return $out;
    }

    public function keywordDifficulty(array $keywords): array
    {
        $out = [];
        foreach (array_chunk(array_values(array_unique(array_filter($keywords))), 1000) as $chunk) {
            $data = $this->call('POST', '/dataforseo_labs/google/bulk_keyword_difficulty/live', [[
                'keywords' => $chunk,
                'location_name' => self::DEFAULT_LOCATION,
                'language_code' => 'en',
            ]]);

            foreach ((array) ($data['tasks'][0]['result'][0]['items'] ?? []) as $item) {
                if (isset($item['keyword'], $item['keyword_difficulty'])) {
                    $out[mb_strtolower((string) $item['keyword'])] = (int) $item['keyword_difficulty'];
                }
            }
        }

        return $out;
    }

    public function searchIntent(array $keywords): array
    {
        $out = [];
        foreach (array_chunk(array_values(array_unique(array_filter($keywords))), 1000) as $chunk) {
            $data = $this->call('POST', '/dataforseo_labs/google/search_intent/live', [[
                'keywords' => $chunk,
                'language_code' => 'en',
            ]]);

            foreach ((array) ($data['tasks'][0]['result'][0]['items'] ?? []) as $item) {
                if (isset($item['keyword'], $item['keyword_intent']['label'])) {
                    $out[mb_strtolower((string) $item['keyword'])] = (string) $item['keyword_intent']['label'];
                }
            }
        }

        return $out;
    }

    public function domainRankOverview(string $domain): ?array
    {
        $data = $this->call('POST', '/dataforseo_labs/google/domain_rank_overview/live', [[
            'target' => $domain,
            'location_name' => self::DEFAULT_LOCATION,
            'language_code' => 'en',
        ]]);

        $metrics = $data['tasks'][0]['result'][0]['items'][0]['metrics']['organic'] ?? null;
        if (! is_array($metrics)) {
            return null;
        }

        return [
            'pos_1' => (int) ($metrics['pos_1'] ?? 0),
            'pos_2_3' => (int) ($metrics['pos_2_3'] ?? 0),
            'pos_4_10' => (int) ($metrics['pos_4_10'] ?? 0),
            'pos_11_20' => (int) ($metrics['pos_11_20'] ?? 0),
            'count' => (int) ($metrics['count'] ?? 0),
            'etv' => (float) ($metrics['etv'] ?? 0),
            'is_new' => (int) ($metrics['is_new'] ?? 0),
            'is_lost' => (int) ($metrics['is_lost'] ?? 0),
        ];
    }

    public function backlinkSummary(string $domain): ?array
    {
        $data = $this->call('POST', '/backlinks/summary/live', [['target' => $domain, 'internal_list_limit' => 5]]);
        $result = $data['tasks'][0]['result'][0] ?? null;
        if (! is_array($result)) {
            return null;
        }

        return [
            'rank' => isset($result['rank']) ? (int) $result['rank'] : null,
            'backlinks' => (int) ($result['backlinks'] ?? 0),
            'referring_domains' => (int) ($result['referring_domains'] ?? 0),
            'spam_score' => isset($result['backlinks_spam_score']) ? (int) $result['backlinks_spam_score'] : null,
        ];
    }

    public function referringDomains(string $domain, int $limit = 100): array
    {
        $data = $this->call('POST', '/backlinks/referring_domains/live', [[
            'target' => $domain,
            'limit' => $limit,
            'order_by' => ['rank,desc'],
            'exclude_internal_backlinks' => true,
        ]]);

        $items = (array) ($data['tasks'][0]['result'][0]['items'] ?? []);
        $this->logIfTruncated('referringDomains', $domain, (int) ($data['tasks'][0]['result'][0]['total_count'] ?? 0), count($items));

        $out = [];
        foreach ($items as $item) {
            if (empty($item['domain'])) {
                continue;
            }

            $platformTypes = $item['referring_links_platform_types'] ?? null;
            $platform = is_array($platformTypes) ? array_key_first($platformTypes) : null;

            $out[] = [
                'domain' => mb_strtolower((string) $item['domain']),
                'rank' => (int) ($item['rank'] ?? 0),
                'backlinks' => (int) ($item['backlinks'] ?? 0),
                'platform' => $platform,
                'spam_score' => isset($item['backlinks_spam_score']) ? (int) $item['backlinks_spam_score'] : null,
            ];
        }

        return $out;
    }

    public function llmAnswer(string $platform, string $model, string $prompt): ?string
    {
        return $this->llmResponse($platform, $model, $prompt)['text'] ?? null;
    }

    public function llmResponse(string $platform, string $model, string $prompt): ?array
    {
        $data = $this->call('POST', "/ai_optimization/{$platform}/llm_responses/live", [[
            'user_prompt' => $prompt,
            'model_name' => $model,
            'web_search' => true,
        ]]);

        $sections = $data['tasks'][0]['result'][0]['items'][0]['sections'] ?? null;
        if (! is_array($sections)) {
            return null;
        }

        $text = '';
        $sources = [];
        foreach ($sections as $section) {
            $text .= ($section['text'] ?? '')."\n";
            foreach ((array) ($section['annotations'] ?? []) as $annotation) {
                $url = trim((string) ($annotation['url'] ?? ''));
                $host = mb_strtolower((string) parse_url($url, PHP_URL_HOST));
                if ($host === '' || isset($sources[$url]) || count($sources) >= 20) {
                    continue;
                }
                $title = trim((string) ($annotation['title'] ?? ''));
                $sources[$url] = [
                    'url' => $url,
                    'domain' => (string) preg_replace('/^www\./', '', $host),
                    'title' => $title !== '' ? $title : null,
                ];
            }
        }

        return trim($text) !== '' ? ['text' => trim($text), 'sources' => array_values($sources)] : null;
    }

    public function mapsResults(string $keyword, float $lat, float $lng, int $depth = 20): array
    {
        $data = $this->call('POST', '/serp/google/maps/live/advanced', [[
            'keyword' => $keyword,
            'location_coordinate' => sprintf('%.6f,%.6f,14z', $lat, $lng),
            'language_code' => 'en',
            'depth' => $depth,
        ]]);

        $out = [];
        foreach ((array) ($data['tasks'][0]['result'][0]['items'] ?? []) as $item) {
            if (($item['type'] ?? '') !== 'maps_search' && ! isset($item['rank_absolute'])) {
                continue;
            }

            $categories = array_values(array_filter(array_merge(
                [(string) ($item['category'] ?? '')],
                (array) ($item['additional_categories'] ?? [])
            )));

            $out[] = [
                'rank' => (int) ($item['rank_absolute'] ?? $item['rank_group'] ?? 0),
                'title' => (string) ($item['title'] ?? ''),
                'place_id' => $item['place_id'] ?? null,
                'url' => $item['url'] ?? null,
                'rating' => isset($item['rating']['value']) ? (float) $item['rating']['value'] : null,
                'reviews' => isset($item['rating']['votes_count']) ? (int) $item['rating']['votes_count'] : null,
                'claimed' => isset($item['is_claimed']) ? (bool) $item['is_claimed'] : null,
                'categories' => $categories ?: null,
            ];
        }

        return $out;
    }

    public function googleOrganicPosition(string $query, string $targetDomain, string $locationName = self::DEFAULT_LOCATION): array
    {
        $empty = ['position' => null, 'matched' => null, 'results' => [], 'local_pack' => false, 'result_count' => null];

        $payload = [[
            'keyword' => $query,
            'location_name' => self::locationName($locationName),
            'language_code' => 'en',
            'device' => 'desktop',
            'depth' => 100,
        ]];

        $data = $this->rawRequest('POST', '/serp/google/organic/live/advanced', $payload, self::SERP_TIMEOUT_SECONDS);
        if ($data === []) {
            return $empty;
        }

        $task = (array) ($data['tasks'][0] ?? []);
        $this->recordTask($task);

        // 40101 "Internal SE Server Error" is DataForSEO's transient upstream
        // failure (gsc's baseline sweep hit it on 8 of 31 queries); one
        // in-place retry clears most of them.
        if ((int) ($task['status_code'] ?? 0) === 40101) {
            ($this->sleep)(2);
            $retryData = $this->rawRequest('POST', '/serp/google/organic/live/advanced', $payload, self::SERP_TIMEOUT_SECONDS);
            if ($retryData !== []) {
                $task = (array) ($retryData['tasks'][0] ?? []);
                $this->recordTask($task);
            }
        }

        if ((int) ($task['status_code'] ?? 0) !== 20000) {
            return $empty;
        }

        return self::parseOrganicResult((array) ($task['result'][0] ?? []), $targetDomain);
    }

    public function googleOrganicStandardBatch(array $tasks, int $maxSeconds = 240, int $interval = 10): ?array
    {
        if ($tasks === []) {
            return [];
        }

        $payload = array_map(static function (array $task): array {
            $task = array_merge(['language_code' => 'en', 'device' => 'desktop', 'depth' => 100], $task);
            if (isset($task['location_name'])) {
                $task['location_name'] = self::locationName((string) $task['location_name']);
            }

            return $task;
        }, array_values($tasks));

        $data = $this->call('POST', '/serp/google/organic/task_post', $payload);

        // One entry per posted task, in the order posted — callers pair
        // these with their queries by position. A task DataForSEO refused
        // (one bad location name in a batch) keeps its place as null:
        // leaving it out moved every later id up one, and each later query
        // was then given the result of the query after it.
        $slots = [];
        foreach ((array) ($data['tasks'] ?? []) as $task) {
            $id = $task['id'] ?? null;
            $slots[] = is_string($id) && in_array((int) ($task['status_code'] ?? 0), [20000, 20100], true) ? $id : null;
        }
        $this->lastStandardTaskIds = array_pad(array_slice($slots, 0, count($payload)), count($payload), null);
        $ids = array_values(array_filter($this->lastStandardTaskIds, 'is_string'));

        if ($ids === []) {
            // task_post failed outright — lastError is already set by call();
            // the caller falls back to per-query Live Advanced for this run.
            return null;
        }

        $pending = array_fill_keys($ids, true);
        $this->pollUntil(function () use (&$pending): ?bool {
            $envelope = $this->call('GET', '/serp/google/organic/tasks_ready');
            foreach (self::resultsOf($envelope) as $row) {
                $id = $row['id'] ?? null;
                if (is_string($id)) {
                    unset($pending[$id]);
                }
            }

            return $pending === [] ? true : null;
        }, $maxSeconds, $interval);

        // Tasks still queued when the wait runs out are simply absent from the
        // map; lastStandardTaskIds() keeps every id, so the rank tracker
        // records them with their task id and `--collect` picks them up
        // later. Returning null here instead (0.19.0–0.19.5) sent every
        // caller to the Live endpoint for the WHOLE batch — paying for the
        // queued tasks and again for Live (seen on 2026-11-02's first run).
        $out = [];
        foreach (array_keys(array_diff_key(array_fill_keys($ids, true), $pending)) as $id) {
            $envelope = $this->call('GET', "/serp/google/organic/task_get/advanced/{$id}");
            $result = self::resultsOf($envelope)[0] ?? null;
            if (is_array($result)) {
                $out[$id] = $result;
            }
        }

        return $out;
    }

    public function googleOrganicTaskResult(string $id): array
    {
        $envelope = $this->call('GET', "/serp/google/organic/task_get/advanced/{$id}");
        $task = (array) ($envelope['tasks'][0] ?? []);
        $status = (int) ($task['status_code'] ?? 0);

        if ($status === 20000) {
            $result = $task['result'][0] ?? null;

            return is_array($result) ? ['status' => 'ready', 'result' => $result] : ['status' => 'error', 'result' => null];
        }

        if (in_array($status, [40601, 40602], true)) {
            return ['status' => 'pending', 'result' => null];
        }

        $this->lastError ??= ($status !== 0 ? (string) $status : '?').' '.($task['status_message'] ?? 'no response');

        return ['status' => 'error', 'result' => null];
    }

    public function googleOrganicReadyTasks(): array
    {
        $rows = [];
        foreach (self::resultsOf($this->call('GET', '/serp/google/organic/tasks_ready')) as $row) {
            $id = $row['id'] ?? null;
            if (is_string($id)) {
                $rows[] = ['id' => $id, 'tag' => isset($row['tag']) ? (string) $row['tag'] : null];
            }
        }

        return $rows;
    }

    /**
     * Parse one Google Organic result envelope's `items` array — the shape
     * shared by Live Advanced (googleOrganicPosition) and the Standard-queue
     * task_get/advanced result (googleOrganicStandardBatch) — into the
     * position/matched-domain/local-pack summary the contract asks for.
     *
     * @return array{position: ?int, matched: ?string, results: list<array{position: int, url: string, domain: string, title: string}>, local_pack: bool, result_count: ?int}
     */
    private static function parseOrganicResult(array $result, string $targetDomain): array
    {
        $items = (array) ($result['items'] ?? []);
        $position = null;
        $matched = null;
        $localPack = false;
        $results = [];
        $resultCount = 0;

        foreach ($items as $item) {
            $type = (string) ($item['type'] ?? '');

            if ($type === 'local_pack' || $type === 'map') {
                $localPack = true;
            }

            if ($type !== 'organic') {
                continue;
            }

            $resultCount++;
            $domain = (string) ($item['domain'] ?? '');

            if (count($results) < 10) {
                $results[] = [
                    'position' => (int) ($item['rank_absolute'] ?? $item['rank_group'] ?? 0),
                    'url' => (string) ($item['url'] ?? ''),
                    'domain' => $domain,
                    'title' => (string) ($item['title'] ?? ''),
                ];
            }

            if ($position === null && $domain !== '' && str_contains($domain, $targetDomain)) {
                $position = (int) ($item['rank_absolute'] ?? 0) ?: null;
                $matched = $domain;
            }
        }

        return [
            'position' => $position,
            'matched' => $matched,
            'results' => $results,
            'local_pack' => $localPack,
            'result_count' => $resultCount,
        ];
    }

    /** @return list<array<string, mixed>> */
    private static function resultsOf(array $envelope): array
    {
        return (array) ($envelope['tasks'][0]['result'] ?? []);
    }

    /**
     * DataForSEO spells a location "Arlington Heights,Illinois,United
     * States": no space after the commas. "Arlington Heights, Illinois,
     * United States" is rejected with 40501 Invalid Field 'location_name' —
     * which is how all of gsc's tracked queries failed every weekly run
     * until 2026-10-11.
     */
    private static function locationName(string $name): string
    {
        return trim((string) preg_replace('/\s*,\s*/', ',', trim($name)));
    }

    /**
     * A6: Labs/Backlinks endpoints return `items` capped at `limit` even when
     * `total_count` says more exist — there is no paging here, so a caller
     * silently working off a partial list (e.g. a 300-row keyword pull that
     * is actually one of 4,000) never finds out. One warning line, no UI.
     */
    private function logIfTruncated(string $method, string $subject, int $totalCount, int $returned): void
    {
        if ($totalCount > $returned) {
            logger()->warning("DataForSeoClient::{$method} truncated for \"{$subject}\": {$returned} of {$totalCount} returned (no paging).");
        }
    }

    /** One authenticated call; records every task's billed cost; returns decoded JSON or [] on failure. */
    private function call(string $method, string $path, array $body = []): array
    {
        $data = $this->rawRequest($method, $path, $body, self::LIVE_TIMEOUT_SECONDS);

        foreach ((array) ($data['tasks'] ?? []) as $task) {
            $this->recordTask((array) $task);
        }

        return $data;
    }

    /**
     * The one HTTP seam: basic-auth, an explicit timeout, two retries on
     * transport failure, [] on anything that goes wrong (getLastError()
     * says what). Deliberately does not record task cost itself —
     * googleOrganicPosition() calls this twice (its own bespoke 40101
     * retry) and must record each attempt's cost separately, so that
     * bookkeeping stays in recordTask(), called by each caller.
     */
    private function rawRequest(string $method, string $path, array $body, int $timeoutSeconds): array
    {
        $this->lastError = null;

        if (! $this->credentials->isConfigured()) {
            $this->lastError = self::NOT_CONFIGURED_ERROR;

            return [];
        }

        try {
            $request = $this->http
                ->withBasicAuth((string) $this->credentials->login(), (string) $this->credentials->password())
                ->timeout($timeoutSeconds)
                ->retry(2, 1500, throw: false);

            $response = $method === 'GET' ? $request->get(self::BASE.$path) : $request->post(self::BASE.$path, $body);
        } catch (\Throwable $e) {
            $this->lastError = 'request failed: '.mb_substr($e->getMessage(), 0, 160);

            return [];
        }

        if (! $response->successful()) {
            $this->lastError = 'HTTP '.$response->status().': '.mb_substr($response->body(), 0, 200);

            return [];
        }

        return (array) $response->json();
    }

    /**
     * Records one decoded task's billed cost (spent()) and, if it failed,
     * the error. googleOrganicPosition() calls this directly (its 40101
     * retry sits outside call()); every other method goes through call(),
     * which calls this once per task in the response.
     *
     * @param  array<string, mixed>  $task
     */
    private function recordTask(array $task): void
    {
        $this->spent += (float) ($task['cost'] ?? 0);

        if ((int) ($task['status_code'] ?? 20000) !== 20000) {
            $this->lastError = ($task['status_code'] ?? '?').' '.($task['status_message'] ?? '');
        }
    }
}
