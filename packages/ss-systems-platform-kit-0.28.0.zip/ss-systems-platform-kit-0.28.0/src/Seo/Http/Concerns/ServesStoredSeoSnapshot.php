<?php

namespace SsSystems\Platform\Seo\Http\Concerns;

use Illuminate\Container\Container;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Carbon;
use SsSystems\Platform\Seo\Checks\SiteCheckBlock;
use SsSystems\Platform\Seo\Snapshot\Contracts\SeoSnapshotSource;
use SsSystems\Platform\Seo\Snapshot\SeoSnapshotStore;
use SsSystems\Platform\Seo\Status\SeoStatus;

/**
 * GET seo/snapshot from the stored copy, and GET seo/summary (kit 0.26.0,
 * 2026-11-11) — the half of a site's snapshot controller that is the same
 * everywhere. See {@see SeoSnapshotStore} for why the snapshot is built
 * ahead of time and which combinations are.
 *
 * The using controller implements {@see SeoSnapshotSource} — its former
 * GET seo/snapshot body becomes `buildSnapshot()`, and
 * `forgetSnapshotCaches()` forgets whatever its blocks cache — and answers
 * the endpoint from {@see storedSnapshot()}:
 *
 * ```php
 * class SeoSnapshotController extends Controller implements SeoSnapshotSource
 * {
 *     use BuildsApiResponses;
 *     use BuildsSeoSnapshot;
 *     use ServesStoredSeoSnapshot;
 *
 *     public function __invoke(Request $request): JsonResponse
 *     {
 *         return $this->itemResponse($this->storedSnapshot($request));
 *     }
 *
 *     public function buildSnapshot(Request $request): array { ... the old body ... }
 *
 *     public function forgetSnapshotCaches(Request $request): void { ... }
 * }
 * ```
 *
 * `summaryHealth()`/`summaryGscErrors()` come with {@see BuildsSeoSnapshot};
 * a controller without that trait (gs.construction's, J. Peterson's)
 * writes its own two. The site then routes `GET seo/summary` to
 * `summary()`, schedules `seo:snapshot-store` every 15 minutes, calls it
 * after its Search Console sync and binds SeoSnapshotSource to the
 * controller.
 */
trait ServesStoredSeoSnapshot
{
    /**
     * {@see SeoSnapshotSource::buildSnapshot()}
     *
     * @return array<string, mixed>
     */
    abstract public function buildSnapshot(Request $request): array;

    /** {@see SeoSnapshotSource::forgetSnapshotCaches()} */
    abstract public function forgetSnapshotCaches(Request $request): void;

    /**
     * The `health` block seo/summary answers.
     *
     * @param  array<string, mixed>|null  $stored  the newest stored snapshot's `health`, null when none is stored
     * @return array<string, mixed>
     */
    abstract protected function summaryHealth(Request $request, ?array $stored): array;

    /**
     * The `gsc_errors` block seo/summary answers: `available` and `totals`.
     *
     * @return array<string, mixed>
     */
    abstract protected function summaryGscErrors(): array;

    /**
     * GET seo/snapshot's `data`: the stored copy for a combination the hub
     * asks for, `computed_at` saying when it was built; `?fresh=1` builds
     * it now — forgetting the blocks' own caches first — and stores it; any
     * other query builds on demand as before.
     *
     * Whatever is built here leaves with the kit's own `site_checks` block
     * on it ({@see SiteCheckBlock}): the plain-language summary of the site
     * checks, read from what the last health-check stored, so no site's
     * `buildSnapshot()` has to know of it.
     *
     * @return array<string, mixed>
     */
    protected function storedSnapshot(Request $request): array
    {
        $fresh = $request->boolean('fresh');

        return $this->seoSnapshotStore()->serve(
            self::snapshotQuery($request),
            $fresh,
            function () use ($request, $fresh): array {
                if ($fresh) {
                    $this->forgetSnapshotCaches($request);
                }

                return SiteCheckBlock::attach($this->buildSnapshot($request));
            },
        );
    }

    /**
     * GET seo/summary — the platform dashboard card's figures without
     * building the snapshot: the health score (and its pillars, which
     * decide whether the hub may show it as one number) from the newest
     * stored snapshot, the prior score for `prior_days`, and the trouble
     * tiles' counts read now. `computed_at` is when the oldest figure in
     * it was computed — the stored snapshot's, or now.
     *
     * Since 2026-11-12 it also carries `status`: how the site's data
     * collection is doing in five figures ({@see SeoStatus::summary()}) —
     * the worst state among its sources, how many are failing and late,
     * how many count, and the scheduler's own state — so the dashboard can
     * say "1 failing" without a second request per site. The kit adds it;
     * no site's controller knows of it. Should it fail to build, the
     * summary goes out without it, as it did before.
     */
    public function summary(Request $request): JsonResponse
    {
        $stored = $this->seoSnapshotStore()->newest();
        $storedHealth = is_array($stored['health'] ?? null) ? $stored['health'] : null;

        $data = [
            'health' => $this->summaryHealth($request, $storedHealth),
            'gsc_errors' => $this->summaryGscErrors(),
            'computed_at' => $storedHealth !== null && isset($stored['computed_at'])
                ? (string) $stored['computed_at']
                : Carbon::now()->toIso8601String(),
        ];

        try {
            $data['status'] = SeoStatus::summary();
        } catch (\Throwable $e) {
            if (function_exists('report')) {
                report($e);
            }
        }

        return new JsonResponse(['data' => $data]);
    }

    /**
     * The query a snapshot request stands for, without `fresh`. The input,
     * not only the query string: POST seo/snapshot/refresh carries its
     * trend window in the body.
     *
     * @return array<string, mixed>
     */
    protected static function snapshotQuery(Request $request): array
    {
        return Arr::except($request->input(), ['fresh']);
    }

    protected function seoSnapshotStore(): SeoSnapshotStore
    {
        return Container::getInstance()->make(SeoSnapshotStore::class);
    }
}
