<?php

namespace SsSystems\Platform\Seo\Http\Concerns;

use Illuminate\Http\JsonResponse;
use SsSystems\Platform\Seo\Status\SeoStatus;

/**
 * GET seo/status (2026-11-12) — every source of SEO/GEO data this site
 * collects, when each last ran and last succeeded, and one word for how it
 * is doing; plus the scheduler's own heartbeat. What ss.systems' status
 * collector reads every half hour to say "data OK", "2 late" or "Bing has
 * been failing since Tuesday" — see {@see SeoStatus} for how a row is
 * worked out, and docs/SEO-STATUS.md for the shape.
 *
 * It reads the heartbeat store and one MAX(date) per data table, never a
 * vendor, and needs nothing from the controller that uses it: there is no
 * hook to implement.
 *
 * NO SITE HAS TO USE THIS TRAIT. The kit's own
 * {@see \SsSystems\Platform\Seo\Status\SeoStatusController} answers the
 * endpoint, and {@see \SsSystems\Platform\Seo\Status\SeoStatusServiceProvider}
 * routes it beside the site's `seo/summary`. A site that wants the
 * endpoint on a controller of its own (to answer under another path, or
 * behind other middleware) uses the trait and routes it itself:
 *
 * ```php
 * Route::get('seo/status', [SeoSnapshotController::class, 'status']);
 * ```
 *
 * A route the site registers always wins; the kit then adds none.
 */
trait ServesSeoStatus
{
    public function status(): JsonResponse
    {
        return new JsonResponse(['data' => SeoStatus::payload()]);
    }
}
