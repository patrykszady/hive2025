<?php

namespace SsSystems\Platform\Seo\Inspection;

/**
 * What UrlInspectionSweep::run() hands back — everything a site's thin
 * seo:gsc-inspect-bulk wrapper needs to behave exactly like the original
 * command did (print `lines` in order, write `markdown` to storage when
 * asked) without owning any of the sweep's own algorithm.
 *
 * The original command's own FAILURE exit was exactly one case ("Nothing
 * to inspect.", when the resolved pool was empty) and every other early
 * return was SUCCESS — a spent allowance, a mid-run 429, a normal
 * completion. Every site's wrapper reads `lines` for that line and for
 * UrlInspectionSweep::NOT_CONNECTED_LINE; see docs/INSPECTION-SWEEP.md.
 *
 * {@see failed()} is the same answer without string matching, and one case
 * wider: a sweep in which nothing was inspected and every call failed for
 * a reason other than the daily allowance. `$refused` marks the case every
 * wrapper already exits 1 on since 2026-11 — Google answered 401 or 403 for
 * every URL — because the sweep ends that run on NOT_CONNECTED_LINE.
 */
final class SweepResult
{
    /**
     * @param  list<array{url: string, prev_verdict: ?string, verdict: ?string, prev_coverage: ?string, coverage: ?string, rich_issue_count: int, changed: bool}>  $changes  Only rows whose verdict/coverage_state/page_fetch_state/google_canonical changed since the previous inspection — exactly what the original command's $changes accumulated and writeReport()'s "State changes this run" table lists.
     * @param  list<string>  $lines  The console lines the command printed, in order (info/warn/per-URL result lines, the closing "Done. inspected=…" line) — plain text, no color/level attached; the site's wrapper prints each with $this->line().
     */
    public function __construct(
        public readonly int $inspected,
        public readonly int $failures,
        public readonly array $changes,
        public readonly int $richIssues,
        public readonly bool $stoppedOnQuota,
        public readonly int $quotaRemaining,
        public readonly string $markdown,
        public readonly array $lines,
        public readonly bool $refused = false,
    ) {
    }

    /**
     * Whether a wrapper should exit non-zero: an empty pool, no grant,
     * every URL refused, or nothing inspected with every call failed —
     * unless Google stopped the run on its daily allowance, which is a
     * normal end.
     */
    public function failed(): bool
    {
        if ($this->refused
            || in_array('Nothing to inspect.', $this->lines, true)
            || in_array(UrlInspectionSweep::NOT_CONNECTED_LINE, $this->lines, true)) {
            return true;
        }

        return $this->inspected === 0 && $this->failures > 0 && ! $this->stoppedOnQuota;
    }
}
