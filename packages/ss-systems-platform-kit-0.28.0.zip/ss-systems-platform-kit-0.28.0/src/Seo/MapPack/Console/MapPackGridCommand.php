<?php

namespace SsSystems\Platform\Seo\MapPack\Console;

use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use SsSystems\Platform\Seo\Concerns\ExplainsFailure;
use SsSystems\Platform\Seo\Contracts\SeoSiteProfile;
use SsSystems\Platform\Seo\DataForSeo\Budget;
use SsSystems\Platform\Seo\DataForSeo\Contracts\DataForSeoApi;
use SsSystems\Platform\Seo\MapPack\GeoGrid;
use SsSystems\Platform\Seo\MapPack\MapPackStore;

/**
 * `seo:map-pack-grid` — geo-grid scan of the service area via DataForSEO's
 * Google Maps SERP (~$0.002 a point), ported from gs.construction's
 * `SeoMapPackGrid` command. Per keyword, records: rank at every grid point,
 * ARP/ATRP/SoLV, and every other business seen with its pack appearances,
 * reviews and rating — into `MapPackStore`.
 *
 * CHANGED FROM GSC:
 *  - grid size and radius are command options (`--grid`, `--radius`,
 *    gsc's own defaults 7 and 15), not `config('seo.map_pack.*')` — kit
 *    code never reads config() for site facts (see `SeoSiteProfile`).
 *  - self-recognition uses `SeoSiteProfile::brandPatterns()` (a list of
 *    case-insensitive regex fragments), not a single lowercased substring
 *    match against `config('brand.name')`.
 *  - the budget gate is the kit's shared `Budget` class
 *    (`canSpend()`/`charge()` against a flat per-point cost estimate),
 *    not an ad hoc `$dfs->spent() >= $budget` comparison — `--budget` is
 *    therefore a cap on *estimated* spend, checked before each call, same
 *    position in the loop gsc's check occupied.
 *  - `DataForSeoBudget`'s balance precheck (gsc also runs this for its
 *    other DataForSEO commands) is not reproduced; this command's own
 *    "stop" conditions are exactly the two the integrator asked for: the
 *    API being unconfigured, and the budget running out mid-grid.
 *
 * What is and is not a failure (2026-11): a profile with no coordinates or
 * no map queries is "not applicable" and exits 0; a keyword whose every
 * point failed is not stored at all (it used to be stored as rank 21 / 0%
 * and become the latest scan); the run exits 1, with the reason as its last
 * line ({@see ExplainsFailure}), only when every point of the whole run
 * failed.
 */
class MapPackGridCommand extends Command
{
    use ExplainsFailure;

    private const COST_PER_POINT_USD = 0.002;

    protected $signature = 'seo:map-pack-grid
        {--keywords= : CSV override of SeoSiteProfile::mapsQueries()}
        {--budget=2 : USD cap on this run\'s estimated spend}
        {--grid=7 : Grid size (N×N)}
        {--radius=15 : Grid radius in miles}
        {--dry-run : Print the grid and the estimate, spend nothing}';

    protected $description = 'Geo-grid map-pack scan of the service area via DataForSEO Google Maps into map_pack_scans';

    public function handle(DataForSeoApi $dfs, SeoSiteProfile $profile, MapPackStore $store): int
    {
        if (! $dfs->isConfigured()) {
            $this->comment('DataForSEO is not configured (missing login or password) — skipping.');

            return self::SUCCESS;
        }

        if (! $store->hasScansTable()) {
            $this->comment('map_pack_scans table is missing — skipping.');

            return self::SUCCESS;
        }

        $lat = $profile->latitude();
        $lng = $profile->longitude();
        $size = max(3, (int) $this->option('grid'));
        $radius = (float) $this->option('radius');

        $keywordsOption = trim((string) $this->option('keywords'));
        $keywords = $keywordsOption !== ''
            ? array_values(array_filter(array_map('trim', explode(',', $keywordsOption))))
            : $profile->mapsQueries();

        // A site with no office on the map, or nothing it wants found on
        // one (mozaika.haus), has no map pack to scan. That is "does not
        // apply", not a failed run: exiting 1 here made its weekly schedule
        // line report a failure every week.
        if ($lat === null || $lng === null || $keywords === []) {
            $this->comment(sprintf(
                'Not applicable: this site has %s on file, so there is no map pack to scan — nothing was spent. (The site profile supplies latitude(), longitude() and mapsQueries(); --keywords overrides the queries.)',
                $lat === null || $lng === null ? 'no office coordinates' : 'no map queries',
            ));

            return self::SUCCESS;
        }

        $points = GeoGrid::points($lat, $lng, $size, $radius);
        $estimate = count($points) * count($keywords) * self::COST_PER_POINT_USD;
        $balance = $dfs->balance();

        $this->line(sprintf(
            '%d×%d grid (%d points, %s mi radius) × %d keywords — estimated $%.2f · balance %s',
            $size,
            $size,
            count($points),
            $radius,
            count($keywords),
            $estimate,
            $balance === null ? '?' : '$'.number_format($balance, 2),
        ));

        if ($this->option('dry-run')) {
            return self::SUCCESS;
        }

        $budget = Budget::usd((float) $this->option('budget'));
        $brandPatterns = $profile->brandPatterns();
        $today = Carbon::now();
        $attempted = 0;
        $failed = 0;
        $stored = 0;

        foreach ($keywords as $keyword) {
            $grid = [];
            $competitors = [];
            $found = 0;
            $rankSum = 0;
            $totalRankSum = 0;
            $top3 = 0;
            $partial = false;
            $pointsFailed = 0;
            $pointError = null;

            foreach ($points as $point) {
                if (! $budget->canSpend(self::COST_PER_POINT_USD)) {
                    $this->warn('Budget reached mid-grid.');
                    $partial = true;
                    break;
                }
                $budget->charge(self::COST_PER_POINT_USD);
                $attempted++;

                $results = $dfs->mapsResults($keyword, $point['lat'], $point['lng']);
                if ($results === [] && $dfs->getLastError() !== null) {
                    $failed++;
                    $pointsFailed++;
                    $pointError = $dfs->getLastError();
                }

                $rank = null;
                foreach ($results as $result) {
                    $placeId = (string) ($result['place_id'] ?? '');
                    $isUs = self::matchesBrand((string) $result['title'], $brandPatterns);

                    if ($isUs && $rank === null) {
                        $rank = (int) $result['rank'];
                    }
                    if ($placeId === '' || $isUs) {
                        continue;
                    }

                    $competitor = $competitors[$placeId] ?? [
                        'place_id' => $placeId,
                        'name' => $result['title'],
                        'url' => $result['url'],
                        'rating' => $result['rating'],
                        'reviews' => $result['reviews'],
                        'claimed' => $result['claimed'],
                        'categories' => $result['categories'],
                        'pack' => 0,
                        'seen' => 0,
                        'best' => 99,
                    ];
                    $competitor['seen']++;
                    $competitor['best'] = min($competitor['best'], (int) $result['rank']);
                    if ((int) $result['rank'] <= 3) {
                        $competitor['pack']++;
                    }
                    $competitors[$placeId] = $competitor;
                }

                $grid[] = ['lat' => $point['lat'], 'lng' => $point['lng'], 'rank' => $rank];

                if ($rank !== null) {
                    $found++;
                    $rankSum += $rank;
                    $totalRankSum += $rank;
                    if ($rank <= 3) {
                        $top3++;
                    }
                } else {
                    $totalRankSum += 21;
                }
            }

            // A keyword whose every point failed (an outage, a rejected
            // request) or that got no point at all before the budget ran out
            // measured nothing. Stored, it would read "rank 21, 0% of the
            // area" and become the latest scan — a failure shown as a
            // collapse. Nothing is stored; the previous scan stays the latest.
            if ($grid === [] || $pointsFailed === count($grid)) {
                $this->warn(sprintf(
                    '  %-24s not stored: %s',
                    $keyword,
                    $grid === []
                        ? 'no point was asked before the budget was reached'
                        : sprintf('all %d points failed (%s)', count($grid), $pointError ?? 'no answer'),
                ));

                if ($partial) {
                    break;
                }

                continue;
            }

            usort($competitors, static fn (array $a, array $b): int => [$b['pack'], $b['seen']] <=> [$a['pack'], $a['seen']]);
            $competitors = array_slice(array_values($competitors), 0, 25);
            $pointsRecorded = count($grid);
            $scanId = 'grid-'.$today->format('Ymd').'-'.substr(md5($keyword), 0, 8);

            $detail = [
                'source' => 'dataforseo',
                'grid' => $grid,
                'pack_leaders' => array_map(
                    static fn (array $c): array => ['business' => $c['name'], 'appearances' => $c['pack']],
                    array_slice($competitors, 0, 8),
                ),
                'found' => $found,
                'points_total' => $pointsRecorded,
                'points_expected' => count($points),
                // Points DataForSEO did not answer for; they sit in the grid
                // as "not found" like any other miss, so a reader can tell
                // how much of a weak scan is really a weak answer.
                'points_failed' => $pointsFailed,
                // A budget cutoff mid-grid keeps the points collected so far
                // for THIS keyword (flagged partial) instead of discarding
                // them, so the report can tell "scanned the whole area" from
                // "ran out of budget a third of the way through".
                'partial' => $partial,
                'center' => ['lat' => $lat, 'lng' => $lng],
                'radius' => $radius.'mi',
            ];

            $store->recordScan(
                scanId: $scanId,
                keyword: $keyword,
                platform: 'google',
                scannedAt: $today,
                arp: $found ? round($rankSum / $found, 2) : 21.0,
                atrp: $pointsRecorded ? round($totalRankSum / $pointsRecorded, 2) : 21.0,
                solv: $pointsRecorded ? round(100 * $top3 / $pointsRecorded, 2) : 0.0,
                saiv: null,
                gridPoints: $size,
                inTop3: $top3,
                raw: $detail,
            );

            $stored++;

            $store->recordCompetitors($scanId, $keyword, $today, array_map(
                static fn (array $c): array => [
                    'place_id' => $c['place_id'],
                    'name' => $c['name'],
                    'url' => $c['url'],
                    'rating' => $c['rating'],
                    'reviews' => $c['reviews'],
                    'claimed' => $c['claimed'],
                    'categories' => $c['categories'],
                    'pack_points' => $c['pack'],
                    'seen_points' => $c['seen'],
                    'best_rank' => $c['best'] < 99 ? $c['best'] : null,
                ],
                $competitors,
            ));

            $this->line(sprintf(
                '  %-24s in pack %3d/%d · found %3d · ARP %s%s',
                $keyword,
                $top3,
                $pointsRecorded,
                $found,
                $found ? (string) round($rankSum / $found, 1) : '—',
                $partial ? '  [PARTIAL — budget reached]' : '',
            ));

            if ($partial) {
                break; // budget is gone; no further keyword is started this run
            }
        }

        if ($attempted > 0 && $failed === $attempted) {
            return $this->failBecause(self::reasonForError($dfs->getLastError(), self::REASON_NOTHING_SUCCEEDED), sprintf(
                'every grid point failed (%d of %d; last error: %s) — no scan was stored',
                $failed,
                $attempted,
                $dfs->getLastError() ?? 'no answer',
            ));
        }

        $this->info(sprintf('Done. %d of %d keywords stored. Spent $%.3f.', $stored, count($keywords), $dfs->spent()));

        return self::SUCCESS;
    }

    /** @param  list<string>  $patterns */
    private static function matchesBrand(string $title, array $patterns): bool
    {
        foreach ($patterns as $pattern) {
            if (preg_match('/'.$pattern.'/i', $title) === 1) {
                return true;
            }
        }

        return false;
    }
}
