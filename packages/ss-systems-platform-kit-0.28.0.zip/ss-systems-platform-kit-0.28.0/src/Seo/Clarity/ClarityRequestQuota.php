<?php

namespace SsSystems\Platform\Seo\Clarity;

use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;
use Psr\SimpleCache\CacheInterface;

/**
 * Clarity's Data Export API answers ten requests per project per day, and
 * three callers spend from that one allowance without knowing of each
 * other: `seo:clarity-sync` (one request, two with the per-page breakdown),
 * the traffic collector (one) and the clarity-health report (one, and one
 * more when it is retried). Past the tenth Clarity answers 429 — which the
 * client used to report as "check token/project id", sending whoever read
 * the log to the wrong place (2026-11).
 *
 * This is the shared count, the way {@see \SsSystems\Platform\Seo\Inspection\UrlInspectionQuota}
 * is for the URL Inspection allowance: every caller asks {@see allows()}
 * before a request and calls {@see consume()} when it sends one, so the
 * eleventh is refused here, politely and by name, instead of at Clarity;
 * and a 429 that arrives anyway ({@see markExhausted()} — another machine
 * with the same token, a day boundary we guessed wrong) closes the day for
 * every other caller on this site.
 *
 * Keyed by a hash of the API token, not the project id: a token belongs to
 * one project, and the traffic collector is handed the token alone. The
 * token itself is never stored or logged.
 *
 * The count lives in the site's own cache store. Built without one it
 * reaches for the application's default store through the Cache facade; in
 * a process with no cache at all (the kit's own tests, a bare script) it
 * counts nothing and refuses nothing — losing the count must never be what
 * stops a sync. Like UrlInspectionQuota it is read-then-write, not atomic:
 * the callers run minutes apart on the schedule, not concurrently.
 *
 * The day is the UTC day. Microsoft documents "per project per day"
 * without naming a clock; a wrong guess costs at most one refused request
 * that would have been answered, or one 429 that closes the day here.
 */
final class ClarityRequestQuota
{
    public const DAILY_LIMIT = 10;

    public const KEY_PREFIX = 'clarity.export-requests';

    public function __construct(
        private readonly ?CacheInterface $cache = null,
        private readonly int $dailyLimit = self::DAILY_LIMIT,
    ) {
    }

    /** Requests counted against this token's project today. */
    public function used(string $token): int
    {
        return (int) ($this->store()?->get($this->key($token), 0) ?? 0);
    }

    public function remaining(string $token): int
    {
        return max(0, $this->dailyLimit - $this->used($token));
    }

    public function allows(string $token): bool
    {
        return $this->remaining($token) > 0;
    }

    /** One request is about to be sent — counted before the answer, because a request that times out here may still have counted there. */
    public function consume(string $token): void
    {
        $this->store()?->set($this->key($token), $this->used($token) + 1, $this->secondsUntilReset());
    }

    /** Clarity answered 429: the day is spent, whatever this site counted. */
    public function markExhausted(string $token): void
    {
        $this->store()?->set($this->key($token), $this->dailyLimit, $this->secondsUntilReset());
    }

    /** What a caller reports when it did not ask because the count says the day is spent. */
    public function refusal(string $token): string
    {
        return sprintf(
            "Clarity's daily limit is used up: %d of %d Data Export requests for this project were already made today, so this one was not sent. The limit resets at midnight UTC.",
            $this->used($token),
            $this->dailyLimit,
        );
    }

    /** What a caller reports when Clarity itself answered 429. */
    public static function limitReachedMessage(): string
    {
        return sprintf(
            "Clarity answered HTTP 429: the Data Export API's daily limit (%d requests per project per day) is used up. The token and project id are fine; it resets at midnight UTC.",
            self::DAILY_LIMIT,
        );
    }

    private function store(): ?CacheInterface
    {
        if ($this->cache !== null) {
            return $this->cache;
        }

        try {
            $store = Cache::getFacadeRoot()?->store();
        } catch (\Throwable) {
            return null;
        }

        return $store instanceof CacheInterface ? $store : null;
    }

    private function key(string $token): string
    {
        return self::KEY_PREFIX.'.'.substr(hash('sha256', trim($token)), 0, 16).'.'.Carbon::now('UTC')->toDateString();
    }

    private function secondsUntilReset(): int
    {
        $now = Carbon::now('UTC');

        return max(1, (int) $now->diffInSeconds($now->copy()->addDay()->startOfDay(), false));
    }
}
