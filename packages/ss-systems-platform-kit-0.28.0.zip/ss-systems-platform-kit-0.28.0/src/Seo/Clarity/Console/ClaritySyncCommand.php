<?php

namespace SsSystems\Platform\Seo\Clarity\Console;

use Illuminate\Console\Command;
use SsSystems\Platform\Seo\Clarity\ClarityClient;
use SsSystems\Platform\Seo\Clarity\ClarityMetricsStore;
use SsSystems\Platform\Seo\Clarity\Contracts\ClarityCredentials;
use SsSystems\Platform\Seo\Clarity\Contracts\ClaritySiteHosts;
use SsSystems\Platform\Seo\Contracts\SeoSiteProfile;

/**
 * `seo:clarity-sync` — gs.construction's SyncMicrosoftClarity, now one
 * command for every site (2026-11-02). Writes today's site-wide row to
 * clarity_daily_metrics, then — where the site has clarity_page_metrics —
 * the per-page breakdown for the last 24 hours. A site with no Clarity
 * project and token stops cleanly, so the schedule line is safe
 * everywhere; a per-page failure is reported but does not fail the run,
 * since the site-wide row is already written. An answer with no data rows
 * writes nothing (it used to write a row of zeros dated today) and exits 0;
 * a request refused because the day's ten are spent fails the run and says
 * exactly that ({@see \SsSystems\Platform\Seo\Clarity\ClarityRequestQuota}).
 */
final class ClaritySyncCommand extends Command
{
    /** @var string */
    protected $signature = 'seo:clarity-sync
        {--days=3 : Days the site-wide row covers (Clarity answers for 1-3)}
        {--no-pages : Skip the per-page breakdown (saves one of the ten daily API requests)}
        {--dry-run : Fetch and print the rows without writing them}';

    /** @var string */
    protected $description = 'Sync Microsoft Clarity behaviour metrics (site-wide, and per page where the site keeps them).';

    public function handle(): int
    {
        /** @var ClarityCredentials $credentials */
        $credentials = $this->laravel->make(ClarityCredentials::class);
        if (! $credentials->isConfigured()) {
            $this->comment('Microsoft Clarity has no project id and API token on this site (Connect Services); seo:clarity-sync skipped.');

            return self::SUCCESS;
        }

        /** @var ClarityClient $client */
        $client = $this->laravel->make(ClarityClient::class);
        /** @var ClarityMetricsStore $store */
        $store = $this->laravel->make(ClarityMetricsStore::class);
        $dry = (bool) $this->option('dry-run');

        if (! $dry && ! $store->hasDailyTable()) {
            $this->error('No clarity_daily_metrics table: copy the kit stub resources/stubs/seo/create_clarity_daily_metrics_table.php.stub into database/migrations and migrate.');

            return self::FAILURE;
        }

        $requested = max(1, (int) $this->option('days'));
        $days = min($requested, ClarityClient::MAX_DAYS);
        if ($requested !== $days) {
            $this->warn('Clarity answers for at most '.ClarityClient::MAX_DAYS." days; using {$days}.");
        }

        $projectId = (string) $credentials->projectId();
        $day = $client->dailySnapshot($days);
        if ($day === null && $client->lastError() === ClarityClient::NO_DATA_ERROR) {
            // Not a failure and not a day of zeros: nothing is written, and
            // the health report's own staleness check is what notices a
            // site that keeps answering empty.
            $this->comment(ClarityClient::NO_DATA_ERROR.' Nothing written.');

            return self::SUCCESS;
        }
        if ($day === null) {
            $this->error('Clarity fetch failed: '.($client->lastError() ?: 'unknown error'));

            return self::FAILURE;
        }

        if ($dry) {
            $this->line((string) json_encode($day, JSON_UNESCAPED_SLASHES));
        } else {
            $store->recordDay($projectId, $day);
            $this->info("Clarity {$day['date']}: {$day['sessions']} sessions, {$day['rage_clicks']} rage clicks, {$day['dead_clicks']} dead clicks, {$day['script_errors']} script errors.");
        }

        if (! $this->option('no-pages') && $store->hasPageTable()) {
            $this->syncPages($client, $store, $projectId, $dry);
        }

        return self::SUCCESS;
    }

    private function syncPages(ClarityClient $client, ClarityMetricsStore $store, string $projectId, bool $dry): void
    {
        $hosts = $this->siteHosts();
        if ($hosts === []) {
            $this->warn('Per-page breakdown skipped: no site hosts (bind ClaritySiteHosts or SeoSiteProfile).');

            return;
        }

        $pages = $client->pageMetrics($hosts);
        if ($pages === null) {
            $this->warn('Per-page fetch failed: '.($client->lastError() ?: 'unknown error').'; the site-wide row was still written.');

            return;
        }

        if ($dry) {
            foreach (array_slice($pages, 0, 10) as $row) {
                $this->line((string) json_encode($row, JSON_UNESCAPED_SLASHES));
            }

            return;
        }

        foreach ($pages as $row) {
            $store->recordPage($projectId, $row);
        }
        $this->info('Clarity per page: '.count($pages).' paths.');
    }

    /** @return list<string> */
    private function siteHosts(): array
    {
        if ($this->laravel->bound(ClaritySiteHosts::class)) {
            return $this->laravel->make(ClaritySiteHosts::class)->hosts();
        }

        if ($this->laravel->bound(SeoSiteProfile::class)) {
            $domain = trim((string) $this->laravel->make(SeoSiteProfile::class)->domain());

            return $domain !== '' ? [(string) (parse_url(str_contains($domain, '://') ? $domain : 'https://'.$domain, PHP_URL_HOST) ?: $domain)] : [];
        }

        return [];
    }
}
