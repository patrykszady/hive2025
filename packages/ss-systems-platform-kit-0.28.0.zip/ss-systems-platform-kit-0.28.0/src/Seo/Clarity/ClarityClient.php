<?php

namespace SsSystems\Platform\Seo\Clarity;

use Illuminate\Http\Client\Factory as HttpFactory;
use Illuminate\Support\Carbon;
use SsSystems\Platform\Seo\Clarity\Contracts\ClarityCredentials;

/**
 * Microsoft Clarity's Data Export API (project-live-insights), ported from
 * gs.construction's App\Services\MicrosoftClarityService — the most
 * complete of the five copies the sites carried (2026-11-02) — with its
 * parsing kept exactly, so the rows every site writes from here on read
 * the same as gs.construction's history:
 *
 *   - dailySnapshot(): one site-wide row for the last 1–3 days, dated
 *     today, from a request broken out by OS (a stable dimension keeps the
 *     payload's shape deterministic); sessions include bots, as they always
 *     have in clarity_daily_metrics; scroll depth is session-weighted.
 *   - pageMetrics(): the same signals per path for the last 24 hours, from
 *     a request broken out by URL, human sessions only, kept to the site's
 *     own hosts and folded to a normalised path.
 *
 * Clarity allows ten requests per project per day; one sync spends one
 * (two with the per-page breakdown). Null with lastError() set on any
 * failure — the caller never has to tell a missing token from a 401.
 *
 * Every request is counted in {@see ClarityRequestQuota}, shared with the
 * traffic collector and the health report: the eleventh of a day is not
 * sent, and a 429 is named as the daily limit rather than a token problem.
 * An answer with no data rows is not a day of zeros: dailySnapshot()
 * returns null with {@see NO_DATA_ERROR}, and nothing is written.
 */
final class ClarityClient
{
    public const ENDPOINT = 'https://www.clarity.ms/export-data/api/v1/project-live-insights';

    /** The API answers for the last 1–3 days only. */
    public const MAX_DAYS = 3;

    /** lastError() after an answer that held no data rows — a caller writes nothing and need not fail. */
    public const NO_DATA_ERROR = 'Clarity answered with no data rows for the period, so there is nothing to record.';

    private ?string $lastError = null;

    /**
     * @param  \Closure(): string|null  $today  'Y-m-d' the rows are dated; defaults to today in the app's timezone
     */
    public function __construct(
        private readonly ClarityCredentials $credentials,
        private readonly ?HttpFactory $http = null,
        private readonly ?\Closure $today = null,
        private readonly ?ClarityRequestQuota $quota = null,
    ) {
    }

    public function isConfigured(): bool
    {
        return $this->credentials->isConfigured();
    }

    public function lastError(): ?string
    {
        return $this->lastError;
    }

    /**
     * @return array{date: string, sessions: int, users: int, pageviews: int, scroll_depth: float, active_time_seconds: int, bounce_rate: float, dead_clicks: int, rage_clicks: int, quickbacks: int, script_errors: int, error_clicks: int}|null
     */
    public function dailySnapshot(int $days = self::MAX_DAYS): ?array
    {
        $payload = $this->request(['numOfDays' => max(1, min(self::MAX_DAYS, $days)), 'dimension1' => 'OS']);
        if ($payload === null) {
            return null;
        }

        // An empty answer summed to a row of zeros dated today, which the
        // store kept as the day's numbers and the health report read as
        // fresh data. No rows is "nothing to record", not zero sessions.
        if (! self::hasRows($payload)) {
            $this->lastError = self::NO_DATA_ERROR;

            return null;
        }

        $summary = [
            'date' => $this->today(),
            'sessions' => 0,
            'users' => 0,
            'pageviews' => 0,
            'scroll_depth' => 0.0,
            'active_time_seconds' => 0,
            // project-live-insights does not report a bounce rate.
            'bounce_rate' => 0.0,
            'dead_clicks' => 0,
            'rage_clicks' => 0,
            'quickbacks' => 0,
            'script_errors' => 0,
            'error_clicks' => 0,
        ];

        $sessionsByOs = [];
        foreach ($payload as $group) {
            if (is_array($group) && strcasecmp((string) ($group['metricName'] ?? ''), 'Traffic') === 0) {
                foreach ((array) ($group['information'] ?? []) as $row) {
                    if (is_array($row)) {
                        $sessionsByOs[(string) ($row['OS'] ?? $row['Browser'] ?? '')] = self::int($row, ['totalSessionCount', 'sessionCount', 'sessions']);
                    }
                }
                break;
            }
        }

        $scrollWeighted = 0.0;
        $scrollSessions = 0;

        foreach ($payload as $group) {
            if (! is_array($group) || ! is_array($group['information'] ?? null)) {
                continue;
            }
            $metric = strtolower((string) ($group['metricName'] ?? ''));

            foreach ($group['information'] as $row) {
                if (! is_array($row)) {
                    continue;
                }
                $os = (string) ($row['OS'] ?? $row['Browser'] ?? '');
                $rowSessions = $sessionsByOs[$os] ?? self::int($row, ['totalSessionCount', 'sessionCount', 'sessions']);

                switch ($metric) {
                    case 'traffic':
                        $sessions = self::int($row, ['totalSessionCount', 'sessionCount', 'sessions']);
                        $summary['sessions'] += $sessions;
                        $summary['users'] += self::int($row, ['distinctUserCount', 'distantUserCount', 'uniqueUsers', 'users']);
                        $perSession = self::float($row, ['pagesPerSessionPercentage', 'pagesPerSession']);
                        if ($sessions > 0 && $perSession > 0) {
                            $summary['pageviews'] += (int) round($perSession * $sessions);
                        }
                        break;
                    case 'engagementtime':
                        $summary['active_time_seconds'] += self::int($row, ['activeTime', 'engagementTime', 'activeTimeSeconds']);
                        break;
                    case 'scrolldepth':
                        $depth = self::float($row, ['averageScrollDepth', 'ScrollDepth', 'scrollDepth']);
                        if ($depth > 0 && $rowSessions > 0) {
                            $scrollWeighted += $depth * $rowSessions;
                            $scrollSessions += $rowSessions;
                        }
                        break;
                    case 'deadclickcount':
                        $summary['dead_clicks'] += self::int($row, ['subTotal', 'deadClickCount', 'deadClicks']);
                        break;
                    case 'rageclickcount':
                        $summary['rage_clicks'] += self::int($row, ['subTotal', 'rageClickCount', 'rageClicks']);
                        break;
                    case 'quickbackclick':
                        $summary['quickbacks'] += self::int($row, ['subTotal', 'quickbackClick', 'quickbacks']);
                        break;
                    case 'scripterrorcount':
                        $summary['script_errors'] += self::int($row, ['subTotal', 'scriptErrorCount', 'scriptErrors']);
                        break;
                    case 'errorclickcount':
                        $summary['error_clicks'] += self::int($row, ['subTotal', 'errorClickCount', 'errorClicks']);
                        break;
                }
            }
        }

        if ($scrollSessions > 0) {
            $summary['scroll_depth'] = round($scrollWeighted / $scrollSessions, 4);
        }

        return $summary;
    }

    /**
     * Per-path signals for the last 24 hours, the site's own hosts only;
     * a path with nothing in any signal is not a row (Traffic lists every
     * URL the project has ever seen).
     *
     * @param  list<string>  $hosts  the site's hosts; a leading www is ignored
     * @return list<array{date: string, path: string, sessions: int, rage_clicks: int, dead_clicks: int, quickbacks: int, script_errors: int, scroll_depth: float}>|null
     */
    public function pageMetrics(array $hosts): ?array
    {
        $payload = $this->request(['numOfDays' => 1, 'dimension1' => 'URL']);
        if ($payload === null) {
            return null;
        }

        $hosts = array_values(array_unique(array_filter(array_map(
            static fn ($host): string => (string) preg_replace('/^www\./', '', strtolower(trim((string) $host))),
            $hosts,
        ))));
        $pages = [];

        foreach ($payload as $group) {
            if (! is_array($group) || ! is_array($group['information'] ?? null)) {
                continue;
            }
            $metric = strtolower((string) ($group['metricName'] ?? ''));

            foreach ($group['information'] as $row) {
                if (! is_array($row)) {
                    continue;
                }
                // Asked for as "URL", the dimension comes back as "Url".
                $path = self::pathOnHosts($row['Url'] ?? $row['URL'] ?? null, $hosts);
                if ($path === null) {
                    continue;
                }

                $pages[$path] ??= ['sessions' => 0, 'rage_clicks' => 0, 'dead_clicks' => 0, 'quickbacks' => 0, 'script_errors' => 0, 'scroll_sum' => 0.0, 'scroll_n' => 0];

                switch ($metric) {
                    case 'traffic':
                        $total = self::int($row, ['totalSessionCount', 'sessionCount', 'sessions']);
                        $bots = self::int($row, ['totalBotSessionCount', 'botSessionCount']);
                        $pages[$path]['sessions'] += max(0, $total - $bots);
                        break;
                    case 'scrolldepth':
                        $depth = self::float($row, ['averageScrollDepth', 'ScrollDepth', 'scrollDepth']);
                        if ($depth > 0) {
                            $pages[$path]['scroll_sum'] += $depth;
                            $pages[$path]['scroll_n']++;
                        }
                        break;
                    case 'deadclickcount':
                        $pages[$path]['dead_clicks'] += self::int($row, ['subTotal', 'deadClickCount', 'deadClicks']);
                        break;
                    case 'rageclickcount':
                        $pages[$path]['rage_clicks'] += self::int($row, ['subTotal', 'rageClickCount', 'rageClicks']);
                        break;
                    case 'quickbackclick':
                        $pages[$path]['quickbacks'] += self::int($row, ['subTotal', 'quickbackClick', 'quickbacks']);
                        break;
                    case 'scripterrorcount':
                        $pages[$path]['script_errors'] += self::int($row, ['subTotal', 'scriptErrorCount', 'scriptErrors']);
                        break;
                }
            }
        }

        $date = $this->today();
        $out = [];
        foreach ($pages as $path => $m) {
            if ($m['sessions'] + $m['rage_clicks'] + $m['dead_clicks'] + $m['quickbacks'] + $m['script_errors'] === 0) {
                continue;
            }
            $out[] = [
                'date' => $date,
                'path' => (string) $path,
                'sessions' => $m['sessions'],
                'rage_clicks' => $m['rage_clicks'],
                'dead_clicks' => $m['dead_clicks'],
                'quickbacks' => $m['quickbacks'],
                'script_errors' => $m['script_errors'],
                'scroll_depth' => $m['scroll_n'] > 0 ? round($m['scroll_sum'] / $m['scroll_n'], 2) : 0.0,
            ];
        }

        return $out;
    }

    /**
     * "/kitchens" for https://www.example.com/kitchens/ and every
     * http/https/www/trailing-slash variant of it; "/" for the home page.
     * The same form Search Console pages are reduced to when the two are
     * joined (gs.construction's FrustratedPages::normalisePath).
     */
    public static function normalisePath(string $urlOrPath): string
    {
        $path = parse_url($urlOrPath, PHP_URL_PATH);
        $path = is_string($path) && $path !== '' ? rawurldecode($path) : '/';
        $path = '/'.ltrim($path, '/');

        return $path === '/' ? '/' : rtrim($path, '/');
    }

    /**
     * @param  array<string, int|string>  $query
     * @return array<int, mixed>|null
     */
    private function request(array $query): ?array
    {
        $this->lastError = null;
        $token = trim((string) ($this->credentials->apiToken() ?? ''));
        if ($token === '') {
            $this->lastError = 'Clarity API token missing';

            return null;
        }

        $quota = $this->quota ?? new ClarityRequestQuota;
        if (! $quota->allows($token)) {
            $this->lastError = $quota->refusal($token);

            return null;
        }
        $quota->consume($token);

        try {
            $response = ($this->http ?? new HttpFactory)->withToken($token)->acceptJson()->timeout(45)->get(self::ENDPOINT, $query);
        } catch (\Throwable $e) {
            $this->lastError = 'Clarity API request failed: '.$e->getMessage();

            return null;
        }

        if ($response->status() === 429) {
            $quota->markExhausted($token);
            $this->lastError = ClarityRequestQuota::limitReachedMessage();

            return null;
        }

        if (! $response->successful()) {
            $this->lastError = 'Clarity API request failed with HTTP '.$response->status().' (check token/project id and API permissions).';

            return null;
        }

        $payload = $response->json();
        if (! is_array($payload)) {
            $this->lastError = 'Unexpected Clarity payload shape.';

            return null;
        }

        return $payload;
    }

    private function today(): string
    {
        return $this->today !== null ? (string) ($this->today)() : Carbon::now()->toDateString();
    }

    /** @param  array<int, mixed>  $payload */
    private static function hasRows(array $payload): bool
    {
        foreach ($payload as $group) {
            if (is_array($group) && is_array($group['information'] ?? null) && $group['information'] !== []) {
                return true;
            }
        }

        return false;
    }

    /** @param  list<string>  $hosts */
    private static function pathOnHosts(mixed $url, array $hosts): ?string
    {
        if (! is_string($url) || $url === '') {
            return null;
        }

        $host = parse_url($url, PHP_URL_HOST);
        if (! is_string($host) || ! in_array((string) preg_replace('/^www\./', '', strtolower($host)), $hosts, true)) {
            return null;
        }

        return self::normalisePath($url);
    }

    /**
     * @param  array<string, mixed>  $row
     * @param  list<string>  $keys
     */
    private static function int(array $row, array $keys): int
    {
        foreach ($keys as $key) {
            if (array_key_exists($key, $row) && is_numeric($row[$key])) {
                return (int) $row[$key];
            }
        }

        return 0;
    }

    /**
     * @param  array<string, mixed>  $row
     * @param  list<string>  $keys
     */
    private static function float(array $row, array $keys): float
    {
        foreach ($keys as $key) {
            if (array_key_exists($key, $row) && is_numeric($row[$key])) {
                return round((float) $row[$key], 4);
            }
        }

        return 0.0;
    }
}
