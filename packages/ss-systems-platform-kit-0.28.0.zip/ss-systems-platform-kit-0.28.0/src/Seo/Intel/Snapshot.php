<?php

namespace SsSystems\Platform\Seo\Intel;

/**
 * One measurement a source took this run: what it measured (kind), about
 * whom (subject — a domain, keyword, page URL or place), the numbers worth
 * charting (metrics, a flat name => number map) and the detail behind them
 * (payload, anything JSON). Stored once per family/kind/subject/day by
 * {@see IntelStore::save()}.
 *
 * Ported verbatim from gs.construction's
 * App\Services\Seo\Intel\Snapshot — no app-specific behaviour to generalise.
 *
 * One addition (2026-11): `takenOn`. A snapshot is stored under the day of
 * the run that returns it unless it names its own — which a measurement
 * that was ASKED FOR on an earlier day needs (a standard-queue SERP task
 * posted last week and collected now belongs with last week's set, not
 * this week's; see {@see Sources\SerpSource}).
 */
final class Snapshot
{
    /**
     * @param  array<string, int|float|null>  $metrics
     * @param  array<string, mixed>  $payload
     * @param  ?string  $takenOn  'Y-m-d' this was measured for, when that is not the day of the run storing it
     */
    public function __construct(
        public readonly string $kind,
        public readonly string $subject,
        public readonly array $metrics = [],
        public readonly array $payload = [],
        public readonly ?string $takenOn = null,
    ) {
    }

    /** The same measurement, stored under $day instead of the day of the run. */
    public function on(string $day): self
    {
        return new self($this->kind, $this->subject, $this->metrics, $this->payload, $day);
    }
}
