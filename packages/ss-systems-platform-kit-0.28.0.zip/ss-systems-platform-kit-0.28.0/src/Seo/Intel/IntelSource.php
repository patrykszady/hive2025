<?php

namespace SsSystems\Platform\Seo\Intel;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Collection;
use SsSystems\Platform\Seo\Contracts\SeoSiteProfile;
use SsSystems\Platform\Seo\DataForSeo\Contracts\DataForSeoApi;

/**
 * One DataForSEO API family as a scheduled collector — ported from
 * gs.construction's App\Services\Seo\Intel\IntelSource, the base every
 * `seo:intel {family}` source extends.
 *
 * Lifecycle per run (see {@see IntelRunner::run()}): `collect()` talks to
 * the API and returns `Snapshot`s; the store persists them for today;
 * `findings()` compares today's snapshots with a previous run's (via
 * `latest()`/`previous()`/`latestSet()`/`previousSet()`) and returns
 * `Finding`s; `report()` shapes the stored data for the admin SEO page in
 * the uniform tiles/tables/note shape {@see IntelSnapshot} reads.
 *
 * GENERALISED from gs.construction (read this before porting another
 * source — every substitution below is deliberate, not a simplification
 * you need to re-derive):
 *
 *   - `config("seo-intel.families.{family}.{key}", $default)` →
 *     `$this->config($key, $default)`, now backed by an injected
 *     {@see IntelSettings} value object instead of Laravel's `config()`
 *     facade (the kit has no config dependency at all).
 *   - `DataForSeoService` → the frozen {@see DataForSeoApi} contract.
 *     IMPORTANT: `DataForSeoService::resultOf($envelope)` (a static helper
 *     gs.construction's sources call after every `request()`) has no
 *     equivalent on the contract — use `$this->resultOf($envelope)` below
 *     instead, which does the same `$envelope['tasks'][0]['result'] ?? []`
 *     unwrap.
 *   - `App\Models\Site::current()?->id` / `Tenancy::table()` → an optional
 *     injected `ConnectionInterface` plus `$tenantColumn`/`$tenantId`,
 *     exactly like {@see \SsSystems\Platform\Seo\AiTraffic\AiTrafficStore}
 *     — only `competitorDomains()` below needs raw table reads; a source
 *     with no cross-table lookup of its own never touches `$connection`.
 *   - `ourDomain()` (was `config('app.url')`) → `$this->profile->domain()`.
 *   - `competitorDomains()` (was `SeoDomainOverview::competitorDomains()`,
 *     itself `map_pack_competitors` hosts + a `Storage`-held competitor-
 *     discovery JSON file) → `$this->profile->competitorPatterns()` merged
 *     with hosts read straight off `map_pack_competitors` (host, pack_points)
 *     and `seo_rank_snapshots` (`top_results` JSON, `host`/`link` per
 *     entry) through the injected connection — both reads are wrapped so a
 *     site missing either table (or passing no connection at all) gets an
 *     empty contribution instead of an exception. The competitor-discovery
 *     JSON file itself has no kit equivalent (no Storage dependency) and is
 *     dropped; a site wanting that third source can still fold it into its
 *     own `SeoSiteProfile::competitorPatterns()` implementation.
 *   - `coreTowns()` (was `AreaServed::coreTowns($n)`) →
 *     `array_slice($this->profile->towns(), 0, $n)`.
 *   - `center()` (was two `config('seo.map_pack.center_*')` reads with a
 *     gs.construction-specific fallback coordinate) →
 *     `[$this->profile->latitude(), $this->profile->longitude()]`, and
 *     NULLABLE: a profile with no coordinates on file returns null, and a
 *     source that needs one (SerpSource's live-SERP location, a map-pack
 *     grid) must `skip()` rather than silently centre on 0,0.
 *   - `isExcludedHost()` is new: gs.construction's sources called a static
 *     `CompetitorFilter::isCompetitor()`/`isAggregator()` (curated-list +
 *     giant-SaaS-threshold logic with no kit equivalent) to skip a
 *     directory/aggregator domain out of a SERP's top-10 or a backlink
 *     list. The kit substitutes the one piece of that check a
 *     `SeoSiteProfile` can actually answer: an exact-host-or-subdomain
 *     match against `competitorExclusions()`. A follow-up source that
 *     needs the giant-SaaS-threshold half of the original check has no
 *     contract for it yet — note that gap in your own port rather than
 *     silently dropping the check.
 */
abstract class IntelSource
{
    protected bool $skipped = false;

    /** @var array<string, string> part of this run's collection that failed while the rest went on => why */
    protected array $partial = [];

    public function __construct(
        protected readonly DataForSeoApi $dfs,
        protected readonly IntelStore $store,
        protected readonly SeoSiteProfile $profile,
        protected readonly IntelSettings $settings,
        protected readonly ?ConnectionInterface $connection = null,
        protected readonly ?string $tenantColumn = null,
        protected readonly ?\Closure $tenantId = null,
    ) {
    }

    /** collect() had nothing to do this run (a crawl still queued, a family not due, no coordinates to centre on): no snapshots, no ledger row. */
    protected function skip(): array
    {
        $this->skipped = true;

        return [];
    }

    public function wasSkipped(): bool
    {
        return $this->skipped;
    }

    /**
     * One part of collect() failed and the rest went on: name it. collect()
     * still returns what it has ("return what you have on partial
     * failures"), which the runner stores and records as ok — so without
     * this a family missing a third of its data read exactly like a clean
     * run. A source that makes several independent pulls calls this for
     * each one that failed, and clears `$partial` at the start of collect().
     */
    protected function notePartial(string $part, ?string $error): void
    {
        $this->partial[$part] = mb_substr(trim((string) ($error ?? '')) ?: 'no answer', 0, 300);
    }

    /**
     * What the last collect() could not get, part => reason; empty after a
     * clean run. {@see IntelRunner::run()} returns it as `partial` /
     * `partial_errors`.
     *
     * @return array<string, string>
     */
    public function partialFailures(): array
    {
        return $this->partial;
    }

    /** Short machine name, also the settings key: 'serp', 'trends', … */
    abstract public function family(): string;

    /** Human label for the admin card. */
    abstract public function label(): string;

    /** Expected USD for one run, for the budget guard. */
    abstract public function estimateCost(): float;

    /**
     * Call the API and describe what was measured. Throw on a failure that
     * makes the run meaningless; return what you have on partial failures;
     * call `skip()` and return its (empty) result when there is nothing to
     * collect this run.
     *
     * @return Snapshot[]
     */
    abstract public function collect(): array;

    /**
     * Compare today's snapshots with the previous run's. Return every finding
     * that is currently true — the store opens new ones and resolves the ones
     * you no longer return.
     *
     * @return Finding[]
     */
    abstract public function findings(): array;

    /**
     * Admin card payload, one uniform shape for every family:
     *   tiles:  [['label' => 'Avg. position', 'value' => 4.2, 'prev' => 5.1, 'unit' => null, 'good' => 'down'], …]
     *   tables: [['title' => 'Tracked queries', 'columns' => ['Query', 'Position'], 'rows' => [['kitchen remodeling', 4], …]], …]
     *   note:   one sentence on what was measured and when.
     *
     * @return array{tiles: list<array<string, mixed>>, tables: list<array{title: string, columns: list<string>, rows: list<list<mixed>>}>, note?: string}
     */
    abstract public function report(): array;

    /** Per-family knob from the injected IntelSettings, with a code default. */
    protected function config(string $key, mixed $default = null): mixed
    {
        return $this->settings->get($this->family(), $key, $default);
    }

    /** Today's snapshot for a kind/subject, or null. */
    protected function latest(string $kind, string $subject): ?array
    {
        return $this->store->latest($this->family(), $kind, $subject);
    }

    /** The run before the latest one for a kind/subject, or null on the first run. */
    protected function previous(string $kind, string $subject): ?array
    {
        return $this->store->previous($this->family(), $kind, $subject);
    }

    /** Every subject's latest-day snapshot for a kind, keyed by subject. */
    protected function latestSet(string $kind): Collection
    {
        return $this->store->latestSet($this->family(), $kind);
    }

    /** Every subject's previous-day snapshot for a kind, keyed by subject. */
    protected function previousSet(string $kind): Collection
    {
        return $this->store->previousSet($this->family(), $kind);
    }

    /** Our bare domain ('gs.construction'), from the site profile. */
    protected function ourDomain(): string
    {
        return $this->profile->domain();
    }

    /**
     * Known competitor hosts, highest confidence first: the profile's own
     * curated list, then whatever can be read off `map_pack_competitors`
     * and `seo_rank_snapshots` (see this class's docblock for the exact
     * substitution) — our own domain and anything matching
     * `competitorExclusions()` are never included.
     *
     * @return list<string>
     */
    protected function competitorDomains(int $limit = 8): array
    {
        $domains = [];
        foreach ($this->profile->competitorPatterns() as $pattern) {
            $host = $this->normalizeHost($pattern);
            if ($host !== '') {
                $domains[$host] = true;
            }
        }
        foreach ($this->mapPackHosts() as $host) {
            $domains[$host] = true;
        }
        foreach ($this->rankSnapshotHosts() as $host) {
            $domains[$host] = true;
        }

        $ours = $this->ourDomain();
        $kept = [];
        foreach (array_keys($domains) as $host) {
            if ($host === '' || $host === $ours || $this->isExcludedHost($host)) {
                continue;
            }
            $kept[] = $host;
        }

        return array_slice($kept, 0, $limit);
    }

    /** The first $n towns the business serves, from the site profile — the ones a geo-focused query/grid should anchor on. */
    protected function coreTowns(int $n = 6): array
    {
        return array_values(array_slice(array_map('strval', $this->profile->towns()), 0, $n));
    }

    /**
     * Office coordinates the geo-grid/live-SERP location is centred on, or
     * null when the profile has none on file — a source that needs one
     * must `skip()` rather than guess.
     *
     * @return array{0: float, 1: float}|null
     */
    protected function center(): ?array
    {
        $lat = $this->profile->latitude();
        $lng = $this->profile->longitude();

        return ($lat !== null && $lng !== null) ? [$lat, $lng] : null;
    }

    /** TRUE when $host is an exact or subdomain match against the profile's competitor exclusions (directories, aggregators, socials — never a real competitor). */
    protected function isExcludedHost(string $host): bool
    {
        $host = $this->normalizeHost($host);
        if ($host === '') {
            return false;
        }
        foreach ($this->profile->competitorExclusions() as $excluded) {
            $excluded = $this->normalizeHost($excluded);
            if ($excluded !== '' && ($host === $excluded || str_ends_with($host, '.'.$excluded))) {
                return true;
            }
        }

        return false;
    }

    /** A finding builder that prefixes the code with the family. */
    protected function finding(string $code, string $severity, string $title, string $detail = '', ?string $subject = null, ?string $key = null, array $delta = [], ?array $action = null): Finding
    {
        return new Finding($this->family().'.'.$code, $severity, $title, $detail, $subject, $key, $delta, $action);
    }

    /**
     * `$envelope['tasks'][0]['result']` unwrapped — the one static helper
     * (`DataForSeoService::resultOf()`) gs.construction's sources called
     * directly on the old service class; the DataForSeoApi contract has no
     * equivalent, so every ported source calls this instead.
     *
     * @param  array<string, mixed>  $envelope
     * @return list<array<string, mixed>>
     */
    protected function resultOf(array $envelope): array
    {
        return (array) ($envelope['tasks'][0]['result'] ?? []);
    }

    /** @return list<string> */
    private function mapPackHosts(): array
    {
        if ($this->connection === null) {
            return [];
        }
        try {
            if (! $this->connection->getSchemaBuilder()->hasTable('map_pack_competitors')) {
                return [];
            }

            return $this->scopedTable('map_pack_competitors')
                ->whereNotNull('host')->where('pack_points', '>', 0)
                ->selectRaw('host, SUM(pack_points) as weight')->groupBy('host')->orderByDesc('weight')->limit(30)
                ->pluck('host')->map(fn ($h) => $this->normalizeHost((string) $h))->filter()->values()->all();
        } catch (\Throwable) {
            return [];
        }
    }

    /** @return list<string> */
    private function rankSnapshotHosts(): array
    {
        if ($this->connection === null) {
            return [];
        }
        try {
            if (! $this->connection->getSchemaBuilder()->hasTable('seo_rank_snapshots')) {
                return [];
            }
            $rows = $this->scopedTable('seo_rank_snapshots')->whereNotNull('top_results')->orderByDesc('fetched_at')->limit(200)->pluck('top_results');
        } catch (\Throwable) {
            return [];
        }

        $counts = [];
        foreach ($rows as $raw) {
            foreach ((array) json_decode((string) $raw, true) as $entry) {
                $host = $this->normalizeHost((string) (($entry['host'] ?? $entry['link'] ?? '')));
                if ($host !== '') {
                    $counts[$host] = ($counts[$host] ?? 0) + 1;
                }
            }
        }
        arsort($counts);

        return array_keys($counts);
    }

    private function scopedTable(string $table): \Illuminate\Database\Query\Builder
    {
        $query = $this->connection->table($table);
        if ($this->tenantColumn !== null) {
            $query->where($this->tenantColumn, ($this->tenantId)());
        }

        return $query;
    }

    private function normalizeHost(string $value): string
    {
        $value = trim($value);
        if ($value === '') {
            return '';
        }
        $host = parse_url(str_contains($value, '://') ? $value : '//'.$value, PHP_URL_HOST) ?: $value;
        $host = mb_strtolower((string) $host);

        return preg_replace('/^www\./', '', $host) ?? $host;
    }
}
