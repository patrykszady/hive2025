<?php

namespace SsSystems\Platform\Seo\Intel\Sources;

use Illuminate\Support\Carbon;
use SsSystems\Platform\Seo\Intel\Finding;
use SsSystems\Platform\Seo\Intel\IntelSource;
use SsSystems\Platform\Seo\Intel\Snapshot;

/**
 * SERP family: weekly rank + SERP-feature tracking for the queries that
 * matter, seen from our service area — via serp/google/organic/live/advanced.
 * Ported from gs.construction's App\Services\Seo\Intel\Sources\SerpSource —
 * one of the two reference ports proving `IntelSource`'s base-class API
 * (the first of the nine remaining families; read this alongside
 * {@see TrendsSource} before porting another one).
 *
 * Why it matters: Search Console only tells us impressions/clicks for
 * queries Google already shows us for; it never shows what actually renders
 * on the page — whether an AI Overview now answers the question before any
 * blue link, whether the local 3-pack (the box most "near me" clicks go to)
 * has us in it, or which competitor just took the spot we lost. Those are
 * the features that quietly erode local traffic and GSC never reports them.
 *
 * Endpoint: by default the Standard queue (task_post/tasks_ready/task_get,
 * ~$0.0006/check), falling back automatically to POST
 * /serp/google/organic/live/advanced (one call per tracked query, ~$0.002/
 * SERP of up to 10 results; depth above 10 multiplies) when the queue path
 * errors. Both use location_coordinate centred on {@see IntelSource::center()},
 * device desktop, depth config('depth', 20). calculate_rectangles stays
 * false (no pixel-ranking surcharge). load_async_ai_overview is on
 * (config ai_overview_async, default true, 2026-11-11): Google loads most
 * AI Overviews after the page, so without it the overview is usually
 * missed; DataForSEO charges $0.0006 more per check and refunds it when no
 * overview loads. Every page an AI Overview cites is recorded
 * (ai_overview_sources), so the report says which sites Google's AI
 * answer draws on for each tracked query and whether we are one of them.
 *
 * Paid for and collected (2026-11): the Standard queue answers when it
 * answers. A task not ready when the wait runs out was already paid for,
 * and this source used to drop it — no id kept, no result ever read. Now a
 * task missing from the batch is asked about once by its id; what is still
 * queued is remembered in a 'pending_tasks' snapshot (its id and query,
 * the day it was posted), and the next run collects it first, before
 * posting anything new — the same "collect late" seo:track-rankings does
 * for its own rows. A late result is stored under the day it was asked
 * for ({@see \SsSystems\Platform\Seo\Intel\Snapshot::$takenOn}), so it
 * completes that run's set instead of being mistaken for today's.
 *
 * GENERALISED from gs.construction (see also IntelSource's own docblock):
 *
 *   - `googleOrganicStandardBatch()`'s result map is keyed by TASK ID on
 *     the kit's frozen {@see \SsSystems\Platform\Seo\DataForSeo\Contracts\DataForSeoApi}
 *     contract, not by the query's array position the way gs.construction's
 *     own `DataForSeoService` returned it — `collect()` below pairs
 *     `$dfs->lastStandardTaskIds()` (returned in submission order) with
 *     `$queries` to look each result up by id. Porting another
 *     Standard-queue source must do the same; indexing the result map by
 *     `$i` silently returns nothing for every query.
 *   - `CompetitorFilter::isCompetitor($domain)` (curated-list +
 *     giant-SaaS-threshold logic, no kit equivalent) → `! $this->isExcludedHost($domain)`.
 *   - `AreaServed::coreTowns(6)` → `$this->coreTowns(6)`. gs.construction's
 *     `servedTowns()` (core towns unioned with `config('gbp-services.service_areas')`,
 *     used only to gate the dropped `seo_keywords` augmentation below) has
 *     no caller left once that augmentation is gone, so it is dropped
 *     entirely rather than ported unused.
 *   - The `seo_keywords`-table "researched phrases per city" augmentation
 *     in gs.construction's `buildQueries()` has no kit equivalent (that
 *     table belongs to a different, unported keyword-research module) —
 *     dropped. `buildQueries()` now prefers `$this->profile->trackedQueries()`
 *     (each entry's `q`) over the service×town anchor fallback; a site that
 *     wants the old per-city research behaviour supplies it through its own
 *     `SeoSiteProfile::trackedQueries()` implementation instead. The
 *     hardcoded " IL" state suffix on anchor queries is also dropped — a
 *     site names its own state in the service/town strings it configures
 *     if it wants one.
 *   - `config('seo.rank_tracker.serp_mode', ...)` and the per-family
 *     `config('seo-intel.families.serp.*')` reads both become
 *     `$this->config('serp_mode'|..., $default)` — one settings namespace
 *     instead of two.
 */
class SerpSource extends IntelSource
{
    protected const DEFAULT_SERVICES = ['kitchen remodeling', 'bathroom remodeling'];

    /** Snapshot kind/subject holding the standard-queue tasks a run posted and could not collect. */
    protected const PENDING_KIND = 'pending_tasks';

    protected const PENDING_SUBJECT = 'standard';

    public function family(): string
    {
        return 'serp';
    }

    public function label(): string
    {
        return 'SERP tracking';
    }

    public function estimateCost(): float
    {
        return round(count($this->buildQueries()) * $this->pricePerQuery(), 4);
    }

    /** @return Snapshot[] */
    public function collect(): array
    {
        $center = $this->center();
        if ($center === null) {
            return $this->skip();
        }

        $queries = $this->buildQueries();
        $maxCost = (float) $this->config('max_cost', 0.15);
        $spentAtStart = $this->dfs->spent();
        [$lat, $lng] = $center;
        $depth = $this->depth();
        $ourDomain = $this->ourDomain();
        $snapshots = [];

        // What an earlier run paid for and could not wait for comes first.
        $late = $this->collectLate($ourDomain);

        $standard = (string) $this->config('serp_mode', 'standard') === 'standard'
            ? $this->dfs->googleOrganicStandardBatch(array_map(fn ($q) => [
                'keyword' => $q,
                'location_coordinate' => sprintf('%.6f,%.6f,100000', $lat, $lng),
                'depth' => $depth,
            ] + $this->aiOverviewParams(), $queries), max(10, (int) $this->config('standard_wait', 240)))
            : null;

        if ($standard !== null) {
            $ids = $this->dfs->lastStandardTaskIds();
            $queued = $late['carry'];
            foreach ($queries as $i => $query) {
                $taskId = $ids[$i] ?? null;
                $result = $taskId !== null ? ($standard[$taskId] ?? null) : null;

                // Not in the batch: ask about this one task before letting
                // go of it. Ready now is a result; still queued is kept for
                // the next run; an error is the only thing dropped.
                if (! is_array($result) && $taskId !== null) {
                    $answer = $this->dfs->googleOrganicTaskResult($taskId);
                    $status = $answer['status'] ?? null;
                    if ($status === 'ready' && is_array($answer['result'] ?? null)) {
                        $result = $answer['result'];
                    } elseif ($status === 'pending') {
                        $queued[] = ['id' => $taskId, 'query' => $query];
                    }
                }

                if (is_array($result)) {
                    $snapshots[] = $this->snapshotFor($query, $result, $ourDomain);
                }
            }

            if ($snapshots === [] && $queued === [] && $this->dfs->getLastError()) {
                throw new \RuntimeException($this->dfs->getLastError());
            }

            if ($queued !== []) {
                $snapshots[] = $this->pendingSnapshot($queued, Carbon::now()->toDateString());
            }

            return [...$late['snapshots'], ...$snapshots];
        }

        foreach ($queries as $query) {
            if (($this->dfs->spent() - $spentAtStart) > $maxCost) {
                break;
            }
            $envelope = $this->dfs->request('POST', '/serp/google/organic/live/advanced', [[
                'keyword' => $query,
                'location_coordinate' => sprintf('%.6f,%.6f,100000', $lat, $lng),
                'language_code' => 'en',
                'device' => 'desktop',
                'depth' => $depth,
                'calculate_rectangles' => false,
            ] + $this->aiOverviewParams()]);
            $result = $this->resultOf($envelope)[0] ?? null;
            if (! is_array($result)) {
                continue;
            }
            $snapshots[] = $this->snapshotFor($query, $result, $ourDomain);
        }

        if ($snapshots === [] && $this->dfs->getLastError()) {
            throw new \RuntimeException($this->dfs->getLastError());
        }

        if ($late['carry'] !== []) {
            $snapshots[] = $this->pendingSnapshot($late['carry'], Carbon::now()->toDateString());
        }

        return [...$late['snapshots'], ...$snapshots];
    }

    /**
     * Collect the standard-queue tasks the latest run with any left posted
     * and could not wait for. Each is asked about by its id: a finished one
     * becomes that query's snapshot, dated the day it was posted; one still
     * queued stays on the list; one DataForSEO no longer has is let go. The
     * list is rewritten under its own day with what is left. Results are
     * kept `late_collect_days` (default 30) — DataForSEO holds a finished
     * task's result about that long.
     *
     * `carry` is the still-queued remainder of a list posted TODAY (a
     * second run the same day): it has to be merged into today's new list
     * rather than rewritten beside it, since a day holds one list.
     *
     * @return array{snapshots: Snapshot[], carry: list<array{id: string, query: string}>}
     */
    protected function collectLate(string $ourDomain): array
    {
        $marker = $this->latest(self::PENDING_KIND, self::PENDING_SUBJECT);
        $tasks = array_values(array_filter((array) ($marker['payload']['tasks'] ?? []), 'is_array'));
        if ($marker === null || $tasks === []) {
            return ['snapshots' => [], 'carry' => []];
        }

        $postedOn = (string) ($marker['payload']['posted_on'] ?? $marker['taken_on']);
        $today = Carbon::now()->toDateString();
        if ($postedOn < Carbon::now()->subDays(max(1, (int) $this->config('late_collect_days', 30)))->toDateString()) {
            return ['snapshots' => [], 'carry' => []];
        }

        $snapshots = [];
        $still = [];
        foreach ($tasks as $task) {
            $id = (string) ($task['id'] ?? '');
            $query = (string) ($task['query'] ?? '');
            if ($id === '' || $query === '') {
                continue;
            }
            $answer = $this->dfs->googleOrganicTaskResult($id);
            $status = $answer['status'] ?? null;
            if ($status === 'ready' && is_array($answer['result'] ?? null)) {
                $snapshots[] = $this->snapshotFor($query, $answer['result'], $ourDomain)->on($postedOn);
            } elseif ($status === 'pending') {
                $still[] = ['id' => $id, 'query' => $query];
            }
        }

        if ($postedOn === $today) {
            return ['snapshots' => $snapshots, 'carry' => $still];
        }

        $snapshots[] = $this->pendingSnapshot($still, $postedOn);

        return ['snapshots' => $snapshots, 'carry' => []];
    }

    /**
     * The list of posted-and-not-yet-collected tasks for one day.
     *
     * @param  list<array{id: string, query: string}>  $tasks
     */
    protected function pendingSnapshot(array $tasks, string $postedOn): Snapshot
    {
        return new Snapshot(self::PENDING_KIND, self::PENDING_SUBJECT, ['open' => count($tasks)], ['tasks' => array_values($tasks), 'posted_on' => $postedOn], $postedOn);
    }

    /** @return Finding[] */
    public function findings(): array
    {
        $now = $this->latestSet('keyword');
        $prev = $this->previousSet('keyword');
        $maxFindings = max(1, (int) $this->config('max_findings', 25));
        $candidates = [];

        foreach ($now as $query => $snap) {
            $nowPos = $snap['metrics']['position'] ?? null;
            $prevSnap = $prev->get($query);
            $prevPos = $prevSnap['metrics']['position'] ?? null;
            $path = $this->pathFor($snap['payload']['best_organic_url'] ?? null);

            // Position drop >=3, or fallen out of the tracked depth entirely.
            if ($prevPos !== null) {
                $depth = $this->depth();
                $effectiveNow = $nowPos ?? ($depth + 1);
                $drop = $effectiveNow - $prevPos;
                if ($drop >= 3) {
                    $critical = $prevPos <= 3 && $effectiveNow > 10;
                    $candidates[] = $this->finding(
                        'position_drop', $critical ? Finding::CRITICAL : Finding::WARN,
                        "\"{$query}\" dropped ".round($drop).' spots',
                        $nowPos === null ? "Was #{$prevPos}, now outside the top {$depth}." : "From #{$prevPos} to #{$nowPos}.",
                        $query, null, ['position' => ['prev' => $prevPos, 'now' => $nowPos]],
                        $path ? ['type' => 'content_refresh', 'path' => $path] : null,
                    );
                } elseif ($prevPos - $effectiveNow >= 3) {
                    $candidates[] = $this->finding(
                        'position_gain', Finding::WIN,
                        "\"{$query}\" gained ".round($prevPos - $effectiveNow).' spots',
                        "From #{$prevPos} to #{$nowPos}.", $query, null,
                        ['position' => ['prev' => $prevPos, 'now' => $nowPos]],
                    );
                }
            }

            // AI Overview appeared where it was absent last run.
            if ($prevSnap !== null && ($snap['metrics']['ai_overview'] ?? 0) == 1 && ($prevSnap['metrics']['ai_overview'] ?? 0) == 0) {
                $candidates[] = $this->finding(
                    'ai_overview_appeared', Finding::INFO,
                    "AI Overview now answers \"{$query}\"",
                    $snap['payload']['ai_overview_mentions_us'] ?? false
                        ? 'It cites us — worth strengthening the page it draws from.'
                        : 'It does not cite us — worth refreshing our ranking page to be a better source.',
                    $query, null, [], $path ? ['type' => 'content_refresh', 'path' => $path] : null,
                );
            }

            // An AI Overview that started or stopped citing us, or newly cites another site.
            if ($prevSnap !== null && ($snap['metrics']['ai_overview'] ?? 0) == 1 && ($prevSnap['metrics']['ai_overview'] ?? 0) == 1) {
                $nowCites = (int) ($snap['metrics']['ai_overview_cites_us'] ?? 0);
                $prevCites = (int) ($prevSnap['metrics']['ai_overview_cites_us'] ?? 0);
                if ($nowCites === 1 && $prevCites === 0) {
                    $candidates[] = $this->finding(
                        'ai_overview_cites_us', Finding::WIN,
                        "Google's AI Overview for \"{$query}\" now cites us",
                        'It links '.($snap['payload']['ai_overview_our_url'] ?? 'our site').'.',
                        $query,
                    );
                } elseif ($nowCites === 0 && $prevCites === 1) {
                    $candidates[] = $this->finding(
                        'ai_overview_dropped_us', Finding::WARN,
                        "Google's AI Overview for \"{$query}\" stopped citing us",
                        'It now draws on: '.(implode(', ', array_slice((array) ($snap['payload']['ai_overview_domains'] ?? []), 0, 5)) ?: 'no sites listed').'.',
                        $query, null, [], $path ? ['type' => 'content_refresh', 'path' => $path] : null,
                    );
                }

                $newSources = array_values(array_diff(
                    (array) ($snap['payload']['ai_overview_domains'] ?? []),
                    (array) ($prevSnap['payload']['ai_overview_domains'] ?? []),
                    [$this->ourDomain()],
                ));
                if ($newSources !== [] && $nowCites === 0) {
                    $candidates[] = $this->finding(
                        'ai_overview_new_sources', Finding::INFO,
                        "Google's AI Overview for \"{$query}\" now cites ".$newSources[0].(count($newSources) > 1 ? ' and '.(count($newSources) - 1).' more' : ''),
                        'New sources: '.implode(', ', array_slice($newSources, 0, 6)).'. A listing or a mention on those pages is how a business gets into the answer.',
                        $query, $newSources[0],
                    );
                }
            }

            // Local pack present but we are not in it.
            if (($snap['payload']['local_pack_present'] ?? false) && ! ($snap['metrics']['in_local_pack'] ?? 0)) {
                // A metro's pack (Chicago) is city-local: measured from the office it is not ours to win, so it informs rather than warns.
                $metro = $this->isMetroQuery($query);
                $candidates[] = $this->finding(
                    'local_pack_absent', $metro ? Finding::INFO : Finding::WARN,
                    "Local pack shows for \"{$query}\" — we are not in it",
                    'A 3-pack renders for this query on Google Maps/Search and our listing does not appear in it.'
                        .($metro ? ' Measured from the office; for a city this size the pack is city-local — the organic position is the number to move.' : ''),
                    $query,
                );
            }

            // A domain new to the top 3 now ranks above us (needs a previous run to be "new" against).
            $prevTop3 = array_slice((array) (($prevSnap['payload'] ?? [])['top10_domains'] ?? []), 0, 3);
            $nowTop3 = array_slice((array) ($snap['payload']['top10_domains'] ?? []), 0, 3);
            foreach ($prevSnap === null ? [] : array_diff($nowTop3, $prevTop3, [$this->ourDomain()]) as $domain) {
                $rank = array_search($domain, $nowTop3, true) + 1;
                if ($nowPos === null || $rank < $nowPos) {
                    $candidates[] = $this->finding(
                        'competitor_top3', Finding::INFO,
                        "{$domain} entered the top 3 for \"{$query}\"",
                        $nowPos === null ? 'We do not rank in the tracked depth for this query.' : "It now outranks us (we're #{$nowPos}).",
                        $query, $domain,
                    );
                }
            }

            // Unanswered "People also ask" questions on a query we rank for.
            $paa = (array) ($snap['payload']['paa_questions'] ?? []);
            if ($paa !== [] && $nowPos !== null) {
                $candidates[] = $this->finding(
                    'paa_gap', Finding::INFO,
                    "\"{$query}\" has unanswered People Also Ask questions",
                    'Questions Google surfaces for this query: '.implode(' · ', $paa),
                    $query, null, [], $path ? ['type' => 'content_refresh', 'path' => $path] : null,
                );
            }
        }

        usort($candidates, fn (Finding $a, Finding $b) => $this->severityRank($a->severity) <=> $this->severityRank($b->severity));

        return array_slice($candidates, 0, $maxFindings);
    }

    public function report(): array
    {
        $now = $this->latestSet('keyword');
        $prev = $this->previousSet('keyword');

        $positions = $now->map(fn ($s) => $s['metrics']['position'] ?? null)->filter(fn ($p) => $p !== null);
        $prevPositions = $prev->map(fn ($s) => $s['metrics']['position'] ?? null)->filter(fn ($p) => $p !== null);

        $tiles = [
            ['label' => 'Tracked queries', 'value' => $now->count()],
            ['label' => 'Avg. position', 'value' => $positions->isNotEmpty() ? round($positions->avg(), 1) : null, 'prev' => $prevPositions->isNotEmpty() ? round($prevPositions->avg(), 1) : null, 'good' => 'down'],
            ['label' => 'In top 10', 'value' => $positions->filter(fn ($p) => $p <= 10)->count(), 'prev' => $prevPositions->filter(fn ($p) => $p <= 10)->count(), 'good' => 'up'],
            ['label' => 'In local pack', 'value' => $now->sum(fn ($s) => (int) ($s['metrics']['in_local_pack'] ?? 0)), 'prev' => $prev->sum(fn ($s) => (int) ($s['metrics']['in_local_pack'] ?? 0)), 'good' => 'up'],
            ['label' => 'AI Overview present', 'value' => $now->sum(fn ($s) => (int) ($s['metrics']['ai_overview'] ?? 0)), 'prev' => $prev->sum(fn ($s) => (int) ($s['metrics']['ai_overview'] ?? 0))],
            ['label' => 'AI Overview cites us', 'value' => $now->sum(fn ($s) => (int) ($s['metrics']['ai_overview_cites_us'] ?? 0)), 'prev' => $prev->sum(fn ($s) => (int) ($s['metrics']['ai_overview_cites_us'] ?? 0)), 'good' => 'up'],
        ];

        $rows = $now->map(function ($s, $query) use ($prev) {
            $prevPos = $prev->get($query)['metrics']['position'] ?? null;
            $pos = $s['metrics']['position'] ?? null;
            $topCompetitor = collect((array) ($s['payload']['top10_domains'] ?? []))->first(fn ($d) => $d !== $this->ourDomain());

            return [
                'sort' => $pos ?? PHP_FLOAT_MAX,
                'row' => [
                    $query,
                    ($pos ?? '—').($prevPos !== null ? " ({$prevPos})" : ''),
                    ($s['metrics']['in_local_pack'] ?? 0) ? '✓' : '✗',
                    $this->aiOverviewCell($s),
                    $topCompetitor ?? '—',
                ],
            ];
        })->sortBy('sort')->take(12)->pluck('row')->values()->all();

        $day = $now->isNotEmpty() ? $this->store->latestDay($this->family(), 'keyword') : null;

        $tables = [['title' => 'Tracked queries', 'columns' => ['Query', 'Position (prev)', 'Local pack', 'AI Overview', 'Top competitor'], 'rows' => $rows]];
        $cited = $this->aiOverviewCitedSites($now);
        if ($cited !== []) {
            $tables[] = ['title' => "Sites Google's AI Overviews cite", 'columns' => ['Site', 'Queries', 'Example page'], 'rows' => $cited];
        }

        return [
            'tiles' => $tiles,
            'tables' => $tables,
            'note' => $day ? "Live Google SERPs for {$now->count()} tracked queries, checked {$day}." : 'No SERP checks stored yet.',
        ];
    }

    /** Configured/profile queries first; otherwise service×town anchors, deduped, capped. */
    protected function buildQueries(): array
    {
        $configured = array_values(array_filter(array_map('trim', (array) $this->config('queries', []))));
        if ($configured !== []) {
            return array_slice($this->dedupe($configured), 0, max(1, (int) $this->config('tracked', 30)));
        }

        $tracked = max(1, (int) $this->config('tracked', 30));

        $fromProfile = array_values(array_filter(array_map(
            static fn (array $q): string => trim((string) ($q['q'] ?? '')),
            $this->profile->trackedQueries()
        )));
        if ($fromProfile !== []) {
            return array_slice($this->dedupe($fromProfile), 0, $tracked);
        }

        $services = (array) $this->config('services', $this->profile->services() ?: self::DEFAULT_SERVICES);
        $anchors = [];
        foreach ($this->coreTowns(6) as $town) {
            foreach ($services as $service) {
                $anchors[] = "{$service} {$town}";
            }
        }

        return array_slice($this->dedupe($anchors), 0, $tracked);
    }

    /** Case-insensitive de-dupe that keeps the first-seen casing. */
    protected function dedupe(array $queries): array
    {
        $seen = [];
        $out = [];
        foreach ($queries as $q) {
            $q = trim((string) $q);
            $key = mb_strtolower($q);
            if ($q === '' || isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $out[] = $q;
        }

        return $out;
    }

    /** Names a metro (config metro_cities, default Chicago) whose local pack is not winnable from the office. */
    protected function isMetroQuery(string $query): bool
    {
        foreach ((array) $this->config('metro_cities', ['chicago']) as $city) {
            if ((string) $city !== '' && stripos($query, (string) $city) !== false) {
                return true;
            }
        }

        return false;
    }

    /**
     * Standard queue: a flat ~$0.0006/check regardless of depth. Live
     * Advanced (the fallback path, and whatever collect() runs when
     * serp_mode is not 'standard'): $0.002 per SERP of up to 10 results,
     * depth above 10 multiplies. Must track collect()'s own mode selection
     * so estimateCost() matches actual spend — the outer seo:intel budget
     * gate reads it.
     */
    protected function pricePerQuery(): float
    {
        $aiOverview = $this->aiOverviewParams() !== [] ? 0.0006 : 0.0;

        if ((string) $this->config('serp_mode', 'standard') === 'standard') {
            return round(0.0006 + $aiOverview, 4);
        }

        return round(0.002 * ceil($this->depth() / 10) + $aiOverview, 4);
    }

    /**
     * Ask for the AI Overview Google loads after the page (most of them).
     * DataForSEO refunds the surcharge when none loads.
     *
     * @return array<string, bool>
     */
    protected function aiOverviewParams(): array
    {
        return (bool) $this->config('ai_overview_async', true) ? ['load_async_ai_overview' => true] : [];
    }

    /**
     * Google sometimes hands DataForSEO a google.com/goto?url=… link whose
     * target is readable only when it carries a plain URL; such a link is
     * unwrapped, an opaque one is kept as it is.
     */
    public static function unwrapGoogleRedirect(string $url): string
    {
        if (! preg_match('#^https?://(www\.)?google\.com/(goto|url)\?#i', $url)) {
            return $url;
        }
        parse_str((string) parse_url($url, PHP_URL_QUERY), $query);
        $target = trim((string) ($query['url'] ?? $query['q'] ?? ''));

        return preg_match('#^https?://#i', $target) ? $target : $url;
    }

    /** "cabinetsplus.com" or "Cabinets Plus, Inc." as a source name: a domain when it reads as one, else nothing. */
    protected static function domainFromSourceName(string $source): string
    {
        $source = mb_strtolower(trim($source));

        return preg_match('/^(?:www\.)?([a-z0-9-]+(?:\.[a-z0-9-]+)+)$/', $source, $m) ? (string) preg_replace('/^www\./', '', $m[1]) : '';
    }

    /** The table's AI Overview cell: absent, citing us, or how many sites it cites. */
    protected function aiOverviewCell(array $snapshot): string
    {
        if (! ($snapshot['metrics']['ai_overview'] ?? 0)) {
            return '✗';
        }
        if ($snapshot['metrics']['ai_overview_cites_us'] ?? ($snapshot['payload']['ai_overview_mentions_us'] ?? false)) {
            return '✓ cites us';
        }
        $sites = count((array) ($snapshot['payload']['ai_overview_domains'] ?? []));

        return $sites > 0 ? "✓ {$sites} other site".($sites === 1 ? '' : 's') : '✓';
    }

    /**
     * Sites the latest AI Overviews cite, by how many tracked queries cite
     * them, ours marked.
     *
     * @return list<array{0: string, 1: int, 2: string}>
     */
    protected function aiOverviewCitedSites(\Illuminate\Support\Collection $now): array
    {
        $sites = [];
        foreach ($now as $query => $snapshot) {
            foreach ((array) ($snapshot['payload']['ai_overview_sources'] ?? []) as $source) {
                $domain = (string) ($source['domain'] ?? '');
                if ($domain === '') {
                    continue;
                }
                $sites[$domain] ??= ['queries' => [], 'url' => (string) ($source['url'] ?? '')];
                $sites[$domain]['queries'][(string) $query] = true;
            }
        }
        uasort($sites, fn (array $a, array $b): int => count($b['queries']) <=> count($a['queries']));

        $ourDomain = $this->ourDomain();
        $rows = [];
        foreach (array_slice($sites, 0, 10, true) as $domain => $site) {
            $rows[] = [$domain.($ourDomain !== '' && str_contains($domain, $ourDomain) ? ' (us)' : ''), count($site['queries']), $site['url']];
        }

        return $rows;
    }

    /** Clamped to DataForSEO's documented range for this endpoint: 10-200. */
    protected function depth(): int
    {
        return min(200, max(10, (int) $this->config('depth', 20)));
    }

    protected function snapshotFor(string $query, array $result, string $ourDomain): Snapshot
    {
        $items = (array) ($result['items'] ?? []);
        $position = null;
        $bestUrl = null;
        $top10 = [];
        $localPackPresent = false;
        $inLocalPack = false;
        $ourLocalPackRank = null;
        $aiOverviewPresent = false;
        $aiOverviewMentionsUs = false;
        $aiOverviewSources = [];
        $aiOverviewOurUrl = null;
        $paaQuestions = [];
        $featuredDomain = null;

        foreach ($items as $item) {
            $type = (string) ($item['type'] ?? '');
            $domain = mb_strtolower((string) ($item['domain'] ?? ''));

            if ($type === 'organic') {
                if ($domain !== '' && $this->isExcludedHost($domain)) {
                    // A directory/aggregator (Houzz, Yelp, ...): skip it and
                    // keep filling top10_domains from the next real organic result.
                    continue;
                }
                if (count($top10) < 10) {
                    $top10[] = $domain;
                }
                if ($position === null && $domain !== '' && str_contains($domain, $ourDomain)) {
                    $position = (int) ($item['rank_absolute'] ?? 0) ?: null;
                    $bestUrl = $item['url'] ?? null;
                }
            } elseif ($type === 'local_pack') {
                $localPackPresent = true;
                if ($domain !== '' && str_contains($domain, $ourDomain)) {
                    $inLocalPack = true;
                    $ourLocalPackRank = $item['rank_group'] ?? null;
                }
            } elseif ($type === 'ai_overview') {
                $aiOverviewPresent = true;
                $refs = (array) ($item['references'] ?? []);
                foreach ((array) ($item['items'] ?? []) as $el) {
                    $refs = array_merge($refs, (array) ($el['references'] ?? []), (array) ($el['links'] ?? []));
                }
                foreach ($refs as $ref) {
                    $url = self::unwrapGoogleRedirect(trim((string) ($ref['url'] ?? '')));
                    $refDomain = (string) preg_replace('/^www\./', '', mb_strtolower((string) parse_url($url, PHP_URL_HOST)));
                    if ($refDomain === '' || $refDomain === 'google.com') {
                        $refDomain = (string) preg_replace('/^www\./', '', mb_strtolower((string) ($ref['domain'] ?? '')));
                    }
                    if ($refDomain === '' || $refDomain === 'google.com') {
                        // A google.com/goto redirect whose target is opaque: the source name is all that is known.
                        $refDomain = self::domainFromSourceName((string) ($ref['source'] ?? ''));
                    }
                    if ($refDomain === '') {
                        continue;
                    }
                    $url = $url !== '' ? $url : "https://{$refDomain}/";
                    if (isset($aiOverviewSources[$url])) {
                        continue;
                    }
                    if ($ourDomain !== '' && str_contains($refDomain, $ourDomain)) {
                        $aiOverviewMentionsUs = true;
                        $aiOverviewOurUrl ??= $url;
                    }
                    if (count($aiOverviewSources) < 12) {
                        $title = trim((string) (($ref['title'] ?? '') ?: ($ref['source'] ?? '')));
                        $aiOverviewSources[$url] = ['domain' => $refDomain, 'url' => $url, 'title' => $title !== '' ? $title : null];
                    }
                }
            } elseif ($type === 'people_also_ask') {
                foreach ((array) ($item['items'] ?? []) as $el) {
                    $title = trim((string) ($el['title'] ?? ''));
                    if ($title !== '' && count($paaQuestions) < 8) {
                        $paaQuestions[] = $title;
                    }
                }
            } elseif ($type === 'featured_snippet') {
                $featuredDomain = $item['domain'] ?? null;
            }
        }

        $metrics = [
            'position' => $position,
            'in_local_pack' => $inLocalPack ? 1 : 0,
            'ai_overview' => $aiOverviewPresent ? 1 : 0,
            'ai_overview_cites_us' => $aiOverviewMentionsUs ? 1 : 0,
            'paa_count' => count($paaQuestions),
            'featured' => ($featuredDomain !== null && str_contains(mb_strtolower((string) $featuredDomain), $ourDomain)) ? 1 : 0,
        ];
        $payload = [
            'top10_domains' => $top10,
            'best_organic_url' => $bestUrl,
            'local_pack_present' => $localPackPresent,
            'local_pack_rank' => $ourLocalPackRank,
            'ai_overview_present' => $aiOverviewPresent,
            'ai_overview_mentions_us' => $aiOverviewMentionsUs,
            'ai_overview_our_url' => $aiOverviewOurUrl,
            'ai_overview_sources' => array_values($aiOverviewSources),
            'ai_overview_domains' => array_values(array_unique(array_column($aiOverviewSources, 'domain'))),
            'paa_questions' => $paaQuestions,
            'featured_domain' => $featuredDomain,
        ];

        return new Snapshot('keyword', $query, $metrics, $payload);
    }

    protected function pathFor(?string $url): ?string
    {
        if (! $url) {
            return null;
        }
        $path = parse_url($url, PHP_URL_PATH);

        return is_string($path) && $path !== '' ? $path : '/';
    }

    protected function severityRank(string $severity): int
    {
        return match ($severity) {
            Finding::CRITICAL => 0,
            Finding::WARN => 1,
            Finding::INFO => 2,
            Finding::WIN => 3,
            default => 4,
        };
    }
}
