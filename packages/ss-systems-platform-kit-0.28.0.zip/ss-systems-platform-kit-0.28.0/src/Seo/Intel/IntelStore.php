<?php

namespace SsSystems\Platform\Seo\Intel;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Database\Query\Builder;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;

/**
 * The one read/write path to `seo_intel_runs`/`seo_intel_snapshots`/
 * `seo_intel_findings` — ported from gs.construction's
 * App\Services\Seo\Intel\IntelStore, generalised exactly like
 * {@see \SsSystems\Platform\Seo\AiTraffic\AiTrafficStore} (its sibling and
 * model): an injected `ConnectionInterface` replaces `Tenancy::table()`,
 * and optional `$tenantColumn`/`$tenantId` replace `Site::current()?->id`
 * — a single-tenant site passes neither, a multi-tenant site (gs.construction)
 * passes `'site_id'` and a closure reading the current tenant at call time
 * (never captured once at construction, the same reasoning AiTrafficStore's
 * own docblock gives: the bound singleton outlives any one request's
 * tenant in a queue worker).
 *
 * Semantics kept identical to the original: snapshots are upserted per
 * family/kind/subject/day; findings are upserted by a fingerprint (a
 * finding that had been resolved and comes back starts a new "first seen"
 * streak); a run that no longer reports a previously-open finding resolves
 * it in the same `saveFindings()` call that would otherwise re-open it.
 */
final class IntelStore
{
    private const RUNS = 'seo_intel_runs';

    private const SNAPSHOTS = 'seo_intel_snapshots';

    private const FINDINGS = 'seo_intel_findings';

    public function __construct(
        private readonly ConnectionInterface $connection,
        private readonly ?string $tenantColumn = null,
        private readonly ?\Closure $tenantId = null,
    ) {
    }

    public function ready(): bool
    {
        try {
            $schema = $this->connection->getSchemaBuilder();

            return $schema->hasTable(self::RUNS) && $schema->hasTable(self::SNAPSHOTS) && $schema->hasTable(self::FINDINGS);
        } catch (\Throwable) {
            return false;
        }
    }

    /**
     * Each snapshot is stored under `$takenOn`, the day of the run — unless
     * it names its own day ({@see Snapshot::$takenOn}), which is how a
     * measurement asked for on an earlier day lands in that day's set.
     *
     * @param  Snapshot[]  $snapshots
     */
    public function save(string $family, string $runId, string $takenOn, array $snapshots): int
    {
        $n = 0;
        foreach ($snapshots as $s) {
            $this->connection->table(self::SNAPSHOTS)->updateOrInsert(
                $this->withTenant(['family' => $family, 'kind' => $s->kind, 'subject' => mb_substr($s->subject, 0, 191), 'taken_on' => $s->takenOn ?? $takenOn]),
                ['run_id' => $runId, 'metrics' => json_encode($s->metrics), 'payload' => json_encode($s->payload), 'updated_at' => Carbon::now(), 'created_at' => Carbon::now()]
            );
            $n++;
        }

        return $n;
    }

    /** @return array{taken_on: string, run_id: string, metrics: array, payload: array}|null */
    public function latest(string $family, string $kind, string $subject): ?array
    {
        $row = $this->scoped($this->connection->table(self::SNAPSHOTS))->where('family', $family)->where('kind', $kind)
            ->where('subject', mb_substr($subject, 0, 191))->orderByDesc('taken_on')->first();

        return $row ? $this->hydrate($row) : null;
    }

    /** @return array{taken_on: string, run_id: string, metrics: array, payload: array}|null */
    public function previous(string $family, string $kind, string $subject): ?array
    {
        $latest = $this->latest($family, $kind, $subject);
        if (! $latest) {
            return null;
        }
        $row = $this->scoped($this->connection->table(self::SNAPSHOTS))->where('family', $family)->where('kind', $kind)
            ->where('subject', mb_substr($subject, 0, 191))->where('taken_on', '<', $latest['taken_on'])->orderByDesc('taken_on')->first();

        return $row ? $this->hydrate($row) : null;
    }

    /** Latest day a kind was measured for the family, or null. */
    public function latestDay(string $family, ?string $kind = null): ?string
    {
        $q = $this->scoped($this->connection->table(self::SNAPSHOTS))->where('family', $family);
        if ($kind !== null) {
            $q->where('kind', $kind);
        }
        $d = $q->max('taken_on');

        return $d ? substr((string) $d, 0, 10) : null;
    }

    /** The measured day before $day for a family/kind, or null. */
    public function previousDay(string $family, string $day, ?string $kind = null): ?string
    {
        $q = $this->scoped($this->connection->table(self::SNAPSHOTS))->where('family', $family)->where('taken_on', '<', $day);
        if ($kind !== null) {
            $q->where('kind', $kind);
        }
        $d = $q->max('taken_on');

        return $d ? substr((string) $d, 0, 10) : null;
    }

    /** All subjects of a kind on the latest day it was measured, keyed by subject. */
    public function latestSet(string $family, string $kind): Collection
    {
        $day = $this->latestDay($family, $kind);

        return $day ? $this->set($family, $kind, $day) : collect();
    }

    /** All subjects of a kind on the day before the latest, keyed by subject. */
    public function previousSet(string $family, string $kind): Collection
    {
        $day = $this->latestDay($family, $kind);
        $prev = $day ? $this->previousDay($family, $day, $kind) : null;

        return $prev ? $this->set($family, $kind, $prev) : collect();
    }

    public function set(string $family, string $kind, string $day): Collection
    {
        return $this->scoped($this->connection->table(self::SNAPSHOTS))->where('family', $family)->where('kind', $kind)->where('taken_on', $day)
            ->get()->mapWithKeys(fn ($r) => [$r->subject => $this->hydrate($r)]);
    }

    /**
     * Upsert this run's findings by fingerprint; resolve the family's open
     * findings the run no longer reports.
     *
     * @param  Finding[]  $findings
     * @return array{new: int, open: int, resolved: int}
     */
    public function saveFindings(string $family, string $runId, string $takenOn, array $findings): array
    {
        $seen = [];
        $new = 0;
        foreach ($findings as $f) {
            $fp = substr(sha1($family.'|'.$f->fingerprint), 0, 40);
            $seen[] = $fp;
            $existing = $this->scoped($this->connection->table(self::FINDINGS))->where('fingerprint', $fp)->first();
            $values = [
                'family' => $family, 'code' => mb_substr($f->code, 0, 60), 'severity' => $f->severity,
                'subject' => $f->subject !== null ? mb_substr($f->subject, 0, 191) : null, 'key' => $f->key,
                'title' => mb_substr($f->title, 0, 255), 'detail' => $f->detail,
                'delta' => $f->delta ? json_encode($f->delta) : null, 'action' => $f->action ? json_encode($f->action) : null,
                'last_seen_on' => $takenOn, 'last_run_id' => $runId, 'resolved_at' => null, 'updated_at' => Carbon::now(),
            ];
            if ($existing) {
                // A finding that had been resolved and comes back starts a new streak.
                if ($existing->resolved_at !== null) {
                    $values['first_seen_on'] = $takenOn;
                    $new++;
                }
                $this->connection->table(self::FINDINGS)->where('id', $existing->id)->update($values);
            } else {
                $this->connection->table(self::FINDINGS)->insert($this->withTenant($values + ['fingerprint' => $fp, 'first_seen_on' => $takenOn, 'created_at' => Carbon::now()]));
                $new++;
            }
        }
        $resolveQuery = $this->scoped($this->connection->table(self::FINDINGS))->where('family', $family)->whereNull('resolved_at');
        if ($seen) {
            $resolveQuery->whereNotIn('fingerprint', $seen);
        }
        $resolved = $resolveQuery->update(['resolved_at' => Carbon::now(), 'updated_at' => Carbon::now()]);

        return ['new' => $new, 'open' => count($seen), 'resolved' => (int) $resolved];
    }

    /** Open findings, most severe first. */
    public function openFindings(?string $family = null, int $limit = 50): Collection
    {
        $q = $this->scoped($this->connection->table(self::FINDINGS))->whereNull('resolved_at');
        if ($family !== null) {
            $q->where('family', $family);
        }
        $order = "case severity when 'critical' then 0 when 'warn' then 1 when 'win' then 2 else 3 end";

        return $q->orderByRaw($order)->orderByDesc('last_seen_on')->orderBy('id')->limit($limit)->get()->map(function ($r) {
            $r->delta = $r->delta ? json_decode((string) $r->delta, true) : [];
            $r->action = $r->action ? json_decode((string) $r->action, true) : null;

            return $r;
        });
    }

    /** @param  array<string, mixed>  $stats */
    public function recordRun(string $family, string $runId, string $takenOn, array $stats): void
    {
        $this->connection->table(self::RUNS)->updateOrInsert(
            $this->withTenant(['family' => $family, 'run_id' => $runId]),
            array_merge([
                'taken_on' => $takenOn, 'cost' => 0, 'snapshots' => 0, 'findings_open' => 0, 'findings_new' => 0, 'findings_resolved' => 0,
                'duration_ms' => 0, 'error' => null, 'updated_at' => Carbon::now(), 'created_at' => Carbon::now(),
            ], $stats)
        );
    }

    /**
     * Remove everything a family has stored (its next run starts over).
     *
     * @return array{snapshots: int, findings: int, runs: int}
     */
    public function reset(string $family): array
    {
        return [
            'snapshots' => $this->scoped($this->connection->table(self::SNAPSHOTS))->where('family', $family)->delete(),
            'findings' => $this->scoped($this->connection->table(self::FINDINGS))->where('family', $family)->delete(),
            'runs' => $this->scoped($this->connection->table(self::RUNS))->where('family', $family)->delete(),
        ];
    }

    /** Latest runs of a family, newest first. */
    public function runs(string $family, int $limit = 12): Collection
    {
        return $this->scoped($this->connection->table(self::RUNS))->where('family', $family)->orderByDesc('taken_on')->orderByDesc('id')->limit($limit)->get();
    }

    /** Total cost recorded across every family's runs on or after $sinceDate — the hub card's 30-day spend figure. */
    public function spentSince(string $sinceDate): float
    {
        return (float) $this->scoped($this->connection->table(self::RUNS))->where('taken_on', '>=', $sinceDate)->sum('cost');
    }

    /** @return array{taken_on: string, run_id: string, metrics: array, payload: array} */
    private function hydrate(object $row): array
    {
        return [
            'taken_on' => substr((string) $row->taken_on, 0, 10),
            'run_id' => $row->run_id,
            'metrics' => (array) json_decode((string) $row->metrics, true),
            'payload' => (array) json_decode((string) $row->payload, true),
        ];
    }

    /** @param  array<string, mixed>  $conditions @return array<string, mixed> */
    private function withTenant(array $conditions): array
    {
        if ($this->tenantColumn !== null) {
            $conditions[$this->tenantColumn] = ($this->tenantId)();
        }

        return $conditions;
    }

    private function scoped(Builder $query): Builder
    {
        if ($this->tenantColumn !== null) {
            $query->where($this->tenantColumn, ($this->tenantId)());
        }

        return $query;
    }
}
