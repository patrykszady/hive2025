<?php

namespace SsSystems\Platform\Seo\Intel\Console;

use Illuminate\Console\Command;
use SsSystems\Platform\Seo\Concerns\ExplainsFailure;
use SsSystems\Platform\Seo\DataForSeo\Contracts\DataForSeoApi;
use SsSystems\Platform\Seo\Intel\IntelRunner;
use SsSystems\Platform\Seo\Intel\IntelStore;

/**
 * `seo:intel` — every DataForSEO intelligence family as a scheduled
 * collector whose results are stored per run and compared with the
 * previous run. Ported from gs.construction's App\Console\Commands\SeoIntel,
 * signature and console output unchanged:
 *
 *   php artisan seo:intel                 all families, within --budget
 *   php artisan seo:intel serp trends
 *   php artisan seo:intel --list          families, estimated cost, last run
 *   php artisan seo:intel --dry-run       collect and print, store nothing
 *   php artisan seo:intel --findings      re-run only the comparison on stored data (no API calls)
 *   php artisan seo:intel --reset serp    wipe one family's history before collecting
 *
 * GENERALISED: gs.construction split the balance/budget guard into a
 * reusable `App\Support\Seo\DataForSeoBudget` class shared by several
 * commands (map-pack grid, domain overview, backlink gap, …) that have no
 * place in this port — only `seo:intel` itself is in scope. Its two
 * behaviours (fail closed when the balance reading itself failed; track
 * whether every attempted family failed, for the final exit code) are
 * reproduced inline below instead of pulling in a class this module
 * otherwise has no use for.
 *
 * A site registers this the same way it registers any other kit console
 * command: a thin `App\Console\Commands\SeoIntel extends IntelCommand {}`
 * under `app/Console/Commands/`, auto-discovered by Laravel, with
 * `DataForSeoApi`/`IntelRunner`/`IntelStore` bound in its container.
 */
class IntelCommand extends Command
{
    use ExplainsFailure;

    /** @var string */
    protected $signature = 'seo:intel {family?* : Families to run (default: all registered)}
        {--budget=2 : Max USD to spend across this run}
        {--dry-run : Collect and print, store nothing}
        {--findings : Only recompute findings from stored snapshots}
        {--list : Show registered families and their last run}
        {--reset : Delete the named families\' snapshots, findings and runs before collecting (start over)}';

    /** @var string */
    protected $description = 'Collect DataForSEO intelligence (SERP, Trends, …) into per-run snapshots and findings, compared with the previous run';

    public function handle(DataForSeoApi $dfs, IntelRunner $runner, IntelStore $store): int
    {
        if (! $store->ready()) {
            $this->comment('seo_intel_* tables missing — run migrations first.');

            return self::SUCCESS;
        }

        $only = (array) $this->argument('family') ?: null;
        $sources = $runner->sources($only);
        if ($only && count($sources) !== count($only)) {
            return $this->failBecause(self::REASON_NOT_CONFIGURED, 'Unknown family: '.implode(', ', array_diff($only, array_keys($sources))).'. Registered: '.implode(', ', array_keys($runner->sources())));
        }
        if ($this->option('list')) {
            $rows = [];
            foreach ($sources as $family => $source) {
                $last = $store->runs($family, 1)->first();
                $rows[] = [$family, $source->label(), number_format($source->estimateCost(), 3), $last->taken_on ?? '—', $last ? number_format((float) $last->cost, 3) : '—', $store->openFindings($family, 500)->count()];
            }
            $this->table(['Family', 'Label', 'Est. $/run', 'Last run', 'Cost', 'Open findings'], $rows);

            return self::SUCCESS;
        }
        if (! $sources) {
            $this->comment('No intelligence sources registered.');

            return self::SUCCESS;
        }

        if ($this->option('reset')) {
            if (! $only) {
                return $this->failBecause(self::REASON_NOT_CONFIGURED, '--reset needs explicit family names.');
            }
            foreach (array_keys($sources) as $family) {
                $n = $store->reset($family);
                $this->warn("  {$family}: reset — removed {$n['snapshots']} snapshots, {$n['findings']} findings, {$n['runs']} runs.");
            }
        }

        $findingsOnly = (bool) $this->option('findings');
        $dryRun = (bool) $this->option('dry-run');
        $budget = (float) $this->option('budget');
        $attempted = 0;
        $failed = 0;
        $errors = [];

        if (! $findingsOnly) {
            if (! $dfs->isConfigured()) {
                $this->comment('DataForSEO not configured — skipping.');

                return self::SUCCESS;
            }
            $estimate = array_sum(array_map(fn ($s) => $s->estimateCost(), $sources));
            $balance = $dfs->balance();
            $capped = min($estimate, $budget);
            if ($balance === null) {
                return $this->failBecause(self::reasonForError($dfs->getLastError(), self::REASON_VENDOR_ERROR), sprintf('DataForSEO balance unknown (%s) — refusing to spend blind.', $dfs->getLastError() ?? 'balance check failed'));
            }
            if ($balance < $capped) {
                return $this->failBecause(self::REASON_BALANCE_TOO_LOW, sprintf('DataForSEO balance $%.2f cannot cover this run ($%.2f).', $balance, $capped));
            }
            $this->line(sprintf('Balance $%s · budget $%.2f · estimated $%.2f for %s', number_format($balance, 2), $budget, $estimate, implode(', ', array_keys($sources))));
        }

        foreach ($sources as $family => $source) {
            if (! $findingsOnly && $runner->spent() > 0 && $runner->spent() + $source->estimateCost() > $budget) {
                $this->warn(sprintf('  %s: skipped, budget reached ($%.3f spent).', $family, $runner->spent()));

                continue;
            }
            $r = $runner->run($source, $dryRun, $findingsOnly);
            if (! empty($r['skipped'])) {
                $this->line(sprintf('  %-18s —    nothing to collect right now', $family));

                continue;
            }
            $line = sprintf('  %-18s %s  %3d snapshots  $%.3f  findings +%d / %d open / -%d resolved  (%.1fs)',
                $family, $r['ok'] ? 'ok ' : 'ERR', $r['snapshots'], $r['cost'], $r['findings']['new'], $r['findings']['open'], $r['findings']['resolved'], $r['duration_ms'] / 1000);
            $r['ok'] ? $this->info($line) : $this->error($line.'  '.$r['error']);
            if ($r['ok'] && ($r['partial_errors'] ?? []) !== []) {
                $gaps = [];
                foreach ($r['partial_errors'] as $part => $why) {
                    $gaps[] = "{$part} ({$why})";
                }
                $this->warn('     partial — not collected: '.implode('; ', $gaps));
            }
            $attempted++;
            $failed += $r['ok'] ? 0 : 1;
            if (! $r['ok']) {
                $errors[] = $family.': '.($r['error'] ?? 'no error given');
            }
            if ($this->output->isVerbose() || $dryRun) {
                foreach ($store->openFindings($family, 12) as $f) {
                    $this->line(sprintf('     [%s] %s%s', $f->severity, $f->title, $f->key ? ' — '.$f->key : ''));
                }
            }
        }
        $this->info(sprintf('Done. Spent $%.3f.', $runner->spent()));

        if ($attempted > 0 && $failed === $attempted) {
            return $this->failBecause(self::familyFailureReason($errors), implode(' | ', $errors));
        }

        return self::SUCCESS;
    }

    /**
     * Every attempted family failed: why? First what the errors themselves
     * say (insufficient funds, the daily cost limit, rejected credentials —
     * {@see reasonForError()}). Failing that, an error carrying one of
     * DataForSEO's status codes ("40501 Invalid Field"), an HTTP status or
     * a failed request is a vendor error; anything else (an exception in
     * the source's own code, say) is only "nothing succeeded", with the
     * error text there to read either way.
     *
     * @param  list<string>  $errors
     */
    private static function familyFailureReason(array $errors): string
    {
        foreach ($errors as $error) {
            $said = self::reasonForError($error, '');
            if ($said !== '') {
                return $said;
            }
        }

        foreach ($errors as $error) {
            if (preg_match('/\b[45]\d{4}\b|HTTP \d{3}|request failed/', $error) === 1) {
                return self::REASON_VENDOR_ERROR;
            }
        }

        return self::REASON_NOTHING_SUCCEEDED;
    }
}
