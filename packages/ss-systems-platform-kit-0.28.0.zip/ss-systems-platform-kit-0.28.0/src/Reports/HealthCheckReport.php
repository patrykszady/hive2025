<?php

namespace SsSystems\Platform\Reports;

use Illuminate\Support\Carbon;
use SsSystems\Platform\Reports\Contracts\PageFetcher;
use SsSystems\Platform\Reports\Contracts\SiteCatalog;
use SsSystems\Platform\Reports\Contracts\SiteIdentity;
use SsSystems\Platform\Seo\Checks\Contracts\SiteCheckStore;
use SsSystems\Platform\Seo\Checks\SiteCheckRun;
use SsSystems\Platform\Seo\Checks\SiteCheckStores;

/**
 * Local SEO health-check — ported verbatim from gs.construction's
 * app/Console/Commands/SeoHealthCheck.php (same eight checks, same
 * thresholds, same score weights, same markdown headings/table, same
 * per-URL breakdown wording). Single fetch per URL; no external APIs.
 *
 * Score breakdown (max 100):
 *   - Title length 30–60        : 15
 *   - Meta description 70–160   : 15
 *   - Exactly one <h1>          : 10
 *   - Image alt coverage ≥ 90%  : 15
 *   - Internal-link count 3–80  : 10
 *   - JSON-LD present           : 15
 *   - Word count > 300          : 10
 *   - <link rel="canonical">    : 10
 *
 * Two places this port could not be a pure 1:1 transcription:
 *
 *   - The original resolved its crawl list by fetching {sitemap or
 *     --sitemap}/sitemap.xml itself (Http::timeout(15)) and regexing out
 *     <loc>. That fetch-and-parse now lives behind
 *     SiteCatalog::sitemapUrls() (unfiltered, already trimmed/deduplicated;
 *     a network failure or unparseable response is already folded into []
 *     by the interface, exactly like the original's try/catch). This report
 *     still applies the original's OWN extension filter (looksLikeHtml())
 *     to that raw list before slicing to --limit, per
 *     docs/REPORTS-PORTING.md's filter table. Because the sitemap URL is no
 *     longer chosen by the report, the original's `--sitemap` option has no
 *     equivalent here (ReportRegistry's `health-check` entry does not list
 *     one either) — only `--urls` (explicit override) and `--limit` survive
 *     as options alongside `--min-score`.
 *   - The original returned a non-zero exit code (Command::FAILURE) when
 *     the worst-scoring URL fell below --min-score, while still having
 *     printed/saved the full report first. A ReportResult is either fully
 *     successful or not — there is no "ok, but exit 1" shape — so that case
 *     becomes ReportResult::degraded() (report is complete, `data` and
 *     `markdown` are exactly what a passing run would produce, `missing`
 *     lists the URLs that fell below the threshold) instead of
 *     ReportResult::error(), which would suppress the report/markdown a
 *     site's wrapper is supposed to still write. The site's thin wrapper
 *     exits 1 on STATUS_DEGRADED for this report, matching the original
 *     command's behaviour, per docs/REPORTS-PORTING.md.
 *
 * **The site checks ride on this report's fetches (2026-11-12).** Each
 * page's response is also read for what the score does not cover — a
 * noindex tag on a sitemap page, the link preview, review markup on the
 * business itself, the viewport tag, structured data that cannot be read —
 * and the home page for the privacy, phone and contact links and the
 * business's own markup ({@see SiteCheckRun}). They are findings of their
 * own in `data['page_checks']` and under their own markdown heading: no
 * check, weight, score, average, `rows` entry or summary line above
 * changed, so the score history compares what it always has.
 *
 * They live here rather than in an eleventh report for three reasons the
 * porting guide's own conventions give: a new report needs a thin command
 * and a schedule line on every site, where `seo:health-check` already runs
 * on all six; it would fetch every page a second time, where this one
 * already holds the response; and a report's capabilities are fixed by
 * `requires`, which stays `page_fetcher` + `site_catalog` — the two new
 * constructor arguments are optional and a site binds nothing new.
 *
 *   - `$siteIdentity` — the container hands it over on a site that binds
 *     it (every site does, for gbp-parity); it only says whether the site
 *     has a phone number for the tap-to-call check to ask about.
 *   - `$siteCheckStore` — where a sitemap run keeps its findings for the
 *     SEO snapshot to read; unbound, {@see SiteCheckStores::current()}
 *     picks the local-disk default. An `--urls` run reports its findings
 *     and stores nothing: a hand-picked list must not overwrite the
 *     site's.
 *
 * A page is still fetched once. Two addresses the list above does not
 * cover are read once each, and only on a sitemap run with somewhere to
 * keep the answer: the home page when the list left it out, and
 * robots.txt (whether Google, Bing or an AI assistant's crawler is shut
 * out of the whole site).
 */
final class HealthCheckReport implements Report
{
    private const TIMEOUT_SECONDS = 20;

    private const USER_AGENT = 'GS-SEO-Health/1.0';

    /** @var list<string> */
    private const SKIP_EXTENSIONS = [
        'json', 'xml', 'txt', 'csv', 'rss', 'atom', 'pdf', 'jpg', 'jpeg',
        'png', 'webp', 'gif', 'svg', 'ico', 'css', 'js', 'map', 'webmanifest',
    ];

    public function __construct(
        private readonly PageFetcher $pageFetcher,
        private readonly SiteCatalog $siteCatalog,
        private readonly ?SiteIdentity $siteIdentity = null,
        private readonly ?SiteCheckStore $siteCheckStore = null,
    ) {
    }

    public static function key(): string
    {
        return 'health-check';
    }

    /** @return list<string> */
    public static function requires(): array
    {
        return ['page_fetcher', 'site_catalog'];
    }

    public function generate(array $options = []): ReportResult
    {
        $minScore = max(0, (int) ($options['min_score'] ?? 80));

        // The sitemap is read at most once a run: for the crawl list, and
        // again only to tell whether a noindex page is one the sitemap lists.
        $sitemap = null;
        $sitemapUrls = function () use (&$sitemap): array {
            return $sitemap ??= $this->siteCatalog->sitemapUrls();
        };

        $urls = $this->resolveUrls($options, $sitemapUrls);

        if ($urls === []) {
            return ReportResult::unavailable([], 'No URLs to audit.');
        }

        $appHost = $this->siteCatalog->canonicalHost();
        $checkError = null;

        // The site's adapters are asked two things the scored report never
        // asked them (its address, its phone number): should either throw,
        // the checks are skipped and the report goes on as it always has.
        try {
            $checks = new SiteCheckRun(
                rtrim($this->siteCatalog->baseUrl(), '/'),
                $appHost,
                $this->siteIdentity?->expectedPhone(),
                $this->siteIdentity !== null,
            );
        } catch (\Throwable $e) {
            $checks = null;
            $checkError = $e->getMessage();
        }

        $rows = [];
        foreach ($urls as $url) {
            $fetch = $this->pageFetcher->fetch($url, self::TIMEOUT_SECONDS, self::USER_AGENT);
            $row = $this->scoreUrl($url, $appHost, $fetch);
            $rows[] = $row;

            try {
                $checks?->page($url, $fetch, $row['breakdown']);
            } catch (\Throwable $e) {
                // The score above stands whatever the extra reading of a page does.
                $checkError ??= $url.': '.$e->getMessage();
            }
        }

        // Sort worst first, exactly like the original's usort() before
        // renderSummary()/saveMarkdown().
        usort($rows, fn (array $a, array $b) => $a['score'] <=> $b['score']);

        $avg = $rows ? (int) round(array_sum(array_column($rows, 'score')) / count($rows)) : 0;
        $worst = $rows[0]['score'] ?? 100;

        $belowMinRows = array_values(array_filter($rows, fn (array $r): bool => $r['score'] < $minScore));
        $belowMinUrls = array_column($belowMinRows, 'url');

        $pageChecks = $this->siteChecks($checks, $sitemapUrls, empty($options['urls']), $checkError);

        $markdown = $this->buildMarkdown($rows, $avg).SiteCheckRun::markdown($pageChecks);
        $summary = sprintf(
            'Average score: %d / 100 across %d URL(s); worst %d (%s).',
            $avg,
            count($rows),
            $worst,
            $rows[0]['url'],
        );

        $data = [
            'average_score' => $avg,
            'url_count' => count($rows),
            'worst_score' => $worst,
            'below_min_score' => count($belowMinRows),
            'rows' => $rows,
            'page_checks' => $pageChecks,
        ];

        if ($worst < $minScore) {
            return ReportResult::degraded($markdown, $summary, $belowMinUrls, $data);
        }

        return ReportResult::ok($markdown, $summary, $data);
    }

    /**
     * The site checks' findings for this run, stored when it is a sitemap
     * run with a store to keep them in. Only then are the home page (when
     * the list left it out) and robots.txt read, once each: without a
     * store nothing would keep the answer, and an `--urls` run is somebody
     * looking at particular pages, not at the site. `stored` says whether
     * the snapshot will see these findings.
     *
     * The scored report never depends on any of this: should the checks
     * themselves fail (on a page, here, or writing the store), the result
     * says so in `error`, nothing half-read is stored, and the scores, the
     * rows and the status of the run are exactly what they would have been.
     *
     * @param  callable(): list<string>  $sitemapUrls
     * @return array<string, mixed>
     */
    private function siteChecks(?SiteCheckRun $checks, callable $sitemapUrls, bool $sitemapRun, ?string $pageError): array
    {
        if ($checks === null || $pageError !== null) {
            return SiteCheckRun::failed($pageError ?? 'The checks could not start.');
        }

        try {
            $store = $sitemapRun ? ($this->siteCheckStore ?? SiteCheckStores::current()) : null;

            if ($store !== null) {
                if ($checks->needsHomePage()) {
                    $checks->homePage($this->pageFetcher->fetch($checks->homePageUrl(), self::TIMEOUT_SECONDS, self::USER_AGENT));
                }

                $checks->robots($this->pageFetcher->fetch($checks->robotsUrl(), self::TIMEOUT_SECONDS, self::USER_AGENT));
            }

            $result = $checks->result($sitemapUrls);
        } catch (\Throwable $e) {
            return SiteCheckRun::failed($e->getMessage());
        }

        $result['stored'] = $store !== null;

        try {
            $store?->put($result);
        } catch (\Throwable) {
            // The report is still whole; the snapshot keeps the last run's findings.
            $result['stored'] = false;
        }

        return $result;
    }

    /**
     * @param  array<string, mixed>  $options
     * @param  callable(): list<string>  $sitemapUrls
     * @return list<string>
     */
    private function resolveUrls(array $options, callable $sitemapUrls): array
    {
        $limit = max(1, (int) ($options['limit'] ?? 60));

        if (! empty($options['urls'])) {
            return array_slice(
                array_filter(array_map('trim', explode(',', (string) $options['urls']))),
                0,
                $limit,
            );
        }

        $urls = array_values(array_filter(
            $sitemapUrls(),
            fn (string $u): bool => $this->looksLikeHtml($u),
        ));

        return array_slice($urls, 0, $limit);
    }

    private function looksLikeHtml(string $url): bool
    {
        $path = (string) parse_url($url, PHP_URL_PATH);
        if ($path === '' || $path === '/') {
            return true;
        }
        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));

        return ! in_array($ext, self::SKIP_EXTENSIONS, true);
    }

    /**
     * @return array{url:string, score:int, breakdown:array<string,array{ok:bool,note:string}>}
     */
    private function scoreUrl(string $url, string $appHost, PageFetchResult $fetch): array
    {
        $breakdown = [];
        $score = 0;

        if (! $fetch->successful) {
            return [
                'url' => $url,
                'score' => 0,
                'breakdown' => [
                    'fetch' => [
                        'ok' => false,
                        'note' => $fetch->status === null ? 'connection failed' : "HTTP {$fetch->status}",
                    ],
                ],
            ];
        }

        $html = $fetch->body;

        // Content HTML = page with global chrome (header/nav/footer) stripped.
        // The shared layout adds the logo (decorative alt="") and ~130 nav/
        // footer links on every page; counting those would unfairly tank the
        // image-alt and internal-link metrics. Measure the unique page body.
        $contentHtml = preg_replace('#<(header|nav|footer)\b[^>]*>.*?</\1>#is', ' ', $html) ?? $html;

        // Title
        preg_match('#<title[^>]*>(.*?)</title>#is', $html, $m);
        $title = trim(html_entity_decode($m[1] ?? '', ENT_QUOTES | ENT_HTML5, 'UTF-8'));
        $tl = mb_strlen($title);
        $ok = $tl >= 30 && $tl <= 60;
        if ($ok) {
            $score += 15;
        }
        $breakdown['title'] = ['ok' => $ok, 'note' => "{$tl} chars".($ok ? '' : ' (target 30–60)')];

        // Meta description
        preg_match('#<meta[^>]+name=["\']description["\'][^>]*content=["\']([^"\']*)["\']#i', $html, $m);
        $desc = trim($m[1] ?? '');
        $dl = mb_strlen($desc);
        $ok = $dl >= 70 && $dl <= 160;
        if ($ok) {
            $score += 15;
        }
        $breakdown['description'] = ['ok' => $ok, 'note' => "{$dl} chars".($ok ? '' : ' (target 70–160)')];

        // H1 count
        $h1Count = preg_match_all('#<h1\b[^>]*>#i', $html);
        $ok = $h1Count === 1;
        if ($ok) {
            $score += 10;
        }
        $breakdown['h1'] = ['ok' => $ok, 'note' => "{$h1Count} H1".($ok ? '' : ' (want exactly 1)')];

        // Image alt coverage (content images only; chrome logos excluded)
        $imgs = preg_match_all('#<img\b[^>]*>#i', $contentHtml, $im) ? $im[0] : [];
        $imgTotal = 0;
        $withAlt = 0;
        foreach ($imgs as $tag) {
            // Decorative images (aria-hidden="true") correctly use empty alt and
            // must not count against coverage — e.g. blur-up LQIP placeholders.
            if (preg_match('#\baria-hidden=["\']true["\']#i', $tag)) {
                continue;
            }
            $imgTotal++;
            // alt="..." with non-empty content
            if (preg_match('#\balt=["\']([^"\']*)["\']#i', $tag, $am) && trim($am[1]) !== '') {
                $withAlt++;
            }
        }
        $coverage = $imgTotal > 0 ? $withAlt / $imgTotal : 1.0;
        $ok = $coverage >= 0.9;
        if ($ok) {
            $score += 15;
        }
        $breakdown['image_alt'] = [
            'ok' => $ok,
            'note' => $imgTotal === 0 ? 'no images' : sprintf('%d/%d (%d%%)', $withAlt, $imgTotal, (int) round($coverage * 100)),
        ];

        // Internal links — count links in the MAIN content only. Global
        // header/nav/footer regions add ~130 boilerplate links on every page,
        // which would otherwise blow past any sane ceiling. Use the chrome-
        // stripped $contentHtml so the metric reflects real interlinking.
        $links = preg_match_all('#<a\b[^>]*href=["\']([^"\']+)["\']#i', $contentHtml, $lm) ? $lm[1] : [];
        $internal = 0;
        foreach ($links as $href) {
            if ($href === '' || $href[0] === '#') {
                continue;
            }
            if (str_starts_with($href, '/') && ! str_starts_with($href, '//')) {
                $internal++;
                continue;
            }
            if ($appHost && stripos($href, $appHost) !== false) {
                $internal++;
            }
        }
        $ok = $internal >= 3 && $internal <= 80;
        if ($ok) {
            $score += 10;
        }
        $breakdown['internal_links'] = ['ok' => $ok, 'note' => "{$internal} internal".($ok ? '' : ' (target 3–80)')];

        // JSON-LD
        $jsonLdCount = preg_match_all('#<script[^>]+type=["\']application/ld\+json["\']#i', $html);
        $ok = $jsonLdCount > 0;
        if ($ok) {
            $score += 15;
        }
        $breakdown['jsonld'] = ['ok' => $ok, 'note' => "{$jsonLdCount} block(s)".($ok ? '' : ' (missing)')];

        // Word count (body text)
        $bodyText = '';
        if (preg_match('#<body\b[^>]*>(.*?)</body>#is', $html, $bm)) {
            $bodyText = preg_replace('#<(script|style|noscript|template)\b[^>]*>.*?</\1>#is', ' ', $bm[1]) ?? '';
            $bodyText = trim((string) preg_replace('/\s+/u', ' ', strip_tags($bodyText)));
        }
        $words = str_word_count($bodyText);
        $ok = $words > 300;
        if ($ok) {
            $score += 10;
        }
        $breakdown['word_count'] = ['ok' => $ok, 'note' => "{$words} words".($ok ? '' : ' (want > 300)')];

        // Canonical
        $ok = (bool) preg_match('#<link[^>]+rel=["\']canonical["\']#i', $html);
        if ($ok) {
            $score += 10;
        }
        $breakdown['canonical'] = ['ok' => $ok, 'note' => $ok ? 'present' : 'missing'];

        return ['url' => $url, 'score' => $score, 'breakdown' => $breakdown];
    }

    /**
     * @param  list<array{url:string, score:int, breakdown:array<string,array{ok:bool,note:string}>}>  $rows
     */
    private function buildMarkdown(array $rows, int $avg): string
    {
        $now = Carbon::now()->toIso8601String();
        $md = "# Local SEO health-check\n\nRun: {$now}\n\nAverage score: **{$avg} / 100** across ".count($rows)." URLs.\n\n";
        $md .= "## Per-URL scores (worst first)\n\n";
        $md .= "| Score | URL | Failing checks |\n|---:|---|---|\n";
        foreach ($rows as $r) {
            $failed = collect($r['breakdown'])
                ->filter(fn ($v) => ! $v['ok'])
                ->map(fn ($v, $k) => "**{$k}** ({$v['note']})")
                ->values()
                ->implode('; ');
            $md .= "| {$r['score']} | {$r['url']} | ".($failed ?: '_all checks passed_')." |\n";
        }

        return $md;
    }
}
