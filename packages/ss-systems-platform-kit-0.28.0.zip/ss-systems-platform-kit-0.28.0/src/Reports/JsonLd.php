<?php

namespace SsSystems\Platform\Reports;

/**
 * Reading the JSON-LD a page carries — the one parser every kit check
 * shares. The methods are SchemaAuditReport's own, moved here unchanged
 * (same block extraction, same recursive @type collection, same per-type
 * required-property rules, same full-definition fingerprinting) so the
 * page checks that ride on the health-check's fetch
 * ({@see \SsSystems\Platform\Seo\Checks\PageInspector}) read structured
 * data exactly the way the schema audit does, instead of a second parser
 * that would drift from it. SchemaAuditReport calls these and nothing else.
 *
 * {@see walk()} is the one addition: the review-markup check needs to know
 * WHICH entity a rating sits on, so it visits each typed node together
 * with its parent and the property it hangs from.
 */
final class JsonLd
{
    /**
     * The body of every `<script type="application/ld+json">` block.
     *
     * @return array<int, string>
     */
    public static function blocks(string $html): array
    {
        if (! preg_match_all('#<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>#is', $html, $m)) {
            return [];
        }

        return array_map(fn ($s) => trim((string) preg_replace('/^<!--|-->\z/', '', trim($s))), $m[1]);
    }

    /**
     * @param  array<string, mixed>|array<int, mixed>  $data
     * @param  array<int, string>  $bag
     */
    public static function collectTypes(array $data, array &$bag): void
    {
        if (isset($data['@graph']) && is_array($data['@graph'])) {
            foreach ($data['@graph'] as $node) {
                if (is_array($node)) {
                    self::collectTypes($node, $bag);
                }
            }
        }
        if (isset($data['@type'])) {
            foreach ((array) $data['@type'] as $t) {
                $bag[] = (string) $t;
            }
        }
        foreach ($data as $v) {
            if (is_array($v) && (isset($v['@type']) || isset($v['@graph']) || (function_exists('array_is_list') && array_is_list($v)))) {
                if (array_is_list($v)) {
                    foreach ($v as $item) {
                        if (is_array($item)) {
                            self::collectTypes($item, $bag);
                        }
                    }
                } else {
                    self::collectTypes($v, $bag);
                }
            }
        }
    }

    /**
     * Collect @id values ONLY when the node is a full definition
     * (has @id, has @type, and has other properties beyond just those two).
     * Bare {"@id":"..."} references — the recommended JSON-LD entity-reuse
     * pattern — must not count as duplicates.
     *
     * @param  array<string, mixed>|array<int, mixed>  $data
     * @param  array<string, list<string>>  $bag
     */
    public static function collectFullDefinitions(array $data, array &$bag): void
    {
        if (
            isset($data['@id'], $data['@type'])
            && is_string($data['@id'])
            && count($data) > 2
        ) {
            $types = (array) $data['@type'];
            $isImageObject = in_array('ImageObject', $types, true);

            // Logo/image entities are commonly re-declared across compatible
            // schema fragments and are generally non-actionable for this
            // audit. Focus duplicate-id warnings on higher-risk entities.
            if (! $isImageObject) {
                $canonical = self::canonicalize($data);
                $bag[$data['@id']][] = md5((string) json_encode($canonical));
            }
        }
        foreach ($data as $v) {
            if (is_array($v)) {
                self::collectFullDefinitions($v, $bag);
            }
        }
    }

    /**
     * Canonicalize a JSON-LD node for stable hashing.
     */
    public static function canonicalize(mixed $value): mixed
    {
        if (! is_array($value)) {
            return $value;
        }

        if (array_is_list($value)) {
            return array_map(fn ($item) => self::canonicalize($item), $value);
        }

        ksort($value);

        foreach ($value as $k => $v) {
            $value[$k] = self::canonicalize($v);
        }

        return $value;
    }

    /**
     * The per-type required-property rules: every gap is added to $bag as
     * "{Type}: missing `{property}`".
     *
     * @param  array<string, mixed>|array<int, mixed>  $data
     * @param  array<int, string>  $bag
     */
    public static function validateNode(array $data, array &$bag): void
    {
        if (isset($data['@graph']) && is_array($data['@graph'])) {
            foreach ($data['@graph'] as $node) {
                if (is_array($node)) {
                    self::validateNode($node, $bag);
                }
            }
        }

        $type = $data['@type'] ?? null;
        $typeStr = is_array($type) ? implode(',', $type) : (string) $type;
        if ($typeStr === '') {
            return;
        }

        $check = function (array $required) use (&$bag, $data, $typeStr): void {
            foreach ($required as $key) {
                if (! array_key_exists($key, $data) || $data[$key] === '' || $data[$key] === null) {
                    $bag[] = "{$typeStr}: missing `{$key}`";
                }
            }
        };

        $hasType = fn (string $t) => $typeStr === $t || str_contains($typeStr, $t);
        // Exact-type match (no substring). Needed for types whose names are
        // substrings of other valid types, e.g. "HowTo" vs "HowToStep"/"HowToTool".
        $typeTokens = array_map('trim', explode(',', $typeStr));
        $isType = fn (string $t) => in_array($t, $typeTokens, true);

        if ($hasType('FAQPage')) {
            if (empty($data['mainEntity']) || ! is_array($data['mainEntity'])) {
                $bag[] = 'FAQPage: empty `mainEntity`';
            }
        }
        if ($hasType('BreadcrumbList')) {
            if (empty($data['itemListElement']) || ! is_array($data['itemListElement'])) {
                $bag[] = 'BreadcrumbList: empty `itemListElement`';
            }
        }
        // Exact: a Service is offered by a provider; a ProfessionalService,
        // FinancialService or FoodService IS the business (LocalBusiness
        // subtypes) and needs none. The substring match flagged every page
        // of ss.systems and jpeterson-design (2026-10-10).
        if ($isType('Service')) {
            $check(['name', 'provider']);
        }
        if ($hasType('LocalBusiness') || $hasType('GeneralContractor') || $hasType('HomeAndConstructionBusiness')) {
            $check(['name', 'address']);
        }
        if ($hasType('Article') || $hasType('BlogPosting') || $hasType('NewsArticle')) {
            $check(['headline', 'author', 'datePublished']);
        }
        if ($hasType('Review')) {
            $check(['author', 'reviewRating']);
        }
        if ($hasType('AggregateRating')) {
            $check(['ratingValue', 'reviewCount']);
        }
        if ($isType('HowTo')) {
            $check(['name', 'step']);
        }
        if ($hasType('VideoObject')) {
            $check(['name', 'thumbnailUrl', 'uploadDate']);
        }
        if ($hasType('ImageObject')) {
            $check(['contentUrl']);
        }
        if ($hasType('Person')) {
            $check(['name']);
        }

        // Recurse into nested entities
        foreach ($data as $v) {
            if (is_array($v)) {
                if (function_exists('array_is_list') && array_is_list($v)) {
                    foreach ($v as $item) {
                        if (is_array($item)) {
                            self::validateNode($item, $bag);
                        }
                    }
                } elseif (isset($v['@type'])) {
                    self::validateNode($v, $bag);
                }
            }
        }
    }

    /**
     * Visits every node that carries an @type — through @graph, lists and
     * nested objects — handing $visit the node, the typed node it sits in
     * (null at the top level and for a member of @graph) and the property
     * of that parent it hangs from. A rating is only "the business's own"
     * or "a product's" once its parent is known, which the flat @type bag
     * collectTypes() fills cannot say.
     *
     * @param  array<string, mixed>|array<int, mixed>  $data
     * @param  callable(array<string, mixed>, ?array<string, mixed>, ?string): void  $visit
     * @param  array<string, mixed>|null  $parent
     */
    public static function walk(array $data, callable $visit, ?array $parent = null, ?string $property = null): void
    {
        if (array_is_list($data)) {
            foreach ($data as $item) {
                if (is_array($item)) {
                    self::walk($item, $visit, $parent, $property);
                }
            }

            return;
        }

        $typed = isset($data['@type']);

        if ($typed) {
            $visit($data, $parent, $property);
        }

        foreach ($data as $key => $value) {
            if (! is_array($value)) {
                continue;
            }

            if ($key === '@graph') {
                self::walk($value, $visit);

                continue;
            }

            self::walk($value, $visit, $typed ? $data : $parent, $typed ? (string) $key : $property);
        }
    }
}
