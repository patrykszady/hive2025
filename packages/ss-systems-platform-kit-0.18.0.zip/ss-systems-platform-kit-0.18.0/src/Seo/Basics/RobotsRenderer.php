<?php

namespace SsSystems\Platform\Seo\Basics;

use SsSystems\Platform\Seo\Basics\Contracts\PublicSite;

/**
 * `robots.txt`'s body. The one branch that matters: a host that isn't this
 * site's live production host (a staging domain, a preview deploy, a dev
 * tunnel) gets a blanket `Disallow: /` and NOTHING else — no sitemap line,
 * so a crawler that somehow reaches staging is never handed a pointer back
 * to the real site's sitemap from there.
 */
final class RobotsRenderer
{
    public function render(PublicSite $site, bool $live): string
    {
        if (! $live) {
            return "User-agent: *\nDisallow: /\n";
        }

        $lines = ['User-agent: *', 'Allow: /'];

        foreach ($site->robotsDisallow() as $path) {
            $lines[] = "Disallow: {$path}";
        }

        $lines[] = '';

        foreach ($site->sitemapUrls() as $sitemapUrl) {
            $lines[] = "Sitemap: {$sitemapUrl}";
        }

        return implode("\n", $lines)."\n";
    }
}
