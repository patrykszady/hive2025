<?php

namespace SsSystems\Platform\Seo\Basics;

use DateTimeInterface;

/**
 * One URL a site hands the kit for sitemap.xml and llms.txt — the one unit
 * `Contracts\PublicSite::pages()` yields. A site builds these from its own
 * route list/page catalog; the kit never inspects where a page "came from",
 * only these eight facts about it.
 */
final class PublicPage
{
    /**
     * @param  string  $url  Absolute URL — the kit never resolves a relative one.
     * @param  ?DateTimeInterface  $lastmod  When this page last changed. Null when the site doesn't track that.
     * @param  ?string  $title  Used by LlmsTxtRenderer; a page with no title falls back to its URL path there.
     * @param  ?string  $description  One sentence. Used by LlmsTxtRenderer; omitted there when null.
     * @param  array<string, string>  $alternates  locale => absolute URL (hreflang), for SitemapRenderer's per-page `<xhtml:link>` entries.
     * @param  ?string  $section  Groups this page under a heading in llms.txt (e.g. "Blog"). Null groups it under "Pages".
     * @param  ?string  $changefreq  A sitemap.xml `<changefreq>` value (e.g. "weekly"). Null omits the element.
     * @param  ?float  $priority  A sitemap.xml `<priority>` value (0.0-1.0). Null omits the element.
     */
    public function __construct(
        public readonly string $url,
        public readonly ?DateTimeInterface $lastmod = null,
        public readonly ?string $title = null,
        public readonly ?string $description = null,
        public readonly array $alternates = [],
        public readonly ?string $section = null,
        public readonly ?string $changefreq = null,
        public readonly ?float $priority = null,
    ) {}
}
