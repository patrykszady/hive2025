<?php

namespace SsSystems\Platform\Seo\Basics;

use SsSystems\Platform\Seo\Basics\Contracts\PublicSite;

/**
 * `llms.txt`'s body, in the shape ss.systems and gs.construction already
 * publish by hand (see hive.contractors's own `LlmsTxtController`, added
 * the same day this module was built): `# {name}`, a one-line `>`
 * description, then every page as a flat markdown list grouped under a
 * `## {section}` heading — ungrouped pages (`section: null`) under
 * `## Pages`, always listed first.
 *
 * Plain markdown, not HTML: nothing here is entity-escaped (a title with
 * "Salt & Pepper" stays exactly that, never "Salt &amp; Pepper").
 */
final class LlmsTxtRenderer
{
    public function render(PublicSite $site): string
    {
        $identity = $site->identity();
        $lines = ['# '.$identity->name, '', '> '.$identity->description];

        foreach ($this->groupedPages($site) as $heading => $pages) {
            $lines[] = '';
            $lines[] = '## '.$heading;

            foreach ($pages as $page) {
                $lines[] = $this->entry($page);
            }
        }

        foreach ($site->notes() as $heading => $text) {
            $lines[] = '';
            $lines[] = '## '.$heading;
            $lines[] = rtrim($text);
        }

        return implode("\n", $lines)."\n";
    }

    /**
     * @return array<string, list<PublicPage>> heading => its pages, in
     *                                          first-seen order, except the
     *                                          null-section "Pages" group
     *                                          is always moved first.
     */
    private function groupedPages(PublicSite $site): array
    {
        $groups = [];

        foreach ($site->pages() as $page) {
            $groups[$page->section ?? 'Pages'][] = $page;
        }

        if (isset($groups['Pages'])) {
            $groups = ['Pages' => $groups['Pages']] + $groups;
        }

        return $groups;
    }

    private function entry(PublicPage $page): string
    {
        $path = parse_url($page->url, PHP_URL_PATH);
        $title = $page->title ?? (is_string($path) && $path !== '' ? $path : $page->url);
        $suffix = $page->description !== null && $page->description !== '' ? ': '.$page->description : '';

        return '- ['.$title.']('.$page->url.')'.$suffix;
    }
}
