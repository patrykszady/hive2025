<?php

namespace SsSystems\Platform\Seo\Basics;

use Illuminate\Http\Request;
use SsSystems\Platform\Seo\Basics\Contracts\PublicSite;

/**
 * Everything a brand-new site needs for day-one SEO basics, from one small
 * class: `identity()` and `pages()` are the only two methods a site
 * actually writes. `sitemapUrls()`, `robotsDisallow()` and `isLive()` below
 * cover the common case and are overridden only when a site's needs differ
 * (extra sitemaps, a wider disallow list, a non-host-based staging check).
 *
 * The full "new site" recipe:
 *
 *     // app/Support/Seo/MyPublicSite.php
 *     final class MyPublicSite extends PublicSiteAdapter
 *     {
 *         public function identity(): SiteIdentity
 *         {
 *             return new SiteIdentity(
 *                 name: 'My Company',
 *                 url: 'https://example.com',
 *                 description: 'What we do, in one sentence.',
 *                 logo: 'https://example.com/icon-512.png',
 *                 sameAs: ['https://www.facebook.com/mycompany'],
 *                 type: 'HomeAndConstructionBusiness',
 *             );
 *         }
 *
 *         public function pages(): iterable
 *         {
 *             yield new PublicPage(url: 'https://example.com/');
 *             yield new PublicPage(url: 'https://example.com/contact');
 *         }
 *     }
 *
 *     // a service provider's register():
 *     $this->app->singleton(PublicSite::class, fn () => new MyPublicSite(app()->environment('production')));
 *
 *     // routes/web.php:
 *     Route::get('sitemap.xml', SitemapController::class);
 *     Route::get('robots.txt', RobotsController::class);
 *     Route::get('llms.txt', LlmsTxtController::class);
 *
 *     // every layout's <head>:
 *     {!! IconLinks::html() !!}
 *
 *     // the HOME layout's <head> ONLY — Google reads the WebSite node once:
 *     {!! IdentitySchema::script($identity) !!}
 *     // every OTHER page still carries the organization/LocalBusiness node on its own:
 *     {!! IdentitySchema::scriptFor([IdentitySchema::organizationNode($identity)]) !!}
 *
 *     // once, committed to the repo — never re-run by a deploy:
 *     php artisan seo:icons public/logo.svg
 *
 * A literal "@context" must never appear inside a Blade template — Blade
 * compiles `@context` as a directive and mangles the template. This is
 * exactly why `IdentitySchema::script()`/`scriptFor()` hand back a
 * finished string a site only ever echoes with `{!! !!}`, never a Blade
 * `@json`/array a template would need to spell `@context` itself.
 *
 * A static `public/robots.txt` or `public/sitemap.xml` file — the default
 * Laravel skeleton ships neither, but a copied-over old site might —
 * SHADOWS the routes above (a file under `public/` always wins over a
 * route at the same path) and must not exist once this adapter is wired up.
 */
abstract class PublicSiteAdapter implements PublicSite
{
    public function __construct(protected readonly bool $production = true) {}

    /** @return list<string> */
    public function sitemapUrls(): array
    {
        return [$this->identity()->home().'sitemap.xml'];
    }

    /**
     * @return array<string, string>
     */
    public function notes(): array
    {
        return [];
    }

    /** @return list<string> */
    public function robotsDisallow(): array
    {
        return ['/admin', '/admin/', '/api/'];
    }

    /** Live only in production, and only for the identity's own host — a leading "www." is ignored on both sides. */
    public function isLive(Request $request): bool
    {
        if (! $this->production) {
            return false;
        }

        $expected = $this->normalizeHost((string) parse_url($this->identity()->url, PHP_URL_HOST));
        $actual = $this->normalizeHost($request->getHost());

        return $expected !== '' && $expected === $actual;
    }

    private function normalizeHost(string $host): string
    {
        $host = strtolower($host);

        return str_starts_with($host, 'www.') ? substr($host, 4) : $host;
    }
}
