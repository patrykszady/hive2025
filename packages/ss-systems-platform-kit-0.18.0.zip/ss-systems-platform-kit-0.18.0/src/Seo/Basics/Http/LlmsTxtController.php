<?php

namespace SsSystems\Platform\Seo\Basics\Http;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use SsSystems\Platform\Seo\Basics\Contracts\PublicSite;
use SsSystems\Platform\Seo\Basics\LlmsTxtRenderer;

/**
 * `GET /llms.txt` — see `PublicSiteAdapter`'s docblock for how a site
 * wires this up.
 */
final class LlmsTxtController
{
    public function __construct(
        private readonly PublicSite $site,
        private readonly LlmsTxtRenderer $renderer = new LlmsTxtRenderer,
    ) {}

    public function __invoke(Request $request): Response
    {
        return new Response($this->renderer->render($this->site), 200, [
            'Content-Type' => 'text/plain; charset=UTF-8',
            'Cache-Control' => 'public, max-age=3600',
        ]);
    }
}
