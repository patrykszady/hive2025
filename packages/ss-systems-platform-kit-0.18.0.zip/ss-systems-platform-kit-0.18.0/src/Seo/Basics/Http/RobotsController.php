<?php

namespace SsSystems\Platform\Seo\Basics\Http;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use SsSystems\Platform\Seo\Basics\Contracts\PublicSite;
use SsSystems\Platform\Seo\Basics\RobotsRenderer;

/**
 * `GET /robots.txt` — see `PublicSiteAdapter`'s docblock for how a site
 * wires this up. `$site->isLive($request)` is what keeps a staging host
 * or a dev tunnel from ever advertising a sitemap.
 */
final class RobotsController
{
    public function __construct(
        private readonly PublicSite $site,
        private readonly RobotsRenderer $renderer = new RobotsRenderer,
    ) {}

    public function __invoke(Request $request): Response
    {
        return new Response($this->renderer->render($this->site, $this->site->isLive($request)), 200, [
            'Content-Type' => 'text/plain; charset=UTF-8',
            'Cache-Control' => 'public, max-age=3600',
        ]);
    }
}
