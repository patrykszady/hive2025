<?php

namespace SsSystems\Platform\Seo\Basics\Http;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use SsSystems\Platform\Seo\Basics\Contracts\PublicSite;
use SsSystems\Platform\Seo\Basics\SitemapRenderer;

/**
 * `GET /sitemap.xml` — see `PublicSiteAdapter`'s docblock for how a site
 * wires this up (`Route::get('sitemap.xml', SitemapController::class)`,
 * `PublicSite` bound once in a provider).
 */
final class SitemapController
{
    public function __construct(
        private readonly PublicSite $site,
        private readonly SitemapRenderer $renderer = new SitemapRenderer,
    ) {}

    public function __invoke(Request $request): Response
    {
        return new Response($this->renderer->render($this->site->pages()), 200, [
            'Content-Type' => 'application/xml; charset=UTF-8',
            'Cache-Control' => 'public, max-age=3600',
        ]);
    }
}
