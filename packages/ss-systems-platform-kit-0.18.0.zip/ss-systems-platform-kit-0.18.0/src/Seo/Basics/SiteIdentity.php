<?php

namespace SsSystems\Platform\Seo\Basics;

/**
 * Who this site is, for `IdentitySchema`'s WebSite/organization JSON-LD and
 * for `PublicSiteAdapter`'s own `sitemapUrls()`/`isLive()` defaults. One
 * object, built once, shared by the sitemap/robots/llms.txt plumbing and
 * every layout's head.
 *
 * Deliberately NOT the same contract as `Reports\Contracts\SiteIdentity` —
 * that one is the NAP-parity-check's own narrow phone/address/GBP-catalog
 * shape for a single report; this one is the full organization identity a
 * brand-new site's JSON-LD needs, and the two are free to disagree (a site
 * can have a landing-page NAP phone that differs from its public switchboard
 * number, say) without either file knowing the other exists.
 */
final class SiteIdentity
{
    /**
     * @param  string  $name  The public-facing name ("GS Construction").
     * @param  string  $url  The home URL, with or without a trailing slash — see `home()`.
     * @param  string  $description  One sentence: what this site/business is.
     * @param  ?string  $logo  Absolute URL of a square image at least 112px per side (Google's own minimum for an Organization logo). Null when the site has none to declare yet.
     * @param  list<string>  $sameAs  Social/profile URLs (Facebook, Instagram, Yelp, ...). Empty when none are configured.
     * @param  string  $type  The schema.org type for the organization node: "Organization", "HomeAndConstructionBusiness", "ProfessionalService", "RealEstateAgent", etc.
     * @param  list<string>  $alternateNames  Other names this business is known by (a DBA, a shortened form). Empty when there are none.
     * @param  ?string  $legalName  The registered/legal name, when it differs from `$name`. Null when there is none to show.
     * @param  ?string  $telephone  Null when not published.
     * @param  ?string  $email  Null when not published.
     * @param  array<string, mixed>  $extra  Merged into the organization node LAST (see `IdentitySchema::organizationNode()`), so a key here can add to — or deliberately override — anything the fields above already set.
     */
    public function __construct(
        public readonly string $name,
        public readonly string $url,
        public readonly string $description,
        public readonly ?string $logo = null,
        public readonly array $sameAs = [],
        public readonly string $type = 'Organization',
        public readonly array $alternateNames = [],
        public readonly ?string $legalName = null,
        public readonly ?string $telephone = null,
        public readonly ?string $email = null,
        public readonly array $extra = [],
    ) {}

    /** `$url` with exactly one trailing slash, however it was given. */
    public function home(): string
    {
        return rtrim($this->url, '/').'/';
    }
}
