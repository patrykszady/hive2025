<?php

namespace SsSystems\Platform\Seo\Basics;

/**
 * The two JSON-LD nodes every new site needs: a `WebSite` node (Google
 * reads this once, for sitelinks search box eligibility and the site's
 * canonical name) and the organization/local-business node (the NAP facts
 * AI Overviews and knowledge-panel lookups actually cite, expected on
 * every page, not just the home page).
 *
 * `websiteNode()` and `organizationNode()` exist as their own methods —
 * not just inlined into `graph()` — because the two nodes are placed
 * differently in a real layout: `script()` (the whole graph) belongs on
 * the HOME page only, while `scriptFor([organizationNode($identity)])`
 * belongs on every OTHER page, where only the organization node repeats.
 * See `PublicSiteAdapter`'s own docblock for exactly where each call goes.
 *
 * Every method here is static and side-effect-free: a site calls
 * `IdentitySchema::script($identity)` directly, no instance to build.
 *
 * Never write a literal "@context" inside a Blade template — Blade
 * compiles `@context` as a directive and mangles the output. `script()`/
 * `scriptFor()` hand back the finished `<script>` tag as a plain string
 * precisely so a site only ever echoes it with `{!! !!}`, never spells
 * the JSON-LD keys itself in a template.
 */
final class IdentitySchema
{
    /**
     * @return array{'@context': string, '@type': string, '@id': string, name: string, url: string, alternateName?: string|list<string>, publisher: array{'@id': string}}
     */
    public static function websiteNode(SiteIdentity $identity): array
    {
        $home = $identity->home();

        $node = [
            '@context' => 'https://schema.org',
            '@type' => 'WebSite',
            '@id' => $home.'#website',
            'name' => $identity->name,
            'url' => $home,
        ];

        if ($identity->alternateNames !== []) {
            $node['alternateName'] = count($identity->alternateNames) === 1
                ? $identity->alternateNames[0]
                : $identity->alternateNames;
        }

        $node['publisher'] = ['@id' => $home.'#organization'];

        return $node;
    }

    /**
     * @return array<string, mixed>
     */
    public static function organizationNode(SiteIdentity $identity): array
    {
        $home = $identity->home();

        $node = array_filter([
            '@context' => 'https://schema.org',
            '@type' => $identity->type,
            '@id' => $home.'#organization',
            'name' => $identity->name,
            'url' => $home,
            'logo' => $identity->logo,
            'sameAs' => $identity->sameAs !== [] ? $identity->sameAs : null,
            'legalName' => $identity->legalName,
            'telephone' => $identity->telephone,
            'email' => $identity->email,
        ], static fn (mixed $value): bool => $value !== null);

        return array_merge($node, $identity->extra);
    }

    /**
     * The WebSite node, then the organization node — `script()`'s own
     * payload. @return list<array<string, mixed>>
     */
    public static function graph(SiteIdentity $identity): array
    {
        return [self::websiteNode($identity), self::organizationNode($identity)];
    }

    /** The full graph (both nodes), wrapped as a `<script>` tag — the home page's copy. */
    public static function script(SiteIdentity $identity): string
    {
        return self::scriptFor(self::graph($identity));
    }

    /**
     * Any subset of the graph (typically just `[organizationNode($identity)]`
     * for a non-home page), wrapped as a `<script>` tag. A single-node list
     * is encoded as a bare JSON object, not a one-element array — most
     * consumers expect `@type` at the top level when there is only one node.
     *
     * @param  list<array<string, mixed>>  $nodes
     */
    public static function scriptFor(array $nodes): string
    {
        $payload = count($nodes) === 1 ? $nodes[0] : $nodes;

        return '<script type="application/ld+json">'.json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE).'</script>';
    }
}
