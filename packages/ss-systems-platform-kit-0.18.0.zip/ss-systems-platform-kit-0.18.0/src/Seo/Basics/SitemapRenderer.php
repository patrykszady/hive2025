<?php

namespace SsSystems\Platform\Seo\Basics;

use XMLWriter;

/**
 * `sitemap.xml`'s body, rendered off whatever `Contracts\PublicSite::pages()`
 * yields. Built on `XMLWriter` rather than string concatenation so a `&` in
 * a URL (a query string, a tracking param) can never produce invalid XML —
 * every value below goes through `XMLWriter::writeElement()`/
 * `writeAttribute()`, which escape on the way out.
 */
final class SitemapRenderer
{
    /**
     * @param  iterable<PublicPage>  $pages
     */
    public function render(iterable $pages): string
    {
        $writer = new XMLWriter;
        $writer->openMemory();
        $writer->setIndent(true);
        $writer->startDocument('1.0', 'UTF-8');
        $writer->startElement('urlset');
        $writer->writeAttribute('xmlns', 'http://www.sitemaps.org/schemas/sitemap/0.9');
        $writer->writeAttribute('xmlns:xhtml', 'http://www.w3.org/1999/xhtml');

        foreach ($pages as $page) {
            $this->writeUrl($writer, $page);
        }

        $writer->endElement();
        $writer->endDocument();

        return $writer->outputMemory();
    }

    private function writeUrl(XMLWriter $writer, PublicPage $page): void
    {
        $writer->startElement('url');
        $writer->writeElement('loc', $page->url);

        if ($page->lastmod !== null) {
            $writer->writeElement('lastmod', $page->lastmod->format(DATE_W3C));
        }

        if ($page->changefreq !== null) {
            $writer->writeElement('changefreq', $page->changefreq);
        }

        if ($page->priority !== null) {
            $writer->writeElement('priority', (string) $page->priority);
        }

        foreach ($page->alternates as $locale => $href) {
            $this->writeAlternate($writer, (string) $locale, $href);
        }

        // The page carries no field for "this is itself the Spanish version",
        // so whenever it declares alternates at all, its own locale is - by
        // definition, for this value object - never known; x-default always
        // points back at the page itself.
        if ($page->alternates !== []) {
            $this->writeAlternate($writer, 'x-default', $page->url);
        }

        $writer->endElement();
    }

    private function writeAlternate(XMLWriter $writer, string $hreflang, string $href): void
    {
        $writer->startElement('xhtml:link');
        $writer->writeAttribute('rel', 'alternate');
        $writer->writeAttribute('hreflang', $hreflang);
        $writer->writeAttribute('href', $href);
        $writer->endElement();
    }
}
