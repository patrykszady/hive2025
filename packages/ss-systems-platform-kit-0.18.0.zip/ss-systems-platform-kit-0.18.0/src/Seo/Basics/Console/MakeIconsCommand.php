<?php

namespace SsSystems\Platform\Seo\Basics\Console;

use Illuminate\Console\Command;
use Symfony\Component\Process\ExecutableFinder;
use Symfony\Component\Process\Process;

/**
 * `php artisan seo:icons public/logo.svg` — the one-time step a new site
 * runs to produce every file `IconLinks::html()` links to, plus the two
 * square PNGs app manifests and search engines expect at fixed names
 * (`icon-192.png`, `icon-512.png`). See `PublicSiteAdapter`'s own docblock
 * for where this fits in the full "new site" recipe — it runs once,
 * committed to the repo, never re-run by a deploy.
 *
 * Shells out to ImageMagick's `convert` (via symfony/process, already a
 * kit dependency) rather than intervention/image: `convert`'s `-density`
 * and `-define icon:auto-resize=...` flags are what produce a crisp
 * multi-resolution `favicon.ico` and a correctly rasterized high-DPI PNG
 * from a vector source, neither of which intervention/image's API exposes.
 *
 * A site registers this the same way it registers any other kit console
 * command (see `Reports\Console\KitReportCommand`'s per-site subclasses):
 * a thin `App\Console\Commands\SeoIcons extends MakeIconsCommand {}` under
 * `app/Console/Commands/`, auto-discovered by Laravel — or it is simply run
 * once via `vendor/bin/... seo:icons` if never registered at all, since it
 * takes no site-specific hook.
 */
class MakeIconsCommand extends Command
{
    /** @var string */
    protected $signature = 'seo:icons
        {source : an SVG, or a PNG at least 512px square}
        {--out=public : where favicon.ico, favicon.svg, apple-touch-icon.png, icon-192.png and icon-512.png are written}';

    /** @var string */
    protected $description = 'Generate favicon.ico, favicon.svg, apple-touch-icon.png, icon-192.png and icon-512.png from one source image';

    public function handle(): int
    {
        $source = (string) $this->argument('source');

        if (! is_file($source)) {
            $this->error("The source file \"{$source}\" does not exist.");

            return self::FAILURE;
        }

        $binary = (new ExecutableFinder)->find('convert');

        if ($binary === null) {
            $this->error('ImageMagick\'s "convert" command is not installed or not on the PATH.');

            return self::FAILURE;
        }

        $out = rtrim((string) $this->option('out'), '/');

        if (! is_dir($out) && ! mkdir($out, 0755, true) && ! is_dir($out)) {
            $this->error("Could not create the output directory \"{$out}\".");

            return self::FAILURE;
        }

        $isSvg = strtolower(pathinfo($source, PATHINFO_EXTENSION)) === 'svg';
        $sourceArgs = $isSvg ? ['-background', 'none', '-density', '1152', $source] : [$source];

        if (! $this->convert($binary, $sourceArgs, ['-resize', '512x512'], $out.'/icon-512.png', reportSize: true)) {
            return self::FAILURE;
        }

        if (! $this->convert($binary, $sourceArgs, ['-resize', '192x192'], $out.'/icon-192.png', reportSize: true)) {
            return self::FAILURE;
        }

        if (! $this->convert($binary, $sourceArgs, ['-resize', '180x180'], $out.'/apple-touch-icon.png', reportSize: true)) {
            return self::FAILURE;
        }

        if (! $this->convert($binary, $sourceArgs, ['-define', 'icon:auto-resize=48,32,16'], $out.'/favicon.ico', reportSize: false)) {
            return self::FAILURE;
        }

        $this->line('Wrote '.$out.'/favicon.ico (48x48, 32x32, 16x16)');

        if ($isSvg) {
            copy($source, $out.'/favicon.svg');
            $this->line('Wrote '.$out.'/favicon.svg (vector)');
        }

        return self::SUCCESS;
    }

    /**
     * @param  list<string>  $sourceArgs
     * @param  list<string>  $operationArgs
     */
    private function convert(string $binary, array $sourceArgs, array $operationArgs, string $destination, bool $reportSize): bool
    {
        $process = new Process([$binary, ...$sourceArgs, ...$operationArgs, $destination]);
        $process->run();

        if (! $process->isSuccessful()) {
            $this->error('convert failed for '.$destination.': '.trim($process->getErrorOutput()));

            return false;
        }

        if ($reportSize) {
            $size = @getimagesize($destination);
            $this->line('Wrote '.$destination.' ('.($size !== false ? $size[0].'x'.$size[1] : 'unknown size').')');
        }

        return true;
    }
}
