<?php

namespace SsSystems\Platform\Seo\Basics\Contracts;

use Illuminate\Http\Request;
use SsSystems\Platform\Seo\Basics\PublicPage;
use SsSystems\Platform\Seo\Basics\SiteIdentity;

/**
 * Everything `SitemapController`/`RobotsController`/`LlmsTxtController`
 * need from a site. A brand-new site never implements this directly — it
 * extends `PublicSiteAdapter`, which supplies `sitemapUrls()`,
 * `robotsDisallow()` and `isLive()` and leaves only `identity()` and
 * `pages()` for the site to write. See `PublicSiteAdapter`'s own docblock
 * for the full "new site" recipe.
 */
interface PublicSite
{
    public function identity(): SiteIdentity;

    /** @return iterable<PublicPage> every public URL — the sitemap.xml/llms.txt content walk. */
    public function pages(): iterable;

    /** @return list<string> absolute sitemap URLs listed in robots.txt's `Sitemap:` lines. */
    public function sitemapUrls(): array;

    /** @return list<string> paths listed in robots.txt's `Disallow:` lines when the site is live. */
    public function robotsDisallow(): array;

    /** True when `$request` is hitting this site's real production host — see `RobotsRenderer`: false sends back a blanket `Disallow: /` and no sitemap. */
    public function isLive(Request $request): bool;

    /**
     * Short prose sections for llms.txt after the page lists — heading =>
     * text (a paragraph or a few lines), e.g. 'Where we work' => 'The
     * Chicago suburbs…', 'Privacy' => '…'. Nothing a page URL can carry.
     *
     * @return array<string, string>
     */
    public function notes(): array;
}
