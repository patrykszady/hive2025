<?php

namespace SsSystems\Platform\Seo\Basics;

/**
 * The three `<link>` tags every layout's `<head>` needs for Google to
 * accept this site's favicon: Google requires the icon be fetchable by its
 * own URL (an inline `data:` icon does not count) and be either an SVG or a
 * raster image that is a multiple of 48px square. `php artisan seo:icons`
 * (see `Console\MakeIconsCommand`) produces all three files this links to.
 */
final class IconLinks
{
    public static function html(string $prefix = ''): string
    {
        return implode("\n", [
            '<link rel="icon" href="'.$prefix.'/favicon.ico" sizes="48x48">',
            '<link rel="icon" href="'.$prefix.'/favicon.svg" type="image/svg+xml">',
            '<link rel="apple-touch-icon" href="'.$prefix.'/apple-touch-icon.png">',
        ]);
    }
}
