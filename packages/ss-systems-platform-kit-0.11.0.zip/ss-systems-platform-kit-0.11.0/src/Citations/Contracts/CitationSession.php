<?php

namespace SsSystems\Platform\Citations\Contracts;

use App\Models\Citation;

/**
 * One remote-browser session for the citation builder, or the honest
 * absence of one. Every site binds this to whichever implementation fits
 * its host: `RemoteBrowserSession` (gsc, jpeterson — the real Xvfb/
 * Chromium/x11vnc/noVNC pipeline) or `UnavailableSession` (hive; dawn
 * until its pipeline is real) — a null object with the exact same eight
 * methods, so `Citations\CitationsController` (and everything else that
 * asks for `CitationSession`) never has to special-case a site that has
 * no browser automation.
 *
 * Deliberately typed on the SITE's own `App\Models\Citation` rather than
 * a kit-owned model or a new marker interface: this package runs INSIDE
 * each site's app as a vendor dependency, so `App\Models\Citation` always
 * resolves to that site's real Eloquent model at runtime (with whatever
 * tenant scoping it carries — see `App\Models\Concerns\BelongsToSite` on
 * gsc). No adapter is needed beyond binding this interface in the site's
 * own `AppServiceProvider`.
 */
interface CitationSession
{
    /** @return array{ok: bool, missing: list<string>} */
    public function checkRequirements(bool $headless = false): array;

    public function dirFor(Citation $citation): string;

    /** Start a session for one directory. Returns ['ok', 'url' (noVNC), 'expires_at', 'slug']. */
    public function start(Citation $citation, bool $headless = false, bool $auto = false): array;

    /** Session status plus the runner's own state for the active directory. */
    public function status(): array;

    /** Let the runner continue after a human step. */
    public function resume(Citation $citation): bool;

    public function stop(): array;

    /** Fold the runner's state into the citation row. */
    public function syncCitation(Citation $citation): Citation;

    public function tailLog(int $bytes = 4000): string;
}
