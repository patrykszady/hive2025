<?php

namespace SsSystems\Platform\Http\Admin\Concerns;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;
use SsSystems\Platform\Http\Admin\Contracts\AnalyticsEventReader;

/**
 * `events()`/`summary()` for `/api/admin/v1/analytics/*` — every kit site's
 * `Livewire\Admin\SiteAnalytics` screen reads exactly this shape (a `days`
 * + `type_filter` scope, a paginated `events()` table and a `summary()`
 * aggregate carrying the four-tile stats/prior-stats, a top-8-pages
 * breakdown and a per-day trend series) regardless of what
 * `AnalyticsEventReader` a site binds — see that contract's own docblock
 * for the two real implementations.
 *
 * Ported from gs.construction/jpeterson-design.com's identical
 * `AnalyticsController` (`TrackedEvent`-backed) and
 * hive.contractors/ss.systems' identical one (Pulse-backed): the whole
 * rest of the class — windowing, the four-tile breakdown, the trend
 * series, top pages, pagination, response shape — was already
 * byte-identical bar the row source. This trait ALSO now cache-buckets
 * `summary()` for every adopter, 5 minutes per {days, type, 5-minute clock
 * bucket} — hive/ss.systems already did this (a full-row scan over
 * `site_events` on every call); gsc/jpeterson previously answered
 * `summary()` from a cheap SQL aggregate with no cache at all, so moving
 * them onto this shared, `rowsSince()`-based implementation makes their
 * `summary()` responses up to 5 minutes stale where they used to be live —
 * a deliberate, minor behaviour change (flagged to the owner), not an
 * oversight: the alternative was two summary() bodies again.
 *
 * Assumes the host controller ALSO `use`s `BuildsApiResponses`
 * (`perPage()`/`paginatedResponse()`) — every existing `AnalyticsController`
 * already does.
 *
 * Two hooks a using controller MUST implement:
 *
 * ```php
 * protected function analyticsEventReader(): AnalyticsEventReader
 * {
 *     return new TrackedEventReader(\App\Models\TrackedEvent::class);
 * }
 *
 * // Every site's own effective zone — gsc/jpeterson/hive/ss.systems all
 * // currently read 'America/Chicago', but the kit itself must never
 * // hardcode that; a site with no analytics-specific config value simply
 * // defaults to the same string it already used.
 * protected function analyticsTimezone(): string
 * {
 *     return config('services.analytics.timezone', 'America/Chicago');
 * }
 * ```
 */
trait BuildsAnalyticsScreen
{
    /** The row source — see AnalyticsEventReader's own docblock for the two real implementations. */
    abstract protected function analyticsEventReader(): AnalyticsEventReader;

    /**
     * The IANA zone the screen's day boundaries, the trend chart's daily
     * buckets and the summary cache's 5-minute clock bucket are all read
     * in — this site's own effective timezone, never a kit constant.
     */
    abstract protected function analyticsTimezone(): string;

    /** @return array<int,int> the windows the range picker offers — identical on every adopting site today. */
    protected function analyticsSpans(): array
    {
        return [7, 14, 28, 60, 90, 180, 360];
    }

    protected function analyticsDefaultSpan(): int
    {
        return 28;
    }

    public function events(Request $request): JsonResponse
    {
        $days = $this->analyticsDays($request);
        $start = $this->analyticsWindowStart($days);
        $type = $this->analyticsTypeFilter($request);

        $rows = $this->analyticsEventReader()->rowsSince($start)
            ->when($type !== null, fn (Collection $rows) => $rows->where('type', $type))
            ->values();

        $perPage = $this->perPage($request);
        $page = max(1, (int) $request->integer('page', 1));

        $paginator = new LengthAwarePaginator(
            items: $rows->forPage($page, $perPage)->values(),
            total: $rows->count(),
            perPage: $perPage,
            currentPage: $page,
            options: ['path' => $request->url(), 'query' => $request->query()],
        );

        return $this->paginatedResponse($paginator, fn (array $row) => $this->analyticsToApiArray($row));
    }

    public function summary(Request $request): JsonResponse
    {
        $days = $this->analyticsDays($request);
        $type = $this->analyticsTypeFilter($request);

        $bucket = intdiv(Carbon::now()->getTimestamp(), 300);
        $cacheKey = "analytics-summary:{$days}:{$type}:{$bucket}";

        $data = Cache::remember($cacheKey, 300, function () use ($days, $type) {
            $start = $this->analyticsWindowStart($days);
            $priorStart = $start->copy()->subDays($days);

            $rows = $this->analyticsEventReader()->rowsSince($priorStart);
            $current = $rows->filter(fn (array $row) => $row['created_at']->gte($start))->values();
            $prior = $rows->filter(fn (array $row) => $row['created_at']->lt($start))->values();

            // The tiles are the per-type breakdown of the window, so they
            // never narrow by type — the selected type is highlighted on
            // the screen instead of the other three collapsing to zero.
            $stats = $this->analyticsCountsByType($current);
            $statsPrev = $this->analyticsCountsByType($prior);

            $topPages = $current
                ->when($type !== null, fn (Collection $rows) => $rows->where('type', $type))
                ->filter(fn (array $row) => $row['page_path'] !== null)
                ->groupBy('page_path')
                ->map(fn (Collection $rows) => $rows->count())
                ->sortDesc()
                ->take(8);

            return [
                'days' => $days,
                'stats' => $stats,
                'stats_prev' => $statsPrev,
                'top_pages' => $topPages,
                'trend' => $this->analyticsTrendChartData($days, $current),
            ];
        });

        return new JsonResponse(['data' => $data]);
    }

    protected function analyticsDays(Request $request): int
    {
        $days = (int) $request->integer('days', $this->analyticsDefaultSpan());

        return in_array($days, $this->analyticsSpans(), true) ? $days : $this->analyticsDefaultSpan();
    }

    /**
     * "Last N days" is today plus the N-1 days before it, on this site's
     * own calendar, converted to UTC so it compares correctly against
     * UTC-stored created_at values.
     */
    protected function analyticsWindowStart(int $days): Carbon
    {
        return Carbon::now($this->analyticsTimezone())->subDays($days - 1)->startOfDay()->utc();
    }

    protected function analyticsTypeFilter(Request $request): ?string
    {
        $type = $request->string('type_filter')->toString();

        return ($type !== '' && $type !== 'all') ? $type : null;
    }

    /**
     * @param  Collection<int,array<string,mixed>>  $rows
     * @return array<string,int>
     */
    protected function analyticsCountsByType(Collection $rows): array
    {
        $counts = [
            'phone' => $rows->where('type', 'phone_click')->count(),
            'email' => $rows->where('type', 'email_click')->count(),
            'form' => $rows->where('type', 'form_submit')->count(),
            'cta' => $rows->where('type', 'cta_click')->count(),
        ];
        $counts['total'] = array_sum($counts);

        return $counts;
    }

    /**
     * Daily per-type event counts for the window, every type in every row:
     * the screen draws only the selected type's line, so one series serves
     * every type filter. Grouped by this site's own calendar day in PHP so
     * DST transitions stay correct and the same code runs against SQLite
     * in tests.
     *
     * @param  Collection<int,array<string,mixed>>  $rows  rows already scoped to the window
     * @return array<int,array<string,mixed>>
     */
    protected function analyticsTrendChartData(int $days, Collection $rows): array
    {
        $tz = $this->analyticsTimezone();
        $byDay = $rows->groupBy(fn (array $row) => $row['created_at']->copy()->timezone($tz)->toDateString());

        return collect(range($days - 1, 0))->map(function ($ago) use ($byDay, $tz) {
            $date = Carbon::now($tz)->subDays($ago)->toDateString();
            $dayRows = $byDay->get($date, collect());
            $types = $dayRows->countBy('type');

            return [
                'date' => Carbon::parse($date)->format('M j'),
                'day' => $date,
                'phone' => (int) ($types['phone_click'] ?? 0),
                'email' => (int) ($types['email_click'] ?? 0),
                'form' => (int) ($types['form_submit'] ?? 0),
                'cta' => (int) ($types['cta_click'] ?? 0),
                'total' => $dayRows->count(),
            ];
        })->values()->all();
    }

    /** @param  array<string,mixed>  $row */
    protected function analyticsToApiArray(array $row): array
    {
        return [
            'id' => $row['id'],
            'type' => $row['type'],
            'type_label' => static::analyticsTypeLabel($row['type']),
            'label' => $row['label'],
            'page_path' => $row['page_path'],
            'referrer' => $row['referrer'],
            'utm_source' => $row['utm_source'],
            'utm_medium' => $row['utm_medium'],
            'utm_campaign' => $row['utm_campaign'],
            'country' => $row['country'],
            'created_at' => $row['created_at']->toIso8601String(),
        ];
    }

    public static function analyticsTypeLabel(string $type): string
    {
        return match ($type) {
            'phone_click' => 'Phone click',
            'email_click' => 'Email click',
            'form_submit' => 'Form submission',
            'cta_click' => 'CTA click',
            default => ucfirst(str_replace('_', ' ', $type)),
        };
    }
}
