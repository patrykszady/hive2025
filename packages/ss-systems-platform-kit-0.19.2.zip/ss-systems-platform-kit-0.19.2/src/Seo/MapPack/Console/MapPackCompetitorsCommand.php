<?php

namespace SsSystems\Platform\Seo\MapPack\Console;

use Illuminate\Console\Command;
use SsSystems\Platform\Seo\MapPack\MapPackStore;

/**
 * `seo:map-pack-competitors` — the map pack's top competitors, aggregated
 * across every keyword and scan `seo:map-pack-grid` has recorded (see
 * `MapPackStore::topCompetitors()`): who shows up most across the whole
 * campaign, by total 3-pack appearances.
 *
 * CHANGED FROM GSC: gs.construction's `SeoMapPackCompetitors` command reads
 * each competitor's own homepage (`CompetitorSiteFetcher`, filtered through
 * `CompetitorFilter::isAggregator()`) to learn what it offers and which of
 * gsc's towns it names — a second analysis pass over `AreaServed` and raw
 * HTTP fetches of third-party sites, neither of which has a contract in the
 * kit yet (no `MapPackContext` method or `SeoSiteProfile` method describes
 * "read a URL and summarise it"). This port keeps the command's name and
 * its purpose ("who owns the pack") but limits it to data the store already
 * has; reading competitor homepages is left for a future port once the kit
 * has a site-reading contract to build it on.
 */
class MapPackCompetitorsCommand extends Command
{
    protected $signature = 'seo:map-pack-competitors {--limit=20 : Competitors to list}';

    protected $description = "List the map pack's top competitors, aggregated across every tracked keyword";

    public function handle(MapPackStore $store): int
    {
        if (! $store->hasCompetitorsTable()) {
            $this->comment('map_pack_competitors table is missing — skipping.');

            return self::SUCCESS;
        }

        $competitors = $store->topCompetitors(max(1, (int) $this->option('limit')));

        if ($competitors === []) {
            $this->comment('No pack competitors recorded yet — run seo:map-pack-grid first.');

            return self::SUCCESS;
        }

        foreach ($competitors as $competitor) {
            $this->line(sprintf(
                '  %-32s %3d pts · %3d seen · best #%s · %s reviews',
                $competitor['name'],
                $competitor['pack_points'],
                $competitor['seen_points'],
                $competitor['best_rank'] ?? '—',
                $competitor['reviews'] ?? '—',
            ));
        }

        $this->info(sprintf('%d competitor(s) listed.', count($competitors)));

        return self::SUCCESS;
    }
}
