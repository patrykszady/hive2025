<?php

namespace SsSystems\Platform\Seo\Bing\Console;

use Illuminate\Console\Command;
use SsSystems\Platform\Seo\Bing\BingCoverageSkipped;
use SsSystems\Platform\Seo\Bing\BingCoverageSync;
use SsSystems\Platform\Seo\Bing\Contracts\BingCoverageClient;
use SsSystems\Platform\Seo\Bing\Contracts\BingCoverageUrls;
use SsSystems\Platform\Seo\Bing\Contracts\BingCoverageWriter;

/**
 * `seo:bing-coverage` — what Bing holds of the site, into the site's own
 * tables for the hub's Bing card (ServesBingCoverage). Daily on every site
 * with a Bing key; see BingCoverageSync for the three steps and the limits.
 */
final class BingCoverageCommand extends Command
{
    protected $signature = 'seo:bing-coverage
        {--limit= : Sitemap URLs to ask Bing about this run (default '.BingCoverageSync::DEFAULT_URL_LIMIT.')}
        {--pause= : Milliseconds between those calls (default '.BingCoverageSync::DEFAULT_PAUSE_MS.')}
        {--dry-run : Read from Bing, write nothing, list the URLs the next run would ask about}';

    protected $description = 'Record what Bing holds of the site: pages in its index, pages shown in its results, when it last fetched each sitemap URL';

    public function handle(BingCoverageClient $client, BingCoverageWriter $writer, BingCoverageUrls $urls): int
    {
        $options = [
            'dry_run' => (bool) $this->option('dry-run'),
            'url_limit' => $this->option('limit') !== null ? max(0, (int) $this->option('limit')) : BingCoverageSync::DEFAULT_URL_LIMIT,
            'pause_ms' => $this->option('pause') !== null ? max(0, (int) $this->option('pause')) : BingCoverageSync::DEFAULT_PAUSE_MS,
        ];

        try {
            $summary = BingCoverageSync::run($client, $writer, $urls->urls(), $options);
        } catch (BingCoverageSkipped $e) {
            $this->info($e->getMessage().' Nothing recorded.');

            return self::SUCCESS;
        }

        if ($summary['status'] === 'failed') {
            $this->error('Bing coverage failed for '.$summary['site_url'].': '.$summary['error']);

            return self::FAILURE;
        }

        $latest = $summary['latest'];
        $this->line(sprintf(
            'Bing coverage for %s: %s; sitemap %d URLs, %d shown in Bing results in the last %d days.',
            $summary['site_url'],
            $latest ? sprintf('%s pages in the index, %d crawled on %s, %d crawl errors', number_format($latest['in_index']), $latest['crawled_pages'], $latest['date'], $latest['crawl_errors']) : 'no crawl stats yet',
            $summary['sitemap_urls'],
            $summary['shown_urls'],
            BingCoverageSync::SHOWN_WINDOW_DAYS,
        ));

        if ($summary['page_stats_error'] !== null) {
            $this->warn('Page stats were not read: '.$summary['page_stats_error']);
        }

        if ($summary['status'] === 'dry-run') {
            $this->line('Dry run — nothing written. Next URLs to ask Bing about:');

            foreach ($summary['sample'] as $url) {
                $this->line('  '.$url);
            }

            return self::SUCCESS;
        }

        $this->line(sprintf(
            'Asked Bing about %d URLs: %d fetched by Bing, %d never fetched, %d errors. %d URLs left the sitemap.',
            $summary['inspected'],
            $summary['crawled'],
            $summary['never_crawled'],
            $summary['inspect_errors'],
            $summary['forgotten'],
        ));

        return self::SUCCESS;
    }
}
