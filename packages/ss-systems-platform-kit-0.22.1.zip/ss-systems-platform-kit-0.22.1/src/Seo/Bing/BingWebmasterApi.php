<?php

namespace SsSystems\Platform\Seo\Bing;

use Illuminate\Http\Client\Factory;
use SsSystems\Platform\Seo\Bing\Contracts\BingCoverageClient;

/**
 * Bing Webmaster Tools API — free, a plain API key on the query string.
 *
 *   https://learn.microsoft.com/en-us/bingwebmaster/getting-access
 *   https://learn.microsoft.com/en-us/dotnet/api/microsoft.bing.webmaster.api.interfaces.iwebmasterapi.getrankandtrafficstats
 *
 * Two calls: GetQueryStats (per query per day) and GetRankAndTrafficStats
 * (the real daily totals — GetQueryStats omits the clicks and impressions of
 * queries Bing anonymises, so its per-day sums under-report against the
 * dashboard; the headline numbers and the trend come from the totals).
 *
 * Coverage (2026-11-10, BingCoverageClient): GetCrawlStats (per day: pages
 * crawled, pages in the index, errors), GetUrlInfo (one URL: when Bing found
 * and last fetched it), GetPageStats (per page per day it was shown in
 * results), GetUrlSubmissionQuota and GetUserSites. Field names and shapes
 * as seen live against hive.contractors on 2026-11-10.
 *
 * The HTTP client is Laravel's, handed in so a site passes the one behind
 * its Http facade (and Http::fake() in its tests applies), and so a kit test
 * can fake it with no container at all. Nothing here logs: a failure comes
 * back as null with lastError() set, and the site decides what to do.
 */
final class BingWebmasterApi implements BingWebmasterClient, BingCoverageClient
{
    public const API_BASE = 'https://ssl.bing.com/webmaster/api.svc/json';

    private ?string $lastError = null;

    public function __construct(
        private readonly ?string $apiKey,
        private readonly string $siteUrl,
        private readonly ?Factory $http = null,
        private readonly int $timeoutSeconds = 45,
    ) {}

    public function isConfigured(): bool
    {
        return trim((string) $this->apiKey) !== '' && trim($this->siteUrl) !== '';
    }

    public function siteUrl(): string
    {
        return $this->siteUrl;
    }

    public function queryStats(): ?array
    {
        $rows = $this->get('GetQueryStats');
        if ($rows === null) {
            return null;
        }

        $out = [];
        foreach ($rows as $row) {
            $date = self::parseMsDate($row['Date'] ?? null);
            if ($date === null) {
                continue;
            }
            $out[] = [
                'date' => $date,
                'site_url' => $this->siteUrl,
                'query' => (string) ($row['Query'] ?? ''),
                'impressions' => (int) ($row['Impressions'] ?? 0),
                'clicks' => (int) ($row['Clicks'] ?? 0),
                'position' => (float) ($row['AvgImpressionPosition'] ?? $row['AvgClickPosition'] ?? 0),
            ];
        }

        return $out;
    }

    public function rankAndTrafficStats(): ?array
    {
        $rows = $this->get('GetRankAndTrafficStats');
        if ($rows === null) {
            return null;
        }

        $out = [];
        foreach ($rows as $row) {
            $date = self::parseMsDate($row['Date'] ?? null);
            if ($date === null) {
                continue;
            }
            $out[] = [
                'date' => $date,
                'site_url' => $this->siteUrl,
                'impressions' => (int) ($row['Impressions'] ?? 0),
                'clicks' => (int) ($row['Clicks'] ?? 0),
            ];
        }

        return $out;
    }

    public function lastError(): ?string
    {
        return $this->lastError;
    }

    /**
     * The sitemaps Bing already holds for the site (GetFeeds): URL, status
     * and URL count. Null when the call failed (see lastError()).
     *
     * @return list<array{url: string, status: string, url_count: int}>|null
     */
    public function feeds(): ?array
    {
        $rows = $this->get('GetFeeds');
        if ($rows === null) {
            return null;
        }

        $out = [];
        foreach ($rows as $row) {
            $url = trim((string) ($row['Url'] ?? ''));
            if ($url === '') {
                continue;
            }
            $out[] = ['url' => $url, 'status' => (string) ($row['Status'] ?? ''), 'url_count' => (int) ($row['UrlCount'] ?? 0)];
        }

        return $out;
    }

    /**
     * Submit one sitemap to Bing (SubmitFeed). Bing answers {"d": null} on
     * success; a non-2xx body is kept in lastError(). mozaika.haus had no
     * sitemap in Bing Webmaster at all until this was added (2026-11-02):
     * Google got every site's maps from the hub, Bing got them by hand.
     */
    public function submitFeed(string $feedUrl): bool
    {
        $http = $this->http ?? new Factory();

        try {
            $response = $http->timeout($this->timeoutSeconds)->asJson()->post(
                self::API_BASE.'/SubmitFeed?apikey='.rawurlencode((string) $this->apiKey),
                ['siteUrl' => $this->siteUrl, 'feedUrl' => $feedUrl],
            );
        } catch (\Throwable $e) {
            $this->lastError = 'SubmitFeed: '.$e->getMessage();

            return false;
        }

        if (! $response->successful()) {
            $this->lastError = 'SubmitFeed answered '.$response->status().': '.mb_substr(trim($response->body()), 0, 300);

            return false;
        }

        $this->lastError = null;

        return true;
    }

    /**
     * Bing writes a date as "/Date(1747353600000)/" — milliseconds since the
     * epoch, at midnight UTC. Read it in UTC: through the app's own timezone
     * (Chicago, six hours behind) that midnight is still the evening before,
     * and every row would land on the wrong day.
     */
    public static function parseMsDate(?string $raw): ?string
    {
        if (! $raw || ! preg_match('/Date\((-?\d+)/', $raw, $m)) {
            return null;
        }

        return gmdate('Y-m-d', intdiv((int) $m[1], 1000));
    }

    public function crawlStats(): ?array
    {
        $rows = $this->get('GetCrawlStats');

        if ($rows === null) {
            return null;
        }

        $out = [];

        foreach ($rows as $row) {
            $date = self::parseMsDate($row['Date'] ?? null);

            if ($date === null) {
                continue;
            }

            $out[] = [
                'date' => $date,
                'crawled_pages' => (int) ($row['CrawledPages'] ?? 0),
                'in_index' => (int) ($row['InIndex'] ?? 0),
                'in_links' => (int) ($row['InLinks'] ?? 0),
                'crawl_errors' => (int) ($row['CrawlErrors'] ?? 0),
                'blocked_by_robots' => (int) ($row['BlockedByRobotsTxt'] ?? 0),
                'code_2xx' => (int) ($row['Code2xx'] ?? 0),
                'code_301' => (int) ($row['Code301'] ?? 0),
                'code_302' => (int) ($row['Code302'] ?? 0),
                'code_4xx' => (int) ($row['Code4xx'] ?? 0),
                'code_5xx' => (int) ($row['Code5xx'] ?? 0),
                'other_codes' => (int) ($row['AllOtherCodes'] ?? 0),
                'connection_timeouts' => (int) ($row['ConnectionTimeout'] ?? 0),
                'dns_failures' => (int) ($row['DnsFailures'] ?? 0),
            ];
        }

        return $out;
    }

    public function urlInfo(string $url): ?array
    {
        $row = $this->call('GetUrlInfo', ['siteUrl' => $this->siteUrl, 'url' => $url]);

        if (! is_array($row)) {
            return null;
        }

        $status = isset($row['HttpStatus']) ? (int) $row['HttpStatus'] : null;

        return [
            'url' => (string) ($row['Url'] ?? $url),
            // Bing reports 0 for a fetch it has not finished judging (the
            // home page did, 2026-11-10): that is "no status", not HTTP 0.
            'http_status' => $status > 0 ? $status : null,
            'is_page' => (bool) ($row['IsPage'] ?? false),
            'document_size' => isset($row['DocumentSize']) ? (int) $row['DocumentSize'] : null,
            'anchor_count' => isset($row['AnchorCount']) ? (int) $row['AnchorCount'] : null,
            'child_url_count' => isset($row['TotalChildUrlCount']) ? (int) $row['TotalChildUrlCount'] : null,
            'discovered_on' => self::parseMsDate($row['DiscoveryDate'] ?? null),
            'last_crawled_at' => self::parseMsDateTime($row['LastCrawledDate'] ?? null),
        ];
    }

    public function pageStats(): ?array
    {
        $rows = $this->get('GetPageStats');

        if ($rows === null) {
            return null;
        }

        $out = [];

        foreach ($rows as $row) {
            $date = self::parseMsDate($row['Date'] ?? null);
            // Bing answers with QueryStats rows whose Query is the page URL.
            $url = trim((string) ($row['Query'] ?? $row['Url'] ?? ''));

            if ($date === null || $url === '') {
                continue;
            }

            $out[] = [
                'date' => $date,
                'url' => $url,
                'impressions' => (int) ($row['Impressions'] ?? 0),
                'clicks' => (int) ($row['Clicks'] ?? 0),
                'position' => (float) ($row['AvgImpressionPosition'] ?? 0),
            ];
        }

        return $out;
    }

    public function urlSubmissionQuota(): ?array
    {
        $row = $this->call('GetUrlSubmissionQuota', ['siteUrl' => $this->siteUrl]);

        if (! is_array($row)) {
            return null;
        }

        return ['daily' => (int) ($row['DailyQuota'] ?? 0), 'monthly' => (int) ($row['MonthlyQuota'] ?? 0)];
    }

    public function userSites(): ?array
    {
        $rows = $this->call('GetUserSites');

        if (! is_array($rows)) {
            return null;
        }

        $out = [];

        foreach ($rows as $row) {
            $url = trim((string) ($row['Url'] ?? ''));

            if ($url === '') {
                continue;
            }

            $out[] = ['url' => $url, 'verified' => (bool) ($row['IsVerified'] ?? false)];
        }

        return $out;
    }

    /** "/Date(1794006114000)/" as 'Y-m-d H:i:s' in UTC; null for a missing date or Bing's epoch-zero "never". */
    public static function parseMsDateTime(?string $raw): ?string
    {
        if (! $raw || ! preg_match('/Date\((-?\d+)/', $raw, $m) || (int) $m[1] <= 0) {
            return null;
        }

        return gmdate('Y-m-d H:i:s', intdiv((int) $m[1], 1000));
    }

    /** A list-shaped call: the rows of `d`, [] for an empty answer, null on failure. @return array<int, array<string, mixed>>|null */
    private function get(string $method): ?array
    {
        $data = $this->call($method, ['siteUrl' => $this->siteUrl]);

        if ($data === false) {
            return null;
        }

        return is_array($data) ? array_values($data) : [];
    }

    /**
     * One GET to Bing: `d` as Bing sent it (a list, an object, or null),
     * false on failure with lastError() set.
     *
     * @param  array<string, string>  $query
     */
    private function call(string $method, array $query = []): mixed
    {
        $http = $this->http ?? new Factory();

        try {
            $response = $http->timeout($this->timeoutSeconds)->get(self::API_BASE.'/'.$method, $query + ['apikey' => (string) $this->apiKey]);
        } catch (\Throwable $e) {
            $this->lastError = $method.': '.$e->getMessage();

            return false;
        }

        if (! $response->successful()) {
            $this->lastError = $method.' answered '.$response->status().': '.mb_substr(trim($response->body()), 0, 300);

            return false;
        }

        $this->lastError = null;

        return $response->json('d');
    }
}
