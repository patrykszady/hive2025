<?php

namespace SsSystems\Platform\Pulse\Storage;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Carbon;
use SsSystems\Platform\Pulse\Contracts\PulseStorage;

/**
 * The default PulseStorage: a plain `site_events` table over one Illuminate
 * connection. Single-tenant sites (dawnsellshomes, jpeterson-design) bind
 * this with no tenant column at all. gs.construction — where every table is
 * scoped to the current Site — passes $tenantColumn ('site_id') and
 * $tenantId (a closure reading `Tenancy::currentId()` / `Site::current()->id`
 * at call time, never captured once at construction, since the bound
 * singleton outlives any one request's tenant in a queue worker): insert()
 * stamps every row with it, since() scopes every read by it. A site with
 * its own tenant-scoping convention (e.g. an Eloquent model carrying a
 * BelongsToSite-style global scope) can implement PulseStorage directly
 * instead of using this class at all.
 */
final class DatabaseTableStorage implements PulseStorage
{
    /** @var list<string> */
    private const COLUMNS = ['id', 'event', 'path', 'meta', 'vhash', 'city', 'mobile', 'created_at'];

    public function __construct(
        private readonly ConnectionInterface $connection,
        private readonly string $table = 'site_events',
        private readonly ?string $tenantColumn = null,
        private readonly ?\Closure $tenantId = null,
    ) {
    }

    public function insert(array $row): void
    {
        if ($this->tenantColumn !== null) {
            $row[$this->tenantColumn] = ($this->tenantId)();
        }

        $this->connection->table($this->table)->insert($row);
    }

    public function since(\DateTimeInterface $since, array $events = []): array
    {
        $query = $this->connection->table($this->table)
            ->where('created_at', '>=', Carbon::parse($since)->toDateTimeString());

        if ($events !== []) {
            $query->whereIn('event', $events);
        }
        if ($this->tenantColumn !== null) {
            $query->where($this->tenantColumn, ($this->tenantId)());
        }

        return $query->orderBy('id')->get(self::COLUMNS)
            ->map(fn ($row) => [
                'id' => (int) $row->id,
                'event' => (string) $row->event,
                'path' => $row->path !== null ? (string) $row->path : null,
                'meta' => $row->meta !== null ? (string) $row->meta : null,
                'vhash' => (string) $row->vhash,
                'city' => $row->city !== null ? (string) $row->city : null,
                'mobile' => (bool) $row->mobile,
                'created_at' => Carbon::parse($row->created_at),
            ])
            ->all();
    }
}
