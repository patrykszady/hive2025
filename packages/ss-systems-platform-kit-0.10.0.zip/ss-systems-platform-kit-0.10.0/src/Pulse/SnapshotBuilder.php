<?php

namespace SsSystems\Platform\Pulse;

use Illuminate\Support\Carbon;
use SsSystems\Platform\Pulse\Contracts\PulseStorage;

/**
 * Builds exactly dawnsellshomes.com's `pulse` snapshot shape from a
 * PulseStorage — ported from its App\Support\PulseSnapshot::build(), same
 * bucketing rules, generalized so a site with no "search" concept
 * (gs.construction, jpeterson-design) gets the same shape minus the
 * search-derived fields, rather than zeros:
 *
 *   - `search_event` null (the default) OMITS `searches` from
 *     `totals`/`totals_prev`/each `days` row, and omits `searched_cities`/
 *     `filters` entirely — a site with no search feature has nothing
 *     honest to report there, so those keys are simply absent.
 *   - Every other site declares its own `events` (the same whitelist given
 *     to its Recorder) and `feature_labels` (event key => human label); an
 *     event with no label falls back to its raw key, same as Dawn's
 *     `FEATURE_LABELS[$row->event] ?? $row->event` (Dawn's own `call`/
 *     `email` events are deliberately unlabeled this way).
 *   - `search_flag_features` lets a site derive an extra feature row from
 *     a boolean meta flag on its search event without teaching the kit
 *     what that flag MEANS — Dawn's "payment-first searches"
 *     (meta.pay) stays Dawn's own configuration, passed in as
 *     `[['meta_key' => 'pay', 'feature_key' => 'payment_first', 'label' => 'Payment-first searches']]`.
 *
 * The vhash "human search" filter (a search event counts only if the same
 * vhash also fired a `page` event) is applied against the trend-window page
 * rows everywhere, including inside `features()` — Dawn's own features()
 * query instead ran an unbounded (no date filter) correlated EXISTS check,
 * but since vhash = sha256(ip + key + calendar day), two rows can only ever
 * share a vhash when they happened on the very same day, so a matching page
 * event is necessarily inside the same window a matching search event is
 * — the bounded and unbounded checks can never disagree in practice, and
 * unifying them keeps one rule instead of two.
 *
 * Caching is deliberately NOT this class's job: `build()` always computes
 * fresh, and each site wraps the call in its own `Cache::remember(...,
 * now()->addMinutes(5), ...)`, matching how every other seo/snapshot
 * section already caches itself.
 */
final class SnapshotBuilder
{
    public const DEFAULT_SEARCH_META_FIELDS = ['searched_cities' => 'city', 'filters' => 'flt'];

    public const DEFAULT_SEARCH_META_LIMITS = ['searched_cities' => 10, 'filters' => 8];

    public const VISITOR_CITIES_LIMIT = 10;

    public const TOP_PAGES_LIMIT = 12;

    public const JS_ERROR_RAW_LIMIT = 300;

    public const JS_ERROR_GROUP_LIMIT = 12;

    /**
     * @param  list<string>  $events  every event key this site records (same whitelist given to its Recorder)
     * @param  array{timezone?: string, window_days?: int, trend_days?: int, feature_labels?: array<string, string>, search_event?: ?string, search_meta_fields?: array<string, string>, search_meta_limits?: array<string, int>, search_flag_features?: list<array{meta_key: string, feature_key: string, label: string}>}  $options
     */
    public function __construct(
        private readonly PulseStorage $storage,
        private readonly array $events,
        private readonly array $options = [],
    ) {
    }

    public function build(?Carbon $now = null): array
    {
        $timezone = (string) ($this->options['timezone'] ?? 'UTC');
        $windowDays = (int) ($this->options['window_days'] ?? 7);
        $trendDays = (int) ($this->options['trend_days'] ?? 14);
        $featureLabels = (array) ($this->options['feature_labels'] ?? []);
        $searchEvent = $this->options['search_event'] ?? null;
        $searchMetaFields = (array) ($this->options['search_meta_fields'] ?? self::DEFAULT_SEARCH_META_FIELDS);
        $searchMetaLimits = (array) ($this->options['search_meta_limits'] ?? self::DEFAULT_SEARCH_META_LIMITS);
        $searchFlagFeatures = (array) ($this->options['search_flag_features'] ?? []);
        $withSearch = $searchEvent !== null;

        $now = $now ?? Carbon::now();
        $trendStart = $now->copy()->subDays($trendDays);
        $windowStart = $now->copy()->subDays($windowDays);

        $pageRows = $this->storage->since($trendStart, ['page']);
        $searchRows = $withSearch ? $this->storage->since($trendStart, [$searchEvent]) : [];
        $humanSearchRows = $withSearch ? $this->filterToHuman($pageRows, $searchRows) : [];

        $out = [
            'timezone' => $timezone,
            'window_days' => $windowDays,
            'trend_days' => $trendDays,
            'mobile_share_pct' => $this->mobileSharePct($pageRows, $windowStart),
            'totals' => $this->totalsWindow($pageRows, $humanSearchRows, $windowStart, $now, $withSearch),
            'totals_prev' => $this->totalsWindow($pageRows, $humanSearchRows, $trendStart, $windowStart, $withSearch),
            'days' => $this->days($pageRows, $humanSearchRows, $now, $timezone, $trendDays, $withSearch),
            'features' => $this->features($pageRows, $searchRows, $humanSearchRows, $windowStart, $searchEvent, $featureLabels, $searchFlagFeatures),
            'hours' => $this->hours($pageRows, $timezone),
        ];

        if ($withSearch) {
            foreach ($searchMetaFields as $output => $metaKey) {
                $limit = (int) ($searchMetaLimits[$output] ?? 10);
                $out[$output] = $this->searchMetaCounts($searchRows, $windowStart, $metaKey, $limit);
            }
        }

        $out['visitor_cities'] = $this->visitorCities($pageRows, $windowStart);
        $out['top_pages'] = $this->topPages($pageRows, $windowStart);
        $out['js_errors'] = $this->jsErrors($windowStart);

        return $out;
    }

    /** @return list<array{id:int,event:string,path:?string,meta:?string,vhash:string,city:?string,mobile:bool,created_at:Carbon}> */
    private function filterToHuman(array $pageRows, array $searchRows): array
    {
        $pageVhashes = array_flip(array_map(static fn (array $r) => $r['vhash'], $pageRows));

        return array_values(array_filter($searchRows, static fn (array $r) => isset($pageVhashes[$r['vhash']])));
    }

    private function totalsWindow(array $pageRows, array $humanSearchRows, Carbon $start, Carbon $end, bool $withSearch): array
    {
        $pages = array_filter($pageRows, static fn (array $r) => $r['created_at']->gte($start) && $r['created_at']->lt($end));

        $out = ['visitors' => collect($pages)->pluck('vhash')->unique()->count()];

        if ($withSearch) {
            $searches = array_filter($humanSearchRows, static fn (array $r) => $r['created_at']->gte($start) && $r['created_at']->lt($end));
            $out['searches'] = count($searches);
        }

        $out['page_views'] = count($pages);

        return $out;
    }

    private function mobileSharePct(array $pageRows, Carbon $windowStart): int
    {
        $recent = array_filter($pageRows, static fn (array $r) => $r['created_at']->gte($windowStart));
        $total = count($recent);
        if ($total === 0) {
            return 0;
        }

        $mobile = count(array_filter($recent, static fn (array $r) => $r['mobile']));

        return (int) round($mobile * 100 / $total);
    }

    /** 1 entry per trend day, oldest first, bucketed into the site's own timezone. */
    private function days(array $pageRows, array $humanSearchRows, Carbon $now, string $timezone, int $trendDays, bool $withSearch): array
    {
        $pageByDay = $this->groupByLocalDay($pageRows, $timezone);
        $searchByDay = $withSearch ? $this->groupByLocalDay($humanSearchRows, $timezone) : [];

        $today = $now->copy()->timezone($timezone)->startOfDay();
        $out = [];

        for ($d = $trendDays - 1; $d >= 0; $d--) {
            $date = $today->copy()->subDays($d);
            $key = $date->toDateString();
            $pageGroup = $pageByDay[$key] ?? [];

            $entry = [
                'day' => $key,
                'label' => $date->format('D n/j'),
                'visitors' => collect($pageGroup)->pluck('vhash')->unique()->count(),
            ];
            if ($withSearch) {
                $entry['searches'] = count($searchByDay[$key] ?? []);
            }

            $out[] = $entry;
        }

        return $out;
    }

    /** @return array<string, list<array<string, mixed>>> keyed by Y-m-d in $timezone */
    private function groupByLocalDay(array $rows, string $timezone): array
    {
        $out = [];
        foreach ($rows as $row) {
            $key = $row['created_at']->copy()->timezone($timezone)->toDateString();
            $out[$key][] = $row;
        }

        return $out;
    }

    /** 24 entries (hour 0-23), page events over the trend window, bucketed into the site's own timezone. */
    private function hours(array $pageRows, string $timezone): array
    {
        $counts = array_fill(0, 24, 0);
        foreach ($pageRows as $row) {
            $hour = (int) $row['created_at']->copy()->timezone($timezone)->format('G');
            $counts[$hour]++;
        }

        $out = [];
        for ($h = 0; $h < 24; $h++) {
            $out[] = [
                'hour' => $h,
                'label' => ($h % 12 ?: 12).($h < 12 ? 'am' : 'pm'),
                'views' => $counts[$h],
            ];
        }

        return $out;
    }

    /**
     * Every whitelisted event other than page/jserr/the search event, last
     * WINDOW_DAYS, search rows human-filtered — the search event itself
     * still appears as one row here (labelled, e.g., "Searches"), counted
     * from the same human-filtered set. Ordered by uses desc, then any
     * search-meta-flag features appended (unfiltered, unsorted, only when
     * they actually fired at least once) — matching Dawn's own
     * paymentFirstCount() append order exactly.
     */
    private function features(array $pageRows, array $searchRows, array $humanSearchRows, Carbon $windowStart, ?string $searchEvent, array $featureLabels, array $searchFlagFeatures): array
    {
        $otherEvents = array_values(array_filter(
            $this->events,
            static fn (string $e) => $e !== 'page' && $e !== 'jserr' && $e !== $searchEvent,
        ));
        $otherRows = $otherEvents !== [] ? $this->storage->since($windowStart, $otherEvents) : [];

        $windowHumanSearch = $searchEvent !== null
            ? array_values(array_filter($humanSearchRows, static fn (array $r) => $r['created_at']->gte($windowStart)))
            : [];

        $grouped = [];
        foreach ([...$otherRows, ...$windowHumanSearch] as $row) {
            $grouped[$row['event']]['n'] = ($grouped[$row['event']]['n'] ?? 0) + 1;
            $grouped[$row['event']]['vhashes'][$row['vhash']] = true;
        }

        $features = [];
        foreach ($grouped as $event => $g) {
            $features[] = [
                'key' => $event,
                'label' => $featureLabels[$event] ?? $event,
                'uses' => $g['n'],
                'people' => count($g['vhashes']),
            ];
        }

        usort($features, static fn (array $a, array $b) => $b['uses'] <=> $a['uses']);

        if ($searchEvent !== null && $searchFlagFeatures !== []) {
            $windowRawSearch = array_values(array_filter($searchRows, static fn (array $r) => $r['created_at']->gte($windowStart)));

            foreach ($searchFlagFeatures as $flag) {
                $count = $this->flagCount($windowRawSearch, (string) $flag['meta_key']);
                if ($count > 0) {
                    $features[] = [
                        'key' => (string) $flag['feature_key'],
                        'label' => (string) $flag['label'],
                        'uses' => $count,
                        'people' => null,
                    ];
                }
            }
        }

        return $features;
    }

    private function flagCount(array $rows, string $metaKey): int
    {
        $count = 0;
        foreach ($rows as $row) {
            if ($row['meta'] === null) {
                continue;
            }
            $m = json_decode($row['meta'], true) ?: [];
            if (! empty($m[$metaKey])) {
                $count++;
            }
        }

        return $count;
    }

    /**
     * Top values of one meta array field across every search event (bot or
     * not — matches the /pulse page's own logic, never human-filtered) in
     * the window, most-used first.
     *
     * @return list<array{name: string, count: int}>
     */
    private function searchMetaCounts(array $searchRows, Carbon $windowStart, string $metaKey, int $limit): array
    {
        $windowRows = array_filter($searchRows, static fn (array $r) => $r['created_at']->gte($windowStart));

        $counts = [];
        foreach ($windowRows as $row) {
            if ($row['meta'] === null) {
                continue;
            }
            $m = json_decode($row['meta'], true) ?: [];
            foreach ((array) ($m[$metaKey] ?? []) as $v) {
                $counts[$v] = ($counts[$v] ?? 0) + 1;
            }
        }

        arsort($counts);

        return collect($counts)->take($limit)->map(static fn ($count, $name) => ['name' => $name, 'count' => $count])->values()->all();
    }

    /** @return list<array{name: string, people: int}> */
    private function visitorCities(array $pageRows, Carbon $windowStart): array
    {
        $counts = [];
        foreach ($pageRows as $row) {
            if (! $row['created_at']->gte($windowStart) || $row['city'] === null || $row['city'] === '') {
                continue;
            }
            $counts[$row['city']][$row['vhash']] = true;
        }

        $out = [];
        foreach ($counts as $city => $vhashes) {
            $out[] = ['name' => $city, 'people' => count($vhashes)];
        }
        usort($out, static fn (array $a, array $b) => $b['people'] <=> $a['people']);

        return array_slice($out, 0, self::VISITOR_CITIES_LIMIT);
    }

    /** @return list<array{path: string, views: int}> */
    private function topPages(array $pageRows, Carbon $windowStart): array
    {
        $counts = [];
        foreach ($pageRows as $row) {
            if (! $row['created_at']->gte($windowStart)) {
                continue;
            }
            $path = '/'.ltrim((string) $row['path'], '/');
            $counts[$path] = ($counts[$path] ?? 0) + 1;
        }

        arsort($counts);

        $out = [];
        foreach ($counts as $path => $n) {
            $out[] = ['path' => $path, 'views' => $n];
        }

        return array_slice($out, 0, self::TOP_PAGES_LIMIT);
    }

    /**
     * Top JS_ERROR_GROUP_LIMIT groups from the newest JS_ERROR_RAW_LIMIT
     * jserr rows in the window — the cap applies to the raw rows BEFORE
     * grouping (matching Dawn's `orderByDesc('id')->limit(300)` before its
     * grouping loop), so a burst of one message can crowd out an older,
     * separately-recurring one; that is the existing, accepted behaviour.
     *
     * @return list<array{message: string, location: string, browsers: list<string>, count: int}>
     */
    private function jsErrors(Carbon $windowStart): array
    {
        $rows = $this->storage->since($windowStart, ['jserr']);
        usort($rows, static fn (array $a, array $b) => $b['id'] <=> $a['id']);
        $rows = array_slice($rows, 0, self::JS_ERROR_RAW_LIMIT);

        $groups = [];
        foreach ($rows as $row) {
            $m = $row['meta'] !== null ? (json_decode($row['meta'], true) ?: []) : [];
            $message = (string) ($m['m'] ?? '?');
            $location = (string) ($m['s'] ?? '');
            $key = $message.'|'.$location;

            $groups[$key] ??= ['message' => $message, 'location' => $location, 'browsers' => [], 'count' => 0];
            $groups[$key]['count']++;

            $browser = ($m['b'] ?? '?').(($m['mob'] ?? false) ? ' mobile' : '');
            $groups[$key]['browsers'][$browser] = true;
        }

        uasort($groups, static fn (array $a, array $b) => $b['count'] <=> $a['count']);

        return collect(array_slice($groups, 0, self::JS_ERROR_GROUP_LIMIT, true))
            ->map(static fn (array $g) => [
                'message' => $g['message'],
                'location' => $g['location'],
                'browsers' => array_keys($g['browsers']),
                'count' => $g['count'],
            ])
            ->values()
            ->all();
    }
}
