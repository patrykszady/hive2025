<?php

namespace SsSystems\Platform\Pulse\Contracts;

/**
 * Everything the Recorder and SnapshotBuilder need from `site_events` (or
 * whatever a site calls its table) — one write path, one read path. A site
 * binds `Storage\DatabaseTableStorage` (a plain DB-table implementation with
 * an optional tenant column + scope callback, for gsc's multi-tenant rows)
 * or its own implementation, e.g. one that goes through an Eloquent model
 * with its own global scope instead of a raw connection.
 */
interface PulseStorage
{
    /**
     * @param  array{event: string, path: ?string, meta: ?string, vhash: string, city: ?string, mobile: bool, created_at: string}  $row
     */
    public function insert(array $row): void;

    /**
     * Every row at or after $since, oldest first, optionally restricted to
     * a set of event keys (empty = every event). No upper bound — callers
     * that want a window filter it themselves from what comes back.
     *
     * @param  list<string>  $events
     * @return list<array{id: int, event: string, path: ?string, meta: ?string, vhash: string, city: ?string, mobile: bool, created_at: \Illuminate\Support\Carbon}>
     */
    public function since(\DateTimeInterface $since, array $events = []): array;
}
