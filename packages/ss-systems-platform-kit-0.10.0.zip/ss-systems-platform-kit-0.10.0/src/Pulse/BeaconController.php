<?php

namespace SsSystems\Platform\Pulse;

use Illuminate\Http\Request;
use Illuminate\Http\Response;

/**
 * The one implementation of the `POST /t` beacon handler every site wires
 * up in its own routes file (throttled, CSRF-exempt — see docs/PULSE.md).
 * Ported from dawnsellshomes.com's inline route closure: decode the
 * sendBeacon body ({e, m, p}), cap meta at 6 keys, hand off to Recorder.
 * Never errors — a malformed body or a Recorder exception still answers
 * 204, since the beacon must never surface a failure to the page.
 */
final class BeaconController
{
    public const META_KEY_LIMIT = 6;

    public function __construct(
        private readonly Recorder $recorder,
        private readonly string $appKey,
    ) {
    }

    public function __invoke(Request $request): Response
    {
        try {
            $body = json_decode((string) $request->getContent(), true);
            $body = is_array($body) ? $body : [];

            $meta = is_array($body['m'] ?? null) ? array_slice($body['m'], 0, self::META_KEY_LIMIT, true) : [];
            $event = (string) ($body['e'] ?? '');
            $path = (string) ($body['p'] ?? $request->path());

            $this->recorder->track(
                $event,
                $meta,
                $path,
                (string) $request->ip(),
                (string) $request->userAgent(),
                $this->appKey,
            );
        } catch (\Throwable) {
            // the beacon must never surface a failure to the page
        }

        return new Response('', 204);
    }
}
