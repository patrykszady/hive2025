<?php

namespace SsSystems\Platform\Pulse;

use SsSystems\Platform\Pulse\Contracts\PulseStorage;

/**
 * First-party usage telemetry — one implementation, run by every site.
 * Ported verbatim from dawnsellshomes.com's App\Support\Pulse::track():
 * event whitelist, bot filter, an anonymous visitor key
 * (sha256(ip + app key + date) — no cookies, nothing reversible, resets
 * daily), an optional city-guess callable, never throws (telemetry must
 * never be able to break a page).
 *
 * Deliberately framework-global-free (no `request()`/`config()` calls) so
 * it can be unit-tested with no Laravel bootstrap: every per-request fact
 * (ip, user agent, app key, path, now) is a plain argument, gathered by the
 * site's own thin wrapper (e.g. Dawn's App\Support\Pulse::track(), or the
 * kit's own BeaconController for the /t endpoint).
 */
final class Recorder
{
    public const DEFAULT_BOT_PATTERN = '/bot|crawl|spider|slurp|preview|facebookexternalhit|headless|python|curl|wget/i';

    public const MOBILE_PATTERN = '/Mobile|Android|iPhone/i';

    public const PATH_LENGTH = 191;

    /**
     * @param  list<string>  $events  the event keys this site records; anything else is silently dropped
     * @param  (\Closure(string $ip): ?string)|null  $cityResolver  a city guess for the 'city' column, or null to never fill it
     */
    public function __construct(
        private readonly PulseStorage $storage,
        private readonly array $events,
        private readonly ?\Closure $cityResolver = null,
        private readonly string $botPattern = self::DEFAULT_BOT_PATTERN,
    ) {
    }

    /**
     * @param  array<string, mixed>  $meta
     */
    public function track(
        string $event,
        array $meta,
        string $path,
        string $ip,
        string $userAgent,
        string $appKey,
        ?\DateTimeImmutable $now = null,
    ): void {
        try {
            if (! in_array($event, $this->events, true)) {
                return;
            }
            if ($userAgent !== '' && preg_match($this->botPattern, $userAgent) === 1) {
                return;
            }

            $now ??= new \DateTimeImmutable('now');
            $date = $now->format('Y-m-d');
            $city = $this->cityResolver !== null ? ($this->cityResolver)($ip) : null;

            $this->storage->insert([
                'event' => $event,
                'path' => mb_substr($path, 0, self::PATH_LENGTH),
                'meta' => $meta === [] ? null : json_encode($meta),
                'vhash' => hash('sha256', $ip.$appKey.$date),
                'city' => $city,
                'mobile' => (bool) preg_match(self::MOBILE_PATTERN, $userAgent),
                'created_at' => $now->format('Y-m-d H:i:s'),
            ]);
        } catch (\Throwable) {
            // never let telemetry break the page
        }
    }
}
