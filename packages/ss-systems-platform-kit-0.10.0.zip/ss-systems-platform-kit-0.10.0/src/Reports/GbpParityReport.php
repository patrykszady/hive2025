<?php

namespace SsSystems\Platform\Reports;

use Illuminate\Support\Carbon;
use Illuminate\Support\Str;
use SsSystems\Platform\Reports\Contracts\PageFetcher;
use SsSystems\Platform\Reports\Contracts\SiteCatalog;
use SsSystems\Platform\Reports\Contracts\SiteIdentity;

/**
 * GBP / local-SEO parity audit — ported verbatim from gs.construction's
 * app/Console/Commands/SeoGbpParity.php (same NAP checks, same
 * service-catalog classification, same markdown headings/tables/wording;
 * this is a transcription, not a redesign).
 *
 *  - NAP (Name / Address / Phone) consistency across a configurable set of
 *    landing pages (default /, /contact, /about), fetched and checked
 *    against SiteIdentity's expected phone/address.
 *  - Every service in SiteIdentity::gbpServices() has a matching public
 *    /services/{slug} page (and vice versa: every such page is represented
 *    in the GBP catalog) — pillars need their own landing page, sub-services
 *    are "covered" via their parent pillar's page.
 *
 * The original command's `$this->fetch()`/`readSitemap()` (an Http::get()
 * wrapped in try/catch, returning '' / [] on failure) become
 * PageFetcher::fetch() and SiteCatalog::sitemapUrls() respectively — the
 * try/catch-to-empty-result behaviour now lives on those interfaces'
 * implementations, not here. `config('app.url')`, the config chain for the
 * expected phone/address, and `config('gbp-services.*')` become
 * SiteCatalog::baseUrl() and SiteIdentity's three methods. Everything else —
 * normalizePhone(), extractPhones(), stripHtml(), buildCatalog(), the
 * pillar/sub-service classification, and the markdown itself — is copied
 * unchanged.
 *
 * The original also did two things a Command can do that a plain report
 * cannot: print `$this->info()`/`$this->line()` diagnostics as it went, and
 * call `logger()->warning('seo:gbp-parity issues', ...)` unconditionally
 * whenever `$issues` was non-empty (no dedup/cache involved, unlike
 * ContentDecayReport's alert). Both become plain structured `data` — the
 * full `issues` list plus the fields the console lines printed
 * (`expected_phone`, `expected_address`, the parity buckets) — so the
 * site's thin wrapper can print the same lines and log the same warning
 * itself when `data['issues']` is non-empty.
 */
final class GbpParityReport implements Report
{
    private const TIMEOUT_SECONDS = 15;

    private const USER_AGENT = 'GSC-GBPParity/1.0';

    public function __construct(
        private readonly PageFetcher $pageFetcher,
        private readonly SiteCatalog $siteCatalog,
        private readonly SiteIdentity $siteIdentity,
    ) {
    }

    public static function key(): string
    {
        return 'gbp-parity';
    }

    /** @return list<string> */
    public static function requires(): array
    {
        return ['page_fetcher', 'site_catalog', 'site_identity'];
    }

    public function generate(array $options = []): ReportResult
    {
        $base = rtrim($this->siteCatalog->baseUrl(), '/');
        $issues = [];

        $expectedPhone = $this->normalizePhone((string) ($this->siteIdentity->expectedPhone() ?? ''));
        $expectedAddress = (string) ($this->siteIdentity->expectedAddress() ?? '');

        if ($expectedPhone === '') {
            $issues[] = 'No expected phone configured (set geo-answers.meta.phone or seo.phone) — phone-parity check is skipped.';
        }
        if ($expectedAddress === '') {
            $issues[] = 'No expected address configured (set seo.address) — address-parity check is skipped.';
        }

        $napResults = [];
        $landingPaths = array_filter(array_map('trim', explode(
            ',',
            (string) ($options['landing_pages'] ?? '/,/contact,/about'),
        )));
        foreach ($landingPaths as $p) {
            $url = $base.$p;
            $fetched = $this->pageFetcher->fetch($url, self::TIMEOUT_SECONDS, self::USER_AGENT);
            $html = $fetched->successful ? $fetched->body : '';

            if ($html === '') {
                $napResults[$url] = ['phone' => '—', 'phone_ok' => false, 'address_ok' => false, 'note' => 'fetch failed'];
                $issues[] = "Could not fetch {$url}";

                continue;
            }

            $foundPhones = $this->extractPhones($html);
            // null = check skipped (no config), true = match, false = mismatch.
            $phoneOk = $expectedPhone === ''
                ? null
                : in_array($expectedPhone, array_map([$this, 'normalizePhone'], $foundPhones), true);
            $addressOk = $expectedAddress === ''
                ? null
                : (stripos($this->stripHtml($html), $expectedAddress) !== false);

            $napResults[$url] = [
                'phone' => implode(', ', array_slice($foundPhones, 0, 3)) ?: '—',
                'phone_ok' => $phoneOk,
                'address_ok' => $addressOk,
                'note' => '',
            ];
            if ($phoneOk === false) {
                $issues[] = "Phone mismatch on {$url} (expected digits {$expectedPhone})";
            }
            if ($addressOk === false) {
                $issues[] = "Address fragment not found on {$url}";
            }
        }

        // GBP service ↔ site service parity.
        // GBP entries can be pillars (own landing page) or sub-services (rolled up
        // under a pillar). Sub-services don't need a /services/{slug} page; they're
        // considered "covered" if their parent pillar has one.
        $gbp = $this->siteIdentity->gbpServices();
        $catalog = $this->buildCatalog($gbp);
        $slugAliases = $this->siteIdentity->gbpServiceSlugAliases();

        $sitemap = $this->siteCatalog->sitemapUrls();
        $siteServiceSlugs = [];
        foreach ($sitemap as $u) {
            $path = (string) parse_url($u, PHP_URL_PATH);
            // Match both /services/{slug} and /areas-served/{area}/services/{slug}.
            if (preg_match('#/services/([a-z0-9\-]+)/?$#', $path, $m)) {
                $siteServiceSlugs[] = $m[1];
            }
        }
        $siteServiceSlugs = array_values(array_unique($siteServiceSlugs));
        $siteServiceSlugsForParity = array_values(array_unique(array_map(
            fn (string $slug) => (string) ($slugAliases[$slug] ?? $slug),
            $siteServiceSlugs,
        )));

        // Classify GBP entries: covered pillar | orphan pillar | rolled-up sub | orphan sub.
        $pillarsCovered = [];
        $pillarsMissing = [];
        $subsRolled = [];   // [child_slug => parent_slug]
        $subsOrphan = [];   // [slug => declared parent (or null)]
        foreach ($catalog as $slug => $entry) {
            if ($entry['pillar']) {
                in_array($slug, $siteServiceSlugs, true)
                    || in_array($slug, $siteServiceSlugsForParity, true)
                    ? $pillarsCovered[] = $slug
                    : $pillarsMissing[] = $slug;
            } else {
                $parent = $entry['parent'];
                if ($parent !== null && (in_array($parent, $siteServiceSlugs, true) || in_array($parent, $siteServiceSlugsForParity, true))) {
                    $subsRolled[$slug] = $parent;
                } else {
                    $subsOrphan[$slug] = $parent;
                }
            }
        }

        $gbpSlugs = array_keys($catalog);
        $siteOnly = array_values(array_diff($siteServiceSlugsForParity, $gbpSlugs));
        foreach ($pillarsMissing as $s) {
            $issues[] = "Pillar service '{$s}' in GBP but no /services/{$s} page";
        }
        foreach ($subsOrphan as $slug => $parent) {
            $issues[] = $parent === null
                ? "Sub-service '{$slug}' has no parent declared and no landing page"
                : "Sub-service '{$slug}' parent '{$parent}' is not a real landing page";
        }
        foreach ($siteOnly as $s) {
            $issues[] = "Service '{$s}' has page but missing in GBP config";
        }

        $markdown = $this->buildMarkdown(
            $expectedPhone,
            $expectedAddress,
            $napResults,
            $pillarsCovered,
            $pillarsMissing,
            $subsRolled,
            $subsOrphan,
            $siteServiceSlugs,
            $siteOnly,
            $issues,
        );

        $summary = sprintf('%d issue(s) across NAP and service parity.', count($issues));

        $data = [
            'expected_phone' => $expectedPhone,
            'expected_address' => $expectedAddress,
            'nap' => $napResults,
            'pillars_covered' => $pillarsCovered,
            'pillars_missing' => $pillarsMissing,
            'subs_rolled' => $subsRolled,
            'subs_orphan' => $subsOrphan,
            'site_service_slugs' => $siteServiceSlugs,
            'site_only' => $siteOnly,
            'issues' => $issues,
        ];

        return ReportResult::ok($markdown, $summary, $data);
    }

    private function stripHtml(string $html): string
    {
        $html = (string) preg_replace('#<(script|style)\b[^>]*>.*?</\1>#is', ' ', $html);

        return (string) preg_replace('/\s+/u', ' ', html_entity_decode(strip_tags($html), ENT_QUOTES | ENT_HTML5));
    }

    /** @return array<int, string> */
    private function extractPhones(string $html): array
    {
        $out = [];
        if (preg_match_all('#tel:([+0-9\-\(\) ]{7,})#i', $html, $m)) {
            foreach ($m[1] as $p) {
                $out[] = trim($p);
            }
        }
        // Plain-text US-style phone
        $text = $this->stripHtml($html);
        if (preg_match_all('#(\+?1[\s\-\.]?)?(\(?\d{3}\)?[\s\-\.]?\d{3}[\s\-\.]?\d{4})#', $text, $m)) {
            foreach ($m[0] as $p) {
                $out[] = trim($p);
            }
        }

        return array_values(array_unique($out));
    }

    private function normalizePhone(string $p): string
    {
        $digits = preg_replace('/\D+/', '', $p) ?? '';
        // Drop leading "1" for US numbers so +1 and bare 10-digit compare equal.
        if (strlen($digits) === 11 && str_starts_with($digits, '1')) {
            $digits = substr($digits, 1);
        }

        return $digits;
    }

    /**
     * Normalize the site's raw GBP service catalog into a slug-keyed catalog.
     *
     * @param  array<int|string, mixed>  $gbp
     * @return array<string, array{name:string, pillar:bool, parent:?string}>
     */
    private function buildCatalog(array $gbp): array
    {
        $catalog = [];
        foreach ($gbp as $k => $v) {
            if (! is_array($v)) {
                if (is_string($v)) {
                    $slug = Str::slug($v);
                    $catalog[$slug] = ['name' => $v, 'pillar' => true, 'parent' => null];
                }

                continue;
            }
            $name = (string) ($v['name'] ?? (is_string($k) ? $k : ''));
            if ($name === '') {
                continue;
            }
            $slug = isset($v['slug']) ? (string) $v['slug'] : Str::slug($name);
            $catalog[$slug] = [
                'name' => $name,
                'pillar' => (bool) ($v['pillar'] ?? false),
                'parent' => isset($v['parent']) ? (string) $v['parent'] : null,
            ];
        }

        return $catalog;
    }

    /**
     * Legacy flat extractor kept for callers/tests that want just the slug list.
     *
     * @param  array<int|string, mixed>  $gbp
     * @return array<int, string>
     */
    private function extractServiceSlugs(array $gbp): array
    {
        return array_keys($this->buildCatalog($gbp));
    }

    /**
     * @param  array<string, array<string, mixed>>  $nap
     * @param  array<int, string>  $pillarsCovered
     * @param  array<int, string>  $pillarsMissing
     * @param  array<string, string>  $subsRolled
     * @param  array<string, ?string>  $subsOrphan
     * @param  array<int, string>  $siteSlugs
     * @param  array<int, string>  $siteOnly
     * @param  array<int, string>  $issues
     */
    private function buildMarkdown(
        string $phone,
        string $addr,
        array $nap,
        array $pillarsCovered,
        array $pillarsMissing,
        array $subsRolled,
        array $subsOrphan,
        array $siteSlugs,
        array $siteOnly,
        array $issues,
    ): string {
        $md = "# GBP / Local-SEO parity report\n\n";
        $md .= 'Run: '.Carbon::now()->toIso8601String()."\n\n";
        $md .= "## NAP\n\nExpected phone (normalized digits): `".($phone ?: '_none configured_')."`\n\n";
        $md .= "Expected address fragment: `".($addr ?: '_none configured_')."`\n\n";
        $md .= "| URL | Phone(s) found | Phone match | Address match |\n|---|---|:---:|:---:|\n";
        $glyph = fn ($v) => $v === null ? '⚪ skip' : ($v ? '✅' : '❌');
        foreach ($nap as $url => $r) {
            $md .= sprintf(
                "| %s | %s | %s | %s |\n",
                $url,
                $r['phone'],
                $glyph($r['phone_ok']),
                $glyph($r['address_ok']),
            );
        }

        $md .= "\n## Service parity\n\n";
        $md .= '- **Pillars covered ('.count($pillarsCovered).'):** '.(empty($pillarsCovered) ? '_none_' : '`'.implode('`, `', $pillarsCovered).'`')."\n";
        $md .= '- **Pillars missing ('.count($pillarsMissing).'):** '.(empty($pillarsMissing) ? '—' : '`'.implode('`, `', $pillarsMissing).'`')."\n";
        $md .= '- **Sub-services rolled up ('.count($subsRolled).'):** '.(empty($subsRolled) ? '—' : implode(', ', array_map(fn ($c, $p) => "`{$c}` → `{$p}`", array_keys($subsRolled), $subsRolled)))."\n";
        $md .= '- **Sub-services orphaned ('.count($subsOrphan).'):** '.(empty($subsOrphan) ? '—' : '`'.implode('`, `', array_keys($subsOrphan)).'`')."\n";
        $md .= '- **Site /services/* slugs:** '.(empty($siteSlugs) ? '_none_' : '`'.implode('`, `', $siteSlugs).'`')."\n";
        $md .= '- **On site, missing in GBP:** '.(empty($siteOnly) ? '—' : '`'.implode('`, `', $siteOnly).'`')."\n";

        $md .= "\n## Issues\n\n";
        $md .= empty($issues) ? "_None — full parity._\n" : ('- '.implode("\n- ", $issues)."\n");

        return $md;
    }
}
