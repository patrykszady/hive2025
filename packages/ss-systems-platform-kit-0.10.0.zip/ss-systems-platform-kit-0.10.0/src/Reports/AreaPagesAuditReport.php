<?php

namespace SsSystems\Platform\Reports;

use Illuminate\Support\Carbon;
use SsSystems\Platform\Reports\Contracts\AreaCatalog;
use SsSystems\Platform\Reports\Contracts\PageFetcher;
use SsSystems\Platform\Reports\Contracts\SiteCatalog;

/**
 * Per-area landing-page audit — ported verbatim from gs.construction's
 * app/Console/Commands/SeoAreaPagesAudit.php (same variant→path map, same
 * thin-content threshold, same Jaccard near-duplicate clustering, same
 * markdown text and section order; this is a transcription, not a
 * redesign).
 *
 * For each area AreaCatalog::areas() returns, fetches a configurable set of
 * page variants (home, contact, about, projects, testimonials, services
 * pillar pages) and reports word count of the main content plus
 * near-duplicate clusters WITHIN the same variant (e.g. all the
 * /areas-served/{area}/services/kitchen-remodeling pages whose text differs
 * only by city name), via Jaccard similarity on word shingles.
 *
 * Two places this port could not be a pure 1:1 transcription:
 *
 *   - A site whose AreaCatalog::areas() is [] (no per-city×service page
 *     matrix — jpeterson-design) returns ReportResult::unavailable() with
 *     `missing = ['area_catalog']` instead of silently running an
 *     "audited 0 areas, all good" report the way the original command's
 *     `AreaServed::query()->get()` returning an empty collection would have
 *     — see docs/REPORTS-PORTING.md and the task this class was ported
 *     under: an empty catalog means "not applicable here", never "zero
 *     problems found".
 *   - The original's `$areas->random($sample)` (Laravel Collection::random)
 *     becomes `array_rand()` over the area list sorted by slug — the same
 *     "sample N at random, otherwise keep everything in slug order"
 *     behaviour, expressed without a Collection.
 */
final class AreaPagesAuditReport implements Report
{
    public function __construct(
        private readonly AreaCatalog $areaCatalog,
        private readonly PageFetcher $pageFetcher,
        private readonly SiteCatalog $siteCatalog,
    ) {
    }

    public static function key(): string
    {
        return 'area-pages-audit';
    }

    /** @return list<string> */
    public static function requires(): array
    {
        return ['area_catalog', 'page_fetcher', 'site_catalog'];
    }

    public function generate(array $options = []): ReportResult
    {
        $sample = max(0, (int) ($options['sample'] ?? 10));
        $thinThreshold = max(50, (int) ($options['thin'] ?? 350));
        $sim = max(0.0, min(1.0, (float) ($options['sim'] ?? 0.85)));
        $shingle = max(2, (int) ($options['shingle'] ?? 5));

        $variantsOption = (string) ($options['variants'] ?? 'home,contact,services-kitchen,services-bathroom,services-home');
        $variants = array_values(array_filter(array_map('trim', explode(',', $variantsOption))));
        if ($variants === []) {
            return ReportResult::error('No variants specified.');
        }

        $areas = $this->areaCatalog->areas();
        if ($areas === []) {
            return ReportResult::unavailable(['area_catalog'], 'No area-served pages configured for this site.');
        }

        usort($areas, fn (array $a, array $b): int => $a['slug'] <=> $b['slug']);
        if ($sample > 0 && count($areas) > $sample) {
            $keys = (array) array_rand($areas, $sample);
            sort($keys);
            $areas = array_values(array_map(fn ($k) => $areas[$k], $keys));
        }

        $base = rtrim($this->siteCatalog->baseUrl(), '/');

        // Per-variant: [area_slug => ['url'=>..., 'city'=>..., 'words'=>int, 'text'=>string]]
        $byVariant = [];
        $fetchFails = [];

        foreach ($areas as $area) {
            foreach ($variants as $variant) {
                $path = $this->variantPath($area['slug'], $variant);
                if ($path === null) {
                    continue;
                }
                $url = $base.$path;
                $text = $this->fetchMainText($url);
                if ($text === null) {
                    $fetchFails[] = $url;
                    continue;
                }
                $words = str_word_count($text);
                $byVariant[$variant][$area['slug']] = [
                    'url' => $url,
                    'city' => $area['city'],
                    'words' => $words,
                    'text' => $text,
                ];
            }
        }

        // Thin pages
        $thin = [];
        foreach ($byVariant as $variant => $rows) {
            foreach ($rows as $slug => $r) {
                if ($r['words'] < $thinThreshold) {
                    $thin[] = ['variant' => $variant, 'slug' => $slug, 'city' => $r['city'], 'url' => $r['url'], 'words' => $r['words']];
                }
            }
        }

        // Duplicate clusters per variant
        $clusters = []; // ['variant' => [[slug1, slug2, ...], ...]]
        foreach ($byVariant as $variant => $rows) {
            $slugs = array_keys($rows);
            $shingles = [];
            foreach ($slugs as $s) {
                // Normalize: strip the city name itself so we don't penalize unique city words.
                $normalized = $this->normalize($rows[$s]['text'], $rows[$s]['city']);
                $shingles[$s] = $this->shingleSet($normalized, $shingle);
            }
            // Union-find clustering: edge if jaccard >= $sim
            $parent = array_combine($slugs, $slugs);
            $find = function ($x) use (&$parent, &$find) {
                while ($parent[$x] !== $x) {
                    $parent[$x] = $parent[$parent[$x]];
                    $x = $parent[$x];
                }

                return $x;
            };
            $union = function ($a, $b) use (&$parent, $find) {
                $ra = $find($a);
                $rb = $find($b);
                if ($ra !== $rb) {
                    $parent[$ra] = $rb;
                }
            };
            $n = count($slugs);
            for ($i = 0; $i < $n; $i++) {
                for ($j = $i + 1; $j < $n; $j++) {
                    $jScore = $this->jaccard($shingles[$slugs[$i]], $shingles[$slugs[$j]]);
                    if ($jScore >= $sim) {
                        $union($slugs[$i], $slugs[$j]);
                    }
                }
            }
            $groups = [];
            foreach ($slugs as $s) {
                $groups[$find($s)][] = $s;
            }
            foreach ($groups as $members) {
                if (count($members) >= 2) {
                    $clusters[$variant][] = $members;
                }
            }
        }

        $totalClusters = array_sum(array_map('count', $clusters));

        $variantOverview = [];
        foreach ($byVariant as $variant => $rows) {
            $words = array_column($rows, 'words');
            $variantOverview[] = [
                'variant' => $variant,
                'pages' => count($rows),
                'min' => $words ? min($words) : 0,
                'avg' => $words ? (int) round(array_sum($words) / count($words)) : 0,
                'max' => $words ? max($words) : 0,
            ];
        }

        $markdown = $this->buildMarkdown($variantOverview, $thin, $clusters, $fetchFails, $thinThreshold, $sim);
        $summary = sprintf(
            '%d thin page(s), %d near-duplicate cluster(s), %d fetch failure(s).',
            count($thin),
            $totalClusters,
            count($fetchFails),
        );

        $data = [
            'areas_sampled' => count($areas),
            'variants' => $variants,
            'variant_overview' => $variantOverview,
            'thin_count' => count($thin),
            'thin' => $thin,
            'clusters_count' => $totalClusters,
            'clusters' => $clusters,
            'fetch_failures_count' => count($fetchFails),
            'fetch_failures' => $fetchFails,
        ];

        return ReportResult::ok($markdown, $summary, $data);
    }

    protected function variantPath(string $areaSlug, string $variant): ?string
    {
        return match ($variant) {
            'home' => "/areas-served/{$areaSlug}",
            'contact' => "/areas-served/{$areaSlug}/contact",
            'about' => "/areas-served/{$areaSlug}/about",
            'projects' => "/areas-served/{$areaSlug}/projects",
            'testimonials' => "/areas-served/{$areaSlug}/testimonials",
            'services' => "/areas-served/{$areaSlug}/services",
            'services-kitchen' => "/areas-served/{$areaSlug}/services/kitchen-remodeling",
            'services-bathroom' => "/areas-served/{$areaSlug}/services/bathroom-remodeling",
            'services-home' => "/areas-served/{$areaSlug}/services/home-remodeling",
            'services-basement' => "/areas-served/{$areaSlug}/services/basement-remodeling",
            'services-additions' => "/areas-served/{$areaSlug}/services/home-additions",
            default => null,
        };
    }

    protected function fetchMainText(string $url): ?string
    {
        $resp = $this->pageFetcher->fetch($url, 20, 'GS-SEO-Audit/1.0');
        if (! $resp->successful) {
            return null;
        }
        $html = $resp->body;

        // Extract <main>...</main> if present; fall back to <body>.
        if (preg_match('#<main\b[^>]*>(.*?)</main>#is', $html, $m)) {
            $inner = $m[1];
        } elseif (preg_match('#<body\b[^>]*>(.*?)</body>#is', $html, $m)) {
            $inner = $m[1];
        } else {
            $inner = $html;
        }

        // Strip scripts/styles/templates.
        $inner = preg_replace('#<(script|style|noscript|template)\b[^>]*>.*?</\1>#is', ' ', $inner);
        $text = trim(html_entity_decode(strip_tags((string) $inner), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
        $text = preg_replace('/\s+/u', ' ', $text);

        return $text === '' ? null : $text;
    }

    protected function normalize(string $text, ?string $city): string
    {
        $t = mb_strtolower($text);
        if ($city) {
            $t = str_replace(mb_strtolower($city), 'CITY', $t);
        }

        return $t;
    }

    /** @return array<string,true> */
    protected function shingleSet(string $text, int $n): array
    {
        $tokens = preg_split('/[^a-z0-9]+/u', $text, -1, PREG_SPLIT_NO_EMPTY) ?: [];
        if (count($tokens) < $n) {
            return [implode(' ', $tokens) => true];
        }
        $out = [];
        for ($i = 0, $end = count($tokens) - $n; $i <= $end; $i++) {
            $out[implode(' ', array_slice($tokens, $i, $n))] = true;
        }

        return $out;
    }

    protected function jaccard(array $a, array $b): float
    {
        if (empty($a) && empty($b)) {
            return 1.0;
        }
        $inter = count(array_intersect_key($a, $b));
        $union = count($a) + count($b) - $inter;

        return $union > 0 ? $inter / $union : 0.0;
    }

    /**
     * @param  list<array{variant: string, pages: int, min: int, avg: int, max: int}>  $variantOverview
     * @param  list<array{variant: string, slug: string, city: ?string, url: string, words: int}>  $thin
     * @param  array<string, list<list<string>>>  $clusters
     * @param  list<string>  $fetchFails
     */
    private function buildMarkdown(array $variantOverview, array $thin, array $clusters, array $fetchFails, int $thinThreshold, float $sim): string
    {
        $now = Carbon::now()->toIso8601String();
        $md = "# Area-pages audit\n\nRun: {$now}\n\n";
        $md .= "Thin threshold: {$thinThreshold} words · Similarity threshold: {$sim}\n\n";

        $md .= "## Variant overview\n\n| Variant | Pages | Min | Avg | Max |\n|---|---:|---:|---:|---:|\n";
        foreach ($variantOverview as $v) {
            $md .= "| {$v['variant']} | {$v['pages']} | {$v['min']} | {$v['avg']} | {$v['max']} |\n";
        }

        $md .= "\n## Thin pages (".count($thin).")\n\n";
        if (empty($thin)) {
            $md .= "_None below {$thinThreshold} words._\n";
        } else {
            $md .= "| Words | Variant | URL |\n|---:|---|---|\n";
            foreach ($thin as $t) {
                $md .= "| {$t['words']} | {$t['variant']} | {$t['url']} |\n";
            }
        }

        $md .= "\n## Near-duplicate clusters\n\n";
        $any = false;
        foreach ($clusters as $variant => $groups) {
            if (empty($groups)) {
                continue;
            }
            $any = true;
            $md .= "### {$variant}\n\n";
            foreach ($groups as $i => $members) {
                $md .= '- Cluster '.($i + 1).' ('.count($members).' areas): '.implode(', ', $members)."\n";
            }
            $md .= "\n";
        }
        if (! $any) {
            $md .= "_No clusters detected above similarity ≥ {$sim}._\n";
        }

        if (! empty($fetchFails)) {
            $md .= "\n## Fetch failures (".count($fetchFails).")\n\n";
            foreach ($fetchFails as $u) {
                $md .= "- {$u}\n";
            }
        }

        return $md;
    }
}
