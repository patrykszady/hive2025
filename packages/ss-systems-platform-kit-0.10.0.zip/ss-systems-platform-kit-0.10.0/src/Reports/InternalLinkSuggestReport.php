<?php

namespace SsSystems\Platform\Reports;

use Illuminate\Support\Carbon;
use Illuminate\Support\Str;
use SsSystems\Platform\Reports\Contracts\PageFetcher;
use SsSystems\Platform\Reports\Contracts\SiteCatalog;

/**
 * Internal-link opportunity finder — ported verbatim from gs.construction's
 * app/Console/Commands/SeoInternalLinkSuggest.php (same regexes, same
 * generic-anchor stoplist, same excerpt trimming, same markdown text and
 * table shape; this is a transcription, not a redesign).
 *
 * For every URL in the site's sitemap, fetch the page, isolate the visible
 * <main> region (or body), and look for plain-text mentions of OTHER pages'
 * target keyword (derived from URL slug + H1) that are NOT already wrapped
 * in any <a> tag. Each match becomes a "from → to (anchor)" suggestion.
 *
 * Read-only; one HTTP request per URL (via PageFetcher, 15s timeout,
 * "GSC-LinkSuggest/1.0" — see docs/REPORTS-PORTING.md, do not change).
 * SiteCatalog::sitemapUrls() returns the site's sitemap UNFILTERED; this
 * report re-applies the original command's OWN extension filter
 * (txt/xml/json/csv/webmanifest/ico/png/jpe?g/webp/gif/svg/pdf/mp4/mp3)
 * rather than relying on a shared filter, exactly like the porting guide's
 * table says.
 *
 * The original command's `buildTargets(array $urls, string $base)` took a
 * $base parameter it never actually used — dropped here since it changed
 * nothing behaviourally; every other line of logic is unchanged.
 */
final class InternalLinkSuggestReport implements Report
{
    public function __construct(
        private readonly PageFetcher $pageFetcher,
        private readonly SiteCatalog $siteCatalog,
    ) {
    }

    public static function key(): string
    {
        return 'internal-link-suggest';
    }

    /** @return list<string> */
    public static function requires(): array
    {
        return ['page_fetcher', 'site_catalog'];
    }

    public function generate(array $options = []): ReportResult
    {
        $limit = max(1, (int) ($options['limit'] ?? 80));
        $targetLimit = max(1, (int) ($options['target_limit'] ?? 60));
        $minAnchor = (int) ($options['min_anchor'] ?? 4);
        $maxPerPage = max(1, (int) ($options['max_per_page'] ?? 5));

        $urls = $this->filterSitemapUrls($this->siteCatalog->sitemapUrls());

        if ($urls === []) {
            $sitemap = $this->siteCatalog->baseUrl().'/sitemap.xml';

            return ReportResult::error("No URLs from {$sitemap}");
        }

        // Build target index: URL => primary anchor phrase (longest reasonable phrase from H1 or slug)
        $targets = $this->buildTargets(array_slice($urls, 0, $targetLimit));

        $sources = array_slice($urls, 0, $limit);
        $suggestions = []; // [source_url => [ ['target'=>..., 'anchor'=>..., 'excerpt'=>...] ]]

        foreach ($sources as $src) {
            $html = $this->fetch($src);
            if ($html === '') {
                continue;
            }
            $text = $this->extractText($html);
            if ($text === '') {
                continue;
            }
            // Strip everything already inside <a> so we don't suggest a link that already exists.
            $textOutsideLinks = preg_replace('#<a\b[^>]*>.*?</a>#is', ' ', $html);
            $textOutsideLinks = $this->extractText((string) $textOutsideLinks);

            foreach ($targets as $targetUrl => $anchor) {
                if ($targetUrl === $src) {
                    continue;
                }
                if (mb_strlen($anchor) < $minAnchor) {
                    continue;
                }
                $needle = preg_quote($anchor, '#');
                if (preg_match('#\\b'.$needle.'\\b#i', $textOutsideLinks, $m, PREG_OFFSET_CAPTURE)) {
                    $offset = $m[0][1];
                    $excerpt = trim(Str::limit(
                        mb_substr($textOutsideLinks, max(0, $offset - 40), 120),
                        110,
                    ));
                    $suggestions[$src][] = [
                        'target' => $targetUrl,
                        'anchor' => $anchor,
                        'excerpt' => $excerpt,
                    ];
                    if (count($suggestions[$src]) >= $maxPerPage) {
                        break;
                    }
                }
            }
        }

        $total = array_sum(array_map('count', $suggestions));

        $markdown = $this->buildMarkdown($suggestions);
        $summary = sprintf('%d suggestion(s) across %d page(s).', $total, count($suggestions));

        $data = [
            'targets_indexed' => count($targets),
            'total' => $total,
            'pages_with_suggestions' => count($suggestions),
            'suggestions' => $suggestions,
        ];

        return ReportResult::ok($markdown, $summary, $data);
    }

    /**
     * @param  array<int, string>  $urls
     * @return array<string, string> url => anchor phrase
     */
    private function buildTargets(array $urls): array
    {
        $targets = [];
        foreach ($urls as $url) {
            $html = $this->fetch($url);
            $anchor = null;
            if ($html !== '' && preg_match('#<h1[^>]*>(.*?)</h1>#is', $html, $m)) {
                $anchor = trim(html_entity_decode(strip_tags($m[1]), ENT_QUOTES | ENT_HTML5));
            }
            if ($anchor === null || $anchor === '') {
                $path = (string) parse_url($url, PHP_URL_PATH);
                $slug = trim(basename($path), '/');
                $anchor = ucwords(str_replace('-', ' ', $slug));
            }
            // Trim to a short, link-worthy anchor (max 6 words).
            $words = preg_split('/\s+/', $anchor) ?: [];
            $anchor = trim(implode(' ', array_slice($words, 0, 6)));
            // Drop super-generic anchors that would create noise.
            if (in_array(strtolower($anchor), ['home', 'about', 'contact', 'services', 'projects', ''], true)) {
                continue;
            }
            $targets[$url] = $anchor;
        }

        return $targets;
    }

    private function fetch(string $url): string
    {
        $result = $this->pageFetcher->fetch($url, 15, 'GSC-LinkSuggest/1.0');

        return $result->successful ? $result->body : '';
    }

    private function extractText(string $html): string
    {
        // Isolate <main>...</main> if present, else <body>.
        if (preg_match('#<main\b[^>]*>(.*?)</main>#is', $html, $m)) {
            $html = $m[1];
        } elseif (preg_match('#<body\b[^>]*>(.*?)</body>#is', $html, $m)) {
            $html = $m[1];
        }
        $html = (string) preg_replace('#<(script|style|noscript|nav|footer|header|svg)\b[^>]*>.*?</\1>#is', ' ', $html);
        $text = html_entity_decode(strip_tags($html), ENT_QUOTES | ENT_HTML5);

        return trim((string) preg_replace('/\s+/u', ' ', $text));
    }

    /**
     * @param  array<string, array<int, array<string, string>>>  $suggestions
     */
    private function buildMarkdown(array $suggestions): string
    {
        $md = "# Internal-link suggestions\n\n";
        $md .= 'Run: '.Carbon::now()->toIso8601String()."\n\n";
        $md .= "Each row: an unlinked plain-text mention of another page's anchor phrase. Add an `<a href=\"...\">` only where editorially natural.\n\n";
        foreach ($suggestions as $src => $list) {
            $md .= "## From: {$src}\n\n";
            $md .= "| Target | Anchor | Excerpt |\n|---|---|---|\n";
            foreach ($list as $s) {
                $md .= sprintf(
                    "| %s | %s | …%s… |\n",
                    $s['target'],
                    str_replace('|', '\\|', $s['anchor']),
                    str_replace(['|', "\n"], ['\\|', ' '], $s['excerpt']),
                );
            }
            $md .= "\n";
        }

        return $md;
    }

    /**
     * @param  list<string>  $urls
     * @return list<string>
     */
    private function filterSitemapUrls(array $urls): array
    {
        return array_values(array_filter($urls, function (string $u): bool {
            $p = (string) parse_url($u, PHP_URL_PATH);

            return ! preg_match('#\.(txt|xml|json|csv|webmanifest|ico|png|jpe?g|webp|gif|svg|pdf|mp4|mp3)$#i', $p);
        }));
    }
}
