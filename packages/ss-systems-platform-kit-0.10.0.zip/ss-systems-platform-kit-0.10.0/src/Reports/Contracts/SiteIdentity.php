<?php

namespace SsSystems\Platform\Reports\Contracts;

/**
 * The NAP (name/address/phone) and GBP-service-catalog facts SeoGbpParity
 * reads from config today — gsc's chain is
 * geo-answers.meta.phone ?? seo.phone ?? socials.phone ?? services.business.phone
 * for phone, seo.address ?? socials.address ?? services.business.address for
 * address, and config('gbp-services.services', config('gbp-services', []))
 * for the service catalog. A site adapter reads whatever ITS own config
 * uses and answers the same shape.
 *
 * Capability key: `site_identity`.
 */
interface SiteIdentity
{
    /**
     * The phone every landing page is expected to show. Raw (not yet
     * digit-normalized) — SeoGbpParity::normalizePhone() stays in the
     * ported report, since it's pure transformation with no external
     * dependency. Null when nothing is configured (the phone-parity check
     * is then skipped, exactly like today).
     */
    public function expectedPhone(): ?string;

    /** The address fragment every landing page is expected to contain verbatim. Null when nothing is configured. */
    public function expectedAddress(): ?string;

    /**
     * The site's raw GBP service catalog, in EXACTLY the shape gsc's
     * config('gbp-services.services', config('gbp-services', [])) returns:
     * either a flat list of name strings, or an assoc array of
     * ['name' => ..., 'slug' => ?..., 'pillar' => bool, 'parent' => ?slug]
     * entries keyed by slug or numeric index. SeoGbpParity::buildCatalog()
     * normalizes this shape itself (kept verbatim in the ported report) —
     * this method hands back the SAME raw structure a site's config file
     * holds, not a pre-normalized one, so that normalization logic has
     * exactly one owner.
     *
     * @return array<int|string, mixed>
     */
    public function gbpServices(): array;

    /**
     * child slug => the slug it should be compared against for parity
     * (gsc's config('gbp-services.slug_aliases', [])). [] when the site
     * declares no aliases.
     *
     * @return array<string, string>
     */
    public function gbpServiceSlugAliases(): array;
}
