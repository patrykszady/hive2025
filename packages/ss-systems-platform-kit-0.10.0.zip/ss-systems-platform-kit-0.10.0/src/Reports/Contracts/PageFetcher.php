<?php

namespace SsSystems\Platform\Reports\Contracts;

use SsSystems\Platform\Reports\PageFetchResult;

/**
 * Fetch a single URL exactly the way every self-crawl report already does
 * it: one GET request, a bounded timeout, an identifying User-Agent, and a
 * network failure that becomes a PageFetchResult::failed() instead of a
 * thrown exception — every one of the five self-crawl commands wraps its
 * Http::get() in a try/catch(ConnectionException) that returns null/empty
 * on failure and never lets it bubble.
 *
 * Used by (with the timeout/UA each ported report must keep using — do NOT
 * standardise on one value, the commands genuinely differ):
 *   - SeoGbpParity            timeout 15, UA "GSC-GBPParity/1.0"
 *   - SeoInternalLinkSuggest  timeout 15, UA "GSC-LinkSuggest/1.0"
 *   - SeoSchemaAudit          timeout 20, UA "GSC-SchemaAudit/1.0"
 *   - SeoHealthCheck          timeout 20, UA "GS-SEO-Health/1.0"
 *   - SeoAreaPagesAudit       timeout 20, UA "GS-SEO-Audit/1.0"
 *
 * Capability key: `page_fetcher`.
 */
interface PageFetcher
{
    public function fetch(string $url, int $timeoutSeconds, string $userAgent): PageFetchResult;
}
