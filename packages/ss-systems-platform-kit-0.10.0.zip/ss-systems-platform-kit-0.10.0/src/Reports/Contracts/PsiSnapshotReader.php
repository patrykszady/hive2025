<?php

namespace SsSystems\Platform\Reports\Contracts;

/**
 * Raw PageSpeed Insights snapshots (psi_snapshots — one row per URL per
 * strategy per sync day) for SeoCwvTemplate, which does its own template
 * classification (URL pattern → home/service/area/project/other), p75
 * bucketing, and field-vs-lab LCP fallback in PHP. This interface hands
 * back one row per snapshot, unaggregated — the report owns all of that
 * logic, transcribed verbatim from SeoCwvTemplate::aggregateWindow()/
 * classify()/p75Int()/p75Float().
 *
 * Capability key: `psi_snapshots`.
 */
interface PsiSnapshotReader
{
    /**
     * @return list<array{
     *     url: string,
     *     strategy: string,
     *     field_lcp_ms: ?int,
     *     field_inp_ms: ?int,
     *     field_cls: ?float,
     *     lab_lcp_ms: ?int,
     *     performance: ?int,
     * }>
     */
    public function snapshots(string $from, string $to): array;
}
