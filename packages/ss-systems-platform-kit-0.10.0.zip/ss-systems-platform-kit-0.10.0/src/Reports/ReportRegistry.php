<?php

namespace SsSystems\Platform\Reports;

/**
 * The ten shared SEO reports: key → class → the artisan command a site's
 * thin wrapper mirrors → the capability keys it cannot run without →
 * documented options → label/description for the admin screen. Copied from
 * gs.construction's config/seo-reports.php (label/description/command) and
 * extended with `class`/`requires`/`options` so a site builds ITS OWN
 * config/seo-reports.php (or the equivalent registry read) from this
 * instead of hand-listing commands — the exact mistake that left
 * jpeterson-design naming ten commands it never had.
 *
 * `requires` is the explicit, checkable replacement for "does the artisan
 * class happen to exist": a site checks its own bound capabilities against
 * this BEFORE ever calling generate(), and shows an honest "not available"
 * state instead of a caught CommandNotFoundException. See
 * docs/REPORTS-PORTING.md.
 *
 * Two reports named in gsc's original estate — competitor-discovery and
 * backlinks-monitor — are NOT here: both depended on Brave Search, which
 * has since been removed from the estate entirely. They do not exist on
 * any site any more and must not be reintroduced by a future port.
 *
 * Only `content-decay` has a real class today (ContentDecayReport, the
 * reference port). The other nine `class` values name classes that do NOT
 * YET EXIST — see docs/REPORTS-PORTING.md, "How to port a report". PHP's
 * `::class` resolves to a fully-qualified name string at compile time
 * without needing the class to exist or be autoloaded, so referencing them
 * here ahead of their being written is safe; each entry becomes correct the
 * moment its class file lands.
 */
final class ReportRegistry
{
    /**
     * @var array<string, array{
     *     label: string,
     *     description: string,
     *     command: string,
     *     class: class-string<Report>,
     *     requires: list<string>,
     *     options: array<string, string>,
     * }>
     */
    private const REPORTS = [
        'content-decay' => [
            'label' => 'Content decay',
            'description' => 'Pages losing clicks or position week over week.',
            'command' => 'seo:content-decay --markdown',
            'class' => ContentDecayReport::class,
            'requires' => ['query_metrics', 'cache'],
            'options' => [
                'window' => 'Days in each comparison window (default 28)',
                'min_impressions' => 'Ignore pages with fewer impressions in the prior window (default 50)',
                'click_drop' => 'Flag pages losing >=N% clicks (default 20)',
                'pos_drop' => 'Flag pages whose average position worsened by >=N (default 2)',
                'limit' => 'Max rows per section (default 40)',
            ],
        ],
        'content-gap' => [
            'label' => 'Content gap (rank 8–20)',
            'description' => 'Striking-distance queries clustered into content briefs.',
            'command' => 'seo:content-gap --markdown',
            'class' => \SsSystems\Platform\Reports\ContentGapReport::class,
            'requires' => ['query_metrics'],
            'options' => [
                'days' => 'Days back to aggregate (default 28)',
                'min_pos' => 'Minimum average position to consider (default 8)',
                'max_pos' => 'Maximum average position to consider (default 20)',
                'min_impressions' => 'Drop queries with fewer impressions (default 50)',
                'max_clusters' => 'Show top N clusters (default 20)',
            ],
        ],
        'cwv-template' => [
            'label' => 'CWV by template',
            'description' => 'p75 LCP/INP/CLS per page template with regression alerts.',
            'command' => 'seo:cwv-template --markdown',
            'class' => \SsSystems\Platform\Reports\CwvTemplateReport::class,
            'requires' => ['psi_snapshots'],
            'options' => [
                'window' => 'Days in each comparison window (default 7)',
                'lcp_regress' => 'Flag templates whose p75 field LCP grew by >=N ms (default 150)',
                'lab_lcp_regress' => 'LCP threshold (ms) for lab-only buckets (default 500)',
                'inp_regress' => 'Flag templates whose p75 INP grew by >=N ms (default 40)',
                'cls_regress' => 'Flag templates whose p75 CLS grew by >=N (default 0.02)',
                'min_samples' => 'Require at least N samples in BOTH windows before flagging (default 10)',
            ],
        ],
        'gbp-parity' => [
            'label' => 'GBP / local-SEO parity',
            'description' => 'NAP consistency and Google Business Profile ↔ site service parity.',
            'command' => 'seo:gbp-parity --markdown',
            'class' => \SsSystems\Platform\Reports\GbpParityReport::class,
            'requires' => ['page_fetcher', 'site_catalog', 'site_identity'],
            'options' => [
                'landing_pages' => 'CSV of paths to check for NAP (default /,/contact,/about)',
            ],
        ],
        'internal-link-suggest' => [
            'label' => 'Internal-link suggestions',
            'description' => 'Unlinked plain-text mentions of other pages’ anchors.',
            'command' => 'seo:internal-link-suggest --markdown',
            'class' => \SsSystems\Platform\Reports\InternalLinkSuggestReport::class,
            'requires' => ['page_fetcher', 'site_catalog'],
            'options' => [
                'limit' => 'Max URLs to scan as sources (default 80)',
                'target_limit' => 'Max target pages to consider (default 60)',
                'min_anchor' => 'Minimum anchor-word length (default 4)',
                'max_per_page' => 'Cap suggestions per source page (default 5)',
            ],
        ],
        'schema-audit' => [
            'label' => 'Schema audit',
            'description' => 'JSON-LD coverage and validity sweep.',
            'command' => 'seo:schema-audit --markdown',
            'class' => \SsSystems\Platform\Reports\SchemaAuditReport::class,
            'requires' => ['page_fetcher', 'site_catalog', 'cache'],
            'options' => [
                'urls' => 'CSV of explicit URLs to audit (overrides the sitemap)',
                'limit' => 'Max URLs (default 80)',
            ],
        ],
        'area-pages-audit' => [
            'label' => 'Area pages (thin/dup)',
            'description' => 'Thin pages and near-duplicate clusters across per-area landing pages.',
            'command' => 'seo:area-pages-audit --markdown',
            'class' => \SsSystems\Platform\Reports\AreaPagesAuditReport::class,
            'requires' => ['area_catalog', 'page_fetcher', 'site_catalog'],
            'options' => [
                'sample' => 'Number of areas to sample, 0 = all (default 10)',
                'variants' => 'CSV of page variants per area (default home,contact,services-kitchen,services-bathroom,services-home)',
                'thin' => 'Word-count threshold considered "thin" (default 350)',
                'sim' => 'Jaccard threshold for near-duplicate clustering, 0..1 (default 0.85)',
                'shingle' => 'N-gram size for similarity (default 5)',
            ],
        ],
        'health-check' => [
            'label' => 'Local SEO health-check',
            'description' => 'Composite 0–100 score per URL across title, meta, H1, alt, links, schema, canonical, word count.',
            'command' => 'seo:health-check --markdown --min-score=0',
            'class' => \SsSystems\Platform\Reports\HealthCheckReport::class,
            'requires' => ['page_fetcher', 'site_catalog'],
            'options' => [
                'urls' => 'CSV of explicit URLs (overrides the sitemap)',
                'limit' => 'Max URLs (default 60)',
                'min_score' => 'Fail (non-zero exit) if any URL scores below this (default 80)',
            ],
        ],
        'health' => [
            'label' => 'SEO health',
            'description' => 'Unified 0–100 SEO pillar dashboard with freshness, rankings, GBP and on-page signals.',
            'command' => 'seo:health --markdown',
            'class' => \SsSystems\Platform\Reports\HealthReport::class,
            // area_catalog is NOT required: a site without service-area pages
            // (jpeterson) still scores the other pillars, and the on-page
            // pillar defaults its area half when areas() is empty, exactly as
            // an empty AreaServed table did on gsc. The report still takes an
            // AreaCatalog; a site binds an empty one.
            'requires' => ['health_data', 'query_metrics'],
            'options' => [
                'quiet_on_pass' => 'Suppress non-zero exit when the score is >= 90 (default false)',
            ],
        ],
        'clarity-health' => [
            'label' => 'Clarity health',
            'description' => 'Clarity API/config status, last sync freshness, and latest behavioral metrics snapshot.',
            'command' => 'seo:clarity-health --markdown',
            'class' => \SsSystems\Platform\Reports\ClarityHealthReport::class,
            'requires' => ['clarity_metrics'],
            'options' => [],
        ],
    ];

    /** @return array<string, array{label: string, description: string, command: string, class: class-string<Report>, requires: list<string>, options: array<string, string>}> */
    public static function all(): array
    {
        return self::REPORTS;
    }

    /** @return array{label: string, description: string, command: string, class: class-string<Report>, requires: list<string>, options: array<string, string>} */
    public static function get(string $key): array
    {
        return self::REPORTS[$key] ?? throw new \InvalidArgumentException("Unknown report key: {$key}");
    }

    /**
     * Every report whose `requires` are all present in $providedCapabilities
     * — the check a site makes before showing a "Run" button, and again
     * before actually calling generate().
     *
     * @param  list<string>  $providedCapabilities
     * @return array<string, array{label: string, description: string, command: string, class: class-string<Report>, requires: list<string>, options: array<string, string>}>
     */
    public static function availableFor(array $providedCapabilities): array
    {
        return array_filter(
            self::REPORTS,
            fn (array $report): bool => array_diff($report['requires'], $providedCapabilities) === [],
        );
    }
}
