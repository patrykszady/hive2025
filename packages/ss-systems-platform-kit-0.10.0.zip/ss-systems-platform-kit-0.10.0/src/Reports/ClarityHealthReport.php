<?php

namespace SsSystems\Platform\Reports;

use Illuminate\Support\Carbon;
use SsSystems\Platform\Reports\Contracts\ClarityMetricsReader;

/**
 * Health check for the Microsoft Clarity integration — ported verbatim from
 * gs.construction's app/Console/Commands/SeoClarityHealth.php (same
 * thresholds, same wording, same markdown headings/tables/ordering; this is
 * a transcription, not a redesign). See docs/REPORTS-PORTING.md.
 *
 * Configured? A live call to Clarity's Data Export API reachable? The
 * stored clarity_daily_metrics rows fresh? Does the latest day's
 * JS-error-per-session rate spike against a trailing baseline, and — if
 * so — does the on-site error beacon corroborate it (Clarity counts every
 * script error including cross-origin noise the beacon deliberately
 * drops)?
 *
 * The original command's console output (`$this->line(...)`,
 * `$this->error(...)`, `$this->warn(...)`) has no analogue in the kit —
 * pure PHP, no artisan Command. Every line it printed instead becomes a key
 * in `ReportResult::data`, so a site's thin wrapper can reproduce the exact
 * same console output. Likewise, the original command's non-zero-exit
 * decisions (never configured; stale stored data; a beacon-corroborated
 * spike) travel as `data['exit'] = 'failure'|'success'` plus
 * `data['failure_reason']`, since the kit's `generate()` returns a
 * ReportResult, never a process exit code — the site's wrapper reads
 * `data['exit']` and returns `self::FAILURE`/`self::SUCCESS` itself. A site
 * with Clarity entirely unbound never gets this far: `ReportRegistry`'s
 * `requires()` = `['clarity_metrics']` means the wrapper checks
 * availability before calling generate() at all, but a bound reader whose
 * `isConfigured()` is false still reaches generate() (a site CAN bind the
 * adapter and still not have finished setup) — see the `unavailable` branch
 * below for that case specifically.
 */
final class ClarityHealthReport implements Report
{
    public function __construct(
        private readonly ClarityMetricsReader $clarity,
    ) {
    }

    public static function key(): string
    {
        return 'clarity-health';
    }

    /** @return list<string> */
    public static function requires(): array
    {
        return ['clarity_metrics'];
    }

    public function generate(array $options = []): ReportResult
    {
        $isConfigured = $this->clarity->isConfigured();

        // Not merely "ran and found nothing" — an unconfigured integration
        // has no clarity_metrics to read at all, so this is `unavailable`
        // (not `ok`/`error`) with the capability key as `missing`, exactly
        // as any other report reports a capability it cannot get data from.
        if (! $isConfigured) {
            return ReportResult::unavailable(['clarity_metrics'], 'Clarity is not configured.');
        }

        // Through the same Settings class the reader itself reads, so a
        // project id stored via /admin (not env) is not read as "(empty)"
        // here while a live call above just fetched real data with it.
        $projectId = (string) ($this->clarity->projectId() ?? '');

        $apiReachable = false;
        $apiError = null;
        $liveSnapshot = $this->clarity->fetchLiveSnapshot();
        if ($liveSnapshot !== null) {
            $apiReachable = true;
        } else {
            $apiError = $this->clarity->lastError();
        }

        $latest = $this->clarity->latestStoredMetric();
        $rowsCount = $this->clarity->storedRowCount();

        $latestDate = $latest['date'] ?? null;
        $latestDateCarbon = $latestDate !== null ? Carbon::parse($latestDate) : null;
        $latestAge = $latestDateCarbon?->diffForHumans();

        // JS error spike detection. Clarity's API gives a count only (no message
        // or stack). Compare the latest day's errors-per-session rate against
        // the trailing baseline so a regression (e.g. a broken deploy) is
        // flagged proactively.
        $spike = $this->detectScriptErrorSpike($latest);

        $lines = [];
        $lines[] = '=== Clarity Health ===';
        $lines[] = 'Configured: '.($isConfigured ? 'yes' : 'no');
        $lines[] = 'API reachable: '.($apiReachable ? 'yes' : 'no');
        $lines[] = 'Project ID: '.($projectId !== '' ? $projectId : '(empty)');
        $lines[] = 'Stored rows: '.$rowsCount;
        $lines[] = 'Latest date: '.($latestDate ?? '(none)');
        $lines[] = 'Latest age: '.($latestAge ?? '(none)');

        if ($latest) {
            $lines[] = 'Latest metrics: '.json_encode([
                'sessions' => $latest['sessions'],
                'users' => $latest['users'],
                'pageviews' => $latest['pageviews'],
                'scroll_depth' => $latest['scroll_depth'],
                'active_time_seconds' => $latest['active_time_seconds'],
                'bounce_rate' => $latest['bounce_rate'],
                'dead_clicks' => $latest['dead_clicks'],
                'rage_clicks' => $latest['rage_clicks'],
                'quickbacks' => $latest['quickbacks'],
                'script_errors' => $latest['script_errors'],
                'error_clicks' => $latest['error_clicks'],
            ], JSON_UNESCAPED_SLASHES);
        }

        if ($spike !== null) {
            $lines[] = '⚠ JS error spike: '.$spike['summary'];
        }

        if (! $apiReachable && $apiError) {
            $lines[] = 'API error: '.$apiError;
        }

        // A completely unconfigured integration is a real setup problem —
        // unreachable this far since we already returned `unavailable`
        // above, kept only to mirror the original's branch order.
        $exit = 'success';
        $failureReason = null;

        // The meaningful failure is STALE stored data — that means the daily
        // sync pipeline is actually broken. Clarity's Data Export API has a very
        // small daily request quota that the 08:32 sync usually consumes, so the
        // health check's own live call at 10:10 often returns a rate-limit error
        // even when the integration is perfectly healthy. Treat an unreachable
        // live API as a hard failure ONLY when stored data is also stale;
        // otherwise it is noise and was producing a false-positive daily error.
        $staleThresholdDays = 3;
        $isStale = $latestDateCarbon === null
            || $latestDateCarbon->lt(Carbon::now()->subDays($staleThresholdDays)->startOfDay());

        $staleMessage = null;
        $unreachableNotice = null;

        if ($isStale) {
            $exit = 'failure';
            $failureReason = 'stale_data';
            $staleMessage = 'Clarity data is stale (latest: '.($latestDate ?? 'none').') — sync pipeline may be broken.';
            $lines[] = $staleMessage;
        } else {
            if (! $apiReachable) {
                $unreachableNotice = 'Clarity live API unreachable at health-check time, but stored data is fresh (likely the daily export quota). Not treating as a failure.';
                $lines[] = $unreachableNotice;
            }

            // Non-zero exit on a confirmed spike so the scheduler's onFailure hook
            // logs it (matches seo:gsc-critical-health behaviour) — but only when
            // our own error beacon corroborates it. Clarity counts ALL script
            // errors including cross-origin ones (Cloudflare challenge scripts,
            // tag managers) that the beacon deliberately drops as un-actionable;
            // a spike with zero beacon-captured errors is third-party noise, not
            // a broken deploy.
            if ($spike !== null) {
                $beaconErrors = $this->clarity->beaconErrorCount(Carbon::now()->subHours(36));

                if ($beaconErrors > 0) {
                    $exit = 'failure';
                    $failureReason = 'spike_corroborated';
                    $spikeMessage = "Beacon corroborates the spike ({$beaconErrors} client errors in 36h) — treating as a real regression.";
                    $lines[] = $spikeMessage;
                    $spike['beacon_message'] = $spikeMessage;
                    $spike['beacon_errors'] = $beaconErrors;
                    $spike['beacon_corroborated'] = true;
                } else {
                    $notCorroboratedMessage = 'Spike NOT corroborated by the on-site error beacon (0 client errors in 36h) — almost certainly cross-origin/third-party noise. Not failing.';
                    $lines[] = $notCorroboratedMessage;
                    $spike['beacon_message'] = $notCorroboratedMessage;
                    $spike['beacon_errors'] = $beaconErrors;
                    $spike['beacon_corroborated'] = false;
                    // Mirrors the original's logger()->warning() call — the site's
                    // thin wrapper reads data['alert'] and logs it, same pattern as
                    // ContentDecayReport::alert().
                    $spike['alert_message'] = 'seo:clarity-health: JS error spike without beacon corroboration (third-party noise)';
                }
            }
        }

        $markdown = $this->buildMarkdown(
            isConfigured: $isConfigured,
            apiReachable: $apiReachable,
            projectId: $projectId,
            rowsCount: $rowsCount,
            latest: $latest,
            apiError: $apiError,
            spike: $spike,
        );

        $summary = sprintf(
            'Configured: %s. API reachable: %s. Stored rows: %d. Latest: %s.',
            $isConfigured ? 'yes' : 'no',
            $apiReachable ? 'yes' : 'no',
            $rowsCount,
            $latestDate ?? '(none)',
        );

        $data = [
            'configured' => $isConfigured,
            'api_reachable' => $apiReachable,
            'project_id' => $projectId,
            'stored_rows' => $rowsCount,
            'latest_date' => $latestDate,
            'latest_age' => $latestAge,
            'latest' => $latest,
            'api_error' => $apiError,
            'spike' => $spike,
            'is_stale' => $isStale,
            'stale_message' => $staleMessage,
            'unreachable_notice' => $unreachableNotice,
            'console_lines' => $lines,
            'exit' => $exit,
            'failure_reason' => $failureReason,
        ];

        return ReportResult::ok($markdown, $summary, $data);
    }

    /**
     * Compare the latest day's JS-error-per-session rate against a trailing
     * baseline. Returns null when there is no spike (or insufficient data).
     *
     * @param  array{date: string, sessions: int, users: int, pageviews: int, scroll_depth: float, active_time_seconds: int, bounce_rate: float, dead_clicks: int, rage_clicks: int, quickbacks: int, script_errors: int, error_clicks: int}|null  $latest
     * @return array{summary:string,latest_rate:float,baseline_rate:float,errors:int}|null
     */
    private function detectScriptErrorSpike(?array $latest): ?array
    {
        if (! $latest || (int) $latest['sessions'] <= 0) {
            return null;
        }

        // Need at least a handful of errors before alerting — tiny counts on
        // low-traffic days are noise, not regressions.
        $errors = (int) $latest['script_errors'];
        if ($errors < 5) {
            return null;
        }

        // Trailing baseline: up to 14 prior days, excluding the latest row.
        $baselineRows = $this->clarity->baselineMetrics($latest['date'], 14);

        if (count($baselineRows) < 3) {
            return null; // not enough history to judge
        }

        $baseSessions = 0;
        $baseErrors = 0;
        foreach ($baselineRows as $row) {
            $baseSessions += (int) $row['sessions'];
            $baseErrors += (int) $row['script_errors'];
        }
        if ($baseSessions <= 0) {
            return null;
        }

        $latestRate = $errors / max((int) $latest['sessions'], 1);
        $baselineRate = $baseErrors / $baseSessions;

        // Alert when the latest rate is at least 2x the baseline. Use a small
        // floor so a baseline of ~0 still requires a meaningful absolute rate.
        $threshold = max($baselineRate * 2, 0.05);
        if ($latestRate < $threshold) {
            return null;
        }

        $summary = sprintf(
            '%d errors across %d sessions (%.1f%% of sessions) vs baseline %.1f%% — %s.',
            $errors,
            (int) $latest['sessions'],
            $latestRate * 100,
            $baselineRate * 100,
            $baselineRate > 0 ? sprintf('%.1fx', $latestRate / $baselineRate) : 'new (no prior errors)',
        );

        return [
            'summary' => $summary,
            'latest_rate' => round($latestRate, 4),
            'baseline_rate' => round($baselineRate, 4),
            'errors' => $errors,
        ];
    }

    /**
     * @param  array{date: string, sessions: int, users: int, pageviews: int, scroll_depth: float, active_time_seconds: int, bounce_rate: float, dead_clicks: int, rage_clicks: int, quickbacks: int, script_errors: int, error_clicks: int}|null  $latest
     * @param  array{summary:string,latest_rate:float,baseline_rate:float,errors:int}|null  $spike
     */
    private function buildMarkdown(
        bool $isConfigured,
        bool $apiReachable,
        string $projectId,
        int $rowsCount,
        ?array $latest,
        ?string $apiError,
        ?array $spike = null,
    ): string {
        $latestDate = $latest['date'] ?? null;
        $latestDateCarbon = $latestDate !== null ? Carbon::parse($latestDate) : null;

        $lines = [];
        $lines[] = '# Clarity health';
        $lines[] = '';
        $lines[] = 'Generated: '.Carbon::now()->toIso8601String();
        $lines[] = '';
        $lines[] = '## Status';
        $lines[] = '';
        $lines[] = '- Configured: '.($isConfigured ? 'yes' : 'no');
        $lines[] = '- API reachable: '.($apiReachable ? 'yes' : 'no');
        $lines[] = '- Project ID: '.($projectId !== '' ? $projectId : '(empty)');
        $lines[] = '- Stored rows: '.$rowsCount;
        $lines[] = '- Latest row date: '.($latestDateCarbon?->toDateString() ?? '(none)');
        $lines[] = '- Latest row age: '.($latestDateCarbon?->diffForHumans() ?? '(none)');

        if ($latest) {
            $lines[] = '';
            $lines[] = '## Latest metrics';
            $lines[] = '';
            $lines[] = '| Metric | Value |';
            $lines[] = '|---|---:|';
            $lines[] = '| sessions | '.(int) $latest['sessions'].' |';
            $lines[] = '| users | '.(int) $latest['users'].' |';
            $lines[] = '| pageviews | '.(int) $latest['pageviews'].' |';
            $lines[] = '| scroll depth | '.(float) $latest['scroll_depth'].' |';
            $lines[] = '| active time seconds | '.(int) $latest['active_time_seconds'].' |';
            $lines[] = '| bounce rate | '.(float) $latest['bounce_rate'].' |';
            $lines[] = '| dead clicks | '.(int) $latest['dead_clicks'].' |';
            $lines[] = '| rage clicks | '.(int) $latest['rage_clicks'].' |';
            $lines[] = '| quickbacks | '.(int) $latest['quickbacks'].' |';
            $lines[] = '| script errors | '.(int) $latest['script_errors'].' |';
            $lines[] = '| error clicks | '.(int) $latest['error_clicks'].' |';
        }

        if ($spike !== null) {
            $lines[] = '';
            $lines[] = '## ⚠ JavaScript error spike';
            $lines[] = '';
            $lines[] = '- '.$spike['summary'];
            $lines[] = '- Latest rate: '.($spike['latest_rate'] * 100).'% of sessions';
            $lines[] = '- Baseline rate: '.($spike['baseline_rate'] * 100).'% of sessions';
            $lines[] = '';
            $lines[] = 'Clarity reports counts only. See `storage/logs/client-errors-*.log`'
                .' (via /log-viewer) for the actual messages and stack traces.';
        }

        if (! $apiReachable && $apiError) {
            $lines[] = '';
            $lines[] = '## API error';
            $lines[] = '';
            $lines[] = '- '.$apiError;
        }

        return implode("\n", $lines)."\n";
    }
}
