<?php

namespace SsSystems\Platform\Reports;

/**
 * One SEO report generator — the kit half of the "kit owns the algorithm,
 * site owns a thin artisan wrapper" split (see docs/REPORTS-PORTING.md).
 *
 * A report never touches Eloquent, DB, Schema, Http, Cache facades, or
 * config() directly: every read goes through one of the small interfaces
 * under Contracts/, injected through the constructor, so the exact same
 * class runs unmodified on gs.construction, jpeterson-design, or any future
 * site that binds the capabilities it needs.
 */
interface Report
{
    /**
     * The registry key — matches gsc's config/seo-reports.php key, the
     * markdown filename (storage/app/reports/{key}.md), and
     * ReportRegistry::all()'s array key.
     */
    public static function key(): string;

    /**
     * Capability keys (see ReportRegistry's named keys: query_metrics,
     * psi_snapshots, page_fetcher, site_catalog, site_identity,
     * area_catalog, health_data, clarity_metrics, cache) this report cannot
     * produce anything without. A site that has not bound one of these
     * should never call generate() at all — check requires() against what
     * it has bound and return ReportResult::unavailable() instead. This is
     * the fix for jpeterson-design's actual bug: today availability is
     * "does the artisan class happen to exist", an accident; requires()
     * makes it an explicit, checkable fact.
     *
     * @return list<string>
     */
    public static function requires(): array;

    /**
     * @param  array<string, mixed>  $options  mirrors the artisan command's own --options (snake_case keys — see ReportRegistry for the exact set and defaults per report).
     */
    public function generate(array $options = []): ReportResult;
}
