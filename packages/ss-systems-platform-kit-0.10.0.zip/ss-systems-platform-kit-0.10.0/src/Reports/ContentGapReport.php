<?php

namespace SsSystems\Platform\Reports;

use Illuminate\Support\Carbon;
use SsSystems\Platform\Reports\Contracts\QueryMetricsReader;

/**
 * Content / topic-cluster gap planner — ported verbatim from
 * gs.construction's app/Console/Commands/SeoContentGap.php (same
 * thresholds, same clustering algorithm, same markdown text and heading
 * order; this is a transcription, not a redesign).
 *
 * Pulls queries in the rank-band [min_pos, max_pos] (default 8..20) with
 * at least min_impressions impressions in the window — i.e. queries the
 * site already "almost" ranks for — and groups them by simple token-overlap
 * clustering on the query text. Each cluster becomes a candidate content
 * brief or page-expansion target.
 *
 * The original command's own SUM/GROUP BY/HAVING query over
 * gsc_query_metrics IS QueryMetricsReader::queryPageMetrics() — that
 * interface method was written for this report and already returns the
 * impression-weighted average position (unrounded; this report rounds it,
 * exactly like the original did after receiving `wpos / impr`). This
 * report still guards against a zero-impression row before trusting that
 * position, exactly like the original's `if ($impr <= 0) continue;`, even
 * though no known adapter can produce one past its own HAVING clause.
 *
 * The original command, when nothing falls in the rank band, warns on the
 * console and returns WITHOUT writing a markdown file even if --markdown
 * was passed — that maps to ReportResult::unavailable(), the one status
 * that produces no markdown, rather than STATUS_OK with empty sections.
 */
final class ContentGapReport implements Report
{
    public function __construct(
        private readonly QueryMetricsReader $queryMetrics,
    ) {
    }

    public static function key(): string
    {
        return 'content-gap';
    }

    /** @return list<string> */
    public static function requires(): array
    {
        return ['query_metrics'];
    }

    public function generate(array $options = []): ReportResult
    {
        $days = max(1, (int) ($options['days'] ?? 28));
        $to = Carbon::today();
        $from = $to->copy()->subDays($days - 1);

        $minImpressions = (int) ($options['min_impressions'] ?? 50);
        $minPos = (float) ($options['min_pos'] ?? 8);
        $maxPos = (float) ($options['max_pos'] ?? 20);
        $maxClusters = (int) ($options['max_clusters'] ?? 20);

        $rows = $this->queryMetrics->queryPageMetrics($from->toDateString(), $to->toDateString(), $minImpressions);

        $candidates = [];
        foreach ($rows as $r) {
            $impr = (int) $r['impressions'];
            if ($impr <= 0) {
                continue;
            }
            $pos = (float) $r['position'];
            if ($pos < $minPos || $pos > $maxPos) {
                continue;
            }
            $candidates[] = [
                'query' => (string) $r['query'],
                'page' => (string) ($r['page'] ?? ''),
                'impr' => $impr,
                'clicks' => (int) $r['clicks'],
                'pos' => round($pos, 2),
            ];
        }

        if (empty($candidates)) {
            return ReportResult::unavailable(
                [],
                'No rank-band queries found in window. Make sure seo:gsc-sync has been run.',
            );
        }

        $clusters = $this->cluster($candidates);
        usort($clusters, fn (array $a, array $b) => $b['impr'] <=> $a['impr']);
        $clusters = array_slice($clusters, 0, $maxClusters);

        $markdown = $this->buildMarkdown($clusters, $from, $to);

        $totalQueries = array_sum(array_map(fn (array $c): int => count($c['queries']), $clusters));
        $summary = sprintf('%d content-gap cluster(s) from %d queries.', count($clusters), $totalQueries);

        $data = [
            'cluster_count' => count($clusters),
            'total_queries' => $totalQueries,
            'clusters' => $clusters,
        ];

        return ReportResult::ok($markdown, $summary, $data);
    }

    /**
     * Token-overlap clustering: queries sharing >=2 significant tokens
     * (length >= 4, not in stopword list) fall into the same cluster.
     * Copied verbatim from SeoContentGap::cluster(), including the
     * duplicated 'have' entry in the stopword list.
     *
     * @param  array<int, array<string, mixed>>  $candidates
     * @return array<int, array<string, mixed>>
     */
    private function cluster(array $candidates): array
    {
        $stop = ['near', 'best', 'cheap', 'cost', 'price', 'with', 'from', 'that', 'this', 'your', 'their', 'they', 'have', 'have'];
        $tokensOf = function (string $q) use ($stop): array {
            $q = strtolower(preg_replace('/[^a-z0-9 ]+/i', ' ', $q) ?? '');
            $parts = array_filter(preg_split('/\s+/', $q) ?: [], fn ($t) => mb_strlen($t) >= 4 && ! in_array($t, $stop, true));

            return array_values(array_unique($parts));
        };

        $items = array_map(function ($c) use ($tokensOf) {
            $c['tokens'] = $tokensOf($c['query']);

            return $c;
        }, $candidates);

        $clusters = [];
        $assigned = array_fill(0, count($items), -1);

        for ($i = 0; $i < count($items); $i++) {
            if ($assigned[$i] !== -1) {
                continue;
            }
            $cid = count($clusters);
            $assigned[$i] = $cid;
            $clusters[$cid] = ['members' => [$items[$i]], 'tokens' => $items[$i]['tokens']];
            for ($j = $i + 1; $j < count($items); $j++) {
                if ($assigned[$j] !== -1) {
                    continue;
                }
                $overlap = count(array_intersect($clusters[$cid]['tokens'], $items[$j]['tokens']));
                if ($overlap >= 2) {
                    $assigned[$j] = $cid;
                    $clusters[$cid]['members'][] = $items[$j];
                    $clusters[$cid]['tokens'] = array_values(array_unique(array_merge($clusters[$cid]['tokens'], $items[$j]['tokens'])));
                }
            }
        }

        // Summarize
        return array_map(function ($c) {
            $impr = array_sum(array_column($c['members'], 'impr'));
            $clicks = array_sum(array_column($c['members'], 'clicks'));
            $avgPos = $impr > 0
                ? array_sum(array_map(fn ($m) => $m['pos'] * $m['impr'], $c['members'])) / $impr
                : 0;
            // Theme label = most-frequent significant token
            $allTokens = [];
            foreach ($c['members'] as $m) {
                $allTokens = array_merge($allTokens, $m['tokens']);
            }
            $freq = array_count_values($allTokens);
            arsort($freq);
            $theme = implode(' + ', array_slice(array_keys($freq), 0, 3));

            return [
                'theme' => $theme,
                'impr' => $impr,
                'clicks' => $clicks,
                'avg_pos' => round($avgPos, 2),
                'queries' => $c['members'],
            ];
        }, $clusters);
    }

    /**
     * Copied verbatim from SeoContentGap::saveMarkdown(), minus the
     * Storage::put()/$this->info() side effect — the site's thin wrapper
     * does that with ->markdown. Note the heading below is hardcoded to
     * "rank-band 8–20" in the original regardless of the actual
     * min_pos/max_pos options — kept exactly as-is.
     *
     * @param  array<int, array<string, mixed>>  $clusters
     */
    private function buildMarkdown(array $clusters, Carbon $from, Carbon $to): string
    {
        $md = "# Content-gap report (rank-band 8–20)\n\n";
        $md .= 'Run: '.Carbon::now()->toIso8601String()."\n\n";
        $md .= sprintf("Window: %s..%s\n\n", $from->toDateString(), $to->toDateString());

        foreach ($clusters as $i => $c) {
            $md .= sprintf("## %d. %s\n\n", $i + 1, $c['theme']);
            $md .= sprintf(
                "- **Impressions:** %d  |  **Clicks:** %d  |  **Avg position:** %.2f  |  **Queries:** %d\n\n",
                $c['impr'], $c['clicks'], $c['avg_pos'], count($c['queries']),
            );
            $md .= "| Query | Current page | Position | Impressions |\n|---|---|---:|---:|\n";
            foreach ($c['queries'] as $q) {
                $md .= sprintf("| %s | %s | %.2f | %d |\n", $q['query'], $q['page'] ?: '—', $q['pos'], $q['impr']);
            }
            $md .= "\n";
        }
        $md .= "\n## Action\n\nFor each cluster: if a strong page exists at _Current page_, expand it (add FAQ, schema, internal links). If multiple pages compete, consolidate. If none rank well, draft a new page targeted at the cluster theme.\n";

        return $md;
    }
}
