<?php

namespace SsSystems\Platform\Reports;

use Illuminate\Support\Carbon;
use Psr\SimpleCache\CacheInterface;
use SsSystems\Platform\Reports\Contracts\PageFetcher;
use SsSystems\Platform\Reports\Contracts\SiteCatalog;

/**
 * JSON-LD schema coverage/validity sweep — ported verbatim from
 * gs.construction's app/Console/Commands/SeoSchemaAudit.php (same crawl,
 * same @type collection, same per-type required-field checks, same
 * duplicate-@id fingerprinting, same markdown headings/tables/ordering;
 * this is a transcription, not a redesign).
 *
 * Crawls the site's own sitemap (or an explicit --urls CSV), extracts every
 * `<script type="application/ld+json">` block per URL, validates it parses,
 * recursively collects every @type (including through @graph and nested
 * objects — a quirk of the original that this port keeps, e.g. a nested
 * PostalAddress shows up in the coverage table alongside its parent
 * LocalBusiness), and reports URLs with no JSON-LD at all, parse errors,
 * per-type required-property gaps, and duplicate @id values that carry
 * DIFFERENT payloads within a single page (identical repeats are the
 * recommended entity-reuse pattern and are never flagged).
 *
 * Two things this port could not carry over 1:1, both boundaries this kit
 * design deliberately keeps out of `src/Reports/`:
 *   - The original's `--sitemap` option let an operator override which
 *     sitemap URL gets crawled. `SiteCatalog::sitemapUrls()` owns fetching
 *     the site's OWN sitemap.xml at the site's own baseUrl() internally and
 *     exposes no way to point it at an arbitrary URL, so that option is
 *     dropped here — `ReportRegistry::get('schema-audit')['options']`
 *     already only documents `urls` and `limit`, confirming this was the
 *     already-decided shape, not a regression introduced by this port.
 *   - Like `SeoContentDecay`, the original decided AND emitted a
 *     `logger()->warning()`/`info()` line itself, gated by a 30-hour
 *     `Cache::add()` dedup key. The kit has no logger dependency, so that
 *     decision travels in `ReportResult::data['alert']` (PSR-16
 *     `has()`/`set()` standing in for `Cache::add()`'s atomicity — fine for
 *     a single-process run) exactly like `ContentDecayReport::alert()`; the
 *     site's thin wrapper reads it and calls logger() itself. See
 *     docs/REPORTS-PORTING.md, "The `cache` capability: no logger in the
 *     kit".
 *
 * The original's console table (`renderSummary()`) becomes structured rows
 * in `ReportResult::data` instead — `coverage`, `missing_schema`,
 * `parse_errors`, `validation_issues`, `duplicate_ids`, `rows` — so a
 * site's thin wrapper can print an equivalent table itself; `summary` is a
 * new one-line digest for a UI badge or log line (the original printed no
 * single summary line, only a progress message before crawling and a
 * console table after).
 */
final class SchemaAuditReport implements Report
{
    private const TIMEOUT_SECONDS = 20;

    private const USER_AGENT = 'GSC-SchemaAudit/1.0';

    public function __construct(
        private readonly PageFetcher $pageFetcher,
        private readonly SiteCatalog $siteCatalog,
        private readonly CacheInterface $cache,
    ) {
    }

    public static function key(): string
    {
        return 'schema-audit';
    }

    /** @return list<string> */
    public static function requires(): array
    {
        return ['page_fetcher', 'site_catalog', 'cache'];
    }

    public function generate(array $options = []): ReportResult
    {
        $limit = max(1, (int) ($options['limit'] ?? 80));
        $urls = $this->resolveUrls($options, $limit);

        if (empty($urls)) {
            return ReportResult::error('No URLs to audit.');
        }

        $rows = [];                  // per-url result
        $typeIndex = [];             // type => [urls]
        $missingSchema = [];
        $parseErrors = [];           // [url => [errors]]
        $validationIssues = [];      // [url => [issues]]
        $duplicateIds = [];          // [url => [ids]]

        foreach ($urls as $url) {
            $html = $this->fetch($url);
            if ($html === null) {
                $rows[] = ['url' => $url, 'blocks' => 0, 'types' => [], 'note' => 'fetch failed'];
                continue;
            }

            $blocks = $this->extractJsonLdBlocks($html);
            if (empty($blocks)) {
                $missingSchema[] = $url;
                $rows[] = ['url' => $url, 'blocks' => 0, 'types' => [], 'note' => 'no JSON-LD'];
                continue;
            }

            $types = [];
            // only nodes that are full definitions (have @id + @type + other props)
            // keyed as @id => list of canonical payload fingerprints.
            $fullDefFingerprints = [];
            $urlErrors = [];
            $urlIssues = [];
            foreach ($blocks as $raw) {
                $data = json_decode($raw, true);
                if (! is_array($data)) {
                    $urlErrors[] = 'parse error: '.(json_last_error_msg() ?: 'unknown');
                    continue;
                }
                $this->collectTypes($data, $types);
                $this->collectFullDefinitions($data, $fullDefFingerprints);
                $this->validateNode($data, $urlIssues);
            }

            if (! empty($urlErrors)) {
                $parseErrors[$url] = $urlErrors;
            }
            if (! empty($urlIssues)) {
                $validationIssues[$url] = array_values(array_unique($urlIssues));
            }
            // Flag @id only when it is FULL-DEFINED multiple times with
            // DIFFERENT payloads. Identical repeats are harmless duplicates and
            // not actionable.
            $dupIds = [];
            foreach ($fullDefFingerprints as $id => $fingerprints) {
                if (count(array_unique($fingerprints)) > 1) {
                    $dupIds[] = $id;
                }
            }
            if (! empty($dupIds)) {
                $duplicateIds[$url] = $dupIds;
            }

            $uniqueTypes = array_values(array_unique($types));
            sort($uniqueTypes);
            foreach ($uniqueTypes as $t) {
                $typeIndex[$t][] = $url;
            }

            $rows[] = [
                'url' => $url,
                'blocks' => count($blocks),
                'types' => $uniqueTypes,
                'note' => '',
            ];
        }

        $coverage = [];
        foreach ($typeIndex as $type => $urlsForType) {
            $coverage[$type] = count(array_unique($urlsForType));
        }
        arsort($coverage);

        $markdown = $this->buildMarkdown($rows, $coverage, $missingSchema, $parseErrors, $validationIssues, $duplicateIds);
        $summary = sprintf(
            '%d URL(s) audited, %d missing schema, %d parse error(s), %d validation issue(s), %d duplicate @id(s).',
            count($rows),
            count($missingSchema),
            count($parseErrors),
            count($validationIssues),
            count($duplicateIds),
        );

        $coverageList = [];
        foreach ($coverage as $type => $n) {
            $coverageList[] = ['type' => $type, 'urls' => $n];
        }

        $data = [
            'urls_audited' => count($rows),
            'coverage' => $coverageList,
            'missing_schema' => $missingSchema,
            'parse_errors' => $parseErrors,
            'validation_issues' => $validationIssues,
            'duplicate_ids' => $duplicateIds,
            'rows' => $rows,
        ];
        $data['alert'] = $this->alert($missingSchema, $parseErrors, $validationIssues, $duplicateIds);

        return ReportResult::ok($markdown, $summary, $data);
    }

    /**
     * @param  array<string, mixed>  $options
     * @return list<string>
     */
    private function resolveUrls(array $options, int $limit): array
    {
        $explicit = trim((string) ($options['urls'] ?? ''));
        if ($explicit !== '') {
            return array_values(array_filter(array_map('trim', explode(',', $explicit))));
        }

        // SiteCatalog::sitemapUrls() already returns a trimmed, deduplicated,
        // unfiltered <loc> list for this site's own sitemap.xml — apply this
        // command's OWN extension filter and limit on top of it, exactly
        // like the original's resolveUrls() did on its own regex extraction.
        $urls = $this->siteCatalog->sitemapUrls();
        // Only audit HTML pages — skip txt/xml/json/media assets occasionally listed in sitemaps.
        $urls = array_values(array_filter($urls, function (string $u): bool {
            $path = (string) parse_url($u, PHP_URL_PATH);

            return ! preg_match('#\.(txt|xml|json|csv|webmanifest|ico|png|jpg|jpeg|webp|gif|svg|pdf|mp4|mp3)$#i', $path);
        }));

        return array_slice($urls, 0, $limit);
    }

    private function fetch(string $url): ?string
    {
        $result = $this->pageFetcher->fetch($url, self::TIMEOUT_SECONDS, self::USER_AGENT);

        return $result->successful ? $result->body : null;
    }

    /**
     * @return array<int, string>
     */
    private function extractJsonLdBlocks(string $html): array
    {
        if (! preg_match_all('#<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>#is', $html, $m)) {
            return [];
        }

        return array_map(fn ($s) => trim((string) preg_replace('/^<!--|-->\z/', '', trim($s))), $m[1]);
    }

    /**
     * @param  array<string, mixed>|array<int, mixed>  $data
     * @param  array<int, string>  $bag
     */
    private function collectTypes(array $data, array &$bag): void
    {
        if (isset($data['@graph']) && is_array($data['@graph'])) {
            foreach ($data['@graph'] as $node) {
                if (is_array($node)) {
                    $this->collectTypes($node, $bag);
                }
            }
        }
        if (isset($data['@type'])) {
            foreach ((array) $data['@type'] as $t) {
                $bag[] = (string) $t;
            }
        }
        foreach ($data as $v) {
            if (is_array($v) && (isset($v['@type']) || isset($v['@graph']) || (function_exists('array_is_list') && array_is_list($v)))) {
                if (array_is_list($v)) {
                    foreach ($v as $item) {
                        if (is_array($item)) {
                            $this->collectTypes($item, $bag);
                        }
                    }
                } else {
                    $this->collectTypes($v, $bag);
                }
            }
        }
    }

    /**
     * Collect @id values ONLY when the node is a full definition
     * (has @id, has @type, and has other properties beyond just those two).
     * Bare {"@id":"..."} references — the recommended JSON-LD entity-reuse
     * pattern — must not count as duplicates.
     *
     * @param  array<string, mixed>|array<int, mixed>  $data
     * @param  array<int, string>  $bag
     */
    private function collectFullDefinitions(array $data, array &$bag): void
    {
        if (
            isset($data['@id'], $data['@type'])
            && is_string($data['@id'])
            && count($data) > 2
        ) {
            $types = (array) $data['@type'];
            $isImageObject = in_array('ImageObject', $types, true);

            // Logo/image entities are commonly re-declared across compatible
            // schema fragments and are generally non-actionable for this
            // audit. Focus duplicate-id warnings on higher-risk entities.
            if (! $isImageObject) {
                $canonical = $this->canonicalize($data);
                $bag[$data['@id']][] = md5((string) json_encode($canonical));
            }
        }
        foreach ($data as $v) {
            if (is_array($v)) {
                $this->collectFullDefinitions($v, $bag);
            }
        }
    }

    /**
     * Canonicalize a JSON-LD node for stable hashing.
     */
    private function canonicalize(mixed $value): mixed
    {
        if (! is_array($value)) {
            return $value;
        }

        if (array_is_list($value)) {
            return array_map(fn ($item) => $this->canonicalize($item), $value);
        }

        ksort($value);

        foreach ($value as $k => $v) {
            $value[$k] = $this->canonicalize($v);
        }

        return $value;
    }

    /**
     * @param  array<string, mixed>|array<int, mixed>  $data
     * @param  array<int, string>  $bag
     */
    private function validateNode(array $data, array &$bag): void
    {
        if (isset($data['@graph']) && is_array($data['@graph'])) {
            foreach ($data['@graph'] as $node) {
                if (is_array($node)) {
                    $this->validateNode($node, $bag);
                }
            }
        }

        $type = $data['@type'] ?? null;
        $typeStr = is_array($type) ? implode(',', $type) : (string) $type;
        if ($typeStr === '') {
            return;
        }

        $check = function (array $required) use (&$bag, $data, $typeStr): void {
            foreach ($required as $key) {
                if (! array_key_exists($key, $data) || $data[$key] === '' || $data[$key] === null) {
                    $bag[] = "{$typeStr}: missing `{$key}`";
                }
            }
        };

        $hasType = fn (string $t) => $typeStr === $t || str_contains($typeStr, $t);
        // Exact-type match (no substring). Needed for types whose names are
        // substrings of other valid types, e.g. "HowTo" vs "HowToStep"/"HowToTool".
        $typeTokens = array_map('trim', explode(',', $typeStr));
        $isType = fn (string $t) => in_array($t, $typeTokens, true);

        if ($hasType('FAQPage')) {
            if (empty($data['mainEntity']) || ! is_array($data['mainEntity'])) {
                $bag[] = 'FAQPage: empty `mainEntity`';
            }
        }
        if ($hasType('BreadcrumbList')) {
            if (empty($data['itemListElement']) || ! is_array($data['itemListElement'])) {
                $bag[] = 'BreadcrumbList: empty `itemListElement`';
            }
        }
        if ($hasType('Service')) {
            $check(['name', 'provider']);
        }
        if ($hasType('LocalBusiness') || $hasType('GeneralContractor') || $hasType('HomeAndConstructionBusiness')) {
            $check(['name', 'address']);
        }
        if ($hasType('Article') || $hasType('BlogPosting') || $hasType('NewsArticle')) {
            $check(['headline', 'author', 'datePublished']);
        }
        if ($hasType('Review')) {
            $check(['author', 'reviewRating']);
        }
        if ($hasType('AggregateRating')) {
            $check(['ratingValue', 'reviewCount']);
        }
        if ($isType('HowTo')) {
            $check(['name', 'step']);
        }
        if ($hasType('VideoObject')) {
            $check(['name', 'thumbnailUrl', 'uploadDate']);
        }
        if ($hasType('ImageObject')) {
            $check(['contentUrl']);
        }
        if ($hasType('Person')) {
            $check(['name']);
        }

        // Recurse into nested entities
        foreach ($data as $v) {
            if (is_array($v)) {
                if (function_exists('array_is_list') && array_is_list($v)) {
                    foreach ($v as $item) {
                        if (is_array($item)) {
                            $this->validateNode($item, $bag);
                        }
                    }
                } elseif (isset($v['@type'])) {
                    $this->validateNode($v, $bag);
                }
            }
        }
    }

    /**
     * Decides whether today's issues were already reported (suppressed for
     * 30 hours, same as the original Cache::add() dedup key) — mirrors the
     * original command's two-way branch exactly, just returning the
     * decision instead of calling logger().
     *
     * @param  array<int, string>  $missingSchema
     * @param  array<string, array<int, string>>  $parseErrors
     * @param  array<string, array<int, string>>  $validationIssues
     * @param  array<string, array<int, string>>  $duplicateIds
     * @return array{suppressed: bool, level: ?string, message: ?string}
     */
    private function alert(array $missingSchema, array $parseErrors, array $validationIssues, array $duplicateIds): array
    {
        $hasProblems = ! empty($missingSchema) || ! empty($parseErrors) || ! empty($validationIssues) || ! empty($duplicateIds);
        if (! $hasProblems) {
            return ['suppressed' => false, 'level' => null, 'message' => null];
        }

        $summary = [
            'missing_schema' => count($missingSchema),
            'parse_errors' => count($parseErrors),
            'validation_issues' => count($validationIssues),
            'duplicate_ids' => count($duplicateIds),
        ];

        $cacheKey = 'seo:schema-audit:warn:'.Carbon::now()->format('Ymd').':'.md5((string) json_encode($summary));

        if ($this->cache->has($cacheKey)) {
            return [
                'suppressed' => true,
                'level' => 'info',
                'message' => 'seo:schema-audit repeated issues suppressed',
            ];
        }

        // 30 hours, exactly like the original's Cache::add($cacheKey, true, now()->addHours(30)).
        $this->cache->set($cacheKey, true, 30 * 3600);

        return [
            'suppressed' => false,
            'level' => 'warning',
            'message' => 'seo:schema-audit found issues',
        ];
    }

    /**
     * @param  array<int, array{url: string, blocks: int, types: list<string>, note: string}>  $rows
     * @param  array<string, int>  $coverage  @type => URL count, already arsort()ed by count
     * @param  array<int, string>  $missingSchema
     * @param  array<string, array<int, string>>  $parseErrors
     * @param  array<string, array<int, string>>  $validationIssues
     * @param  array<string, array<int, string>>  $duplicateIds
     */
    private function buildMarkdown(
        array $rows,
        array $coverage,
        array $missingSchema,
        array $parseErrors,
        array $validationIssues,
        array $duplicateIds,
    ): string {
        $md = "# Schema markup audit\n\n";
        $md .= 'Run: '.Carbon::now()->toIso8601String()."\n\n";
        $md .= 'URLs audited: '.count($rows)."\n\n";

        $md .= "## Coverage by @type\n\n| @type | URLs |\n|---|---:|\n";
        foreach ($coverage as $type => $n) {
            $md .= "| {$type} | {$n} |\n";
        }

        $md .= "\n## URLs with no JSON-LD (".count($missingSchema).")\n\n";
        $md .= empty($missingSchema) ? "_None — every audited page emits schema._\n" : ('- '.implode("\n- ", $missingSchema)."\n");

        $md .= "\n## JSON-LD parse errors (".count($parseErrors).")\n\n";
        if (empty($parseErrors)) {
            $md .= "_None._\n";
        } else {
            foreach ($parseErrors as $url => $errs) {
                $md .= "- {$url}\n";
                foreach ($errs as $e) {
                    $md .= "  - {$e}\n";
                }
            }
        }

        $md .= "\n## Validation issues (".count($validationIssues).")\n\n";
        if (empty($validationIssues)) {
            $md .= "_None._\n";
        } else {
            foreach ($validationIssues as $url => $issues) {
                $md .= "- {$url}\n";
                foreach ($issues as $i) {
                    $md .= "  - {$i}\n";
                }
            }
        }

        $md .= "\n## Duplicate @id within page (".count($duplicateIds).")\n\n";
        if (empty($duplicateIds)) {
            $md .= "_None._\n";
        } else {
            foreach ($duplicateIds as $url => $ids) {
                $md .= "- {$url}\n";
                foreach ($ids as $id) {
                    $md .= "  - `{$id}`\n";
                }
            }
        }

        $md .= "\n## Per-URL detail\n\n| URL | Blocks | @types |\n|---|---:|---|\n";
        foreach ($rows as $r) {
            $md .= sprintf(
                "| %s | %d | %s |\n",
                $r['url'],
                $r['blocks'],
                empty($r['types']) ? ($r['note'] ?: '—') : implode(', ', $r['types']),
            );
        }

        return $md;
    }
}
