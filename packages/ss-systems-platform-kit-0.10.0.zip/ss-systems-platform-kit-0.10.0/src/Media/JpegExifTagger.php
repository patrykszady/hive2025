<?php

namespace SsSystems\Platform\Media;

use DateTimeImmutable;
use DateTimeInterface;
use DateTimeZone;
use lsolesen\pel\PelDataWindow;
use lsolesen\pel\PelEntryAscii;
use lsolesen\pel\PelEntryByte;
use lsolesen\pel\PelEntryRational;
use lsolesen\pel\PelEntryTime;
use lsolesen\pel\PelExif;
use lsolesen\pel\PelIfd;
use lsolesen\pel\PelJpeg;
use lsolesen\pel\PelTag;
use lsolesen\pel\PelTiff;

/**
 * Stamp a JPEG with where and when a project photo was taken, for Google
 * Business Profile (0.2.2, 2026-09-22).
 *
 * Google reads a photo's EXIF on upload and shows its "Image capture" date
 * from it — the project's completion date, not the day the admin pushed
 * the file — and treats GPS that matches the listing's area as a soft
 * local signal. This is gs.construction's JpegGeoTagger, which wrote the
 * GPS block only, grown to write the capture date too, shared here so
 * both sites stamp the same way. The image bytes are untouched: only the
 * EXIF segment is added or extended. On any failure the original bytes
 * come back, so a photo is never lost to a metadata problem.
 */
final class JpegExifTagger
{
    /**
     * @param  DateTimeInterface|null  $takenAt  DateTimeOriginal/Digitized and the GPS date stamp; null leaves any existing date alone
     */
    public function stamp(string $jpegBytes, ?float $latitude, ?float $longitude, ?DateTimeInterface $takenAt): string
    {
        try {
            $data = new PelDataWindow($jpegBytes);

            if (! PelJpeg::isValid($data)) {
                return $jpegBytes;
            }

            $jpeg = new PelJpeg();
            $jpeg->load($data);

            $exif = $jpeg->getExif();
            if ($exif === null) {
                $exif = new PelExif();
                $exif->setTiff(new PelTiff());
                $jpeg->setExif($exif);
            }
            $tiff = $exif->getTiff() ?? new PelTiff();
            $exif->setTiff($tiff);

            $ifd0 = $tiff->getIfd();
            if ($ifd0 === null) {
                $ifd0 = new PelIfd(PelIfd::IFD0);
                $tiff->setIfd($ifd0);
            }

            if ($takenAt !== null) {
                $this->writeDate($ifd0, $takenAt);
            }

            if ($latitude !== null && $longitude !== null) {
                $this->writeGps($ifd0, $latitude, $longitude, $takenAt);
            }

            return $jpeg->getBytes();
        } catch (\Throwable) {
            return $jpegBytes;
        }
    }

    /** Does this JPEG already carry a capture date (so a cached copy need not be re-stamped)? */
    public static function capturedAt(string $jpegBytes): ?string
    {
        if (! function_exists('exif_read_data')) {
            return null;
        }

        try {
            $data = @exif_read_data('data://image/jpeg;base64,'.base64_encode($jpegBytes), 'EXIF', false, false);

            return is_array($data) ? ($data['DateTimeOriginal'] ?? null) : null;
        } catch (\Throwable) {
            return null;
        }
    }

    protected function writeDate(PelIfd $ifd0, DateTimeInterface $takenAt): void
    {
        $local = DateTimeImmutable::createFromInterface($takenAt);
        $ifd0->addEntry(new PelEntryAscii(PelTag::DATE_TIME, $local->format('Y:m:d H:i:s')));

        $exifIfd = $ifd0->getSubIfd(PelIfd::EXIF);
        if ($exifIfd === null) {
            $exifIfd = new PelIfd(PelIfd::EXIF);
            $ifd0->addSubIfd($exifIfd);
        }

        // PelEntryTime formats a UNIX timestamp as UTC; give it the local
        // wall-clock time so the stamp reads as the date the owner set.
        $asUtc = (new DateTimeImmutable($local->format('Y-m-d H:i:s'), new DateTimeZone('UTC')))->getTimestamp();
        $exifIfd->addEntry(new PelEntryTime(PelTag::DATE_TIME_ORIGINAL, $asUtc));
        $exifIfd->addEntry(new PelEntryTime(PelTag::DATE_TIME_DIGITIZED, $asUtc));
    }

    protected function writeGps(PelIfd $ifd0, float $latitude, float $longitude, ?DateTimeInterface $when): void
    {
        $gps = new PelIfd(PelIfd::GPS);
        $ifd0->addSubIfd($gps); // replaces any GPS block already there

        $gps->addEntry(new PelEntryByte(PelTag::GPS_VERSION_ID, 2, 3, 0, 0));
        $gps->addEntry(new PelEntryAscii(PelTag::GPS_LATITUDE_REF, $latitude >= 0 ? 'N' : 'S'));
        $gps->addEntry(new PelEntryRational(PelTag::GPS_LATITUDE, ...$this->degreesToRationals(abs($latitude))));
        $gps->addEntry(new PelEntryAscii(PelTag::GPS_LONGITUDE_REF, $longitude >= 0 ? 'E' : 'W'));
        $gps->addEntry(new PelEntryRational(PelTag::GPS_LONGITUDE, ...$this->degreesToRationals(abs($longitude))));

        $utc = ($when ? DateTimeImmutable::createFromInterface($when) : new DateTimeImmutable('now'))->setTimezone(new DateTimeZone('UTC'));
        $gps->addEntry(new PelEntryAscii(PelTag::GPS_DATE_STAMP, $utc->format('Y:m:d')));
        $gps->addEntry(new PelEntryRational(
            PelTag::GPS_TIME_STAMP,
            [(int) $utc->format('H'), 1],
            [(int) $utc->format('i'), 1],
            [(int) $utc->format('s'), 1],
        ));
    }

    /**
     * Decimal degrees → the three EXIF rationals (degrees, minutes, seconds×1000).
     *
     * @return array{0: array{0:int,1:int}, 1: array{0:int,1:int}, 2: array{0:int,1:int}}
     */
    protected function degreesToRationals(float $deg): array
    {
        $d = (int) floor($deg);
        $minFloat = ($deg - $d) * 60;
        $m = (int) floor($minFloat);
        $s = ($minFloat - $m) * 60;

        return [[$d, 1], [$m, 1], [(int) round($s * 1000), 1000]];
    }
}
