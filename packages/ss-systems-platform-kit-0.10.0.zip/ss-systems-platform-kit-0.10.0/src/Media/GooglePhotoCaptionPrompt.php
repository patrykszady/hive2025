<?php

namespace SsSystems\Platform\Media;

/**
 * The one prompt every tenant uses to write a Google Business Profile
 * photo caption (0.3.0, 2026-09-22), so gs.construction's and
 * jpeterson-design's photos read the same way on Google: as long as
 * Google allows (250 characters), naming the business, the kind of work,
 * the town, and what is actually in the picture — the details local
 * search can read. The site runs it through its own AI driver with the
 * photo attached; clean() makes the reply safe to store.
 */
final class GooglePhotoCaptionPrompt
{
    public const MAX = 250;

    public const MIN = 200;

    /**
     * @param  string  $brand  e.g. "J. Peterson Design"
     * @param  string  $businessKind  e.g. "interior design studio", "home remodeling contractor"
     * @param  array<string, string|null>  $facts  project_type, location, market, title, alt_text, caption — what the site knows
     */
    public static function build(string $brand, string $businessKind, array $facts): string
    {
        $lines = [];
        foreach (['title' => 'Project', 'project_type' => 'Kind of work', 'location' => 'Town', 'market' => 'Market', 'alt_text' => 'What the photo shows (alt text)', 'caption' => 'Existing caption'] as $key => $label) {
            $value = trim((string) ($facts[$key] ?? ''));
            if ($value !== '') {
                $lines[] = "- {$label}: {$value}";
            }
        }
        $context = $lines === [] ? '- (no project facts on file; describe only what is visible)' : implode("\n", $lines);
        $max = self::MAX;
        $min = self::MIN;

        return <<<PROMPT
You write photo captions for {$brand}, a {$businessKind}, for its Google Business Profile listing.

Write ONE caption for the attached photo.

Known facts:
{$context}

Rules:
- Between {$min} and {$max} characters. Use almost all of them — Google allows {$max}.
- Third person. Name "{$brand}" exactly once, early.
- Say the kind of work and the town (with state) when known; never invent a place.
- Describe what is actually visible: room, materials, finishes, fixtures, colours, layout. Concrete nouns, not adjectives.
- Plain sentences ending with a period. No hashtags, emojis, quotation marks, labels, or line breaks.
- Output only the caption text.
PROMPT;
    }

    /** A model's reply, made safe to store: one line, no wrapping quotes, within the limit on a sentence boundary. */
    public static function clean(string $raw): string
    {
        $text = trim(preg_replace('/\s+/u', ' ', $raw) ?? '');
        $text = trim(preg_replace('/^(caption:\s*)/iu', '', $text) ?? '');
        $text = trim($text, "\"'“”‘’ ");

        if (mb_strlen($text) <= self::MAX) {
            return $text;
        }

        $cut = mb_substr($text, 0, self::MAX);
        $lastStop = max(mb_strrpos($cut, '. ') ?: 0, mb_strrpos($cut, '.') ?: 0);

        return $lastStop > self::MIN / 2 ? rtrim(mb_substr($cut, 0, $lastStop + 1)) : rtrim($cut);
    }
}
