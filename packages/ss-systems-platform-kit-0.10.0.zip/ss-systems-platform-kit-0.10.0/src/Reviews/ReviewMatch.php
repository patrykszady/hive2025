<?php

namespace SsSystems\Platform\Reviews;

use Illuminate\Support\Carbon;

/**
 * One rule for "is this review on one platform the same review on another?"
 * and one rule for what the merged review becomes. Decided here, in the
 * kit, so gs.construction, jpeterson-design and the central admin never
 * disagree about a pair, and a site never grows its own version.
 *
 * The review Barbara Brunka left on Houzz and the one "B Brunka" left on
 * Google (both 2 Jan 2025, both five stars, texts a few sentences apart)
 * is the shape this exists for: same person, same job, two platforms,
 * slightly different words.
 *
 * Five gates, all of which must pass, in this order:
 *   1. different platforms — two rows on ONE platform are never the same
 *      review here (the platform's own id already keeps those apart);
 *   2. compatible names — same surname and same given name, where one
 *      side may carry an initial ("B" for "Barbara", "Brunka" for "B."),
 *      but at least one of the two names must match in full and a name
 *      with no surname at all never matches;
 *   3. dates within a few days of each other (a review is copied from
 *      one platform to the other within days, not months);
 *   4. star ratings equal when both are known;
 *   5. enough shared words: the Sørensen–Dice overlap of the two texts'
 *      distinct words, after ReviewText::comparable() normalisation.
 *
 * The overlap decides how sure the match is: CERTAIN merges without
 * asking, LIKELY is shown to a person first. The real Brunka pair scores
 * 0.91; two different customers with the same surname fail gate 3 long
 * before the text is compared. A false merge joins two customers' words
 * under one name, so every threshold here leans towards "not the same".
 */
final class ReviewMatch
{
    /** Texts shorter than this, in distinct words, are never compared: template phrases would carry them. */
    public const MIN_COMPARABLE_WORDS = 8;

    /** Dice overlap from which a pair is proposed to a person. */
    public const LIKELY_THRESHOLD = 0.65;

    /** Dice overlap from which a pair is merged without asking. */
    public const CERTAIN_THRESHOLD = 0.80;

    /** How far apart the two review dates may be, in days. */
    public const DATE_TOLERANCE_DAYS = 3;

    public const NO_MATCH = 'no';

    public const LIKELY = 'likely';

    public const CERTAIN = 'certain';

    /**
     * @param  array{platform: string, reviewer_name: string, review_description: string, review_date?: ?string, star_rating?: ?int}  $a
     * @param  array{platform: string, reviewer_name: string, review_description: string, review_date?: ?string, star_rating?: ?int}  $b
     * @return self::NO_MATCH|self::LIKELY|self::CERTAIN
     */
    public static function compare(array $a, array $b): string
    {
        if (strtolower(trim((string) $a['platform'])) === strtolower(trim((string) $b['platform']))) {
            return self::NO_MATCH;
        }

        if (! self::namesCompatible((string) $a['reviewer_name'], (string) $b['reviewer_name'])) {
            return self::NO_MATCH;
        }

        if (! self::datesCompatible($a['review_date'] ?? null, $b['review_date'] ?? null)) {
            return self::NO_MATCH;
        }

        if (! self::ratingsCompatible($a['star_rating'] ?? null, $b['star_rating'] ?? null)) {
            return self::NO_MATCH;
        }

        $similarity = self::textSimilarity((string) $a['review_description'], (string) $b['review_description']);

        if ($similarity >= self::CERTAIN_THRESHOLD) {
            return self::CERTAIN;
        }

        return $similarity >= self::LIKELY_THRESHOLD ? self::LIKELY : self::NO_MATCH;
    }

    /**
     * @param  array{platform: string, reviewer_name: string, review_description: string, review_date?: ?string, star_rating?: ?int}  $a
     * @param  array{platform: string, reviewer_name: string, review_description: string, review_date?: ?string, star_rating?: ?int}  $b
     */
    public static function isSameReview(array $a, array $b): bool
    {
        return self::compare($a, $b) !== self::NO_MATCH;
    }

    /**
     * Same surname and same given name, either of which may be an initial
     * on one side — but not both, and never without a surname: "B Brunka"
     * matches "Barbara Brunka" and "Barbara B." matches "Barbara Brunka",
     * while "B B." matches neither and "Barbara" alone matches nothing.
     */
    public static function namesCompatible(string $a, string $b): bool
    {
        $ta = self::nameTokens($a);
        $tb = self::nameTokens($b);

        if (count($ta) < 2 || count($tb) < 2) {
            return false;
        }

        $given = self::tokensCompatible($ta[0], $tb[0]);
        $surname = self::tokensCompatible(end($ta), end($tb));

        if ($given === null || $surname === null) {
            return false;
        }

        // At least one of the two names has to match in full; two initials
        // in a row ("B B." against "Barbara Brunka") say too little.
        return $given === 'exact' || $surname === 'exact';
    }

    public static function datesCompatible(?string $a, ?string $b, int $toleranceDays = self::DATE_TOLERANCE_DAYS): bool
    {
        if ($a === null || $a === '' || $b === null || $b === '') {
            return false;
        }

        try {
            $da = Carbon::parse($a)->startOfDay();
            $db = Carbon::parse($b)->startOfDay();
        } catch (\Throwable) {
            return false;
        }

        return abs($da->diffInDays($db, false)) <= $toleranceDays;
    }

    /** A real disagreement between two known ratings is a different review; an unknown rating on either side is not held against the pair. */
    public static function ratingsCompatible(?int $a, ?int $b): bool
    {
        return $a === null || $b === null || $a === $b;
    }

    /**
     * Sørensen–Dice overlap of the two texts' distinct words, 0.0 to 1.0.
     * Zero when either text has too few words to be compared at all.
     */
    public static function textSimilarity(string $a, string $b): float
    {
        $wa = self::words($a);
        $wb = self::words($b);

        if (min(count($wa), count($wb)) < self::MIN_COMPARABLE_WORDS) {
            return 0.0;
        }

        $shared = count(array_intersect($wa, $wb));

        return round((2 * $shared) / (count($wa) + count($wb)), 4);
    }

    /**
     * What the merged review becomes: the longer text, the fuller name,
     * every field the survivor left empty filled from the other, and the
     * other's platform links added where the survivor has none for that
     * platform. Never decides WHICH row survives — the caller does (the
     * older row keeps its public address).
     *
     * @param  array{reviewer_name: string, review_description: string, star_rating?: ?int, review_date?: ?string, project_location?: ?string, project_type?: ?string, review_urls: array<int, array{platform: string, url: string, external_id?: ?string}>}  $keep
     * @param  array{reviewer_name: string, review_description: string, star_rating?: ?int, review_date?: ?string, project_location?: ?string, project_type?: ?string, review_urls: array<int, array{platform: string, url: string, external_id?: ?string}>}  $lose
     * @return array{reviewer_name: string, review_description: string, star_rating: ?int, review_date: ?string, project_location: ?string, project_type: ?string, add_review_urls: array<int, array{platform: string, url: string, external_id?: ?string}>}
     */
    public static function plan(array $keep, array $lose): array
    {
        $keepPlatforms = array_map(
            fn (array $u) => strtolower(trim((string) $u['platform'])),
            $keep['review_urls'] ?? [],
        );

        return [
            'reviewer_name' => self::fullerName((string) $keep['reviewer_name'], (string) $lose['reviewer_name']),
            'review_description' => self::longer((string) $keep['review_description'], (string) $lose['review_description']),
            'star_rating' => $keep['star_rating'] ?? $lose['star_rating'] ?? null,
            'review_date' => self::nonEmpty($keep['review_date'] ?? null, $lose['review_date'] ?? null),
            'project_location' => self::nonEmpty($keep['project_location'] ?? null, $lose['project_location'] ?? null),
            'project_type' => self::nonEmpty($keep['project_type'] ?? null, $lose['project_type'] ?? null),
            'add_review_urls' => array_values(array_filter(
                $lose['review_urls'] ?? [],
                fn (array $u) => ! in_array(strtolower(trim((string) $u['platform'])), $keepPlatforms, true),
            )),
        ];
    }

    /**
     * The name with no initials wins; between two such names, or two with
     * initials, the longer one. "Barbara Brunka" over "B Brunka"; the
     * survivor's own name when nothing separates them.
     */
    public static function fullerName(string $keep, string $lose): string
    {
        $keepInitials = self::initialCount($keep);
        $loseInitials = self::initialCount($lose);

        if ($loseInitials < $keepInitials) {
            return $lose;
        }

        if ($loseInitials === $keepInitials) {
            return self::longer($keep, $lose);
        }

        return $keep;
    }

    /** @return list<string> lower-case ASCII name tokens, dots and other punctuation gone. */
    private static function nameTokens(string $value): array
    {
        $v = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value) ?: $value;
        $v = mb_strtolower(trim((string) preg_replace('/[^a-zA-Z0-9\s]/', ' ', $v)));
        $v = (string) preg_replace('/\s+/', ' ', trim($v));

        return $v === '' ? [] : explode(' ', $v);
    }

    /** 'exact', 'initial' (one side is the other's first letter) or null (different). */
    private static function tokensCompatible(string $a, string $b): ?string
    {
        if ($a === $b) {
            return 'exact';
        }

        if (strlen($a) === 1 && str_starts_with($b, $a)) {
            return 'initial';
        }

        if (strlen($b) === 1 && str_starts_with($a, $b)) {
            return 'initial';
        }

        return null;
    }

    private static function initialCount(string $name): int
    {
        return count(array_filter(self::nameTokens($name), fn (string $t) => strlen($t) === 1));
    }

    /** @return list<string> distinct normalised words */
    private static function words(string $text): array
    {
        $normalised = trim(ReviewText::comparable($text, 20000));

        return $normalised === '' ? [] : array_values(array_unique(explode(' ', $normalised)));
    }

    private static function longer(string $a, string $b): string
    {
        return mb_strlen(trim($b)) > mb_strlen(trim($a)) ? $b : $a;
    }

    private static function nonEmpty(?string $a, ?string $b): ?string
    {
        return ($a !== null && trim($a) !== '') ? $a : (($b !== null && trim($b) !== '') ? $b : null);
    }
}
