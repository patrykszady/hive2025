<?php

namespace SsSystems\Platform\Seo;

/**
 * Where SearchConsoleSync's results land. The kit computes every row; each
 * site's own implementation of this interface is the only place that writes
 * one, because how a row is stored is exactly the part that cannot be
 * shared — gs.construction's writes are tenant-scoped through Tenancy and
 * carry a site_id, jpeterson-design's are a single site's plain Eloquent
 * models and DB::table() calls. Bound once in each site's AppServiceProvider.
 */
interface SearchConsoleWriter
{
    /**
     * Insert or update one query/page/country/device metrics row, keyed on
     * its dim_hash (see SearchConsoleSync for why that key is a hash rather
     * than the natural columns). The date-only lookup used by
     * upsertDailyTotal() below is deliberately NOT this method's job.
     *
     * @param  array<string, mixed>  $row
     * @return 'inserted'|'updated'
     */
    public function upsertQueryMetric(array $row): string;

    /**
     * Insert or update the true site-wide totals for one day. Finding the
     * existing row for that day is left entirely to the site: Eloquent's
     * `date` cast always writes a full 'Y-m-d H:i:s' string, and only a
     * MySQL DATE column truncates that back down on write, which is the
     * only reason a plain string-equality match finds the row again in
     * production — under sqlite (what both sites' test suites run against)
     * nothing truncates it, so that same match always misses and a re-sync
     * would insert a duplicate instead of updating. A kit-level upsert
     * cannot get this right for both engines at once, so each site keeps
     * its own whereDate()-based lookup here.
     *
     * @param  array{clicks: int, impressions: int, ctr: float, position: float}  $totals
     */
    public function upsertDailyTotal(string $date, string $siteUrl, array $totals): void;

    /**
     * Insert or update one day's metrics for one search-appearance type (AI
     * Overview, review snippet, FAQ rich result, …), keyed on the date and
     * the appearance label.
     *
     * @param  array{clicks: int, impressions: int, ctr: float, position: float}  $metrics
     */
    public function upsertSearchAppearance(string $date, string $appearance, array $metrics): void;

    /**
     * Bookkeeping for one run of the sync — called exactly once, whether the
     * run finished, was skipped, failed, or was a dry run.
     *
     * @param  array{status: string, inserted: int, updated: int, daily_totals: int, appearance_rows: int, days: int, lag_days: int, window_start: ?string, window_end: ?string, site_url: string, started_at: string, finished_at: ?string, error: ?string}  $summary
     */
    public function recordSyncRun(array $summary): void;
}
