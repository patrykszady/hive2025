<?php

namespace SsSystems\Platform\Seo\Inspection;

/**
 * What UrlInspectionSweep::run() hands back — everything a site's thin
 * seo:gsc-inspect-bulk wrapper needs to behave exactly like the original
 * command did (print `lines` in order, write `markdown` to storage when
 * asked) without owning any of the sweep's own algorithm.
 *
 * There is no status/exit-code field: the original command's own FAILURE
 * exit is exactly one case ("Nothing to inspect.", when the resolved pool
 * was empty) and every other early return is SUCCESS — a spent allowance,
 * a mid-run 429, a normal completion. A wrapper that wants that exact
 * FAILURE distinction reads `lines`; see docs/INSPECTION-SWEEP.md.
 */
final class SweepResult
{
    /**
     * @param  list<array{url: string, prev_verdict: ?string, verdict: ?string, prev_coverage: ?string, coverage: ?string, rich_issue_count: int, changed: bool}>  $changes  Only rows whose verdict/coverage_state/page_fetch_state/google_canonical changed since the previous inspection — exactly what the original command's $changes accumulated and writeReport()'s "State changes this run" table lists.
     * @param  list<string>  $lines  The console lines the command printed, in order (info/warn/per-URL result lines, the closing "Done. inspected=…" line) — plain text, no color/level attached; the site's wrapper prints each with $this->line().
     */
    public function __construct(
        public readonly int $inspected,
        public readonly int $failures,
        public readonly array $changes,
        public readonly int $richIssues,
        public readonly bool $stoppedOnQuota,
        public readonly int $quotaRemaining,
        public readonly string $markdown,
        public readonly array $lines,
    ) {
    }
}
