<?php

namespace SsSystems\Platform\Seo\Inspection\Contracts;

/**
 * The paths Googlebot has 404'd on — the 'tracked' off-sitemap pool, joined
 * onto SitemapSource::baseUrl() to build full URLs. Mirrors
 * Tracked404::query()->where('user_agent', 'like',
 * '%Googlebot%')->orderByDesc('hit_count')->pluck('path'). A site with no
 * 404-tracking table at all (no Tracked404 equivalent) returns [] — the
 * 'tracked' pool then simply contributes nothing, same as a site that never
 * binds this kit's Reports\Contracts\AreaCatalog.
 */
interface TrackedPaths
{
    /** @return list<string> */
    public function recent404Paths(): array;
}
