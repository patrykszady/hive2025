<?php

namespace SsSystems\Platform\Seo\Inspection;

use Illuminate\Support\Carbon;
use Psr\SimpleCache\CacheInterface;

/**
 * The URL Inspection API's daily allowance, shared by every caller that
 * draws on ONE property's quota — the nightly sweep, a Console CSV import,
 * an admin's inspect-this-URL button — ported from gs.construction's
 * App\Support\Seo\UrlInspectionQuota (2,000 calls/day, 600/minute per
 * property, reset at midnight Pacific because that is where Google's daily
 * quotas roll over, not local midnight).
 *
 * The original was a static class reading Laravel's Cache facade and
 * config(); this is an instance so two sites (or two properties on one
 * multi-tenant site) never share a counter by accident — each gets its own
 * CacheInterface + key prefix at construction. The site passes a prefix
 * already scoped to itself (gs.construction's Tenancy::cacheKey('gsc.url-
 * inspection') is exactly that shape), and this class appends the day.
 *
 * One deliberate divergence from the original: consume() there does
 * `Cache::add($key, 0, $resetsAt); Cache::increment($key, $calls);` — add
 * then atomic increment, specifically to survive a cache store where
 * increment() on a missing key is a no-op (the comment on the original
 * explains this exact failure mode). PSR-16 (CacheInterface) has no atomic
 * increment at all, so consume() here is read-then-write instead. That is
 * fine for what this class actually does — one sweep is one PHP process —
 * but it is NOT safe against two processes racing the same key the way the
 * original's Cache::increment() (on a store that supports it) was. A site
 * that shares one property's quota across genuinely concurrent processes
 * needs its own atomic counter in front of this.
 */
final class UrlInspectionQuota
{
    /** Where Google's daily quotas roll over. */
    public const RESET_TIMEZONE = 'America/Los_Angeles';

    public function __construct(
        private readonly CacheInterface $cache,
        private readonly string $keyPrefix,
        private readonly int $dailyLimitValue = 2000,
        private readonly int $perMinuteLimitValue = 600,
    ) {
    }

    public function dailyLimit(): int
    {
        return max(1, $this->dailyLimitValue);
    }

    /** Calls a minute, the other published ceiling — callers pace themselves with this. */
    public function perMinuteLimit(): int
    {
        return max(1, $this->perMinuteLimitValue);
    }

    public function used(): int
    {
        return (int) $this->cache->get($this->key(), 0);
    }

    public function remaining(): int
    {
        return max(0, $this->dailyLimit() - $this->used());
    }

    /**
     * How many of $wanted calls may actually be made now.
     *
     * Reserving does not consume: a caller that stops early should not burn
     * the allowance it never used, so consume() is called per real request.
     */
    public function reserve(int $wanted): int
    {
        return max(0, min($wanted, $this->remaining()));
    }

    public function consume(int $calls = 1): void
    {
        $this->cache->set($this->key(), $this->used() + $calls, $this->secondsUntilReset());
    }

    /**
     * Google refused on quota — treat the day as spent rather than keep
     * asking, whatever our own count says (another client on the same
     * property spends from the same allowance).
     */
    public function markExhausted(): void
    {
        $this->cache->set($this->key(), $this->dailyLimit(), $this->secondsUntilReset());
    }

    public function resetsAt(): Carbon
    {
        return Carbon::now(self::RESET_TIMEZONE)->addDay()->startOfDay();
    }

    /** @return array{used: int, remaining: int, daily_limit: int, per_minute_limit: int, resets_at: string} */
    public function status(): array
    {
        return [
            'used' => $this->used(),
            'remaining' => $this->remaining(),
            'daily_limit' => $this->dailyLimit(),
            'per_minute_limit' => $this->perMinuteLimit(),
            'resets_at' => $this->resetsAt()->toIso8601String(),
        ];
    }

    private function secondsUntilReset(): int
    {
        return max(1, (int) Carbon::now(self::RESET_TIMEZONE)->diffInSeconds($this->resetsAt(), false));
    }

    private function key(): string
    {
        return $this->keyPrefix.'.'.Carbon::now(self::RESET_TIMEZONE)->toDateString();
    }
}
