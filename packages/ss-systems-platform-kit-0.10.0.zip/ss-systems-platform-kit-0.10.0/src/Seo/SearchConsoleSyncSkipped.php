<?php

namespace SsSystems\Platform\Seo;

/**
 * Thrown by SearchConsoleSync::run() when the site's Search Console client
 * is not configured. A skipped run is not a failure — it means the owner
 * has not connected Search Console yet, or a grant was disconnected — so
 * this is its own type rather than a generic exception: the calling site
 * command decides whether that is a SUCCESS or a FAILURE exit code (today
 * every site treats it as a soft, printed skip, not an error).
 */
final class SearchConsoleSyncSkipped extends \RuntimeException
{
}
