<?php

namespace SsSystems\Platform\Seo;

/**
 * The three things SitemapStatus needs from a site's Search Console service.
 *
 * The services themselves cannot be shared: gs.construction's can delete
 * sitemaps and inspect URLs, jpeterson-design's cannot, and each holds a grant
 * encrypted with its own APP_KEY. Each site's App\Services\GoogleSearchConsoleService
 * implements this and is bound to it in that site's AppServiceProvider.
 */
interface SearchConsoleClient
{
    public function isConfigured(): bool;

    /** @return array<int, array<string, mixed>>|null  Google's sitemaps.list rows, or null on failure */
    public function listSitemaps(string $siteUrl): ?array;

    /** @return array<string, mixed>|null */
    public function getLastError(): ?array;
}
