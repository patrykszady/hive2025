<?php

namespace SsSystems\Platform\Seo\Bing;

/**
 * What BingSync needs from Bing Webmaster Tools. BingWebmasterApi is the one
 * real implementation (the API is the same for every site; only the key and
 * the property differ, and those are constructor arguments); a test hands in
 * a fake with no HTTP behind it.
 */
interface BingWebmasterClient
{
    /** A key and a property to ask about. */
    public function isConfigured(): bool;

    /** The property the rows are for, as Bing knows it ("https://example.com/"). */
    public function siteUrl(): string;

    /**
     * GetQueryStats: one row per query per day, Bing's dates already
     * normalised to 'Y-m-d'. Null when the call failed — see lastError().
     *
     * @return list<array{date: string, site_url: string, query: string, impressions: int, clicks: int, position: float}>|null
     */
    public function queryStats(): ?array;

    /**
     * GetRankAndTrafficStats: the true site-wide totals per day. Null when
     * the call failed.
     *
     * @return list<array{date: string, site_url: string, impressions: int, clicks: int}>|null
     */
    public function rankAndTrafficStats(): ?array;

    /** Why the last call returned null, for the run's summary and the log. */
    public function lastError(): ?string;
}
