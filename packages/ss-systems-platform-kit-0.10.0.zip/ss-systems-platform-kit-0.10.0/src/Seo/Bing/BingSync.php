<?php

namespace SsSystems\Platform\Seo\Bing;

use Illuminate\Support\Carbon;

/**
 * The Bing Webmaster Tools sync — one implementation, run by every site
 * through its own BingWebmasterClient and BingWriter. Ported from
 * gs.construction's app/Console/Commands/SyncBingWebmaster.php, which
 * jpeterson-design never had: its seo:bing-sync was a stub that checked
 * the .env key and did nothing, even after a key was saved from the
 * admin (2026-09-23).
 *
 * Two things happen per run:
 *
 *   1. GetQueryStats, upserted by a hash of the natural key
 *      (date | site_url | query — see queryStatRow()).
 *   2. GetRankAndTrafficStats, the true site-wide daily totals. The
 *      per-query rows silently drop the clicks and impressions of the
 *      queries Bing anonymises, so summing them under-reports; the daily
 *      headline numbers and the trend line come from these.
 *
 * A failed totals fetch does not fail the run — the query rows are already
 * in — it is reported in the summary for the site to warn about.
 */
final class BingSync
{
    public const SITE_URL_LENGTH = 191;

    public const QUERY_LENGTH = 500;

    public const SAMPLE_ROWS = 10;

    /**
     * @param  array{dry_run?: bool}  $options
     * @return array{status: string, site_url: string, fetched: int, inserted: int, updated: int, skipped_rows: int, daily_totals: int, daily_totals_error: ?string, started_at: string, finished_at: ?string, error: ?string, sample: list<array<string, mixed>>}
     *
     * @throws BingSyncSkipped  when the client has no key configured.
     */
    public static function run(BingWebmasterClient $client, BingWriter $writer, array $options = []): array
    {
        $dryRun = (bool) ($options['dry_run'] ?? false);

        $summary = [
            'status' => 'ok',
            'site_url' => $client->siteUrl(),
            'fetched' => 0,
            'inserted' => 0,
            'updated' => 0,
            'skipped_rows' => 0,
            'daily_totals' => 0,
            'daily_totals_error' => null,
            'started_at' => Carbon::now()->toIso8601String(),
            'finished_at' => null,
            'error' => null,
            'sample' => [],
        ];

        if (! $client->isConfigured()) {
            throw new BingSyncSkipped('Bing Webmaster Tools is not configured for '.$client->siteUrl().'.');
        }

        $rows = $client->queryStats();
        if ($rows === null) {
            $summary['status'] = 'failed';
            $summary['error'] = $client->lastError() ?? 'GetQueryStats failed.';
            $summary['finished_at'] = Carbon::now()->toIso8601String();

            return $summary;
        }

        $summary['fetched'] = count($rows);

        foreach ($rows as $raw) {
            $row = self::queryStatRow($raw);
            if ($row === null) {
                $summary['skipped_rows']++;

                continue;
            }

            if ($dryRun) {
                if (count($summary['sample']) < self::SAMPLE_ROWS) {
                    $summary['sample'][] = $row;
                }

                continue;
            }

            $summary[$writer->upsertQueryStat($row)]++;
        }

        $totals = $client->rankAndTrafficStats();
        if ($totals === null) {
            $summary['daily_totals_error'] = $client->lastError() ?? 'GetRankAndTrafficStats failed.';
        } else {
            foreach ($totals as $day) {
                $date = (string) ($day['date'] ?? '');
                if ($date === '') {
                    continue;
                }
                $impressions = (int) ($day['impressions'] ?? 0);
                $clicks = (int) ($day['clicks'] ?? 0);

                if (! $dryRun) {
                    $writer->upsertDailyTotal($date, mb_substr((string) ($day['site_url'] ?? ''), 0, self::SITE_URL_LENGTH), [
                        'clicks' => $clicks,
                        'impressions' => $impressions,
                        'ctr' => $impressions > 0 ? round($clicks / $impressions, 5) : 0.0,
                    ]);
                }
                $summary['daily_totals']++;
            }
        }

        $summary['status'] = $dryRun ? 'dry-run' : 'ok';
        $summary['finished_at'] = Carbon::now()->toIso8601String();

        return $summary;
    }

    /**
     * One GetQueryStats row as a site stores it, or null for a row with no
     * query or no date. The key is a hash of date | site_url | query, on
     * the values AFTER truncation to what the columns hold, so the same row
     * hashes the same on every run.
     *
     * @param  array<string, mixed>  $raw
     * @return array{date: string, site_url: string, query: string, impressions: int, clicks: int, position: float, dim_hash: string}|null
     */
    public static function queryStatRow(array $raw): ?array
    {
        $date = (string) ($raw['date'] ?? '');
        $query = mb_substr(trim((string) ($raw['query'] ?? '')), 0, self::QUERY_LENGTH);
        if ($date === '' || $query === '') {
            return null;
        }
        $siteUrl = mb_substr((string) ($raw['site_url'] ?? ''), 0, self::SITE_URL_LENGTH);

        return [
            'date' => $date,
            'site_url' => $siteUrl,
            'query' => $query,
            'impressions' => (int) ($raw['impressions'] ?? 0),
            'clicks' => (int) ($raw['clicks'] ?? 0),
            'position' => (float) ($raw['position'] ?? 0),
            'dim_hash' => sha1("{$date}|{$siteUrl}|{$query}"),
        ];
    }
}
