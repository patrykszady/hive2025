<?php

namespace SsSystems\Platform\Seo\Bing;

/**
 * Thrown by BingSync::run() when the site has no Bing key. Not a failure —
 * the owner has not connected Bing Webmaster Tools yet — so it is its own
 * type; the site's command decides whether that is a SUCCESS or a FAILURE
 * exit (a nightly schedule prints it and exits clean).
 */
final class BingSyncSkipped extends \RuntimeException
{
}
