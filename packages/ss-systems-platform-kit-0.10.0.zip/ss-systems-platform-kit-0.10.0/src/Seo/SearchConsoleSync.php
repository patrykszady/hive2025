<?php

namespace SsSystems\Platform\Seo;

use Illuminate\Support\Carbon;

/**
 * The Search Console sync itself — one implementation, run by every tenant
 * through its own SearchConsoleSyncClient and SearchConsoleWriter, ported
 * verbatim from gs.construction's app/Console/Commands/SyncGoogleSearchConsole.php
 * (jpeterson-design's app/Console/Commands/SeoGscSync.php is the same port a
 * year later; its only real divergence — finding a day's existing totals row
 * with whereDate() rather than a plain string match — is exactly the part
 * SearchConsoleWriter::upsertDailyTotal() leaves to each site, see that
 * interface's docblock).
 *
 * Three things happen per run, in this order:
 *
 *   1. The full query/page/country/device pull, paginated, upserted by a
 *      deterministic hash of its natural key (dim_hash — see below for why
 *      a hash and not the columns themselves).
 *   2. The true site-wide daily totals, from a date-only query. The pull
 *      above silently drops clicks and impressions from anonymized queries
 *      — Google counts the click but withholds the query text once a query
 *      is rare enough to be personally identifying — so summing its rows
 *      under-reports the real numbers. A date-only query carries no such
 *      gap and is what the daily headline numbers and trend line are built
 *      from.
 *   3. The daily breakdown by search appearance (AI Overview, review
 *      snippet, FAQ rich result, …), one Google request per day in the
 *      window — see syncSearchAppearance() for why it cannot be one request
 *      for the whole window.
 */
final class SearchConsoleSync
{
    /**
     * @param  array{days?: int, lag_days?: int, site_url?: ?string, limit?: int, dry_run?: bool}  $options
     * @return array{status: string, inserted: int, updated: int, daily_totals: int, appearance_rows: int, days: int, lag_days: int, window_start: ?string, window_end: ?string, site_url: string, started_at: string, finished_at: ?string, error: ?string}
     *
     * @throws SearchConsoleSyncSkipped  when the client has no Search Console grant configured. The summary is still recorded before this is thrown.
     */
    public static function run(SearchConsoleSyncClient $client, SearchConsoleWriter $writer, array $options = []): array
    {
        $days = max(1, (int) ($options['days'] ?? SearchConsoleSyncRule::DEFAULT_DAYS));
        $lagDays = max(0, (int) ($options['lag_days'] ?? SearchConsoleSyncRule::DEFAULT_LAG_DAYS));
        $limit = (int) ($options['limit'] ?? 25000);
        $dryRun = (bool) ($options['dry_run'] ?? false);
        $siteUrl = (string) ($options['site_url'] ?? '') ?: $client->siteUrl();

        // GSC data lags a couple of days, so the window's end is shifted back
        // by lag_days rather than ending today; the start is `days` days
        // before that.
        $end = Carbon::today()->subDays($lagDays);
        $start = $end->copy()->subDays($days - 1);

        $summary = [
            'status' => 'ok',
            'inserted' => 0,
            'updated' => 0,
            'daily_totals' => 0,
            'appearance_rows' => 0,
            'days' => $days,
            'lag_days' => $lagDays,
            'window_start' => $start->toDateString(),
            'window_end' => $end->toDateString(),
            'site_url' => $siteUrl,
            'started_at' => Carbon::now()->toIso8601String(),
            'finished_at' => null,
            'error' => null,
        ];

        try {
            if (! $client->isConfigured()) {
                $summary['status'] = 'skipped';
                $summary['finished_at'] = Carbon::now()->toIso8601String();

                throw new SearchConsoleSyncSkipped('Search Console is not configured for '.$siteUrl.'.');
            }

            if ($dryRun) {
                $summary['status'] = 'dry-run';
            }

            self::syncQueryMetrics($client, $writer, $siteUrl, $start, $end, $limit, $dryRun, $summary);
            self::syncDailyTotals($client, $writer, $siteUrl, $start, $end, $dryRun, $summary);
            self::syncSearchAppearance($client, $writer, $siteUrl, $start, $end, $dryRun, $summary);

            $summary['finished_at'] = Carbon::now()->toIso8601String();

            return $summary;
        } catch (SearchConsoleSyncSkipped $e) {
            throw $e;
        } catch (\Throwable $e) {
            $summary['status'] = 'error';
            $summary['error'] = $e->getMessage();
            $summary['finished_at'] = Carbon::now()->toIso8601String();

            throw $e;
        } finally {
            // Exactly once per run, whatever happened above: a run that never
            // gets recorded looks identical to a run that never happened, and
            // the admin's "last synced" line depends on this firing every time.
            $writer->recordSyncRun($summary);
        }
    }

    /**
     * The paginated pull across date, query, page, country and device —
     * Google's most detailed breakdown, and the one the per-query/per-page
     * SEO screens read from.
     */
    private static function syncQueryMetrics(
        SearchConsoleSyncClient $client,
        SearchConsoleWriter $writer,
        string $siteUrl,
        Carbon $start,
        Carbon $end,
        int $limit,
        bool $dryRun,
        array &$summary,
    ): void {
        $startRow = 0;

        do {
            $rows = $client->querySearchAnalytics(
                siteUrl: $siteUrl,
                startDate: $start->toDateString(),
                endDate: $end->toDateString(),
                dimensions: ['date', 'query', 'page', 'country', 'device'],
                rowLimit: $limit,
                startRow: $startRow,
            );

            if ($rows === null) {
                throw new \RuntimeException(
                    'Search Console query failed: '.json_encode($client->getLastError())
                );
            }

            $count = count($rows);

            foreach ($rows as $r) {
                $keys = $r['keys'] ?? [];
                [$date, $query, $page, $country, $device] = array_pad($keys, 5, null);

                if (! $date || ! $query || ! $page) {
                    continue;
                }

                $payload = [
                    'date' => $date,
                    'site_url' => mb_substr($siteUrl, 0, 191),
                    'query' => mb_substr((string) $query, 0, 500),
                    'page' => mb_substr((string) $page, 0, 500),
                    'country' => mb_substr((string) ($country ?? ''), 0, 8) ?: null,
                    'device' => mb_substr((string) ($device ?? ''), 0, 16) ?: null,
                    'impressions' => (int) ($r['impressions'] ?? 0),
                    'clicks' => (int) ($r['clicks'] ?? 0),
                    'ctr' => round((float) ($r['ctr'] ?? 0), 4),
                    'position' => round((float) ($r['position'] ?? 0), 2),
                ];

                // A unique index on the natural key (date, site_url, query,
                // page, country, device) would need MySQL to index the full
                // query and page text, and MySQL refuses a unique index over
                // 3072 bytes — a handful of long URLs or search phrases would
                // hit that limit. Hashing the key first sidesteps it: the
                // index is always exactly 40 bytes, and the hash is
                // deterministic, so re-syncing the same row always finds it
                // again instead of inserting a duplicate.
                $payload['dim_hash'] = sha1(implode('|', [
                    $payload['date'],
                    $payload['site_url'],
                    $payload['query'],
                    $payload['page'],
                    $payload['country'] ?? '',
                    $payload['device'] ?? '',
                ]));

                if ($dryRun) {
                    // Counted as "would touch a row", not split into would-insert
                    // vs would-update — telling those apart means asking whether
                    // the row already exists, which is exactly the writer call a
                    // dry run must not make.
                    $summary['inserted']++;

                    continue;
                }

                $result = $writer->upsertQueryMetric($payload);
                $result === 'inserted' ? $summary['inserted']++ : $summary['updated']++;
            }

            $startRow += $count;
            // Google returns up to `limit` rows per page; loop until a page
            // comes back shorter than that, which means it was the last one.
        } while ($count >= $limit);
    }

    /**
     * The true site-wide totals for each day in the window, from a
     * date-only query — see the class docblock for why this cannot be
     * derived from the detailed pull above.
     */
    private static function syncDailyTotals(
        SearchConsoleSyncClient $client,
        SearchConsoleWriter $writer,
        string $siteUrl,
        Carbon $start,
        Carbon $end,
        bool $dryRun,
        array &$summary,
    ): void {
        $rows = $client->querySearchAnalytics(
            siteUrl: $siteUrl,
            startDate: $start->toDateString(),
            endDate: $end->toDateString(),
            dimensions: ['date'],
            rowLimit: 1000,
            startRow: 0,
        );

        // A failed daily-totals query only loses the headline numbers, not
        // the detailed rows the pull above already wrote, so this stops
        // quietly rather than failing the whole run.
        if ($rows === null) {
            return;
        }

        foreach ($rows as $r) {
            $date = $r['keys'][0] ?? null;

            if (! $date) {
                continue;
            }

            $totals = [
                'clicks' => (int) ($r['clicks'] ?? 0),
                'impressions' => (int) ($r['impressions'] ?? 0),
                'ctr' => round((float) ($r['ctr'] ?? 0), 5),
                'position' => round((float) ($r['position'] ?? 0), 2),
            ];

            if (! $dryRun) {
                // Finding the existing row for this day is left to the site's
                // own Writer — see SearchConsoleWriter::upsertDailyTotal()'s
                // docblock for why a kit-level lookup cannot get this right
                // for both MySQL and sqlite at once.
                $writer->upsertDailyTotal($date, $siteUrl, $totals);
            }

            $summary['daily_totals']++;
        }
    }

    /**
     * The daily breakdown by search appearance (AI Overview, review
     * snippet, FAQ rich result, …), one request per day.
     *
     * Asking for ['date', 'searchAppearance'] together in a single request
     * used to be how this worked, and Google answers that combination with
     * a flat 400 error ("Cannot group by search appearance dimension
     * together with another dimension"). The failure only used to be
     * logged as a warning, so the sync looked healthy while this table sat
     * at zero rows from the day it was created — nothing about it ever
     * reached a dashboard. Asking once per day, with searchAppearance as
     * the only dimension, is the only way to keep the daily granularity
     * the rest of the SEO screens are built on; a nightly one-day window
     * costs exactly one extra request for it.
     */
    private static function syncSearchAppearance(
        SearchConsoleSyncClient $client,
        SearchConsoleWriter $writer,
        string $siteUrl,
        Carbon $start,
        Carbon $end,
        bool $dryRun,
        array &$summary,
    ): void {
        foreach ($start->toPeriod($end) as $day) {
            $date = $day->toDateString();

            $rows = $client->querySearchAnalytics(
                siteUrl: $siteUrl,
                startDate: $date,
                endDate: $date,
                dimensions: ['searchAppearance'],
                rowLimit: 100,
                startRow: 0,
            );

            if ($rows === null) {
                // A property that rejects the dimension rejects it for every
                // day in the window, so stop asking rather than repeat the
                // same failure once per remaining day.
                return;
            }

            foreach ($rows as $r) {
                $appearance = $r['keys'][0] ?? null;

                if (! $appearance) {
                    continue;
                }

                $metrics = [
                    'clicks' => (int) ($r['clicks'] ?? 0),
                    'impressions' => (int) ($r['impressions'] ?? 0),
                    'ctr' => round((float) ($r['ctr'] ?? 0), 5),
                    'position' => round((float) ($r['position'] ?? 0), 2),
                ];

                if (! $dryRun) {
                    $writer->upsertSearchAppearance($date, mb_substr($appearance, 0, 64), $metrics);
                }

                $summary['appearance_rows']++;
            }
        }
    }
}
