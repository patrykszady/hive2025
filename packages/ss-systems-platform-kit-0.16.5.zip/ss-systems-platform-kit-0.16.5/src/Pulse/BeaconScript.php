<?php

namespace SsSystems\Platform\Pulse;

/**
 * The `/t` sendBeacon script every site includes in its public layout —
 * ported verbatim (behaviourally) from dawnsellshomes.com's
 * resources/views/components/site/pulse.blade.php: auto `page` event per
 * view, feature events via `window.<fn>(event, meta)`, delegated
 * tel:/mailto: click tracking (`call`/`email`), and capped (default 3 per
 * page view) first-party JS error capture that ignores bare cross-origin
 * "Script error." noise.
 *
 * A static method, not a Blade component: the kit ships as a plain
 * Composer package with no service provider / view-namespace registration
 * (see docs/PULSE.md), so a site's own layout echoes the returned string,
 * e.g. `{!! \SsSystems\Platform\Pulse\BeaconScript::render('/t') !!}`.
 * `fn` defaults to a neutral name; Dawn passes `'fn' => 'dsT'` so every
 * existing `dsT(...)` call across its blade views keeps working unchanged.
 */
final class BeaconScript
{
    public const DEFAULT_FN = 'ssPulse';

    public const DEFAULT_JS_ERROR_CAP = 3;

    /**
     * Errors that are never the site's to fix, kept off the JS errors board
     * (reviewed across every site, 2026-10-25): code injected by browser
     * extensions and in-app browsers (crypto wallets, Instagram/Facebook's
     * Android WebView, extension messaging), Outlook's SafeLinks scanner
     * running the page, network drops Safari and Chrome report as promise
     * rejections, Google Maps libraries an ad blocker kept out, the
     * ResizeObserver notice, and Flux's stylesheet setup on browsers older
     * than CSS @layer (2022).
     */
    public const NOISE_PATTERN = 'chrome-extension:|moz-extension:|safari-web-extension:|iabjs:|Java object is gone|runtime\\.sendMessage|window\\.ethereum|selectedAddress|Object Not Found Matching Id|ResizeObserver loop|^(promise: )?(Load failed|Failed to fetch|NetworkError|cancelled)\\b|Could not load "|insertRule.*@layer';

    /**
     * @param  array{fn?: string, auto_page?: bool, track_clicks?: bool, js_errors?: bool, js_error_cap?: int}  $options
     */
    public static function render(string $endpoint, array $options = []): string
    {
        $fn = (string) ($options['fn'] ?? self::DEFAULT_FN);
        $autoPage = (bool) ($options['auto_page'] ?? true);
        $trackClicks = (bool) ($options['track_clicks'] ?? true);
        $jsErrors = (bool) ($options['js_errors'] ?? true);
        $cap = (int) ($options['js_error_cap'] ?? self::DEFAULT_JS_ERROR_CAP);
        $endpointJs = json_encode($endpoint, JSON_UNESCAPED_SLASHES);

        $lines = [];
        $lines[] = '<script>';
        $lines[] = "window.{$fn} = function (e, m) {";
        $lines[] = '  try {';
        $lines[] = "    navigator.sendBeacon({$endpointJs}, new Blob(";
        $lines[] = '      [JSON.stringify({ e: e, m: m || {}, p: location.pathname })],';
        $lines[] = "      { type: 'application/json' }));";
        $lines[] = '  } catch (x) {}';
        $lines[] = '};';

        if ($autoPage) {
            $lines[] = "document.addEventListener('DOMContentLoaded', function () { {$fn}('page'); });";
        }

        if ($trackClicks) {
            $lines[] = '';
            $lines[] = '// Phone/text/email clicks, delegated — covers every tel:/sms:/mailto: link';
            $lines[] = '// on the site without touching each view. The number alone is kept: an';
            $lines[] = '// sms: link often carries a prefilled ?body=.';
            $lines[] = "document.addEventListener('click', function (e) {";
            $lines[] = '  var link = e.target.closest(\'a[href^="tel:"], a[href^="sms:"], a[href^="mailto:"]\');';
            $lines[] = '  if (!link) return;';
            $lines[] = "  var kind = link.href.indexOf('tel:') === 0 ? 'call' : link.href.indexOf('sms:') === 0 ? 'text' : 'email';";
            $lines[] = "  {$fn}(kind, { n: link.href.replace(/^(tel:|sms:|mailto:)/, '').replace(/[?&].*$/, '') });";
            $lines[] = '});';
        }

        if ($jsErrors) {
            $lines[] = '';
            $lines[] = '// First-party JS error capture, capped per page view; ignores';
            $lines[] = '// extension/third-party noise where the browser strips detail.';
            $lines[] = '(function () {';
            $lines[] = '  var sent = 0;';
            $lines[] = '  function browser() {';
            $lines[] = '    var u = navigator.userAgent;';
            $lines[] = '    return /Firefox/.test(u) ? \'firefox\' : /Edg\//.test(u) ? \'edge\' : /Chrome|CriOS/.test(u) ? \'chrome\' : /Safari/.test(u) ? \'safari\' : \'other\';';
            $lines[] = '  }';
            $lines[] = '  var noise = new RegExp('.json_encode(self::NOISE_PATTERN).', \'i\');';
            $lines[] = '  function report(msg, src, line) {';
            $lines[] = '    if (/^script error\.?$/i.test(String(msg || \'\').trim()) && !src) return;';
            $lines[] = '    if (noise.test(String(msg || \'\') + \' \' + String(src || \'\'))) return;';
            $lines[] = "    if (sent >= {$cap}) return; sent++;";
            $lines[] = '    var m = String(msg || \'\').slice(0, 160), s = String(src || \'\').replace(/^https?:\/\/[^\/]+/, \'\').slice(0, 80);';
            $lines[] = "    window.{$fn}('jserr', { m: m, s: s + (line ? ':' + line : ''), b: browser(), mob: /Mobile|Android|iPhone/.test(navigator.userAgent) ? 1 : 0 });";
            $lines[] = '  }';
            $lines[] = "  window.addEventListener('error', function (e) { report(e.message, e.filename, e.lineno); });";
            $lines[] = "  window.addEventListener('unhandledrejection', function (e) {";
            $lines[] = '    var r = e.reason; report(\'promise: \' + (r && (r.message || r) || \'rejected\'), \'\', 0);';
            $lines[] = '  });';
            $lines[] = '})();';
        }

        $lines[] = '</script>';

        return implode("\n", $lines)."\n";
    }
}
