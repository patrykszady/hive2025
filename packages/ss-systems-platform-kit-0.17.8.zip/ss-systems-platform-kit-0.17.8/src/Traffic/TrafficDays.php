<?php

namespace SsSystems\Platform\Traffic;

use Illuminate\Database\ConnectionInterface;

/**
 * The `traffic_source_days` table (TrafficSchema::createDailyTable): every
 * provider's per-source numbers by day — our own beacon's visits, calls and
 * forms, leads, Clarity sessions, Google and Bing search clicks, Business
 * Profile actions, and arrivals and crawls read from the server's access log.
 */
final class TrafficDays
{
    /** metric => label on the admin screens */
    public const METRICS = [
        'visits' => 'Visits',
        'sessions' => 'Clarity sessions',
        'landings' => 'Server landings',
        'search_clicks' => 'Search clicks',
        'search_impressions' => 'Search impressions',
        'profile_views' => 'Profile views',
        'profile_website_clicks' => 'Profile website clicks',
        'profile_calls' => 'Profile calls',
        'profile_directions' => 'Direction requests',
        'calls' => 'Calls',
        'texts' => 'Texts',
        'emails' => 'Emails',
        'forms' => 'Forms',
        'cta' => 'Button clicks',
        'leads' => 'Leads',
        'crawls' => 'Crawls',
    ];

    public function __construct(
        private readonly ConnectionInterface $connection,
        private readonly string $table = 'traffic_source_days',
        private readonly ?string $tenantColumn = null,
        private readonly ?\Closure $tenantId = null,
    ) {
    }

    /** The table, narrowed to the current tenant on a multi-tenant site. */
    private function query(): \Illuminate\Database\Query\Builder
    {
        return $this->connection->table($this->table)
            ->when($this->tenantColumn !== null, fn ($q) => $q->where($this->tenantColumn, ($this->tenantId)()));
    }

    /**
     * Replace one provider's rows for one day; rows for the same source and
     * metric are summed first.
     *
     * @param  list<array{channel: string, source: string, metric: string, value: int}>  $rows
     */
    public function replace(string $provider, string $date, array $rows): int
    {
        $merged = [];
        foreach ($rows as $row) {
            if (! isset(self::METRICS[$row['metric']]) || (int) $row['value'] <= 0) {
                continue;
            }
            $key = $row['channel'].'|'.mb_substr($row['source'], 0, 60).'|'.$row['metric'];
            $merged[$key] = ($merged[$key] ?? 0) + (int) $row['value'];
        }

        $now = date('Y-m-d H:i:s');
        $insert = [];
        foreach ($merged as $key => $value) {
            [$channel, $source, $metric] = explode('|', $key, 3);
            $insert[] = ['date' => $date, 'provider' => $provider, 'channel' => $channel, 'source' => $source, 'metric' => $metric, 'value' => $value, 'created_at' => $now, 'updated_at' => $now]
                + ($this->tenantColumn !== null ? [$this->tenantColumn => ($this->tenantId)()] : []);
        }

        $this->connection->transaction(function () use ($provider, $date, $insert) {
            $this->query()->where('provider', $provider)->where('date', $date)->delete();
            foreach (array_chunk($insert, 200) as $chunk) {
                $this->connection->table($this->table)->insert($chunk);
            }
        });

        return count($insert);
    }

    /**
     * Totals per channel, source and metric between two dates (inclusive).
     *
     * @return list<array{provider: string, channel: string, source: string, metric: string, value: int}>
     */
    public function totals(string $from, string $to): array
    {
        return $this->query()
            ->whereBetween('date', [$from, $to])
            ->groupBy('provider', 'channel', 'source', 'metric')
            ->selectRaw('provider, channel, source, metric, SUM(value) as value')
            ->get()
            ->map(fn ($row) => ['provider' => (string) $row->provider, 'channel' => (string) $row->channel, 'source' => (string) $row->source, 'metric' => (string) $row->metric, 'value' => (int) $row->value])
            ->all();
    }

    /**
     * Visitors per source between two dates (inclusive). A day our own tag
     * counted on is read from the tag alone (every source, no double count);
     * a day before the tag ran — history — falls back to the clicks Google,
     * Bing and the Business Profile report, since a click on the site's
     * link is a visitor. Says how many days of each kind the window held.
     *
     * @return array{rows: list<array{channel: string, source: string, visitors: int}>, tag_days: int, estimated_days: int}
     */
    public function visitorsBySource(string $from, string $to): array
    {
        $rows = $this->query()
            ->whereBetween('date', [$from, $to])
            ->whereIn('metric', ['visits', 'search_clicks', 'profile_website_clicks'])
            ->groupBy('date', 'channel', 'source', 'metric')
            ->selectRaw('date, channel, source, metric, SUM(value) as value')
            ->get();

        $byDay = [];
        foreach ($rows as $row) {
            $byDay[substr((string) $row->date, 0, 10)][] = $row;
        }

        $out = [];
        $tagDays = 0;
        $estimatedDays = 0;
        foreach ($byDay as $day => $dayRows) {
            $tagged = collect($dayRows)->contains(fn ($row) => $row->metric === 'visits');
            $tagged ? $tagDays++ : $estimatedDays++;
            foreach ($dayRows as $row) {
                if (($row->metric === 'visits') !== $tagged) {
                    continue;
                }
                $key = $row->channel.'|'.$row->source;
                $out[$key] = ($out[$key] ?? 0) + (int) $row->value;
            }
        }

        $list = [];
        foreach ($out as $key => $visitors) {
            [$channel, $source] = explode('|', $key, 2);
            $list[] = ['channel' => $channel, 'source' => $source, 'visitors' => $visitors];
        }

        return ['rows' => $list, 'tag_days' => $tagDays, 'estimated_days' => $estimatedDays];
    }

    /** The first day with any row — or with that metric's rows — as Y-m-d, or null. */
    public function earliestDay(?string $metric = null): ?string
    {
        $date = $this->query()->when($metric !== null, fn ($q) => $q->where('metric', $metric))->min('date');

        return $date !== null ? substr((string) $date, 0, 10) : null;
    }

    /**
     * The latest day each provider has rows for.
     *
     * @return array<string, string>
     */
    public function latestDays(): array
    {
        return $this->query()
            ->groupBy('provider')
            ->selectRaw('provider, MAX(date) as latest')
            ->pluck('latest', 'provider')
            ->map(fn ($date) => substr((string) $date, 0, 10))
            ->all();
    }
}
