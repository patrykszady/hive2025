<?php

namespace SsSystems\Platform\Traffic;

use Illuminate\Database\Schema\Blueprint;

/**
 * The attribution columns a site adds to its Pulse events table
 * (`site_events`) so every page view, call and form carries where the visit
 * arrived from (2026-10-26). A site's migration calls these, so every site
 * stores the same shape:
 *
 *   Schema::table('site_events', fn (Blueprint $table) => TrafficSchema::addArrivalColumns($table));
 *
 * Pulse's DatabaseTableStorage writes them only when they exist, so a site
 * that has not migrated keeps recording as before.
 */
final class TrafficSchema
{
    public const ARRIVAL_COLUMNS = ['referrer', 'utm_source', 'utm_medium', 'utm_campaign', 'landing_path', 'channel', 'source', 'arrival'];

    public static function addArrivalColumns(Blueprint $table): void
    {
        $table->string('referrer', 255)->nullable();
        $table->string('utm_source', 100)->nullable();
        $table->string('utm_medium', 100)->nullable();
        $table->string('utm_campaign', 100)->nullable();
        $table->string('landing_path', 191)->nullable();
        $table->string('channel', 16)->nullable();
        $table->string('source', 60)->nullable();
        // The first page of a visit: one row per arrival, so visits per source count.
        $table->boolean('arrival')->default(false);
        $table->index(['arrival', 'created_at']);
        $table->index(['channel', 'created_at']);
    }

    /**
     * `traffic_source_days`: one row per day, provider, source and metric —
     * every connection's per-source numbers in one place (Traffic\TrafficDays).
     */
    public static function createDailyTable(Blueprint $table, ?string $tenantColumn = null): void
    {
        $table->id();
        // A multi-tenant site (gs.construction) keeps each tenant's numbers apart.
        if ($tenantColumn !== null) {
            $table->unsignedBigInteger($tenantColumn)->nullable()->index();
        }
        $table->date('date');
        $table->string('provider', 24);
        $table->string('channel', 16);
        $table->string('source', 60);
        $table->string('metric', 32);
        $table->unsignedBigInteger('value')->default(0);
        $table->timestamps();
        $table->unique([...($tenantColumn !== null ? [$tenantColumn] : []), 'date', 'provider', 'channel', 'source', 'metric'], 'traffic_source_days_key');
        $table->index(['metric', 'date']);
    }

    public static function dropArrivalColumns(Blueprint $table): void
    {
        $table->dropIndex(['arrival', 'created_at']);
        $table->dropIndex(['channel', 'created_at']);
        $table->dropColumn(self::ARRIVAL_COLUMNS);
    }
}
