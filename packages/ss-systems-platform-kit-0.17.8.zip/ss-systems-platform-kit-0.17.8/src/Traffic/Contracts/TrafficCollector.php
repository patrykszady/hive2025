<?php

namespace SsSystems\Platform\Traffic\Contracts;

/**
 * One connection's per-source numbers for a day (Traffic\TrafficCollectors
 * stores them in `traffic_source_days`).
 */
interface TrafficCollector
{
    /** The provider key stored with every row, e.g. "clarity". */
    public function provider(): string;

    /**
     * The day's rows: channel, source, metric (one of TrafficDays::METRICS)
     * and value. Null when the connection is not set up, failed, or has
     * nothing for that day yet — the day's stored rows are then left as
     * they are, so a late or broken provider never wipes earlier numbers.
     *
     * @return list<array{channel: string, source: string, metric: string, value: int}>|null
     */
    public function collect(\DateTimeImmutable $day): ?array;

    /** Why the last collect() returned null, for the command's report. */
    public function lastProblem(): ?string;
}
