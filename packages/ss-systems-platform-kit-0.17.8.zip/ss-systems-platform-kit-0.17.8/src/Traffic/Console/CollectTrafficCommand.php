<?php

namespace SsSystems\Platform\Traffic\Console;

use Illuminate\Console\Command;
use SsSystems\Platform\Traffic\TrafficCollectors;

/**
 * `traffic:collect` — every provider's per-source numbers into
 * traffic_source_days. A site runs it three ways: `--date=today` hourly for
 * the providers that read its own tables (beacon, tracked_events, leads);
 * `--days=5` each morning and right after each platform sync lands (Search
 * Console and Business Profile fill in two to five days late; Clarity only
 * reports the last 24 hours); `--from=<date>` once, for history. A site
 * registers it in bootstrap/app.php's withCommands().
 */
class CollectTrafficCommand extends Command
{
    protected $signature = 'traffic:collect
        {--days=5 : Collect yesterday and this many days before it, minus one}
        {--date= : Collect only this day (Y-m-d)}
        {--from= : Collect every day from this date (Y-m-d) to yesterday — the one-time history load}
        {--provider=* : Only these providers (beacon, tracked_events, leads, clarity, search_console, bing, business_profile, server_log)}';

    protected $description = 'Collect visits, clicks, contacts and crawls per traffic source into traffic_source_days';

    public function handle(TrafficCollectors $collectors): int
    {
        $only = array_values(array_filter((array) $this->option('provider')));

        if ($date = $this->option('date')) {
            $days = [new \DateTimeImmutable((string) $date)];
        } elseif ($from = $this->option('from')) {
            // Oldest first, so a long load that stops early leaves a contiguous history.
            $day = new \DateTimeImmutable((string) $from);
            $yesterday = new \DateTimeImmutable('yesterday');
            $days = [];
            while ($day <= $yesterday && count($days) < 730) {
                $days[] = $day;
                $day = $day->modify('+1 day');
            }
        } else {
            $count = max(1, min(60, (int) $this->option('days')));
            $yesterday = new \DateTimeImmutable('yesterday');
            $days = array_map(fn (int $back) => $yesterday->modify("-{$back} days"), range(0, $count - 1));
        }

        foreach ($days as $day) {
            foreach ($collectors->collect($day, $only) as $provider => $outcome) {
                $this->line(sprintf('%s  %-16s %s', $day->format('Y-m-d'), $provider, $outcome));
            }
        }

        return self::SUCCESS;
    }
}
