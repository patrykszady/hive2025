<?php

namespace SsSystems\Platform\Traffic;

use SsSystems\Platform\Traffic\Contracts\TrafficCollector;

/**
 * A site's traffic collectors, run day by day into `traffic_source_days`.
 * A site binds this in its service provider with the connections it has
 * (Clarity, Search Console, Bing, Business Profile, its access log…); a
 * collector that is not set up simply reports why it skipped.
 */
final class TrafficCollectors
{
    /** @param  list<TrafficCollector>  $collectors */
    public function __construct(
        private readonly TrafficDays $days,
        private readonly array $collectors,
    ) {
    }

    /** @return list<TrafficCollector> */
    public function collectors(): array
    {
        return $this->collectors;
    }

    /**
     * Collect one day from every provider (or the named ones).
     *
     * @param  list<string>  $only
     * @return array<string, string> provider => what happened
     */
    public function collect(\DateTimeImmutable $day, array $only = []): array
    {
        $report = [];

        foreach ($this->collectors as $collector) {
            $provider = $collector->provider();
            if ($only !== [] && ! in_array($provider, $only, true)) {
                continue;
            }

            try {
                $rows = $collector->collect($day);
                $report[$provider] = $rows === null
                    ? 'skipped: '.($collector->lastProblem() ?? 'nothing to collect')
                    : $this->days->replace($provider, $day->format('Y-m-d'), $rows).' rows';
            } catch (\Throwable $e) {
                $report[$provider] = 'failed: '.mb_substr($e->getMessage(), 0, 160);
            }
        }

        return $report;
    }
}
