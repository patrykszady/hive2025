<?php

namespace SsSystems\Platform\Traffic;

use Illuminate\Http\Request;

/**
 * Where the current visit arrived from (2026-10-26). The Pulse beacon writes
 * it as the `ss_arrival` cookie on the visit's first page — the external
 * referrer and UTM tags of that page, plus the landing path — and slides it
 * 30 minutes on every page after, so a call, a form or a lead on the fifth
 * page is credited to Google, not to the site's own previous page.
 *
 * Read from the raw Cookie header rather than $request->cookie(): Laravel's
 * EncryptCookies middleware drops any cookie it did not encrypt itself, and
 * this one is written by the browser. No site needs an exception list.
 */
final class Arrival
{
    public const COOKIE = 'ss_arrival';

    public function __construct(
        public readonly ?string $referrer = null,
        public readonly ?string $utmSource = null,
        public readonly ?string $utmMedium = null,
        public readonly ?string $utmCampaign = null,
        public readonly ?string $landingPath = null,
    ) {
    }

    /**
     * The beacon's compact shape: r (referrer), us/um/uc (utm source, medium,
     * campaign), l (landing path).
     *
     * @param  array<string, mixed>  $data
     */
    public static function fromArray(array $data): self
    {
        return new self(
            self::text($data['r'] ?? null, 255),
            self::text($data['us'] ?? null, 100),
            self::text($data['um'] ?? null, 100),
            self::text($data['uc'] ?? null, 100),
            self::text($data['l'] ?? null, 191),
        );
    }

    public static function fromCookieValue(?string $raw): ?self
    {
        if ($raw === null || $raw === '') {
            return null;
        }

        $decoded = json_decode(rawurldecode($raw), true);

        return is_array($decoded) ? self::fromArray($decoded) : null;
    }

    public static function fromRequest(Request $request): ?self
    {
        $header = (string) $request->headers->get('cookie', '');

        if ($header === '' || ! str_contains($header, self::COOKIE.'=')) {
            // No raw header (Livewire's test requests, a site that exempted
            // the cookie from encryption): the parsed cookie, if it is there.
            $parsed = $request->cookies->get(self::COOKIE);

            return is_string($parsed) ? self::fromCookieValue($parsed) : null;
        }

        foreach (explode(';', $header) as $pair) {
            [$name, $value] = array_pad(explode('=', trim($pair), 2), 2, '');
            if ($name === self::COOKIE) {
                return self::fromCookieValue($value);
            }
        }

        return null;
    }

    /**
     * The columns a site stores for an event or a lead, with the source named.
     *
     * @param  list<string>  $ownHosts
     * @return array{referrer: ?string, utm_source: ?string, utm_medium: ?string, utm_campaign: ?string, landing_path: ?string, channel: string, source: string}
     */
    public function attributes(array $ownHosts = []): array
    {
        $named = SourceClassifier::classify($this->referrer, $this->utmSource, $this->utmMedium, $ownHosts, $this->utmCampaign);

        return [
            'referrer' => $this->referrer,
            'utm_source' => $this->utmSource,
            'utm_medium' => $this->utmMedium,
            'utm_campaign' => $this->utmCampaign,
            'landing_path' => $this->landingPath,
            'channel' => $named['channel'],
            'source' => mb_substr($named['source'], 0, 60),
        ];
    }

    /**
     * A lead or event's attribution for this request: the visit's arrival
     * when the beacon recorded one, else the fallback referrer (dropped when
     * it is the site's own page) and UTM tags the caller had.
     *
     * @return array{referrer: ?string, utm_source: ?string, utm_medium: ?string, utm_campaign: ?string, landing_path: ?string, channel: string, source: string}
     */
    public static function attributesFor(Request $request, ?string $fallbackReferrer = null, ?string $utmSource = null, ?string $utmMedium = null, ?string $utmCampaign = null): array
    {
        $own = SourceClassifier::ownHosts($request->getHost());
        $arrival = self::fromRequest($request);

        if ($arrival !== null) {
            return $arrival->attributes($own);
        }

        $referrer = self::text($fallbackReferrer, 255);
        if (SourceClassifier::isOwnReferrer($referrer, $own)) {
            $referrer = null;
        }

        return (new self($referrer, self::text($utmSource, 100), self::text($utmMedium, 100), self::text($utmCampaign, 100)))->attributes($own);
    }

    private static function text(mixed $value, int $max): ?string
    {
        if (! is_string($value)) {
            return null;
        }

        $value = trim($value);

        return $value === '' ? null : mb_substr($value, 0, $max);
    }
}
