<?php

namespace SsSystems\Platform\Traffic\Collectors;

use SsSystems\Platform\Traffic\SourceClassifier;

/**
 * The server's own nginx access log (on since 2026-10-26): page loads that
 * arrived from another site, per named source — counted even when a browser
 * runs no JavaScript — and crawls per bot (Googlebot, GPTBot, ClaudeBot…),
 * which no analytics tag ever sees. Reads the live file and yesterday's
 * rotated copy; nginx's combined format and the estate's ss_timed format
 * both parse.
 */
final class AccessLogCollector extends BaseCollector
{
    private const LINE = '/^\S+ (?:- \S+ )?\[(?<time>[^\]]+)\] (?:"[^"]*" )?"(?<method>[A-Z]+) (?<path>\S+)[^"]*" (?<status>\d{3}) \S+(?: rt=\S+ urt=\S+)? "(?<ref>[^"]*)" "(?<ua>[^"]*)"/';

    /** Paths that are never a page someone landed on. */
    private const NOT_PAGES = '#^/(livewire|build|storage|api|t$|track|admin|flux|vendor|_|up$|favicon|robots\.txt|sitemap)|\.(css|js|mjs|map|png|jpe?g|gif|webp|avif|svg|ico|woff2?|ttf|eot|json|xml|txt|pdf|mp4|webm|mp3|m4a|zip)(\?|$)#i';

    /** User agent fragment => [channel, crawler name]; first match wins. */
    private const CRAWLERS = [
        'Google-InspectionTool' => ['search', 'Google inspection'],
        'AdsBot-Google' => ['search', 'Google Ads bot'],
        'GoogleOther' => ['search', 'GoogleOther'],
        'Googlebot' => ['search', 'Googlebot'],
        'bingbot' => ['search', 'Bingbot'],
        'DuckDuckBot' => ['search', 'DuckDuckBot'],
        'Applebot' => ['search', 'Applebot'],
        'YandexBot' => ['search', 'YandexBot'],
        'Baiduspider' => ['search', 'Baidu'],
        'OAI-SearchBot' => ['ai', 'OpenAI search'],
        'ChatGPT-User' => ['ai', 'ChatGPT browsing'],
        'GPTBot' => ['ai', 'GPTBot'],
        'PerplexityBot' => ['ai', 'PerplexityBot'],
        'Perplexity-User' => ['ai', 'Perplexity browsing'],
        'ClaudeBot' => ['ai', 'ClaudeBot'],
        'Claude-User' => ['ai', 'Claude browsing'],
        'anthropic-ai' => ['ai', 'Anthropic'],
        'meta-externalagent' => ['ai', 'Meta AI'],
        'Amazonbot' => ['ai', 'Amazonbot'],
        'Bytespider' => ['ai', 'ByteDance'],
        'CCBot' => ['ai', 'Common Crawl'],
        'facebookexternalhit' => ['social', 'Facebook previews'],
        'Twitterbot' => ['social', 'X previews'],
        'LinkedInBot' => ['social', 'LinkedIn previews'],
        'Slackbot' => ['social', 'Slack previews'],
        'Discordbot' => ['social', 'Discord previews'],
        'WhatsApp' => ['social', 'WhatsApp previews'],
        'AhrefsBot' => ['referral', 'Ahrefs'],
        'SemrushBot' => ['referral', 'Semrush'],
        'DataForSeoBot' => ['referral', 'DataForSEO'],
        'MJ12bot' => ['referral', 'Majestic'],
        'DotBot' => ['referral', 'Moz'],
    ];

    /** Clients that are neither people nor named crawlers. */
    private const NOT_PEOPLE = '/bot|crawl|spider|slurp|curl|wget|python|go-http|java\/|okhttp|axios|node-fetch|headless|lighthouse|pingdom|uptime|monitor|scanner|^$/i';

    /**
     * @param  list<string>  $paths  live log files; each one's ".1" rotation is read too
     * @param  list<string>  $ownHosts
     */
    public function __construct(
        private readonly array $paths,
        private readonly array $ownHosts = [],
    ) {
    }

    public function provider(): string
    {
        return 'server_log';
    }

    public function collect(\DateTimeImmutable $day): ?array
    {
        $this->problem = null;
        $files = [];
        foreach ($this->paths as $path) {
            foreach ([$path, $path.'.1'] as $file) {
                if (is_file($file) && is_readable($file)) {
                    $files[] = $file;
                }
            }
        }

        if ($files === []) {
            return $this->skip('no readable access log');
        }

        $want = $day->format('d/M/Y');
        $own = SourceClassifier::ownHosts(null, $this->ownHosts);
        $counts = [];

        foreach ($files as $file) {
            $handle = fopen($file, 'r');
            if ($handle === false) {
                continue;
            }
            while (($line = fgets($handle)) !== false) {
                if (! str_contains($line, '['.$want.':') || preg_match(self::LINE, $line, $m) !== 1) {
                    continue;
                }
                $this->count($m, $own, $counts);
            }
            fclose($handle);
        }

        $rows = [];
        foreach ($counts as $key => $value) {
            [$channel, $source, $metric] = explode('|', $key, 3);
            $rows[] = ['channel' => $channel, 'source' => $source, 'metric' => $metric, 'value' => $value];
        }

        return $rows;
    }

    /**
     * @param  array<string, string>  $m
     * @param  list<string>  $own
     * @param  array<string, int>  $counts
     */
    private function count(array $m, array $own, array &$counts): void
    {
        foreach (self::CRAWLERS as $fragment => [$channel, $name]) {
            if (stripos($m['ua'], $fragment) !== false) {
                $key = "{$channel}|{$name}|crawls";
                $counts[$key] = ($counts[$key] ?? 0) + 1;

                return;
            }
        }

        if ($m['method'] !== 'GET' || $m['status'] !== '200' || preg_match(self::NOT_PAGES, $m['path']) === 1 || preg_match(self::NOT_PEOPLE, $m['ua']) === 1) {
            return;
        }

        $referrer = $m['ref'] === '-' ? '' : $m['ref'];
        if ($referrer === '') {
            return;
        }

        if (SourceClassifier::isOwnReferrer($referrer, $own)) {
            return;
        }

        parse_str((string) parse_url($m['path'], PHP_URL_QUERY), $query);
        $named = SourceClassifier::classify($referrer, $query['utm_source'] ?? null, $query['utm_medium'] ?? null, $own, $query['utm_campaign'] ?? null);

        $key = "{$named['channel']}|{$named['source']}|landings";
        $counts[$key] = ($counts[$key] ?? 0) + 1;
    }
}
