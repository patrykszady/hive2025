<?php

namespace SsSystems\Platform\Traffic\Collectors;

use Illuminate\Database\ConnectionInterface;
use SsSystems\Platform\Traffic\SourceClassifier;

/**
 * Leads (`contact_submissions`) that did NOT come through the website's own
 * form, per named source, spam left out. A form lead is already counted as
 * a form (the tracker's form_submit or the beacon's form event), so counting
 * it here again would double it; what this adds are the leads that arrive
 * another way — Yelp's inbox, the crew mailbox, Business Profile messages —
 * named by the table's `source` column. A table without that column counts
 * every lead by its referrer and tags, as before.
 */
final class LeadsCollector extends BaseCollector
{
    /** `source` values that mean the website's own form. */
    public const FORM_SOURCES = ['web', 'ajax', 'website', 'form', 'site'];

    /** `source` values that are internal, never a visitor. */
    public const INTERNAL_SOURCES = ['hive', 'manual', 'admin', 'import', 'test'];

    /**
     * `source` value (lower-cased) => [channel, source name] for leads that
     * arrive outside the website form.
     *
     * @var array<string, array{0: string, 1: string}>
     */
    public const SOURCE_NAMES = [
        'yelp' => ['directory', 'Yelp'],
        'houzz' => ['directory', 'Houzz'],
        'angi' => ['directory', 'Angi'],
        'thumbtack' => ['directory', 'Thumbtack'],
        'messages' => ['local', 'Google Business Profile'],
        'gbp' => ['local', 'Google Business Profile'],
        'google-messages' => ['local', 'Google Business Profile'],
        'crew-email' => ['email', 'Email'],
        'email' => ['email', 'Email'],
        'inbox' => ['email', 'Email'],
        'facebook' => ['social', 'Facebook'],
        'instagram' => ['social', 'Instagram'],
        'nextdoor' => ['social', 'Nextdoor'],
    ];

    /** @param  list<string>  $ownHosts */
    public function __construct(
        private readonly ConnectionInterface $connection,
        private readonly string $table = 'contact_submissions',
        private readonly array $ownHosts = [],
        private readonly ?string $tenantColumn = null,
        private readonly ?\Closure $tenantId = null,
    ) {
    }

    public function provider(): string
    {
        return 'leads';
    }

    public function collect(\DateTimeImmutable $day): ?array
    {
        $this->problem = null;
        $schema = $this->connection->getSchemaBuilder();

        if (! $schema->hasTable($this->table)) {
            return $this->skip("no {$this->table} table");
        }

        $columns = $schema->getColumnListing($this->table);
        $wanted = array_values(array_intersect(['referrer', 'utm_source', 'utm_medium', 'utm_campaign', 'status', 'source'], $columns));
        $hasSource = in_array('source', $columns, true);
        [$start, $end] = $this->bounds($day);
        $own = SourceClassifier::ownHosts(null, $this->ownHosts);
        $rows = [];

        $leads = $this->connection->table($this->table)
            ->whereBetween('created_at', [$start, $end])
            ->when(in_array('status', $columns, true), fn ($q) => $q->where(fn ($w) => $w->whereNull('status')->orWhere('status', '!=', 'spam')))
            ->when($this->tenantColumn !== null, fn ($q) => $q->where($this->tenantColumn, ($this->tenantId)()))
            ->get($wanted === [] ? ['id'] : $wanted);

        foreach ($leads as $lead) {
            if ($hasSource) {
                $via = strtolower(trim((string) ($lead->source ?? '')));
                if ($via === '' || in_array($via, self::FORM_SOURCES, true) || in_array($via, self::INTERNAL_SOURCES, true)) {
                    continue;
                }
                if (isset(self::SOURCE_NAMES[$via])) {
                    [$channel, $name] = self::SOURCE_NAMES[$via];
                    $rows[] = ['channel' => $channel, 'source' => $name, 'metric' => 'leads', 'value' => 1];

                    continue;
                }
            }

            $named = SourceClassifier::classify($lead->referrer ?? null, $lead->utm_source ?? null, $lead->utm_medium ?? null, $own, $lead->utm_campaign ?? null);
            if ($hasSource && $named['channel'] === 'direct') {
                // An unrecognised way in, with no referrer to go on: name the way itself.
                $named = ['channel' => 'referral', 'source' => ucfirst($via)];
            }
            $rows[] = ['channel' => $named['channel'], 'source' => $named['source'], 'metric' => 'leads', 'value' => 1];
        }

        return $rows;
    }
}
