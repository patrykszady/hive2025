<?php

namespace SsSystems\Platform\Traffic\Collectors;

use SsSystems\Platform\Traffic\Contracts\TrafficCollector;

/** The shared "why nothing was collected" note. */
abstract class BaseCollector implements TrafficCollector
{
    protected ?string $problem = null;

    public function lastProblem(): ?string
    {
        return $this->problem;
    }

    /** @return null */
    protected function skip(string $why): ?array
    {
        $this->problem = $why;

        return null;
    }

    /** @return array{0: string, 1: string} the day's first and last second */
    protected function bounds(\DateTimeImmutable $day): array
    {
        return [$day->format('Y-m-d').' 00:00:00', $day->format('Y-m-d').' 23:59:59'];
    }
}
