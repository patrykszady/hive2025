<?php

namespace SsSystems\Platform\Traffic\Collectors;

use Illuminate\Database\ConnectionInterface;

/**
 * Our own beacon (`site_events` with TrafficSchema's arrival columns): visits
 * per source — the first page of each visit — and calls, texts, emails and
 * forms credited to where their visit came from. A site whose conversions are
 * counted by the older /track tracker passes no event metrics, so nothing is
 * counted twice.
 */
final class PulseEventsCollector extends BaseCollector
{
    /** @param  array<string, string>  $eventMetrics  beacon event => metric */
    public function __construct(
        private readonly ConnectionInterface $connection,
        private readonly string $table = 'site_events',
        private readonly array $eventMetrics = ['call' => 'calls', 'text' => 'texts', 'email' => 'emails', 'form' => 'forms'],
        private readonly ?string $tenantColumn = null,
        private readonly ?\Closure $tenantId = null,
    ) {
    }

    public function provider(): string
    {
        return 'beacon';
    }

    public function collect(\DateTimeImmutable $day): ?array
    {
        $this->problem = null;
        $columns = $this->connection->getSchemaBuilder()->getColumnListing($this->table);

        if (! in_array('channel', $columns, true) || ! in_array('arrival', $columns, true)) {
            return $this->skip("{$this->table} has no arrival columns yet");
        }

        [$start, $end] = $this->bounds($day);
        $base = fn () => $this->connection->table($this->table)
            ->whereBetween('created_at', [$start, $end])
            ->whereNotNull('channel')
            ->when($this->tenantColumn !== null, fn ($q) => $q->where($this->tenantColumn, ($this->tenantId)()));

        $rows = [];

        foreach ($base()->where('event', 'page')->where('arrival', true)->groupBy('channel', 'source')->selectRaw('channel, source, COUNT(*) as n')->get() as $row) {
            $rows[] = ['channel' => (string) $row->channel, 'source' => (string) ($row->source ?? 'Direct'), 'metric' => 'visits', 'value' => (int) $row->n];
        }

        if ($this->eventMetrics !== []) {
            foreach ($base()->whereIn('event', array_keys($this->eventMetrics))->groupBy('event', 'channel', 'source')->selectRaw('event, channel, source, COUNT(*) as n')->get() as $row) {
                $rows[] = ['channel' => (string) $row->channel, 'source' => (string) ($row->source ?? 'Direct'), 'metric' => $this->eventMetrics[$row->event], 'value' => (int) $row->n];
            }
        }

        return $rows;
    }
}
