<?php

namespace SsSystems\Platform\Traffic\Collectors;

use Illuminate\Database\ConnectionInterface;

/** Bing's daily clicks and impressions, from the site's BingSync table. */
final class BingTotalsCollector extends BaseCollector
{
    public function __construct(
        private readonly ConnectionInterface $connection,
        private readonly string $table = 'bing_daily_totals',
    ) {
    }

    public function provider(): string
    {
        return 'bing';
    }

    public function collect(\DateTimeImmutable $day): ?array
    {
        $this->problem = null;

        if (! $this->connection->getSchemaBuilder()->hasTable($this->table)) {
            return $this->skip("no {$this->table} table");
        }

        $row = $this->connection->table($this->table)->whereDate('date', $day->format('Y-m-d'))
            ->selectRaw('SUM(clicks) as clicks, SUM(impressions) as impressions')->first();

        if ($row === null || ($row->clicks === null && $row->impressions === null)) {
            return $this->skip('no Bing totals for that day yet');
        }

        return [
            ['channel' => 'search', 'source' => 'Bing', 'metric' => 'search_clicks', 'value' => (int) $row->clicks],
            ['channel' => 'search', 'source' => 'Bing', 'metric' => 'search_impressions', 'value' => (int) $row->impressions],
        ];
    }
}
