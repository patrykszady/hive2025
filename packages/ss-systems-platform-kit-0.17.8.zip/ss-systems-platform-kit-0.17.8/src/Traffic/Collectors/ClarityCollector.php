<?php

namespace SsSystems\Platform\Traffic\Collectors;

use Illuminate\Http\Client\Factory as HttpFactory;
use SsSystems\Platform\Traffic\SourceClassifier;

/**
 * Microsoft Clarity's sessions per traffic source (project-live-insights,
 * dimension1=Source). Clarity only answers for the last 24 hours, so this
 * collects yesterday alone — run it early each day — and one request a day
 * stays well inside Clarity's ten per project.
 */
final class ClarityCollector extends BaseCollector
{
    public const ENDPOINT = 'https://www.clarity.ms/export-data/api/v1/project-live-insights';

    /**
     * @param  \Closure(): ?string  $token  the site's Clarity API token
     * @param  list<string>  $ownHosts  the site's hosts: Clarity names the referring site, which can be the site itself
     */
    public function __construct(
        private readonly \Closure $token,
        private readonly ?HttpFactory $http = null,
        private readonly ?\Closure $today = null,
        private readonly array $ownHosts = [],
    ) {
    }

    public function provider(): string
    {
        return 'clarity';
    }

    public function collect(\DateTimeImmutable $day): ?array
    {
        $this->problem = null;
        $today = $this->today !== null ? ($this->today)() : new \DateTimeImmutable('today');

        if ($day->format('Y-m-d') !== $today->modify('-1 day')->format('Y-m-d')) {
            return $this->skip('Clarity only reports the last 24 hours');
        }

        $token = (string) (($this->token)() ?? '');
        if ($token === '') {
            return $this->skip('no Clarity API token');
        }

        $response = ($this->http ?? new HttpFactory)->withToken($token)->acceptJson()->timeout(30)
            ->get(self::ENDPOINT, ['numOfDays' => 1, 'dimension1' => 'Source']);

        if (! $response->successful()) {
            return $this->skip('Clarity answered '.$response->status());
        }

        $rows = [];
        foreach ((array) $response->json() as $group) {
            if (! is_array($group) || strcasecmp((string) ($group['metricName'] ?? ''), 'Traffic') !== 0) {
                continue;
            }

            foreach ((array) ($group['information'] ?? []) as $info) {
                if (! is_array($info)) {
                    continue;
                }
                $sessions = (int) ($info['totalSessionCount'] ?? $info['sessionsCount'] ?? 0);
                $named = $this->name(self::dimensionValue($info));
                $rows[] = ['channel' => $named['channel'], 'source' => $named['source'], 'metric' => 'sessions', 'value' => $sessions];
            }
        }

        return $rows;
    }

    /**
     * Clarity's Source is the referring site's name ("google.com",
     * "gs.construction") or a tag ("google"): a name with a dot is read as a
     * referrer, so the site itself and local testing are not Campaigns.
     *
     * @return array{channel: string, source: string}
     */
    private function name(?string $value): array
    {
        $value = strtolower(trim((string) $value));

        if ($value === '' || preg_match('/^\(?(direct|none|not set|unknown)\)?$/', $value) === 1) {
            return ['channel' => 'direct', 'source' => 'Direct'];
        }

        if (preg_match('/^(localhost|127\.0\.0\.1|\[?::1\]?)(:\d+)?$/', $value) === 1) {
            return ['channel' => 'direct', 'source' => 'Direct'];
        }

        $own = SourceClassifier::ownHosts(null, $this->ownHosts);

        return str_contains($value, '.') && ! str_contains($value, ' ')
            ? SourceClassifier::classify('https://'.$value, null, null, $own)
            : SourceClassifier::classify(null, $value, null, $own);
    }

    /** The Source value in a row, whatever case Clarity spells the key in. */
    private static function dimensionValue(array $info): ?string
    {
        foreach ($info as $key => $value) {
            if (strcasecmp((string) $key, 'Source') === 0) {
                $value = trim((string) $value);

                return $value === '' ? null : $value;
            }
        }

        return null;
    }
}
