<?php

namespace SsSystems\Platform\Traffic\Collectors;

use Illuminate\Database\ConnectionInterface;
use SsSystems\Platform\Traffic\SourceClassifier;

/**
 * The older /track tracker's `tracked_events` (gs.construction, jpeterson):
 * calls, texts, emails, forms and button clicks per named source — every
 * row the Analytics screen lists, so the two agree.
 */
final class TrackedEventsCollector extends BaseCollector
{
    /**
     * @param  array<string, string>  $typeMetrics  tracked type => metric
     * @param  list<string>  $ownHosts
     */
    public function __construct(
        private readonly ConnectionInterface $connection,
        private readonly string $table = 'tracked_events',
        private readonly array $typeMetrics = ['phone_click' => 'calls', 'text_click' => 'texts', 'email_click' => 'emails', 'form_submit' => 'forms', 'cta_click' => 'cta'],
        private readonly array $ownHosts = [],
        private readonly ?string $tenantColumn = null,
        private readonly ?\Closure $tenantId = null,
    ) {
    }

    public function provider(): string
    {
        return 'tracked_events';
    }

    public function collect(\DateTimeImmutable $day): ?array
    {
        $this->problem = null;
        [$start, $end] = $this->bounds($day);
        $own = SourceClassifier::ownHosts(null, $this->ownHosts);
        $rows = [];

        $events = $this->connection->table($this->table)
            ->whereBetween('created_at', [$start, $end])
            ->whereIn('type', array_keys($this->typeMetrics))
            ->when($this->tenantColumn !== null, fn ($q) => $q->where($this->tenantColumn, ($this->tenantId)()))
            ->get(['type', 'referrer', 'utm_source', 'utm_medium', 'utm_campaign']);

        foreach ($events as $event) {
            $named = SourceClassifier::classify($event->referrer, $event->utm_source, $event->utm_medium, $own, $event->utm_campaign);
            $rows[] = ['channel' => $named['channel'], 'source' => $named['source'], 'metric' => $this->typeMetrics[$event->type], 'value' => 1];
        }

        return $rows;
    }
}
