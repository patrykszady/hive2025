<?php

namespace SsSystems\Platform\Traffic\Collectors;

/**
 * The Google Business Profile's own traffic: views, website clicks, call
 * taps and direction requests for a day (Business Profile Performance API).
 * The site hands in how to ask its own Business Profile connection.
 */
final class BusinessProfileCollector extends BaseCollector
{
    private const METRICS = [
        'views' => 'profile_views',
        'website_clicks' => 'profile_website_clicks',
        'calls' => 'profile_calls',
        'directions' => 'profile_directions',
    ];

    /** @param  \Closure(string $date): ?array{views?: int, website_clicks?: int, calls?: int, directions?: int}  $metrics */
    public function __construct(private readonly \Closure $metrics)
    {
    }

    public function provider(): string
    {
        return 'business_profile';
    }

    public function collect(\DateTimeImmutable $day): ?array
    {
        $this->problem = null;
        $values = ($this->metrics)($day->format('Y-m-d'));

        if (! is_array($values)) {
            return $this->skip('Business Profile did not answer');
        }

        $rows = [];
        foreach (self::METRICS as $key => $metric) {
            $rows[] = ['channel' => 'local', 'source' => 'Google Business Profile', 'metric' => $metric, 'value' => (int) ($values[$key] ?? 0)];
        }

        if (array_sum(array_column($rows, 'value')) === 0) {
            return $this->skip('no Business Profile numbers for that day yet');
        }

        return $rows;
    }
}
