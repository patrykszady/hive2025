<?php

namespace SsSystems\Platform\Traffic\Collectors;

/**
 * Google Search Console's clicks and impressions for every Google surface,
 * not just web search: Images, Video, News, Discover and the Google News app.
 * The site hands in how to ask its own Search Console connection for one
 * search type's totals on one day.
 */
final class SearchConsoleCollector extends BaseCollector
{
    /** Search Console search type => source name */
    public const TYPES = [
        'web' => 'Google',
        'image' => 'Google Images',
        'video' => 'Google Video',
        'news' => 'Google News',
        'discover' => 'Google Discover',
        'googleNews' => 'Google News app',
    ];

    /** @param  \Closure(string $type, string $date): ?array{clicks: int, impressions: int}  $totals */
    public function __construct(private readonly \Closure $totals)
    {
    }

    public function provider(): string
    {
        return 'search_console';
    }

    public function collect(\DateTimeImmutable $day): ?array
    {
        $this->problem = null;
        $rows = [];
        $answered = false;

        foreach (self::TYPES as $type => $source) {
            $totals = ($this->totals)($type, $day->format('Y-m-d'));
            if (! is_array($totals)) {
                continue;
            }
            $answered = true;
            $rows[] = ['channel' => 'search', 'source' => $source, 'metric' => 'search_clicks', 'value' => (int) ($totals['clicks'] ?? 0)];
            $rows[] = ['channel' => 'search', 'source' => $source, 'metric' => 'search_impressions', 'value' => (int) ($totals['impressions'] ?? 0)];
        }

        if (! $answered) {
            return $this->skip('Search Console did not answer');
        }

        // Search Console's last two or three days are still empty: keep the
        // day for a later run rather than storing a day of zeros.
        if (array_sum(array_column($rows, 'value')) === 0) {
            return $this->skip('no Search Console data for that day yet');
        }

        return $rows;
    }
}
