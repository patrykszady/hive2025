<?php

namespace SsSystems\Platform\Traffic;

/**
 * Where a visit came from, named the same way on every site (2026-10-26):
 * a referrer URL and/or UTM tags in, a channel and a source name out —
 * "Google" in Search, "ChatGPT" in AI assistants, "Yelp" in Directories.
 *
 * Rules, in order:
 *   1. A paid or email medium (utm_medium=cpc, email, …) decides the channel.
 *   2. A known utm_source (facebook, chatgpt.com, yelp, gbp…) names the source.
 *   3. Otherwise any utm_source is a Campaign under its own name.
 *   4. A known referrer host (google.*, l.facebook.com, chatgpt.com…) or an
 *      Android app referrer names the source; an unknown host is Other sites.
 *   5. A referrer from the site itself (the visit's first page was not seen,
 *      which is how every visit looked before the arrival cookie) is Direct,
 *      like no referrer at all — the owner wants no "unknown" anywhere.
 *   6. Nothing at all is Direct.
 */
final class SourceClassifier
{
    /** channel key => label shown on the admin screens */
    public const CHANNELS = [
        'search' => 'Search',
        'ai' => 'AI assistants',
        'local' => 'Maps & Business Profile',
        'social' => 'Social',
        'directory' => 'Directories',
        'email' => 'Email',
        'paid' => 'Paid ads',
        'campaign' => 'Campaigns',
        'referral' => 'Other sites',
        'direct' => 'Direct',
    ];

    /**
     * Host (or parent domain) => [channel, source]. Google's many country
     * domains are handled in code (google.<tld>), so only its distinct
     * subdomains are listed here.
     *
     * @var array<string, array{0: string, 1: string}>
     */
    private const HOSTS = [
        // Search engines
        'bing.com' => ['search', 'Bing'],
        'duckduckgo.com' => ['search', 'DuckDuckGo'],
        'search.brave.com' => ['search', 'Brave'],
        'search.yahoo.com' => ['search', 'Yahoo'],
        'yahoo.com' => ['search', 'Yahoo'],
        'ecosia.org' => ['search', 'Ecosia'],
        'startpage.com' => ['search', 'Startpage'],
        'yandex.com' => ['search', 'Yandex'],
        'yandex.ru' => ['search', 'Yandex'],
        'baidu.com' => ['search', 'Baidu'],
        'search.aol.com' => ['search', 'AOL'],
        'news.google.com' => ['search', 'Google News'],
        // AI assistants
        'chatgpt.com' => ['ai', 'ChatGPT'],
        'chat.openai.com' => ['ai', 'ChatGPT'],
        'openai.com' => ['ai', 'ChatGPT'],
        'perplexity.ai' => ['ai', 'Perplexity'],
        'copilot.microsoft.com' => ['ai', 'Copilot'],
        'gemini.google.com' => ['ai', 'Gemini'],
        'bard.google.com' => ['ai', 'Gemini'],
        'claude.ai' => ['ai', 'Claude'],
        'you.com' => ['ai', 'You.com'],
        'meta.ai' => ['ai', 'Meta AI'],
        'grok.com' => ['ai', 'Grok'],
        'poe.com' => ['ai', 'Poe'],
        'phind.com' => ['ai', 'Phind'],
        'deepseek.com' => ['ai', 'DeepSeek'],
        // Maps and business listings
        'maps.google.com' => ['local', 'Google Maps'],
        'business.google.com' => ['local', 'Google Business Profile'],
        'maps.apple.com' => ['local', 'Apple Maps'],
        'mapquest.com' => ['local', 'MapQuest'],
        // Social networks
        'facebook.com' => ['social', 'Facebook'],
        'fb.com' => ['social', 'Facebook'],
        'fb.me' => ['social', 'Facebook'],
        'messenger.com' => ['social', 'Facebook'],
        'instagram.com' => ['social', 'Instagram'],
        'threads.net' => ['social', 'Threads'],
        'nextdoor.com' => ['social', 'Nextdoor'],
        'linkedin.com' => ['social', 'LinkedIn'],
        'lnkd.in' => ['social', 'LinkedIn'],
        'pinterest.com' => ['social', 'Pinterest'],
        'pin.it' => ['social', 'Pinterest'],
        'x.com' => ['social', 'X'],
        'twitter.com' => ['social', 'X'],
        't.co' => ['social', 'X'],
        'youtube.com' => ['social', 'YouTube'],
        'youtu.be' => ['social', 'YouTube'],
        'reddit.com' => ['social', 'Reddit'],
        'tiktok.com' => ['social', 'TikTok'],
        // Directories and marketplaces
        'yelp.com' => ['directory', 'Yelp'],
        'houzz.com' => ['directory', 'Houzz'],
        'angi.com' => ['directory', 'Angi'],
        'angieslist.com' => ['directory', 'Angi'],
        'homeadvisor.com' => ['directory', 'HomeAdvisor'],
        'thumbtack.com' => ['directory', 'Thumbtack'],
        'bbb.org' => ['directory', 'BBB'],
        'porch.com' => ['directory', 'Porch'],
        'buildzoom.com' => ['directory', 'BuildZoom'],
        'bark.com' => ['directory', 'Bark'],
        'networx.com' => ['directory', 'Networx'],
        'yellowpages.com' => ['directory', 'Yellow Pages'],
        'manta.com' => ['directory', 'Manta'],
        'zillow.com' => ['directory', 'Zillow'],
        'realtor.com' => ['directory', 'Realtor.com'],
        'redfin.com' => ['directory', 'Redfin'],
        'homes.com' => ['directory', 'Homes.com'],
        'trulia.com' => ['directory', 'Trulia'],
        // Webmail
        'mail.google.com' => ['email', 'Gmail'],
        'outlook.live.com' => ['email', 'Outlook'],
        'outlook.office.com' => ['email', 'Outlook'],
        'outlook.office365.com' => ['email', 'Outlook'],
        'mail.yahoo.com' => ['email', 'Yahoo Mail'],
        'mail.aol.com' => ['email', 'AOL Mail'],
    ];

    /**
     * Android app referrers (android-app://<package>/) => [channel, source].
     *
     * @var array<string, array{0: string, 1: string}>
     */
    private const ANDROID_APPS = [
        'com.google.android.googlequicksearchbox' => ['search', 'Google'],
        'com.google.android.gm' => ['email', 'Gmail'],
        'com.google.android.apps.maps' => ['local', 'Google Maps'],
        'com.facebook.katana' => ['social', 'Facebook'],
        'com.facebook.orca' => ['social', 'Facebook'],
        'com.instagram.android' => ['social', 'Instagram'],
        'com.linkedin.android' => ['social', 'LinkedIn'],
        'com.nextdoor' => ['social', 'Nextdoor'],
        'com.pinterest' => ['social', 'Pinterest'],
        'com.reddit.frontpage' => ['social', 'Reddit'],
        'com.yelp.android' => ['directory', 'Yelp'],
        'com.openai.chatgpt' => ['ai', 'ChatGPT'],
        'com.microsoft.office.outlook' => ['email', 'Outlook'],
    ];

    /**
     * utm_source values (lower-cased) => [channel, source], for tags that are
     * not host names. A utm_source that IS a host (chatgpt.com) goes through
     * the host table instead.
     *
     * @var array<string, array{0: string, 1: string}>
     */
    private const UTM_SOURCES = [
        'google' => ['search', 'Google'],
        'bing' => ['search', 'Bing'],
        'duckduckgo' => ['search', 'DuckDuckGo'],
        'yahoo' => ['search', 'Yahoo'],
        'chatgpt' => ['ai', 'ChatGPT'],
        'openai' => ['ai', 'ChatGPT'],
        'perplexity' => ['ai', 'Perplexity'],
        'copilot' => ['ai', 'Copilot'],
        'gemini' => ['ai', 'Gemini'],
        'claude' => ['ai', 'Claude'],
        'gbp' => ['local', 'Google Business Profile'],
        'gmb' => ['local', 'Google Business Profile'],
        'google_business' => ['local', 'Google Business Profile'],
        'google-business' => ['local', 'Google Business Profile'],
        'googlebusinessprofile' => ['local', 'Google Business Profile'],
        'business_profile' => ['local', 'Google Business Profile'],
        'google_maps' => ['local', 'Google Maps'],
        'facebook' => ['social', 'Facebook'],
        'fb' => ['social', 'Facebook'],
        'instagram' => ['social', 'Instagram'],
        'ig' => ['social', 'Instagram'],
        'nextdoor' => ['social', 'Nextdoor'],
        'linkedin' => ['social', 'LinkedIn'],
        'pinterest' => ['social', 'Pinterest'],
        'twitter' => ['social', 'X'],
        'x' => ['social', 'X'],
        'youtube' => ['social', 'YouTube'],
        'tiktok' => ['social', 'TikTok'],
        'reddit' => ['social', 'Reddit'],
        'yelp' => ['directory', 'Yelp'],
        'houzz' => ['directory', 'Houzz'],
        'angi' => ['directory', 'Angi'],
        'homeadvisor' => ['directory', 'HomeAdvisor'],
        'thumbtack' => ['directory', 'Thumbtack'],
        'bbb' => ['directory', 'BBB'],
        'zillow' => ['directory', 'Zillow'],
        'newsletter' => ['email', 'Newsletter'],
        'email' => ['email', 'Email'],
    ];

    private const PAID_MEDIUMS = ['cpc', 'ppc', 'paid', 'paidsearch', 'paid_search', 'paid-search', 'paidsocial', 'paid_social', 'paid-social', 'cpm', 'cpv', 'display', 'ads', 'ad', 'banner', 'retargeting', 'remarketing', 'sponsored'];

    private const EMAIL_MEDIUMS = ['email', 'e-mail', 'e_mail', 'newsletter', 'mail'];

    /** Campaign names that mark a Business Profile link tagged as google / organic. */
    private const PROFILE_CAMPAIGNS = ['gbp', 'gmb', 'google_business', 'google-business', 'business_profile', 'googlebusinessprofile', 'local'];

    /**
     * @param  list<string>  $ownHosts  the site's own host names (www. optional)
     * @return array{channel: string, source: string}
     */
    public static function classify(?string $referrer, ?string $utmSource = null, ?string $utmMedium = null, array $ownHosts = [], ?string $utmCampaign = null): array
    {
        $source = self::clean($utmSource);
        $medium = strtolower(self::clean($utmMedium) ?? '');
        $campaign = strtolower(self::clean($utmCampaign) ?? '');

        if ($source !== null || $medium !== '') {
            $known = $source !== null ? self::knownUtmSource($source) : null;
            $name = $known[1] ?? ($source !== null ? self::prettify($source) : 'Untagged');

            if (in_array($medium, self::PAID_MEDIUMS, true)) {
                return ['channel' => 'paid', 'source' => $name === 'Google' ? 'Google Ads' : ($name === 'Bing' ? 'Microsoft Ads' : $name)];
            }

            if (in_array($medium, self::EMAIL_MEDIUMS, true)) {
                return ['channel' => 'email', 'source' => $known !== null && $known[0] === 'email' ? $known[1] : $name];
            }

            if ($known !== null) {
                if ($known[1] === 'Google' && in_array($campaign, self::PROFILE_CAMPAIGNS, true)) {
                    return ['channel' => 'local', 'source' => 'Google Business Profile'];
                }

                return ['channel' => $known[0], 'source' => $known[1]];
            }

            if ($source !== null) {
                return ['channel' => 'campaign', 'source' => $name];
            }
        }

        $referrer = self::clean($referrer);

        if ($referrer === null) {
            return ['channel' => 'direct', 'source' => 'Direct'];
        }

        if (str_starts_with(strtolower($referrer), 'android-app://')) {
            $package = strtolower((string) parse_url($referrer, PHP_URL_HOST));

            if (isset(self::ANDROID_APPS[$package])) {
                return ['channel' => self::ANDROID_APPS[$package][0], 'source' => self::ANDROID_APPS[$package][1]];
            }

            return ['channel' => 'referral', 'source' => $package !== '' ? $package : 'Android app'];
        }

        $host = self::host($referrer);

        if ($host === null) {
            return ['channel' => 'direct', 'source' => 'Direct'];
        }

        if (self::isOwnHost($host, $ownHosts)) {
            return ['channel' => 'direct', 'source' => 'Direct'];
        }

        if (($google = self::google($host, (string) parse_url($referrer, PHP_URL_PATH))) !== null) {
            return $google;
        }

        if (($known = self::knownHost($host)) !== null) {
            return ['channel' => $known[0], 'source' => $known[1]];
        }

        return ['channel' => 'referral', 'source' => $host];
    }

    public static function channelLabel(?string $channel): string
    {
        return self::CHANNELS[$channel ?? 'direct'] ?? self::CHANNELS['direct'];
    }

    /**
     * The site's own host names for a request: its host, plus APP_URL's when
     * a Laravel config is available, without www.
     *
     * @param  list<string>  $extra
     * @return list<string>
     */
    public static function ownHosts(?string $requestHost = null, array $extra = []): array
    {
        $hosts = $extra;

        if ($requestHost !== null && $requestHost !== '') {
            $hosts[] = $requestHost;
        }

        if (function_exists('config')) {
            try {
                $appHost = parse_url((string) config('app.url'), PHP_URL_HOST);
                if (is_string($appHost) && $appHost !== '') {
                    $hosts[] = $appHost;
                }
            } catch (\Throwable) {
                // No config in this context.
            }
        }

        return array_values(array_unique(array_filter(array_map(fn ($host) => self::stripWww(strtolower((string) $host)), $hosts))));
    }

    /** @return array{0: string, 1: string}|null */
    private static function knownUtmSource(string $source): ?array
    {
        $key = strtolower($source);

        if (isset(self::UTM_SOURCES[$key])) {
            return self::UTM_SOURCES[$key];
        }

        if (str_contains($key, '.')) {
            $host = self::stripWww($key);

            return self::google($host, '') ?? self::knownHost($host);
        }

        return null;
    }

    /** @return array{0: string, 1: string}|null */
    private static function knownHost(string $host): ?array
    {
        $candidate = $host;

        while (true) {
            if (isset(self::HOSTS[$candidate])) {
                return self::HOSTS[$candidate];
            }

            $dot = strpos($candidate, '.');
            if ($dot === false || substr_count($candidate, '.') < 1) {
                return null;
            }

            $candidate = substr($candidate, $dot + 1);
            if (! str_contains($candidate, '.')) {
                return null;
            }
        }
    }

    /**
     * google.<tld> and its subdomains: Maps by path or subdomain, the listed
     * subdomains (mail, gemini, news, business) by the host table, the rest
     * Google search.
     *
     * @return array{channel: string, source: string}|null
     */
    private static function google(string $host, string $path): ?array
    {
        if (preg_match('/(^|\.)google\.[a-z]{2,3}(\.[a-z]{2})?$/', $host) !== 1) {
            return null;
        }

        $sub = preg_replace('/\.?google\.[a-z]{2,3}(\.[a-z]{2})?$/', '', $host);
        $sub = $sub === 'www' ? '' : (string) $sub;

        if ($sub === 'maps' || str_starts_with($path, '/maps')) {
            return ['channel' => 'local', 'source' => 'Google Maps'];
        }

        if ($sub !== '' && isset(self::HOSTS[$sub.'.google.com'])) {
            [$channel, $source] = self::HOSTS[$sub.'.google.com'];

            return ['channel' => $channel, 'source' => $source];
        }

        return ['channel' => 'search', 'source' => 'Google'];
    }

    /**
     * Whether a referrer URL points at the site itself.
     *
     * @param  list<string>  $ownHosts
     */
    public static function isOwnReferrer(?string $referrer, array $ownHosts): bool
    {
        $referrer = self::clean($referrer);
        if ($referrer === null) {
            return false;
        }
        $host = self::host($referrer);

        return $host !== null && self::isOwnHost($host, $ownHosts);
    }

    /** @param  list<string>  $ownHosts */
    private static function isOwnHost(string $host, array $ownHosts): bool
    {
        foreach ($ownHosts as $own) {
            $own = self::stripWww(strtolower($own));
            if ($own === '') {
                continue;
            }
            if ($host === $own || str_ends_with($host, '.'.$own) || str_ends_with($own, '.'.$host)) {
                return true;
            }
        }

        return false;
    }

    private static function host(string $url): ?string
    {
        $host = parse_url(str_contains($url, '://') ? $url : 'https://'.$url, PHP_URL_HOST);

        return is_string($host) && $host !== '' ? self::stripWww(strtolower($host)) : null;
    }

    private static function stripWww(string $host): string
    {
        return preg_replace('/^(www|m|mobile)\./', '', $host) ?? $host;
    }

    private static function clean(?string $value): ?string
    {
        $value = $value !== null ? trim($value) : null;

        return $value === null || $value === '' || strtolower($value) === 'direct' || strtolower($value) === 'null' ? null : $value;
    }

    /** "spring_sale" → "Spring sale"; host-like tags keep their spelling. */
    private static function prettify(string $source): string
    {
        if (str_contains($source, '.')) {
            return self::stripWww(strtolower($source));
        }

        $words = trim(preg_replace('/[_\-+]+/', ' ', $source) ?? $source);

        return mb_strtoupper(mb_substr($words, 0, 1)).mb_substr($words, 1);
    }
}
