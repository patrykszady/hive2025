<?php

namespace SsSystems\Platform\Pulse\Storage;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Carbon;
use SsSystems\Platform\Pulse\Contracts\PulseStorage;
use SsSystems\Platform\Traffic\TrafficSchema;

/**
 * The default PulseStorage: a plain `site_events` table over one Illuminate
 * connection. Single-tenant sites (dawnsellshomes, jpeterson-design) bind
 * this with no tenant column at all. gs.construction — where every table is
 * scoped to the current Site — passes $tenantColumn ('site_id') and
 * $tenantId (a closure reading `Tenancy::currentId()` / `Site::current()->id`
 * at call time, never captured once at construction, since the bound
 * singleton outlives any one request's tenant in a queue worker): insert()
 * stamps every row with it, since() scopes every read by it. A site with
 * its own tenant-scoping convention (e.g. an Eloquent model carrying a
 * BelongsToSite-style global scope) can implement PulseStorage directly
 * instead of using this class at all.
 */
final class DatabaseTableStorage implements PulseStorage
{
    /** @var list<string> */
    private const COLUMNS = ['id', 'event', 'path', 'meta', 'vhash', 'city', 'mobile', 'created_at'];

    /** @var list<string>|null the table's columns, read once per process */
    private ?array $tableColumns = null;

    public function __construct(
        private readonly ConnectionInterface $connection,
        private readonly string $table = 'site_events',
        private readonly ?string $tenantColumn = null,
        private readonly ?\Closure $tenantId = null,
    ) {
    }

    public function insert(array $row): void
    {
        if ($this->tenantColumn !== null) {
            $row[$this->tenantColumn] = ($this->tenantId)();
        }

        // A site that has not added the attribution columns yet keeps
        // recording: keys its table lacks are dropped, never an error.
        $columns = $this->tableColumns();
        if ($columns !== []) {
            $row = array_intersect_key($row, array_flip($columns));
        }

        $this->connection->table($this->table)->insert($row);
    }

    /** @return list<string> */
    private function tableColumns(): array
    {
        if ($this->tableColumns === null) {
            try {
                $this->tableColumns = $this->connection->getSchemaBuilder()->getColumnListing($this->table);
            } catch (\Throwable) {
                $this->tableColumns = [];
            }
        }

        return $this->tableColumns;
    }

    public function since(\DateTimeInterface $since, array $events = []): array
    {
        $query = $this->connection->table($this->table)
            ->where('created_at', '>=', Carbon::parse($since)->toDateTimeString());

        if ($events !== []) {
            $query->whereIn('event', $events);
        }
        if ($this->tenantColumn !== null) {
            $query->where($this->tenantColumn, ($this->tenantId)());
        }

        $attribution = array_values(array_intersect(TrafficSchema::ARRIVAL_COLUMNS, $this->tableColumns()));

        return $query->orderBy('id')->get([...self::COLUMNS, ...$attribution])
            ->map(function ($row) use ($attribution) {
                $out = [
                    'id' => (int) $row->id,
                    'event' => (string) $row->event,
                    'path' => $row->path !== null ? (string) $row->path : null,
                    'meta' => $row->meta !== null ? (string) $row->meta : null,
                    'vhash' => (string) $row->vhash,
                    'city' => $row->city !== null ? (string) $row->city : null,
                    'mobile' => (bool) $row->mobile,
                    'created_at' => Carbon::parse($row->created_at),
                ];

                foreach ($attribution as $column) {
                    $out[$column] = $column === 'arrival' ? (bool) $row->arrival : ($row->{$column} !== null ? (string) $row->{$column} : null);
                }

                return $out;
            })
            ->all();
    }
}
