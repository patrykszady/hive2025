<?php

namespace SsSystems\Platform\Http\Admin\Concerns;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use SsSystems\Platform\Traffic\SourceClassifier;
use SsSystems\Platform\Traffic\TrafficDays;

/**
 * `GET /api/admin/v1/traffic/sources?days=28` — where visitors came from in the
 * last N days up to today,
 * from every provider at once (2026-10-26): per channel and per source, our
 * beacon's visits and contacts, leads, Clarity sessions, search clicks and
 * impressions, Business Profile actions and server-log landings, each with
 * the same-length window before it; crawlers listed apart, never as visitors.
 * The SEO screen's "Where visitors come from" card reads exactly this.
 */
trait BuildsTrafficSources
{
    abstract protected function trafficDays(): TrafficDays;

    public function sources(Request $request): JsonResponse
    {
        $days = max(1, min(365, (int) ($request->integer('days') ?: 28)));
        // Today included: our own visitors and contacts are collected hourly,
        // so the window is "the last N days up to now", the way an owner reads it.
        $to = new \DateTimeImmutable('today');
        $from = $to->modify('-'.($days - 1).' days');
        $priorTo = $from->modify('-1 day');
        $priorFrom = $priorTo->modify('-'.($days - 1).' days');

        $build = function () use ($days, $from, $to, $priorFrom, $priorTo) {
            $store = $this->trafficDays();

            return [
                'days' => $days,
                'from' => $from->format('Y-m-d'),
                'to' => $to->format('Y-m-d'),
                ...static::shapeTrafficSources(
                    $store->totals($from->format('Y-m-d'), $to->format('Y-m-d')),
                    $store->totals($priorFrom->format('Y-m-d'), $priorTo->format('Y-m-d')),
                ),
                // Where visitors come from, one number per source — the
                // "Where visitors come from" card's own view of the data.
                'visitors' => static::shapeVisitors(
                    $store->visitorsBySource($from->format('Y-m-d'), $to->format('Y-m-d')),
                    $store->visitorsBySource($priorFrom->format('Y-m-d'), $priorTo->format('Y-m-d')),
                ),
                'providers' => $store->latestDays(),
                // Where the history begins: the platforms' clicks from here…
                'history_from' => $store->earliestDay(),
                // …and our own count of every source from here.
                'tag_from' => $store->earliestDay('visits'),
                'metric_labels' => TrafficDays::METRICS,
            ];
        };

        $data = class_exists(Cache::class) && Cache::getFacadeRoot() !== null
            ? Cache::remember($this->trafficCacheKey("traffic-sources:{$days}:".$to->format('Ymd')), 300, $build)
            : $build();

        return new JsonResponse(['data' => $data]);
    }

    /** A multi-tenant site folds its tenant in, like analyticsCacheKey(). */
    protected function trafficCacheKey(string $key): string
    {
        return $key;
    }

    /**
     * Visitors per channel and source with the window before, most first,
     * each with its share of the window's total.
     *
     * @param  array{rows: list<array{channel: string, source: string, visitors: int}>, tag_days: int, estimated_days: int}  $current
     * @param  array{rows: list<array{channel: string, source: string, visitors: int}>, tag_days: int, estimated_days: int}  $prior
     * @return array{total: int, prior_total: int, tag_days: int, estimated_days: int, channels: list<array{channel: string, label: string, visitors: int, prior: int, share: float, sources: list<array{source: string, visitors: int, prior: int, share: float}>}>}
     */
    public static function shapeVisitors(array $current, array $prior): array
    {
        $channels = [];
        foreach (['visitors' => $current['rows'], 'prior' => $prior['rows']] as $side => $rows) {
            foreach ($rows as $row) {
                $channels[$row['channel']] ??= ['channel' => $row['channel'], 'label' => SourceClassifier::channelLabel($row['channel']), 'visitors' => 0, 'prior' => 0, 'share' => 0.0, 'sources' => []];
                $channels[$row['channel']][$side] += $row['visitors'];
                $channels[$row['channel']]['sources'][$row['source']] ??= ['source' => $row['source'], 'visitors' => 0, 'prior' => 0, 'share' => 0.0];
                $channels[$row['channel']]['sources'][$row['source']][$side] += $row['visitors'];
            }
        }

        $total = (int) array_sum(array_column($channels, 'visitors'));
        $priorTotal = (int) array_sum(array_column($channels, 'prior'));
        $share = fn (int $n): float => $total > 0 ? round($n * 100 / $total, 1) : 0.0;

        $channels = array_values(array_filter(array_map(function (array $channel) use ($share) {
            $channel['share'] = $share($channel['visitors']);
            $sources = array_values(array_filter($channel['sources'], fn ($s) => $s['visitors'] > 0 || $s['prior'] > 0));
            foreach ($sources as &$source) {
                $source['share'] = $share($source['visitors']);
            }
            unset($source);
            usort($sources, fn ($a, $b) => $b['visitors'] <=> $a['visitors'] ?: $b['prior'] <=> $a['prior'] ?: strcmp($a['source'], $b['source']));
            $channel['sources'] = $sources;

            return $channel;
        }, $channels), fn ($channel) => $channel['sources'] !== []));
        usort($channels, fn ($a, $b) => $b['visitors'] <=> $a['visitors'] ?: $b['prior'] <=> $a['prior'] ?: strcmp($a['label'], $b['label']));

        return [
            'total' => $total,
            'prior_total' => $priorTotal,
            'tag_days' => $current['tag_days'],
            'estimated_days' => $current['estimated_days'],
            'channels' => $channels,
        ];
    }

    /**
     * @param  list<array{provider: string, channel: string, source: string, metric: string, value: int}>  $current
     * @param  list<array{provider: string, channel: string, source: string, metric: string, value: int}>  $prior
     * @return array{channels: list<array<string, mixed>>, totals: array{current: array<string, int>, prior: array<string, int>}, crawlers: list<array<string, mixed>>}
     */
    public static function shapeTrafficSources(array $current, array $prior): array
    {
        $channels = [];
        $crawlers = [];
        $totals = ['current' => [], 'prior' => []];

        foreach (['current' => $current, 'prior' => $prior] as $window => $rows) {
            $side = $window === 'current' ? 'metrics' : 'prior';

            foreach ($rows as $row) {
                ['channel' => $channel, 'source' => $source, 'metric' => $metric, 'value' => $value] = $row;

                if ($metric === 'crawls') {
                    $crawlers[$source] ??= ['source' => $source, 'channel' => $channel, 'value' => 0, 'prior' => 0];
                    $crawlers[$source][$window === 'current' ? 'value' : 'prior'] += $value;

                    continue;
                }

                $channels[$channel] ??= ['channel' => $channel, 'label' => SourceClassifier::channelLabel($channel), 'metrics' => [], 'prior' => [], 'sources' => []];
                $channels[$channel][$side][$metric] = ($channels[$channel][$side][$metric] ?? 0) + $value;
                $channels[$channel]['sources'][$source] ??= ['source' => $source, 'metrics' => [], 'prior' => []];
                $channels[$channel]['sources'][$source][$side][$metric] = ($channels[$channel]['sources'][$source][$side][$metric] ?? 0) + $value;
                $totals[$window][$metric] = ($totals[$window][$metric] ?? 0) + $value;
            }
        }

        $reach = fn (array $metrics): int => max($metrics['visits'] ?? 0, $metrics['sessions'] ?? 0, $metrics['landings'] ?? 0, $metrics['search_clicks'] ?? 0, $metrics['profile_website_clicks'] ?? 0) * 1000
            + ($metrics['leads'] ?? 0) + ($metrics['calls'] ?? 0) + ($metrics['forms'] ?? 0);

        $channels = array_map(function (array $channel) use ($reach) {
            $sources = array_values($channel['sources']);
            usort($sources, fn ($a, $b) => $reach($b['metrics']) <=> $reach($a['metrics']) ?: strcmp($a['source'], $b['source']));
            $channel['sources'] = $sources;

            return $channel;
        }, array_values($channels));
        usort($channels, fn ($a, $b) => $reach($b['metrics']) <=> $reach($a['metrics']) ?: strcmp($a['channel'], $b['channel']));

        $crawlers = array_values($crawlers);
        usort($crawlers, fn ($a, $b) => $b['value'] <=> $a['value'] ?: strcmp($a['source'], $b['source']));

        return ['channels' => $channels, 'totals' => $totals, 'crawlers' => $crawlers];
    }
}
