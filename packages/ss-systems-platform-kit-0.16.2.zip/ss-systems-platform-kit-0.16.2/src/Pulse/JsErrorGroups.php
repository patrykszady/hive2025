<?php

namespace SsSystems\Platform\Pulse;

use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use SsSystems\Platform\Pulse\Contracts\PulseStorage;

/**
 * Groups a site's `jserr` Pulse events into one aggregated error per unique
 * (kind, message, source:line) signature — ported verbatim from
 * hive2025's/dawnsellshomes.com's byte-identical (docblock-only diff)
 * App\Support\JsErrorGroups, generalized to read through the SAME
 * Contracts\PulseStorage seam every other Pulse class already uses instead
 * of a hardcoded `DB::table('site_events')` scan — so a future tenant-
 * scoped adopter (a DatabaseTableStorage with a tenant column, or a site's
 * own PulseStorage implementation) groups only its own rows automatically,
 * the way Recorder/SnapshotBuilder already do.
 *
 * There is still no per-error ingest and no time window: every call scans
 * every `jserr` row PulseStorage has ever recorded — `since()` is called
 * with the Unix epoch, matching the sites' original unbounded
 * `where('event', 'jserr')` scan, which carried no date filter at all. That
 * is deliberately simple over being fast: the beacon caps jserr rows at 3
 * per page view client-side (BeaconScript), so a full scan stays cheap. If
 * that ever stops being true, the fix is a scheduled rollup job, not a
 * rewrite of the grouping logic itself.
 *
 * The small bit of state that can't be derived from raw events — resolved/
 * deleted-cutoff bookkeeping, and the stable integer id the resolve/
 * unresolve/delete routes address a group by — lives in the site's OWN
 * `js_error_states` table (copy
 * resources/stubs/pulse/create_js_error_states_table.php.stub). This class
 * is handed that model's class name rather than a kit-owned model: it is
 * one table with no business logic, and every current adopter (hive2025,
 * dawnsellshomes, ss-systems) already carries an identical one of its own —
 * porting it into a kit model would gain nothing and cost the "storage is
 * the one thing that can't be shared" rule the Reports/Seo namespaces
 * already document.
 *
 * Explicitly NOT for gs.construction/jpeterson-design: their
 * ClientError/ClientErrorController design (a dedicated ingest table
 * written row-by-row by a public beacon endpoint) is a different, valid
 * design that survives past Pulse's own retention window — this class is
 * not a replacement for it and must never be ported onto either site.
 */
final class JsErrorGroups
{
    /**
     * @param  class-string<\Illuminate\Database\Eloquent\Model>  $stateModel  a model over a table shaped like
     *         create_js_error_states_table.php.stub: `signature` (unique string), `resolved_at` (nullable
     *         datetime), `deleted_before` (nullable datetime).
     */
    public function __construct(
        private readonly PulseStorage $storage,
        private readonly string $stateModel,
    ) {
    }

    /**
     * Every group with at least one occurrence after its own
     * `deleted_before` cutoff, newest last-seen first.
     *
     * @return Collection<int, array<string, mixed>>
     */
    public function all(): Collection
    {
        $states = ($this->stateModel)::query()->get()->keyBy('signature');
        $groups = $this->computeGroups($states);

        $this->ensureStateRows($groups, $states);

        return collect($groups)
            ->map(function (array $g) use ($states) {
                $g['browsers'] = array_keys($g['browsers']);
                $g['pages'] = array_keys($g['pages']);

                $state = $states->get($g['signature']);
                $g['id'] = $state?->id;
                $g['resolved_at'] = $state?->resolved_at;
                $g['is_resolved'] = $g['resolved_at'] !== null && $g['resolved_at']->gte($g['last_seen_at']);

                unset($g['signature']);

                return $g;
            })
            ->sortByDesc(fn (array $g) => $g['last_seen_at']->getTimestamp())
            ->values();
    }

    /** One group by its js_error_states id, or null if it has no current occurrence. */
    public function find(int $id): ?array
    {
        return $this->all()->first(fn (array $g) => $g['id'] === $id);
    }

    /**
     * The API payload for one group id — the full grouped shape when it has
     * a current occurrence, or a state-only fallback when every occurrence
     * behind it is currently cut off by `deleted_before` (the state row
     * still exists, so this reports it rather than 500ing). Throws the
     * model's own "not found" exception when the id is unknown outright,
     * same as every other lookup here.
     *
     * @return array<string, mixed>
     */
    public function apiPayload(int $id): array
    {
        $group = $this->find($id);

        if ($group !== null) {
            return self::toApiArray($group);
        }

        $state = ($this->stateModel)::query()->findOrFail($id);

        return [
            'id' => $state->id,
            'is_resolved' => $state->resolved_at !== null,
            'resolved_at' => optional($state->resolved_at)->toIso8601String(),
        ];
    }

    public function resolve(int $id): void
    {
        ($this->stateModel)::query()->findOrFail($id)->update(['resolved_at' => Carbon::now()]);
    }

    public function unresolve(int $id): void
    {
        ($this->stateModel)::query()->findOrFail($id)->update(['resolved_at' => null]);
    }

    /** Resolves every currently-open group; returns how many that was. */
    public function resolveOpenGroups(): int
    {
        $open = $this->all()->where('is_resolved', false);

        ($this->stateModel)::query()->whereIn('id', $open->pluck('id'))->update(['resolved_at' => Carbon::now()]);

        return $open->count();
    }

    /**
     * A cutoff, not a row delete: `all()` ignores every occurrence at or
     * before this moment, so the group vanishes from every list until (if
     * ever) a fresh occurrence lands after it — see
     * create_js_error_states_table.php.stub's own docblock.
     */
    public function delete(int $id): void
    {
        ($this->stateModel)::query()->findOrFail($id)->update(['deleted_before' => Carbon::now(), 'resolved_at' => null]);
    }

    /** @param  array<string, mixed>  $group */
    public static function toApiArray(array $group): array
    {
        return [
            'id' => $group['id'],
            'kind' => $group['kind'],
            'message' => $group['message'],
            'source' => $group['source'],
            'line' => $group['line'],
            // Never tracked by the beacon.
            'column' => null,
            'stack' => null,
            'page_path' => $group['page_path'],
            'user_agent' => null,
            // Additive beyond a raw user_agent string: the beacon only ever
            // tells us the browser FAMILY + mobile flag, not a raw
            // user_agent, so it is surfaced as its own list rather than
            // faked into a single user_agent value. Likewise every page
            // path the group was seen on, not just the latest.
            'browsers' => $group['browsers'],
            'pages' => $group['pages'],
            'occurrences' => $group['occurrences'],
            'is_resolved' => $group['is_resolved'],
            'first_seen_at' => $group['first_seen_at']->toIso8601String(),
            'last_seen_at' => $group['last_seen_at']->toIso8601String(),
            'resolved_at' => optional($group['resolved_at'])->toIso8601String(),
        ];
    }

    /**
     * @param  Collection<string, \Illuminate\Database\Eloquent\Model>  $states  keyed by signature
     * @return array<string, array<string, mixed>> keyed by signature
     */
    private function computeGroups(Collection $states): array
    {
        $groups = [];

        foreach ($this->storage->since(new \DateTimeImmutable('@0'), ['jserr']) as $row) {
            $meta = $row['meta'] !== null ? (json_decode((string) $row['meta'], true) ?: []) : [];
            $message = isset($meta['m']) && $meta['m'] !== '' ? (string) $meta['m'] : '(no message)';
            // BeaconScript's report() prefixes a rejected-promise message
            // with "promise: " — the only signal the beacon gives us to
            // tell the two kinds apart.
            $kind = str_starts_with($message, 'promise: ') ? 'promise' : 'error';
            $location = isset($meta['s']) ? (string) $meta['s'] : '';
            $signature = hash('sha256', $kind.'|'.$message.'|'.$location);

            $createdAt = $row['created_at'] instanceof Carbon ? $row['created_at'] : Carbon::parse($row['created_at']);

            $state = $states->get($signature);
            if ($state && $state->deleted_before && $createdAt->lte($state->deleted_before)) {
                continue;
            }

            if (! isset($groups[$signature])) {
                [$source, $line] = self::splitLocation($location);
                $groups[$signature] = [
                    'signature' => $signature,
                    'kind' => $kind,
                    'message' => $message,
                    'source' => $source,
                    'line' => $line,
                    'occurrences' => 0,
                    'browsers' => [],
                    'pages' => [],
                    'page_path' => null,
                    'first_seen_at' => $createdAt,
                    'last_seen_at' => $createdAt,
                ];
            }

            $groups[$signature]['occurrences']++;

            if ($createdAt->lt($groups[$signature]['first_seen_at'])) {
                $groups[$signature]['first_seen_at'] = $createdAt;
            }

            if ($createdAt->gte($groups[$signature]['last_seen_at'])) {
                $groups[$signature]['last_seen_at'] = $createdAt;
                $groups[$signature]['page_path'] = $row['path'] ? '/'.ltrim((string) $row['path'], '/') : null;
            }

            $browser = (string) ($meta['b'] ?? 'other').(($row['mobile'] ?? false) ? ' mobile' : '');
            $groups[$signature]['browsers'][$browser] = true;

            if ($row['path']) {
                $groups[$signature]['pages']['/'.ltrim((string) $row['path'], '/')] = true;
            }
        }

        return $groups;
    }

    /**
     * Every group returned to the API needs a stable integer id up front
     * (the resolve/unresolve/delete routes address a group by id, not by
     * signature) — lazily create its js_error_states row the first time it
     * is seen, rather than requiring a click before one exists.
     *
     * @param  array<string, array<string, mixed>>  $groups
     * @param  Collection<string, \Illuminate\Database\Eloquent\Model>  $states  reloaded in place
     */
    private function ensureStateRows(array $groups, Collection &$states): void
    {
        $missing = array_values(array_diff(array_keys($groups), $states->keys()->all()));

        if ($missing === []) {
            return;
        }

        $now = Carbon::now();
        ($this->stateModel)::query()->insertOrIgnore(array_map(static fn (string $signature) => [
            'signature' => $signature,
            'resolved_at' => null,
            'deleted_before' => null,
            'created_at' => $now,
            'updated_at' => $now,
        ], $missing));

        $states = ($this->stateModel)::query()->get()->keyBy('signature');
    }

    /** @return array{0: ?string, 1: ?int} [source, line] */
    private static function splitLocation(string $location): array
    {
        if ($location === '') {
            return [null, null];
        }

        if (preg_match('/^(.*):(\d+)$/', $location, $m)) {
            return [$m[1] !== '' ? $m[1] : null, (int) $m[2]];
        }

        return [$location, null];
    }
}
