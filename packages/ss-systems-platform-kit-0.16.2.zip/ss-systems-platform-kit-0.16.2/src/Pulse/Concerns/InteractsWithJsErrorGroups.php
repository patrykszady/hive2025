<?php

namespace SsSystems\Platform\Pulse\Concerns;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Pagination\LengthAwarePaginator;
use SsSystems\Platform\Pulse\JsErrorGroups;

/**
 * The index/summary/resolve/unresolve/resolve-all/destroy endpoints every
 * "JS Errors" admin screen needs (ss-systems' JsErrorsBoard/
 * PlatformJsErrors, hive2025's and dawnsellshomes.com's identical screen)
 * — ported verbatim from hive2025's/dawnsellshomes.com's byte-identical
 * (docblock-only diff) Api\Admin\V1\JsErrorController, with one change:
 * every call goes through `jsErrorGroups()` instead of static
 * App\Support\JsErrorGroups calls, so the concrete controller's own
 * JsErrorGroups instance (bound in AppServiceProvider against the site's
 * own PulseStorage + JsErrorState model, the same way Recorder/
 * SnapshotBuilder already are) decides which storage and which state model
 * this screen reads — the kit never hardcodes either.
 *
 * A controller `use`-ing this trait also needs a BuildsApiResponses-shaped
 * trait for `perPage()`/`paginatedResponse()` (each site already has its
 * own, or the kit's `Http\Admin\Concerns\BuildsApiResponses` once that
 * ships) — this trait deliberately does not duplicate those, so add both
 * `use` lines rather than folding one into the other.
 */
trait InteractsWithJsErrorGroups
{
    public function index(Request $request): JsonResponse
    {
        $status = $request->string('status')->toString() ?: 'open';
        $kind = $request->string('kind')->toString();

        $groups = $this->jsErrorGroups()->all()
            ->when($status === 'open', fn ($rows) => $rows->where('is_resolved', false))
            ->when($status === 'resolved', fn ($rows) => $rows->where('is_resolved', true))
            ->when($kind !== '' && $kind !== 'all', fn ($rows) => $rows->where('kind', $kind))
            ->values();

        $perPage = $this->perPage($request);
        $page = max(1, (int) $request->integer('page', 1));

        $paginator = new LengthAwarePaginator(
            items: $groups->forPage($page, $perPage)->values(),
            total: $groups->count(),
            perPage: $perPage,
            currentPage: $page,
            options: ['path' => $request->url(), 'query' => $request->query()],
        );

        return $this->paginatedResponse($paginator, fn (array $group) => JsErrorGroups::toApiArray($group));
    }

    public function summary(): JsonResponse
    {
        $groups = $this->jsErrorGroups()->all();
        $open = $groups->where('is_resolved', false);

        return response()->json([
            'data' => [
                'open' => $open->count(),
                'occurrences' => (int) $open->sum('occurrences'),
                'last_24h' => $groups->where('last_seen_at', '>=', now()->subDay())->count(),
                'resolved' => $groups->where('is_resolved', true)->count(),
            ],
        ]);
    }

    public function resolve(int $jsError): JsonResponse
    {
        $this->jsErrorGroups()->resolve($jsError);

        return $this->groupResponse($jsError);
    }

    public function unresolve(int $jsError): JsonResponse
    {
        $this->jsErrorGroups()->unresolve($jsError);

        return $this->groupResponse($jsError);
    }

    public function resolveAll(): JsonResponse
    {
        return response()->json(['data' => ['resolved_count' => $this->jsErrorGroups()->resolveOpenGroups()]]);
    }

    public function destroy(int $jsError): Response
    {
        $this->jsErrorGroups()->delete($jsError);

        return response()->noContent();
    }

    protected function groupResponse(int $jsError): JsonResponse
    {
        return response()->json(['data' => $this->jsErrorGroups()->apiPayload($jsError)]);
    }

    /**
     * Resolves to the site's own bound singleton by default (see this
     * trait's own docblock) — override only if a controller needs a
     * differently-scoped instance per request.
     */
    protected function jsErrorGroups(): JsErrorGroups
    {
        return app(JsErrorGroups::class);
    }
}
