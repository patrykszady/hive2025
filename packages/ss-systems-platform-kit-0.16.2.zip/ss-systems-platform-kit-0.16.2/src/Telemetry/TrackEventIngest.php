<?php

namespace SsSystems\Platform\Telemetry;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Str;
use SsSystems\Platform\Telemetry\Contracts\TrackedEventWriter;

/**
 * The shared body of gs.construction's and jpeterson-design.com's
 * `App\Http\Controllers\TrackEventController` (`POST /track`) — confirmed
 * byte-identical between the two sites bar docblocks
 * (ss-platform-kit/docs/audit-2026-09-27/public-seo-surface.md unit #11,
 * "Option A" mechanical de-dup). Each site's own controller shrinks to a
 * ~10-line wrapper that constructs this with its own `TrackedEventWriter`
 * adapter (see `Adapters\EloquentTrackedEventWriter`) and calls `handle()`.
 *
 * Validation rules, rate limits (120/60s per IP), the bot-detection regex,
 * and the response shapes are UNCHANGED from the original — this is a
 * verbatim move, not a redesign. `session('visitor_country')`/`utm_*` reads
 * the ambient Laravel session exactly like the original controllers did
 * (both sites already run this behind the same `web` session middleware on
 * their public routes).
 */
final class TrackEventIngest
{
    private const RATE_LIMIT_KEY_PREFIX = 'track-event:';

    private const RATE_LIMIT_MAX_ATTEMPTS = 120;

    private const RATE_LIMIT_DECAY_SECONDS = 60;

    /** Byte-identical to gsc's/jpeterson's own `isBot()` regex. */
    private const BOT_PATTERN = '/bot|crawler|spider|crawling|facebookexternalhit|slurp|bingpreview|headless|lighthouse|gtmetrix|pingdom/i';

    public function __construct(
        private readonly TrackedEventWriter $writer,
    ) {
    }

    public function handle(Request $request): JsonResponse
    {
        // Per-IP rate limit to keep the endpoint from being abused.
        $key = self::RATE_LIMIT_KEY_PREFIX.$request->ip();
        if (RateLimiter::tooManyAttempts($key, self::RATE_LIMIT_MAX_ATTEMPTS)) {
            return new JsonResponse(['ok' => false], 429);
        }
        RateLimiter::hit($key, self::RATE_LIMIT_DECAY_SECONDS);

        $validated = $request->validate([
            'type' => 'required|string|in:'.implode(',', $this->writer->allowedTypes()),
            'label' => 'nullable|string|max:255',
            'page_path' => 'nullable|string|max:255',
            'referrer' => 'nullable|string|max:255',
            'session_id' => 'nullable|string|max:64',
        ]);

        // Drop obvious bots — they shouldn't pollute conversion stats.
        $userAgent = (string) $request->userAgent();
        if ($this->isBot($userAgent)) {
            return new JsonResponse(['ok' => true]);
        }

        $this->writer->record([
            'type' => $validated['type'],
            'label' => $validated['label'] ?? null,
            'page_path' => $validated['page_path'] ?? null,
            'referrer' => $validated['referrer'] ?? null,
            'session_id' => $validated['session_id'] ?? null,
            'country' => session('visitor_country'),
            'utm_source' => session('utm_source'),
            'utm_medium' => session('utm_medium'),
            'utm_campaign' => session('utm_campaign'),
            'ip_address' => (string) $request->ip(),
            'user_agent' => Str::limit($userAgent, 500, ''),
        ]);

        return new JsonResponse(['ok' => true]);
    }

    private function isBot(string $userAgent): bool
    {
        if ($userAgent === '') {
            return true;
        }

        return (bool) preg_match(self::BOT_PATTERN, $userAgent);
    }
}
