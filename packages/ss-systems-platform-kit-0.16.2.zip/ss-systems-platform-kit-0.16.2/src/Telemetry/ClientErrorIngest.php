<?php

namespace SsSystems\Platform\Telemetry;

use Closure;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Str;
use SsSystems\Platform\Telemetry\Contracts\ClientErrorWriter;
use Throwable;

/**
 * The shared body of gs.construction's and jpeterson-design.com's
 * `App\Http\Controllers\ClientErrorController` (`POST /client-error`) —
 * confirmed byte-identical between the two sites except ONE deliberate
 * deviation (ss-platform-kit/docs/audit-2026-09-27/public-seo-surface.md
 * unit #11, "Option A" mechanical de-dup): gsc also writes the full error
 * context to a dedicated `client_errors` daily log channel (for
 * /log-viewer grep-ability), UNGUARDED — a channel-resolution failure
 * would bubble up; jpeterson-design has no such channel configured, so it
 * logs via the default channel wrapped in its own try/catch instead, so a
 * logging hiccup there can never take down the DB aggregation below it.
 *
 * That divergence is real per-site behaviour, not an oversight, so it
 * stays a constructor hook (`$logError`) rather than being flattened into
 * one shared choice: each site's own controller passes a closure that
 * reproduces EXACTLY what it did before (gsc's un-guarded
 * `Log::channel('client_errors')->warning(...)`, jpeterson's guarded
 * `Log::warning(...)`), and this class never wraps that call itself.
 *
 * Everything else — the rate limit (30/60s per IP), the bot-detection
 * regex, the validation rules, the fingerprint algorithm, and the response
 * shapes — is a verbatim move, not a redesign. Each site's own controller
 * shrinks to a small wrapper that constructs this with its own
 * `ClientErrorWriter` adapter (see `Adapters\EloquentClientErrorWriter`)
 * and its own `$logError` closure, then calls `handle()`.
 */
final class ClientErrorIngest
{
    private const RATE_LIMIT_KEY_PREFIX = 'client-error:';

    private const RATE_LIMIT_MAX_ATTEMPTS = 30;

    private const RATE_LIMIT_DECAY_SECONDS = 60;

    /** Byte-identical to gsc's/jpeterson's own `isBot()` regex. */
    private const BOT_PATTERN = '/bot|crawler|spider|crawling|facebookexternalhit|slurp|bingpreview|headless|lighthouse|gtmetrix|pingdom/i';

    /**
     * @param  (Closure(array<string, mixed> $context): void)|null  $logError  writes the full error
     *         context somewhere durable (a dedicated log channel, /log-viewer-visible). Owns its OWN
     *         try/catch if it needs one — see class docblock, this is a real per-site divergence.
     */
    public function __construct(
        private readonly ClientErrorWriter $writer,
        private readonly ?Closure $logError = null,
    ) {
    }

    public function handle(Request $request): JsonResponse
    {
        // Per-IP rate limit. Bursty error storms (e.g. an infinite loop) are
        // deduped client-side, but cap server-side too as a backstop.
        $key = self::RATE_LIMIT_KEY_PREFIX.$request->ip();
        if (RateLimiter::tooManyAttempts($key, self::RATE_LIMIT_MAX_ATTEMPTS)) {
            return new JsonResponse(['ok' => false], 429);
        }
        RateLimiter::hit($key, self::RATE_LIMIT_DECAY_SECONDS);

        // Bots/crawlers and headless audit tools throw plenty of benign JS
        // errors that would pollute the channel. Drop them silently.
        $userAgent = (string) $request->userAgent();
        if ($this->isBot($userAgent)) {
            return new JsonResponse(['ok' => true]);
        }

        $validated = $request->validate([
            'message' => 'required|string|max:500',
            'source' => 'nullable|string|max:255',
            'line' => 'nullable|integer',
            'column' => 'nullable|integer',
            'stack' => 'nullable|string|max:2000',
            'kind' => 'nullable|string|max:32',
            'page_path' => 'nullable|string|max:255',
        ]);

        $kind = $validated['kind'] ?? 'error';
        $message = $validated['message'];
        $source = $validated['source'] ?? null;
        $line = $validated['line'] ?? null;
        $column = $validated['column'] ?? null;
        $stack = isset($validated['stack']) ? Str::limit($validated['stack'], 2000, '') : null;
        $pagePath = $validated['page_path'] ?? null;
        $shortUa = Str::limit($userAgent, 300, '');

        // Preserve the full error for forensic detail and grep-ability. See
        // the class docblock for why this is a per-site closure rather than
        // one shared logging decision.
        if ($this->logError !== null) {
            ($this->logError)([
                'message' => $message,
                'kind' => $kind,
                'source' => $source,
                'line' => $line,
                'column' => $column,
                'page_path' => $pagePath,
                'stack' => $stack,
                'referrer' => Str::limit((string) $request->headers->get('referer', ''), 255, ''),
                'user_agent' => $shortUa,
                'ip' => $request->ip(),
            ]);
        }

        // Aggregate into the DB so the admin dashboard can show a deduped,
        // ranked list (one row per unique error, with an occurrence count).
        $this->persist($kind, $message, $source, $line, $column, $stack, $pagePath, $shortUa);

        return new JsonResponse(['ok' => true]);
    }

    /**
     * Compute the stable fingerprint and hand off to the writer. Never
     * throws — telemetry must not affect the visitor's response.
     */
    private function persist(
        string $kind,
        string $message,
        ?string $source,
        ?int $line,
        ?int $column,
        ?string $stack,
        ?string $pagePath,
        ?string $userAgent,
    ): void {
        try {
            $fingerprint = hash('sha256', $kind.'|'.$message.'|'.($source ?? '').'|'.($line ?? ''));

            $this->writer->record([
                'fingerprint' => $fingerprint,
                'kind' => $kind,
                'message' => $message,
                'source' => $source,
                'line' => $line,
                'column' => $column,
                'stack' => $stack,
                'page_path' => $pagePath,
                'user_agent' => $userAgent,
            ]);
        } catch (Throwable $e) {
            Log::warning('ClientError persist failed', ['error' => $e->getMessage()]);
        }
    }

    private function isBot(string $userAgent): bool
    {
        if ($userAgent === '') {
            return true;
        }

        return (bool) preg_match(self::BOT_PATTERN, $userAgent);
    }
}
