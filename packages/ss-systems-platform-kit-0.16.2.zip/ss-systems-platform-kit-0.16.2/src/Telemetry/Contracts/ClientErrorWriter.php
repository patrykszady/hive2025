<?php

namespace SsSystems\Platform\Telemetry\Contracts;

/**
 * Upserts an aggregated, deduped front-end JS error row for the
 * `POST /client-error` beacon — see `Telemetry\ClientErrorIngest`, the
 * shared controller body ported from gs.construction's and
 * jpeterson-design.com's near-identical `App\Http\Controllers\
 * ClientErrorController` (confirmed byte-identical bar the log-channel
 * divergence documented on `ClientErrorIngest` itself,
 * ss-platform-kit/docs/audit-2026-09-27/public-seo-surface.md unit #11).
 * Each site keeps its own `ClientError` Eloquent model — gsc's
 * `use BelongsToSite;` tenant scope must keep firing exactly as it does
 * today — so an implementation of this contract is a thin adapter over
 * that model (see `Adapters\EloquentClientErrorWriter`), never a
 * kit-owned model.
 */
interface ClientErrorWriter
{
    /**
     * Bump `occurrences` + refresh the latest sample context on a repeat of
     * the same fingerprint (and reopen it, clearing `resolved_at`); insert
     * a fresh row (`occurrences` = 1) otherwise — same semantics as gsc's/
     * jpeterson's `ClientErrorController::persist()`. The fingerprint is
     * computed by the CALLER (`ClientErrorIngest`), not here, so every
     * implementation upserts on the exact same key.
     *
     * @param array{
     *     fingerprint: string,
     *     kind: string,
     *     message: string,
     *     source: ?string,
     *     line: ?int,
     *     column: ?int,
     *     stack: ?string,
     *     page_path: ?string,
     *     user_agent: ?string,
     * } $attributes
     */
    public function record(array $attributes): void;
}
