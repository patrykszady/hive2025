<?php

namespace SsSystems\Platform\Telemetry\Contracts;

/**
 * Persists one first-party analytics event (phone/email/form/CTA click) for
 * the `POST /track` beacon — see `Telemetry\TrackEventIngest`, the shared
 * controller body ported from gs.construction's and jpeterson-design.com's
 * byte-identical `App\Http\Controllers\TrackEventController` (confirmed by
 * diff, ss-platform-kit/docs/audit-2026-09-27/public-seo-surface.md unit
 * #11). Each site keeps its own `TrackedEvent` Eloquent model — gsc's
 * `use BelongsToSite;` tenant scope must keep firing exactly as it does
 * today — so an implementation of this contract is a thin adapter over
 * that model (see `Adapters\EloquentTrackedEventWriter`), never a
 * kit-owned model.
 */
interface TrackedEventWriter
{
    /**
     * The ingest endpoint's own validation whitelist for the `type` field —
     * same list as gsc's/jpeterson's `TrackedEvent::allowedTypes()`
     * (phone_click/email_click/form_submit/cta_click today).
     *
     * @return list<string>
     */
    public function allowedTypes(): array;

    /**
     * Store one already-validated, already-bot-filtered event. Implementations
     * own their own model/table/tenancy entirely — this contract only says
     * WHAT gets recorded, never where or how it is scoped.
     *
     * @param array{
     *     type: string,
     *     label: ?string,
     *     page_path: ?string,
     *     referrer: ?string,
     *     session_id: ?string,
     *     country: ?string,
     *     utm_source: ?string,
     *     utm_medium: ?string,
     *     utm_campaign: ?string,
     *     ip_address: string,
     *     user_agent: string,
     * } $attributes
     */
    public function record(array $attributes): void;
}
