<?php

namespace SsSystems\Platform\Telemetry\Adapters;

use SsSystems\Platform\Telemetry\Contracts\TrackedEventWriter;

/**
 * gs.construction's and jpeterson-design.com's shared `TrackedEvent`
 * backend. Wraps the site's OWN model by class-string, never a kit-owned
 * one, so gsc's `use BelongsToSite;` site_id stamping (the model's
 * `creating` hook) and its query-time tenant scope keep applying exactly
 * as before — this class only ever calls the class-string's own static
 * methods, the same way `Social\Adapters\OAuthTokenCredentialStore` wraps
 * `OAuthToken`.
 */
final class EloquentTrackedEventWriter implements TrackedEventWriter
{
    /**
     * @param  class-string<\Illuminate\Database\Eloquent\Model>  $model  The site's own `TrackedEvent`
     *         model — must expose a static `allowedTypes(): array` (same contract as gsc's/jpeterson's
     *         `TrackedEvent::allowedTypes()`) and accept `create()` with this contract's attribute shape.
     */
    public function __construct(
        private readonly string $model,
    ) {
    }

    public function allowedTypes(): array
    {
        return ($this->model)::allowedTypes();
    }

    public function record(array $attributes): void
    {
        ($this->model)::create($attributes);
    }
}
