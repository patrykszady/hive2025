<?php

namespace SsSystems\Platform\Telemetry\Adapters;

use Illuminate\Support\Carbon;
use SsSystems\Platform\Telemetry\Contracts\ClientErrorWriter;

/**
 * gs.construction's and jpeterson-design.com's shared `ClientError`
 * upsert-by-fingerprint backend — ported verbatim from their byte-identical
 * `ClientErrorController::persist()` (confirmed by diff). Wraps the site's
 * OWN model by class-string, never a kit-owned one, so gsc's
 * `use BelongsToSite;` scope (both the `creating` site_id stamp and the
 * query-time `SiteScope`) keeps applying to every `where()`/`create()`
 * call below exactly as before.
 *
 * Carbon::now(), not the ambient `now()` helper: that helper lives in
 * illuminate/foundation, deliberately not a kit dependency (see
 * `Http\AdminProxyRelay`'s identical choice) — `Illuminate\Support\Carbon`
 * is already available via illuminate/support.
 */
final class EloquentClientErrorWriter implements ClientErrorWriter
{
    /**
     * @param  class-string<\Illuminate\Database\Eloquent\Model>  $model  The site's own `ClientError`
     *         model — fillable fingerprint/kind/message/source/line/column/stack/page_path/user_agent/
     *         occurrences/first_seen_at/last_seen_at/resolved_at, same shape gsc's/jpeterson's already have.
     */
    public function __construct(
        private readonly string $model,
    ) {
    }

    public function record(array $attributes): void
    {
        $model = $this->model;
        $now = Carbon::now();

        $existing = $model::where('fingerprint', $attributes['fingerprint'])->first();

        if ($existing) {
            $existing->forceFill([
                'occurrences' => $existing->occurrences + 1,
                'last_seen_at' => $now,
                // Refresh the latest sample context.
                'stack' => $attributes['stack'] ?? $existing->stack,
                'page_path' => $attributes['page_path'] ?? $existing->page_path,
                'user_agent' => $attributes['user_agent'] ?? $existing->user_agent,
                // A fresh occurrence reopens a previously-resolved error.
                'resolved_at' => null,
            ])->save();

            return;
        }

        $model::create([
            'fingerprint' => $attributes['fingerprint'],
            'kind' => $attributes['kind'],
            'message' => $attributes['message'],
            'source' => $attributes['source'] ?? null,
            'line' => $attributes['line'] ?? null,
            'column' => $attributes['column'] ?? null,
            'stack' => $attributes['stack'] ?? null,
            'page_path' => $attributes['page_path'] ?? null,
            'user_agent' => $attributes['user_agent'] ?? null,
            'occurrences' => 1,
            'first_seen_at' => $now,
            'last_seen_at' => $now,
        ]);
    }
}
