<?php

namespace SsSystems\Platform\Reviews\Http\Concerns;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

/**
 * The `index`/`filters`/`show`/`destroy` quarter of every site's
 * `Api\Admin\V1\TestimonialController` (the central admin's Reviews screen —
 * `App\Livewire\Admin\{TestimonialList,TestimonialForm,TestimonialDuplicates}`
 * are the consumer contract, unchanged by this move) — confirmed byte-
 * identical in SHAPE across gs.construction, jpeterson-design.com,
 * hive.contractors and ss.systems on 2026-09-27 (`docs/audit-2026-09-27/
 * admin-api-skeleton.md` §10), keyed on two hooks so the kit never
 * hardcodes a model class or a tenant:
 *
 * ```php
 * protected function testimonialModel(): string
 * {
 *     return \App\Models\Testimonial::class; // never Testimonial::query() inline —
 *     // gsc's copy carries BelongsToSite; resolving the class by string here
 *     // (rather than importing/hardcoding it in the kit) is what keeps that
 *     // global scope firing. See TestimonialTenantIsolationTest on gsc.
 * }
 * ```
 *
 * `store()`/`update()` are deliberately NOT in this trait: gs.construction's
 * and jpeterson-design's controllers write straight to their own columns
 * (`review_urls`/`project_ids` pulled out and synced onto real pivots —
 * `pullExtras()`/`syncExtras()`), while hive.contractors' and ss.systems'
 * translate the same wire fields onto a simpler schema through their own
 * `mapToColumns()`. That divergence is real business logic, not HTTP
 * plumbing, and stays exactly where it already lives, byte for byte —
 * including each site's own `rules()`, which this trait never calls.
 *
 * **The sort-whitelist decision (2026-09-27, Patryk)**: hive.contractors and
 * ss.systems keep a real, narrower whitelist of sortable columns than a
 * bare `orderBy($column)` would allow; gs.construction and jpeterson-design
 * have never had one and keep taking any `sort` value as-is. Both are kept,
 * selected by the `sortable()` hook below (`null` = the historical
 * pass-anything-through behaviour) — this REPLACES each site's own local
 * `applySort()` override on `TestimonialController` (see `Http\Admin\
 * Concerns\BuildsApiResponses`'s docblock for why that override existed);
 * hive's and ss-systems' copies of that override are dead code once this
 * trait's `index()` is adopted and can be deleted.
 *
 * ```php
 * protected function sortable(): ?array
 * {
 *     return null; // gs.construction, jpeterson-design
 *
 *     return ['name', 'rating', 'review_date', 'platform', 'created_at', 'updated_at', 'id']; // hive.contractors, ss.systems
 * }
 *
 * protected function defaultSort(): string
 * {
 *     return '-created_at'; // gs.construction only — every other site uses '-review_date'
 * }
 *
 * // The where()/whereHas() body straight out of today's index(), unchanged —
 * // gs.construction/jpeterson-design query a review_urls pivot for the
 * // 'platform' filter; hive.contractors/ss.systems query their own
 * // 'platform' column directly.
 * protected function applyIndexFilters(Builder $query, Request $request): void
 * {
 *     // ...
 * }
 *
 * // Same content as today's filters()'s platform half — gs.construction/
 * // jpeterson-design build it from the ReviewUrl model with resolved icon
 * // URLs; hive.contractors/ss.systems build it from the testimonials table's
 * // own 'platform' column with no icons.
 * protected function platformOptions(): array
 * {
 *     // ...
 * }
 * ```
 *
 * `eagerLoads()` and `projectTypeOptions()` default to nothing so
 * hive.contractors/ss.systems (which have neither a `review_urls`/`projects`
 * relation nor a `project_type` concept) need no override at all;
 * gs.construction/jpeterson-design override both to their existing bodies.
 *
 * The using class must also `use \SsSystems\Platform\Http\Admin\Concerns\
 * BuildsApiResponses;` (or provide `itemResponse()`/`paginatedResponse()`/
 * `perPage()` itself) — every method below calls those by `$this->`, duck-
 * typed, never imported here (same convention as `Pulse\Concerns\
 * InteractsWithJsErrorGroups`).
 *
 * dawnsellshomes.com is out of this round (unmerged branches) — its
 * `TestimonialController` is the same hive.contractors-style translation
 * adapter and should adopt this the same way once its admin API lands on
 * `main`.
 */
trait ServesTestimonials
{
    public function index(Request $request): JsonResponse
    {
        $modelClass = $this->testimonialModel();

        $query = $modelClass::query()->with($this->eagerLoads());

        $this->applyIndexFilters($query, $request);
        $this->applyTestimonialSort($query, $request->string('sort')->toString() ?: null, $this->defaultSort());

        $paginator = $query->paginate($this->perPage($request));

        return $this->paginatedResponse($paginator, fn ($testimonial) => $testimonial->toApiArray());
    }

    /**
     * Distinct project types (empty on any site with no such concept) and
     * the review-platform roster for the list's filter dropdowns.
     */
    public function filters(): JsonResponse
    {
        return $this->itemResponse([
            'project_types' => $this->projectTypeOptions(),
            'platforms' => $this->platformOptions(),
        ]);
    }

    public function show(int $testimonial): JsonResponse
    {
        $modelClass = $this->testimonialModel();
        $model = $modelClass::with($this->eagerLoads())->findOrFail($testimonial);

        return $this->itemResponse($model->toApiArray());
    }

    public function destroy(int $testimonial): Response
    {
        $modelClass = $this->testimonialModel();
        $modelClass::findOrFail($testimonial)->delete();

        // new Response(...) rather than the response()->noContent() helper
        // every site's own controller calls — same 204, no body, but
        // testable without a booted Laravel app (see BuildsApiResponses'
        // own docblock for why this trait follows the same convention).
        return new Response('', 204);
    }

    /**
     * '-field' / 'field' sort ('-' = descending). `sortable()` returning
     * null takes any column as-is (gs.construction's/jpeterson-design's
     * historical behaviour, same as `BuildsApiResponses::applySort()`);
     * returning a whitelist rejects an unknown column exactly the way
     * hive.contractors's/ss.systems' local override already did — note the
     * DIRECTION still comes from whatever `$sort` actually was (only the
     * *column* falls back to $default), a real, pre-existing quirk of that
     * override worth preserving rather than "fixing": `?sort=is_hidden`
     * (no leading '-') falls back to the default *column* but sorts
     * ascending, not descending, even though both sites' own $default is
     * '-review_date'. `ServesTestimonialsTest` pins this exact case.
     */
    protected function applyTestimonialSort(Builder $query, ?string $sort, string $default): void
    {
        $whitelist = $this->sortable();
        $spec = $sort ?: $default;
        $direction = str_starts_with($spec, '-') ? 'desc' : 'asc';
        $column = ltrim($spec, '-');

        if ($whitelist !== null && ! in_array($column, $whitelist, true)) {
            $column = ltrim($default, '-');
        }

        $query->orderBy($column, $direction);
    }

    /** Eager loads for index()/show() — only gs.construction/jpeterson-design have any. */
    protected function eagerLoads(): array
    {
        return [];
    }

    /** Distinct project types for filters() — only gs.construction/jpeterson-design have any. */
    protected function projectTypeOptions(): array
    {
        return [];
    }

    /** The `Testimonial` model class for this site, resolved by string so a tenant scope on it keeps firing. */
    abstract protected function testimonialModel(): string;

    /** null = any `sort` column is taken as-is; an array whitelists sortable columns. */
    abstract protected function sortable(): ?array;

    /** index()'s '-field' sort default when no `sort` query param is sent. */
    abstract protected function defaultSort(): string;

    /** index()'s where()/whereHas() body — real per-site query logic, not HTTP plumbing. */
    abstract protected function applyIndexFilters(Builder $query, Request $request): void;

    /** filters()'s platform roster — real per-site vocabulary, not HTTP plumbing. */
    abstract protected function platformOptions(): array;
}
