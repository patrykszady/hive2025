<?php

namespace SsSystems\Platform\Reviews;

/**
 * The last-name-privacy rule every site's public reviews page enforces:
 * "First L" (last name cut to its initial), never the reviewer's full name.
 *
 * Ported verbatim from gs.construction's Testimonial::getDisplayNameAttribute()
 * (jpeterson-design's copy called itself "copied verbatim from gsc's" in its
 * own docblock, and hive.contractors' called itself "same rule as
 * gs.construction's" — both correct in intent). dawnsellshomes had no
 * accessor at all; adding one that calls this closes that gap.
 *
 * One byte-level note preserved from the source, not "cleaned up": the
 * early-return branches below (fewer than two words, or a name that already
 * ends in a single-letter initial) hand back the ORIGINAL, untrimmed input —
 * only the multi-word branch trims. gs.construction and jpeterson-design's
 * models had exactly this quirk; hive's reimplementation trimmed up front
 * instead, which cannot be told apart from this version on any name that
 * doesn't have stray leading/trailing whitespace around a single word — the
 * only case any of the four sites' data or tests ever exercises.
 */
final class DisplayName
{
    public static function from(string $name): string
    {
        $parts = preg_split('/\s+/', trim($name)) ?: [];

        if (count($parts) < 2) {
            return $name;
        }

        $lastPart = end($parts);

        // Already a single letter (already formatted).
        if (mb_strlen($lastPart) === 1) {
            return $name;
        }

        $initial = mb_strtoupper(mb_substr($lastPart, 0, 1));
        array_pop($parts);

        return implode(' ', $parts).' '.$initial;
    }
}
