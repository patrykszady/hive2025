<?php

namespace SsSystems\Platform\Seo;

/**
 * What a site's Search Console service exposes to the rest of the kit —
 * SitemapStatus, SitemapSubmitter and (via the generic
 * Inspection\SearchConsoleUrlInspector adapter) the URL-Inspection sweep all
 * drive a site's grant through this one interface.
 *
 * The services themselves cannot be shared: gs.construction's can delete
 * sitemaps and inspect URLs, jpeterson-design's cannot, hive.contractors'
 * authenticates with a service account instead of an OAuth grant, and each
 * holds its own credential. Each site's App\Services\GoogleSearchConsoleService
 * implements this and is bound to it in that site's AppServiceProvider.
 *
 * isReady()/isAuthStandingCondition() are deliberately NOT derivable from
 * isConfigured(): a site's "am I set up at all" check and its "can I act
 * right now" check have turned out to have different, real semantics
 * (isReady() — see that method's own docblock) or need site-specific,
 * message-aware logic the kit must never hardcode (isAuthStandingCondition()
 * — see SitemapSubmitter). Each site implements both with its own rule.
 */
interface SearchConsoleClient
{
    public function isConfigured(): bool;

    /**
     * Whether a live call (inspectUrl(), submitSitemap(), …) could reach
     * Google at all right now — narrower than, and NOT reducible to,
     * isConfigured(): a site's isConfigured() also weighs things (an
     * explicit kill-switch env flag, whether every config key is filled)
     * that isReady() does not, and the two have genuinely diverged in
     * production. gs.construction's and jpeterson-design's isReady() reads
     * whether a grant with a refresh token is actually stored (the same
     * signal the Platforms card calls "connected"); hive.contractors' has
     * no separate grant to check and returns isConfigured() itself. A
     * caller that wants to avoid spending a scarce daily allowance (the
     * URL Inspection quota) on calls doomed to fail asks this FIRST — see
     * Inspection\UrlInspectionSweep::run().
     */
    public function isReady(): bool;

    /** @return array<int, array<string, mixed>>|null  Google's sitemaps.list rows, or null on failure */
    public function listSitemaps(string $siteUrl): ?array;

    /**
     * Ask Google to (re)fetch one sitemap — sitemaps.submit. Idempotent:
     * submitting an already-registered sitemap simply schedules a
     * re-fetch. See Seo\SitemapSubmitter for the shared loop that drives
     * this across a site's whole sitemap set.
     */
    public function submitSitemap(string $siteUrl, string $sitemapUrl): bool;

    /**
     * One call to Google's URL Inspection API (urlInspection/index:inspect).
     * Every site's GoogleSearchConsoleService already has this exact shape;
     * Inspection\SearchConsoleUrlInspector is the generic adapter that wraps
     * it (catching a network failure, which this method does NOT do — same
     * rule as every other HTTP call on these services) to satisfy the
     * Inspection\Contracts\UrlInspector contract UrlInspectionSweep drives.
     *
     * @return array<string, mixed>|null  Google's raw `inspectionResult` object, or null on ANY failure — call getLastError() for what went wrong.
     */
    public function inspectUrl(string $siteUrl, string $url): ?array;

    /**
     * Whether a failure SitemapSubmitter just saw from THIS client is a
     * standing condition — an unfinished or lapsed setup someone has to fix
     * outside this run (no grant, a lapsed OAuth scope, an unverified
     * property) — rather than a one-off error worth reporting as a failure.
     * A standing condition means "warn once and stop"; anything else counts
     * against the run.
     *
     * Deliberately a per-site HOOK, not kit logic: the kit must never branch
     * on an HTTP status code or match error text itself (that judgment call
     * — which statuses mean "someone has to go fix something", whether a
     * message substring also counts — is real, site-specific knowledge that
     * belongs where the error was produced). gs.construction treats
     * 401/403 (plus its own "no access token" message, which carries no
     * status at all) as standing; jpeterson-design treats 401/403/404.
     *
     * @param  array{status: ?int, message: string}|null  $error  Exactly what getLastError() returned right after the failed call.
     */
    public function isAuthStandingCondition(?array $error): bool;

    /** @return array<string, mixed>|null */
    public function getLastError(): ?array;
}
