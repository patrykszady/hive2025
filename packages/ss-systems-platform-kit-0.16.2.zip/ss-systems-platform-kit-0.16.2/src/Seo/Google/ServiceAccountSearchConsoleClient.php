<?php

namespace SsSystems\Platform\Seo\Google;

use Illuminate\Http\Client\ConnectionException;
use Illuminate\Http\Client\Factory;
use Psr\Log\LoggerInterface;
use Psr\SimpleCache\CacheInterface;
use SsSystems\Platform\Google\ServiceAccountToken;
use SsSystems\Platform\Seo\Inspection\Contracts\UrlInspector;
use SsSystems\Platform\Seo\SearchConsoleSyncClient;

/**
 * A Search Console client authenticated with a service account, not an
 * OAuth grant — for a site with no /admin/{site}/platforms Google sign-in
 * screen of its own for Search Console (hive.contractors and
 * dawnsellshomes.com, both "server-managed" per their PingController; see
 * ss-systems' own CLAUDE.md for the same `managed: 'server'` shape on
 * ss.systems itself). The service account is added as a user on the
 * Search Console property directly — see docs/SEARCH-CONSOLE-SERVICE-
 * ACCOUNT.md for that one human step.
 *
 * Ported from hive.contractors' and dawnsellshomes' App\Services\
 * GoogleSearchConsoleService, which the audit confirmed are 100% identical
 * in logic (docblock wording is the only diff) — this promotes that
 * duplication into ONE concrete kit class instead of a third site copying
 * it by hand. A site adopts this directly (bind the interfaces to an
 * instance in AppServiceProvider) rather than subclassing; see the docs
 * file for the exact binding.
 *
 * Implements the kit's SearchConsoleClient/SearchConsoleSyncClient (so
 * SearchConsoleSync::run() and SitemapStatus can drive it) and, since
 * hive's own inspection adapter (App\Support\Seo\Inspection\
 * SearchConsoleUrlInspector) turned out to be nothing but a thin wrapper
 * around this exact service, UrlInspector too — a site using this class
 * needs no separate inspection adapter at all. `inspectUrl()` keeps its
 * existing name and its existing behaviour (an uncaught
 * ConnectionException, same as every other HTTP call here) for a caller
 * that already calls it directly; `inspect()` (UrlInspector's contract
 * method, which must never throw for a network failure) is the thin
 * catching wrapper around it, exactly like that hive adapter was.
 *
 * `submitSitemap()` is new: neither site had wired direct sitemap
 * submission onto this class before (hive has none at all; dawn's lives
 * inline in its `sitemap:submit` command) — jpeterson-design's OAuth-flavor
 * service already does, and Google 400s on it wearing the wrong body, so
 * this is the fix already proven there, not a fresh guess: a bare
 * `send('PUT', $url)` with no third argument, never `->put()`, which
 * would attach an empty JSON array Google rejects with "Root element must
 * be a message".
 */
final class ServiceAccountSearchConsoleClient implements SearchConsoleSyncClient, UrlInspector
{
    public const SCOPE = 'https://www.googleapis.com/auth/webmasters';

    protected const API_BASE = 'https://searchconsole.googleapis.com/webmasters/v3';

    protected const INSPECTION_URL = 'https://searchconsole.googleapis.com/v1/urlInspection/index:inspect';

    /** @var array{status: ?int, message: string}|null Set by every call below; read by getLastError() and, absent a connection failure, lastError(). */
    protected ?array $lastError = null;

    /** @var array{status: ?int, message: string}|null Only set by inspect()'s own catch — see its docblock. */
    protected ?array $connectionError = null;

    public function __construct(
        protected readonly string $property,
        protected readonly ?string $credential,
        protected readonly CacheInterface $cache,
        protected readonly Factory $http,
        protected readonly ?LoggerInterface $log = null,
    ) {}

    /**
     * The credential is present and a property is set — a cheap, offline
     * check (no network call), matching what GET platforms/status reports
     * as gsc.connected/gsc.configured. Whether the service account
     * actually has permission on that property is a live-API question,
     * answered by the calls below with a clear message via getLastError()
     * — never a stack trace.
     */
    public function isConfigured(): bool
    {
        return $this->token()->isConfigured() && $this->siteUrl() !== '';
    }

    public function siteUrl(): string
    {
        return $this->property;
    }

    /**
     * @param  array<int, string>  $dimensions
     * @return array<int, array<string, mixed>>|null
     */
    public function querySearchAnalytics(
        string $siteUrl,
        string $startDate,
        string $endDate,
        array $dimensions,
        int $rowLimit,
        int $startRow,
    ): ?array {
        $token = $this->getAccessToken();
        if (! $token) {
            return null;
        }

        $url = self::API_BASE.'/sites/'.rawurlencode($siteUrl).'/searchAnalytics/query';
        $resp = $this->http->withToken($token)->timeout(60)->post($url, [
            'startDate' => $startDate,
            'endDate' => $endDate,
            'dimensions' => $dimensions,
            'rowLimit' => $rowLimit,
            'startRow' => $startRow,
            'dataState' => 'final',
        ]);

        if (! $resp->successful()) {
            $this->lastError = $this->describeFailure($resp->status(), (string) $resp->body(), $siteUrl);
            $this->log?->warning('GSC: searchAnalytics query failed', [
                'site' => $siteUrl,
                'status' => $resp->status(),
                'body' => mb_substr((string) $resp->body(), 0, 300),
            ]);

            return null;
        }

        return $resp->json('rows', []);
    }

    /**
     * Every sitemap Search Console knows for the property.
     *
     * @return list<array<string, mixed>>|null
     */
    public function listSitemaps(string $siteUrl): ?array
    {
        $token = $this->getAccessToken();
        if (! $token) {
            return null;
        }

        $resp = $this->http->withToken($token)->timeout(20)->get(self::API_BASE.'/sites/'.rawurlencode($siteUrl).'/sitemaps');

        if (! $resp->successful()) {
            $this->lastError = $this->describeFailure($resp->status(), (string) $resp->body(), $siteUrl);

            return null;
        }

        return $resp->json('sitemap', []);
    }

    /**
     * Ask Google to (re)fetch a sitemap. Idempotent: submitting an
     * already-registered sitemap just schedules a re-fetch.
     *
     * send('PUT') and NOT ->put(): put() attaches an empty JSON array as
     * the body and Google rejects it with 400 "Root element must be a
     * message". sitemaps.submit requires a bodiless PUT (returns 204).
     */
    public function submitSitemap(string $siteUrl, string $sitemapUrl): bool
    {
        $token = $this->getAccessToken();
        if (! $token) {
            return false;
        }

        $resp = $this->http->withToken($token)->timeout(20)->send(
            'PUT',
            self::API_BASE.'/sites/'.rawurlencode($siteUrl).'/sitemaps/'.rawurlencode($sitemapUrl)
        );

        if (! $resp->successful()) {
            $this->lastError = $this->describeFailure($resp->status(), (string) $resp->body(), $siteUrl);

            return false;
        }

        $this->lastError = null;

        return true;
    }

    /**
     * One URL through the URL Inspection API. Deliberately does NOT catch
     * a ConnectionException — same rule as every other HTTP call above —
     * see inspect() for the version that does.
     *
     * @return array<string, mixed>|null
     */
    public function inspectUrl(string $siteUrl, string $url): ?array
    {
        $token = $this->getAccessToken();
        if (! $token) {
            return null;
        }

        $resp = $this->http->withToken($token)->timeout(60)->post(
            self::INSPECTION_URL,
            ['inspectionUrl' => $url, 'siteUrl' => $siteUrl]
        );

        if (! $resp->successful()) {
            $this->lastError = $this->describeFailure($resp->status(), (string) $resp->body(), $siteUrl);

            return null;
        }

        $this->lastError = null;

        return $resp->json('inspectionResult', []);
    }

    /**
     * UrlInspector's contract method: identical to inspectUrl() except a
     * network failure comes back as null + lastError() instead of
     * propagating — the exact behaviour hive's/dawn's separate
     * `SearchConsoleUrlInspector` adapter added on top of this same
     * service; folded in here so a site needs no such adapter at all.
     *
     * @return array<string, mixed>|null
     */
    public function inspect(string $siteUrl, string $url): ?array
    {
        $this->connectionError = null;

        try {
            return $this->inspectUrl($siteUrl, $url);
        } catch (ConnectionException $e) {
            $this->connectionError = ['status' => null, 'message' => $e->getMessage()];

            return null;
        }
    }

    /** UrlInspector's contract method — see the class docblock's shared-$lastError note. */
    public function lastError(): ?array
    {
        return $this->connectionError ?? $this->lastError;
    }

    /** SearchConsoleClient's contract method. @return array{status: ?int, message: string}|null */
    public function getLastError(): ?array
    {
        return $this->lastError;
    }

    /**
     * SearchConsoleClient's contract method. This client has no separate
     * OAuth grant to lapse — every failure describeFailure() above turns
     * into an owner-facing setup instruction (401/403: add the service
     * account as a user on the property; 404: the property isn't verified
     * on this account yet) is exactly the "someone has to go fix something
     * outside this run" case SitemapSubmitter stops on, same set
     * jpeterson-design's OAuth-flavor service already treats as standing.
     * Anything else (a 5xx, a malformed response) counts against the run
     * like any ordinary failure.
     */
    public function isAuthStandingCondition(?array $error): bool
    {
        return in_array($error['status'] ?? null, [401, 403, 404], true);
    }

    /**
     * UrlInspector's contract method: whether inspect() could reach Google
     * at all right now (a credential is configured). Whether the account
     * actually has permission is a live-API question inspect() itself
     * answers through lastError().
     */
    public function isReady(): bool
    {
        return $this->isConfigured();
    }

    protected function token(): ServiceAccountToken
    {
        return new ServiceAccountToken($this->credential, [self::SCOPE], $this->cache, $this->http, $this->log);
    }

    /**
     * A valid access token, or null with lastError() set to an
     * owner-facing reason (never a raw exception message from deep inside
     * the JWT/HTTP plumbing).
     */
    protected function getAccessToken(): ?string
    {
        $token = $this->token();
        $access = $token->get();

        if ($access === null) {
            $this->lastError = ['status' => null, 'message' => $token->lastError() ?? 'Could not obtain a Search Console access token.'];
        }

        return $access;
    }

    /**
     * Turn a Google error into something the owner can act on without
     * needing to know what a service account or an OAuth scope is. Ported
     * verbatim (hive's and dawn's byte-identical wording): the 403 that
     * means "the Search Console API is switched off in this Google Cloud
     * project" is only distinguishable from "this account does not own
     * the property" — the same HTTP status — by the response body.
     *
     * @return array{status: ?int, message: string}
     */
    protected function describeFailure(int $status, string $body, ?string $siteUrl = null): array
    {
        if ($status === 403 && str_contains($body, 'has not been used in project')) {
            preg_match('/project (\d+)/', $body, $m);
            $project = $m[1] ?? null;

            return [
                'status' => $status,
                'message' => 'The Search Console API is switched off in the Google Cloud project behind this service account'
                    .($project ? ' ('.$project.')' : '')
                    .'. Enable it'
                    .($project ? ' at https://console.developers.google.com/apis/api/searchconsole.googleapis.com/overview?project='.$project : '')
                    .', then retry.',
            ];
        }

        return [
            'status' => $status,
            'message' => match ($status) {
                401, 403 => 'Not authorized'.($siteUrl ? ' for '.$siteUrl : '')
                    .' — the service account (GSC_CREDENTIALS) must be added as a user on that Search Console property with Full permission (URL Inspection needs it, not just Restricted).',
                404 => ($siteUrl ?? 'That property').' is not a property on this Search Console account. Add and verify it first.',
                default => mb_substr($body, 0, 300),
            },
        ];
    }
}
