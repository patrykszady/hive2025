<?php

namespace SsSystems\Platform\Seo;

/**
 * What SitemapSubmitter::submit() hands back — everything a site's thin
 * seo:gsc-submit-sitemaps wrapper needs to print exactly what the original
 * command did, without owning any of the submit-loop's own logic.
 *
 * There is no single boolean the kit hands back for "did the whole run
 * work": authStandingSkip() and ok() are the two distinct outcomes a site's
 * command already treated differently before this existed (a standing
 * condition is always a warn-and-exit-clean, whatever else happened; a mix
 * of successes and real failures exits non-zero) — see SitemapSubmitter's
 * own docblock.
 */
final class SitemapSubmitResult
{
    /**
     * @param  list<string>  $submitted  Sitemap URLs Google accepted, in the order they were tried.
     * @param  array<string, string>  $failures  sitemapUrl => error message, for every sitemap that failed for a reason OTHER than the site's own isAuthStandingCondition() — empty when a standing condition was hit (the run stopped there, same as the original commands' own early `return`).
     */
    private function __construct(
        public readonly array $submitted,
        public readonly array $failures,
        public readonly bool $authStandingSkip,
        public readonly ?string $authStandingSitemap,
        public readonly ?string $authStandingMessage,
    ) {}

    /**
     * @param  list<string>  $submitted
     * @param  array<string, string>  $failures
     */
    public static function completed(array $submitted, array $failures): self
    {
        return new self($submitted, $failures, false, null, null);
    }

    /** @param  list<string>  $submitted  Whatever was submitted successfully before this sitemap hit the standing condition. */
    public static function authStanding(array $submitted, string $sitemapUrl, string $message): self
    {
        return new self($submitted, [], true, $sitemapUrl, $message);
    }

    /**
     * True when every sitemap submitted cleanly and no standing condition
     * was hit — a site's command's own SUCCESS/FAILURE exit code. A site's
     * command warms SitemapStatus's cache (fresh: true) whenever
     * authStandingSkip is false, whether or not every sitemap succeeded —
     * exactly when both original commands' own warm call ran.
     */
    public function ok(): bool
    {
        return ! $this->authStandingSkip && $this->failures === [];
    }
}
