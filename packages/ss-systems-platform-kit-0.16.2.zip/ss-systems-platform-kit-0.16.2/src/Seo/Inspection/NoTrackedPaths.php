<?php

namespace SsSystems\Platform\Seo\Inspection;

use SsSystems\Platform\Seo\Inspection\Contracts\TrackedPaths;

/**
 * TrackedPaths for a site with no 404-tracking table: the 'tracked'
 * off-sitemap pool simply contributes nothing. Ported verbatim from
 * jpeterson-design's and hive.contractors' identical null objects — every
 * site with nothing to report here binds directly to this kit class
 * instead of hand-copying it again.
 */
final class NoTrackedPaths implements TrackedPaths
{
    /** @return list<string> */
    public function recent404Paths(): array
    {
        return [];
    }
}
