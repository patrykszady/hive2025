<?php

namespace SsSystems\Platform\Seo\Inspection;

use Illuminate\Support\Carbon;
use SsSystems\Platform\Seo\Inspection\Contracts\CoverageStore;

/**
 * The kit's CoverageStore, over ANY site's own gsc_coverage_states /
 * gsc_rich_result_issues (+ optional history) tables — parameterized by
 * model class-string, never a hardcoded App\Models\* reference (this kit
 * never references a site's own model namespace; see the consolidation
 * rules). Every method here is the same Eloquent call
 * gs.construction's/jpeterson-design's/hive.contractors' own identical
 * local adapters made directly against their own `use App\Models\...`
 * imports — just behind the interface UrlInspectionSweep calls through,
 * and behind this one shared implementation instead of three (four, once
 * dawnsellshomes adopts it) hand-copied files.
 *
 * $historyModel is optional: gs.construction has a real
 * gsc_coverage_state_history table and passes its model class here (every
 * write wrapped in a try/catch — bookkeeping must never fail the sweep,
 * exactly as gs.construction's own pre-kit adapter did); jpeterson-design
 * and hive.contractors have no such table and pass null, which makes
 * recordHistory() the exact documented no-op their own local adapters
 * already were.
 *
 * replaceRichResultIssues() parses `inspected_at` through Carbon::parse()
 * before the raw insert — gs.construction's own local adapter already did
 * this; jpeterson-design's and hive.contractors' did not, inserting the
 * ISO-8601 string (with its literal "T" and UTC offset) as-is. SQLite's
 * text-affinity datetime columns accept that string happily, which is why
 * this went unnoticed on both sites; a real MySQL column in strict mode
 * (both sites' own local/production connection) rejects it. Carbon::parse()
 * hands the query builder a DateTimeInterface, which Laravel's MySQL
 * grammar formats to `Y-m-d H:i:s` itself — the fix that makes this insert
 * behave the same on every engine, not a stylistic preference.
 */
final class EloquentCoverageStore implements CoverageStore
{
    /**
     * @param  class-string  $coverageModel  e.g. \App\Models\GscCoverageState::class — must expose the gsc_coverage_states columns CoverageStore's own docblock documents.
     * @param  class-string  $richResultIssueModel  e.g. \App\Models\GscRichResultIssue::class.
     * @param  ?class-string  $historyModel  e.g. \App\Models\GscCoverageStateHistory::class, or null when the site keeps no history table — see this class's own docblock.
     */
    public function __construct(
        private readonly string $coverageModel,
        private readonly string $richResultIssueModel,
        private readonly ?string $historyModel = null,
    ) {}

    /** @return list<string> */
    public function knownUrls(): array
    {
        return ($this->coverageModel)::query()->orderBy('inspected_at')->pluck('url')->all();
    }

    /**
     * @param  list<string>  $urls
     * @return list<string>
     */
    public function knownUrlsAmong(array $urls): array
    {
        return ($this->coverageModel)::query()
            ->whereIn('url', $urls)
            ->orderBy('inspected_at')
            ->pluck('url')
            ->all();
    }

    public function find(string $url): ?array
    {
        $row = ($this->coverageModel)::query()->where('url', $url)->first();

        if (! $row) {
            return null;
        }

        return [
            'url' => $row->url,
            'source' => $row->source,
            'console_reason' => $row->console_reason,
            'verdict' => $row->verdict,
            'coverage_state' => $row->coverage_state,
            'robots_txt_state' => $row->robots_txt_state,
            'indexing_state' => $row->indexing_state,
            'page_fetch_state' => $row->page_fetch_state,
            'sitemap_url' => $row->sitemap_url,
            'last_crawl_time' => $row->last_crawl_time?->toIso8601String(),
            'user_canonical' => $row->user_canonical,
            'google_canonical' => $row->google_canonical,
            'inspected_at' => $row->inspected_at?->toIso8601String(),
            'last_changed_at' => $row->last_changed_at?->toIso8601String(),
            'consecutive_failures' => (int) $row->consecutive_failures,
        ];
    }

    public function upsert(array $row): void
    {
        ($this->coverageModel)::query()->updateOrCreate(
            ['url' => $row['url']],
            [
                'source' => $row['source'],
                'console_reason' => $row['console_reason'],
                'verdict' => $row['verdict'],
                'coverage_state' => $row['coverage_state'],
                'robots_txt_state' => $row['robots_txt_state'],
                'indexing_state' => $row['indexing_state'],
                'page_fetch_state' => $row['page_fetch_state'],
                'sitemap_url' => $row['sitemap_url'],
                'last_crawl_time' => $row['last_crawl_time'],
                'user_canonical' => $row['user_canonical'],
                'google_canonical' => $row['google_canonical'],
                'inspected_at' => $row['inspected_at'],
                'last_changed_at' => $row['last_changed_at'],
                'consecutive_failures' => $row['consecutive_failures'],
            ]
        );
    }

    /**
     * Best-effort when a history model is configured; a documented no-op
     * when it isn't — see this class's own docblock for which sites are
     * which.
     */
    public function recordHistory(array $row): void
    {
        if ($this->historyModel === null) {
            return;
        }

        try {
            ($this->historyModel)::query()->create([
                'url' => $row['url'],
                'verdict' => $row['verdict'],
                'coverage_state' => $row['coverage_state'],
                'page_fetch_state' => $row['page_fetch_state'],
                'observed_at' => $row['observed_at'],
            ]);
        } catch (\Throwable) {
            // Never let history bookkeeping fail the sweep.
        }
    }

    public function replaceRichResultIssues(string $url, array $issues): void
    {
        ($this->richResultIssueModel)::query()->where('url', $url)->delete();

        if ($issues === []) {
            return;
        }

        $now = Carbon::now();

        ($this->richResultIssueModel)::query()->insert(array_map(fn (array $issue) => [
            'url' => $url,
            'rich_result_type' => $issue['rich_result_type'],
            'issue_severity' => $issue['issue_severity'],
            'issue_type' => $issue['issue_type'],
            'issue_message' => $issue['issue_message'],
            'verdict' => $issue['verdict'],
            // See this class's own docblock: a real MySQL strict-mode fix, not stylistic.
            'inspected_at' => Carbon::parse($issue['inspected_at']),
            'created_at' => $now,
            'updated_at' => $now,
        ], $issues));
    }

    /** @return list<array{verdict: ?string, coverage_state: ?string, n: int}> */
    public function verdictCoverageTotals(): array
    {
        return ($this->coverageModel)::query()
            ->selectRaw('verdict, coverage_state, count(*) as n')
            ->groupBy('verdict', 'coverage_state')
            ->orderByDesc('n')
            ->get()
            ->map(fn ($t) => ['verdict' => $t->verdict, 'coverage_state' => $t->coverage_state, 'n' => (int) $t->n])
            ->all();
    }
}
