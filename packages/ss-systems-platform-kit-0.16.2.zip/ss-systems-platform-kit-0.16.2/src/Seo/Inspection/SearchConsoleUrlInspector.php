<?php

namespace SsSystems\Platform\Seo\Inspection;

use Illuminate\Http\Client\ConnectionException;
use SsSystems\Platform\Seo\Inspection\Contracts\UrlInspector;
use SsSystems\Platform\Seo\SearchConsoleSyncClient;

/**
 * The kit's UrlInspector, wired to ANY site's SearchConsoleSyncClient — the
 * same binding SitemapStatus and SearchConsoleSync already drive. Ported
 * from gs.construction's, jpeterson-design's and hive.contractors' own
 * identical adapters (confirmed byte-identical bar docblocks and the
 * isReady() line — see below), which each did nothing but this: catch the
 * one thing inspectUrl() does not (a network failure) and translate three
 * method names.
 *
 * inspectUrl() has no try/catch around its own HTTP call on any site (same
 * as every other call on these services), so a timeout/DNS/
 * connection-refused throws ConnectionException straight through it.
 * UrlInspectionSweep::run() does not wrap calls to inspect() in a try/catch
 * either (see that class's own docblock) — this adapter is where that
 * catch lives, exactly like this kit's Reports\Contracts\PageFetcher
 * requires of every implementation.
 *
 * isReady()/siteUrl() are pure delegation to the client's own contract
 * methods — NOT hardcoded here — because the three sites' real "am I ready
 * to spend a URL Inspection call" checks are genuinely different
 * (gs.construction/jpeterson-design: a stored grant with a refresh token;
 * hive.contractors: isConfigured() itself, since there is no separate grant
 * to check) and SearchConsoleClient::isReady() is where each site's own
 * service already carries that difference. A site with a real one-line
 * SearchConsoleUrlInspector adapter needs no local file at all any more —
 * bind Inspection\Contracts\UrlInspector to this class directly.
 */
final class SearchConsoleUrlInspector implements UrlInspector
{
    /** @var array{status: ?int, message: string}|null  Set only by a ConnectionException this adapter caught; null means "ask the client instead". */
    private ?array $connectionError = null;

    public function __construct(private readonly SearchConsoleSyncClient $client) {}

    /** @return array<string, mixed>|null */
    public function inspect(string $siteUrl, string $url): ?array
    {
        $this->connectionError = null;

        try {
            return $this->client->inspectUrl($siteUrl, $url);
        } catch (ConnectionException $e) {
            $this->connectionError = ['status' => null, 'message' => $e->getMessage()];

            return null;
        }
    }

    /** @return array{status: ?int, message: string}|null */
    public function lastError(): ?array
    {
        return $this->connectionError ?? $this->client->getLastError();
    }

    public function isReady(): bool
    {
        return $this->client->isReady();
    }

    public function siteUrl(): string
    {
        return $this->client->siteUrl();
    }
}
