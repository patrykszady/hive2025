<?php

namespace SsSystems\Platform\Seo\Concerns;

/**
 * Bookkeeping for one run of a sync (Search Console, Bing, a rank check,
 * ...), keyed by a short slug ('search_console', 'bing', ...), one row per
 * key, replaced whole on every run. `SearchConsoleWriter::recordSyncRun()`
 * and the Bing writer contract both expect the site to persist a summary
 * somewhere every run finishes; a service-account site (hive.contractors,
 * dawnsellshomes — Search Console is a server-held service account, not a
 * per-owner OAuth grant) has no token row to piggyback that on the way
 * jpeterson-design/gsc do on their oauth_tokens' metadata column, so it
 * needs a dedicated table instead. This trait is that table's two static
 * methods, ported verbatim from hive2025/dawnsellshomes' byte-identical
 * `App\Models\SeoSyncRun` (docblock-only diff between the two).
 *
 * The host model owns $table/$fillable/$casts and extends
 * Illuminate\Database\Eloquent\Model itself — see
 * resources/stubs/seo/create_seo_sync_runs_table.php.stub for the matching
 * migration. Adding `use RecordsSyncRuns;` to an existing model is a
 * zero-call-site-change move: every caller (SearchConsoleWriter,
 * PlatformsController, EloquentHealthDataReader, SeoRankCheck, ...) already
 * calls SeoSyncRun::record()/SeoSyncRun::summary() and keeps doing so.
 */
trait RecordsSyncRuns
{
    /** @param  array<string, mixed>  $summary */
    public static function record(string $key, array $summary): void
    {
        static::query()->updateOrCreate(['sync_key' => $key], ['summary' => $summary]);
    }

    /** @return array<string, mixed>|null */
    public static function summary(string $key): ?array
    {
        // ->first()->summary, not ->value('summary'): value() reads the
        // raw column through the query builder, bypassing this model's
        // 'array' cast entirely.
        return static::query()->where('sync_key', $key)->first()?->summary;
    }
}
