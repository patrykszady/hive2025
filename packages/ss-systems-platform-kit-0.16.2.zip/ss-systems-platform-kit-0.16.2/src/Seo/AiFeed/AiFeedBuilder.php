<?php

namespace SsSystems\Platform\Seo\AiFeed;

use Illuminate\Http\JsonResponse;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;
use SsSystems\Platform\Reports\Contracts\SiteIdentity;
use SsSystems\Platform\Seo\AiFeed\Contracts\BusinessIdentity;
use SsSystems\Platform\Seo\AiFeed\Contracts\ContentCatalog;
use SsSystems\Platform\Seo\AiFeed\Contracts\ProjectCatalog;
use SsSystems\Platform\Seo\AiFeed\Contracts\ReviewCatalog;
use SsSystems\Platform\Seo\AiFeed\Contracts\ServiceAreaCatalog;
use SsSystems\Platform\Seo\AiFeed\Contracts\ServiceCatalogFeed;

/**
 * The machine-readable business-facts feed for AI crawlers (ChatGPT,
 * Perplexity, Google AI Overviews, Claude, etc.), ported from
 * gs.construction's and jpeterson-design's near-identical
 * `AiFeedController`s — the two had already drifted apart independently
 * (gs.construction's payload carries `$schema`/`credentials`/`hours`/
 * `rating`/a flat `social` block and no adopter of jpeterson-design's
 * `people`/`markets`/`geo_answers` link, and vice versa). Nobody decided
 * that on purpose, so this port does NOT force one canonical shape: the
 * six catalog contracts hand back already-shaped rows the kit never
 * inspects, `BusinessIdentity::extra()` carries whatever a site's
 * `business` block adds beyond the shared fields, and the `$links`/`$extra`
 * constructor arguments carry whatever a site's top level adds (`$schema`,
 * `service_area`, `credentials` for gs.construction). What the kit DOES
 * now own for both sites: the envelope's shared shape (`generated_at`,
 * `business`, `services`, `service_area_matrix`, `projects`, `stories`,
 * `reviews`, `links`), the response headers, and the cache wrapping.
 *
 * `build()` is pure — no cache, no HTTP — and is what a kit or site unit
 * test calls directly. `respond()` is the cached, `JsonResponse`-wrapped
 * version each site's route actually serves; it needs a booted Laravel
 * app (the `Cache` facade, the `response()` helper) so, like
 * `Seo\Http\Concerns\BuildsSeoSnapshot`'s facade-backed methods, it is
 * pinned by each site's own HTTP feature test
 * (`GET /ai-feed.json` → 200), not by the kit's bare-PHPUnit suite.
 *
 * Phone comes from `Reports\Contracts\SiteIdentity::expectedPhone()`
 * rather than a duplicate method on `BusinessIdentity` — see that
 * contract's docblock for why `address` stays a separate, structured
 * concept instead of also being folded into `SiteIdentity`.
 */
final class AiFeedBuilder
{
    /**
     * @param  array<string,string>  $links  the feed's `links` block,
     *                                        entirely the caller's own —
     *                                        the two current adopters
     *                                        don't even agree on
     *                                        `llms_txt`/`sitemap`/
     *                                        `geo_answers` being present.
     * @param  array<string,mixed>  $extra  merged into the TOP level of the
     *                                      payload, after the shared keys
     *                                      above — gs.construction's
     *                                      `$schema`/`service_area`/
     *                                      `credentials`; empty for a site
     *                                      with nothing extra to say.
     */
    public function __construct(
        private readonly BusinessIdentity $business,
        private readonly SiteIdentity $identity,
        private readonly ServiceCatalogFeed $services,
        private readonly ProjectCatalog $projects,
        private readonly ContentCatalog $content,
        private readonly ReviewCatalog $reviews,
        private readonly ServiceAreaCatalog $areas,
        private readonly array $links = [],
        private readonly array $extra = [],
        private readonly string $cacheKey = 'ai_feed_v1',
        private readonly int $cacheTtl = 900,
    ) {}

    /**
     * The feed payload. Deterministic given its collaborators (aside from
     * `generated_at`, driven by `Carbon::now()`/`Carbon::setTestNow()`
     * exactly like the rest of the kit's time-sensitive classes).
     *
     * @return array<string,mixed>
     */
    public function build(): array
    {
        $payload = [
            'generated_at' => Carbon::now()->toIso8601String(),
            'business' => array_merge($this->businessBlock(), $this->business->extra()),
            'services' => $this->services->services(),
            'service_area_matrix' => $this->areas->serviceAreaMatrix(),
            'projects' => $this->projects->projects(),
            'stories' => $this->content->stories(),
            'reviews' => $this->reviews->reviews(),
            'links' => $this->links,
        ];

        return array_merge($payload, $this->extra);
    }

    /** @return array<string,mixed> */
    private function businessBlock(): array
    {
        $fields = [
            'name' => $this->business->name(),
            'legal_name' => $this->business->legalName(),
            'url' => $this->business->url(),
            'phone' => $this->identity->expectedPhone(),
            'email' => $this->business->email(),
            'founded' => $this->business->founded(),
            'languages' => $this->business->languages() ?: null,
            'address' => $this->address(),
            'social' => $this->business->social() ?: null,
        ];

        return array_filter($fields, static fn (mixed $value): bool => $value !== null);
    }

    /** @return array{locality?: string, region?: string, country?: string}|null */
    private function address(): ?array
    {
        $address = array_filter([
            'locality' => $this->business->addressLocality(),
            'region' => $this->business->addressRegion(),
            'country' => $this->business->addressCountry(),
        ], static fn (mixed $value): bool => $value !== null && $value !== '');

        return $address !== [] ? $address : null;
    }

    /**
     * Cached, response-wrapped version of `build()` — same cache key/TTL,
     * same `Cache-Control`/`X-Robots-Tag` headers and JSON flags both
     * sites' controllers already sent. See class docblock: needs a real
     * Laravel app, exercised by each site's own feature test.
     */
    public function respond(): JsonResponse
    {
        $payload = Cache::remember($this->cacheKey, $this->cacheTtl, fn (): array => $this->build());

        return response()
            ->json($payload, 200, [], JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT)
            ->header('Cache-Control', 'public, max-age='.$this->cacheTtl)
            ->header('X-Robots-Tag', 'all');
    }
}
