<?php

namespace SsSystems\Platform\Seo\AiFeed\Contracts;

/**
 * The business-facts half of `AiFeedController`'s `business` block —
 * everything about "who this company is" that isn't the phone/address NAP
 * pair `Reports\Contracts\SiteIdentity` already owns for GbpParityReport.
 *
 * **Deliberately does NOT declare `phone()`/a raw `address()` string** —
 * that would duplicate `SiteIdentity`, the thing this contract was asked
 * to reconcile with, not shadow. `AiFeedBuilder` takes a `SiteIdentity`
 * alongside this contract and reads `expectedPhone()` straight from it for
 * `business.phone`. `SiteIdentity::expectedAddress()` is NOT reused for
 * `business.address` below, on purpose: that method hands back a single
 * verbatim NAP fragment for a parity *string* match (jpeterson-design's own
 * implementation returns null there — "no street-address config... not the
 * same thing as a landing page's NAP paragraph") while the feed's address
 * is a structured, coarser locality/region/country triple AI crawlers use
 * for geography, not text-matching. Folding one into the other would have
 * silently dropped jpeterson-design's city/state from the feed. They stay
 * two different facts about the same business.
 *
 * Capability key: `ai_feed_business`.
 */
interface BusinessIdentity
{
    public function name(): string;

    /** The registered/legal name, when it differs from the public-facing one. Null when there is none to show. */
    public function legalName(): ?string;

    /** The site's own canonical URL (`https://gs.construction`, `rtrim(config('geo.site_url'), '/')`, ...). */
    public function url(): string;

    public function email(): ?string;

    /** Founding year as a plain string ("2015"), matching both sites' current literal. Null when not tracked. */
    public function founded(): ?string;

    /**
     * Languages spoken, in the exact order they should render. Empty when
     * the site doesn't track this (jpeterson-design has no equivalent
     * today) — `AiFeedBuilder` omits the key entirely rather than emit `[]`.
     *
     * @return list<string>
     */
    public function languages(): array;

    /** City/town. Null when the site has nothing to show here. */
    public function addressLocality(): ?string;

    /** State/region. Null when the site has nothing to show here. */
    public function addressRegion(): ?string;

    /** ISO-ish country string, e.g. "US". Every current adopter always has one. */
    public function addressCountry(): string;

    /**
     * Social profile URLs, already filtered down to the ones that are
     * actually configured — `AiFeedBuilder` does not filter this again.
     *
     * @return array<string,string>
     */
    public function social(): array;

    /**
     * Whatever this site's `business` block carries beyond the shared
     * fields above, merged in as-is (gs.construction: `hours`, `rating`;
     * jpeterson-design: `people`, `markets`). The kit does not know these
     * fields exist; a site adds a new one here without ever touching the
     * kit.
     *
     * @return array<string,mixed>
     */
    public function extra(): array;
}
