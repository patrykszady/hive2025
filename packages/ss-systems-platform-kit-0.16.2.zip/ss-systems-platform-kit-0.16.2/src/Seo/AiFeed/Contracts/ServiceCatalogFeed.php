<?php

namespace SsSystems\Platform\Seo\AiFeed\Contracts;

/**
 * The AI feed's `services` array. Each site keeps its own row shape and its
 * own selection rule — the kit only ever calls `services()` and puts the
 * result straight into the payload, so a site is free to include whatever
 * fields it wants (gs.construction: `slug`/`name`/`description`;
 * jpeterson-design: `slug`/`name`/`url`/`intro`).
 *
 * **This is also where gs.construction's live bug gets fixed**: its
 * adapter must read the real `App\Models\Service` catalog (`Service::
 * ordered()->get()`, the same rows the admin's Services screen manages),
 * never the controller's old hardcoded 5-entry array, which had already
 * drifted out of sync with the real catalog.
 *
 * Capability key: `ai_feed_services`.
 */
interface ServiceCatalogFeed
{
    /**
     * @return list<array<string,mixed>> already-shaped, already-ordered
     *                                    rows, ready to serialize as-is.
     */
    public function services(): array;
}
