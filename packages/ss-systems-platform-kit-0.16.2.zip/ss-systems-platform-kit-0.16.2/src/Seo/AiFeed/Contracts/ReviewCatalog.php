<?php

namespace SsSystems\Platform\Seo\AiFeed\Contracts;

/**
 * The AI feed's `reviews` array. Each site keeps its own row shape and its
 * own visibility rule (both current adopters read `Testimonial::visible()`,
 * latest review first) — the kit only ever calls `reviews()`.
 *
 * Capability key: `ai_feed_reviews`.
 */
interface ReviewCatalog
{
    /**
     * @return list<array<string,mixed>> already-shaped rows, ready to
     *                                    serialize as-is.
     */
    public function reviews(): array;
}
