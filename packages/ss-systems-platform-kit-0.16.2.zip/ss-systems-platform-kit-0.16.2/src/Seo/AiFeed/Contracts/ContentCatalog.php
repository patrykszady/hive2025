<?php

namespace SsSystems\Platform\Seo\AiFeed\Contracts;

/**
 * The AI feed's `stories` array — the long-form, first-person project
 * write-ups (gs.construction and jpeterson-design both call this a
 * `BlogPost`, published + ordered by date, related back to its project).
 * Each site keeps its own row shape; the kit only ever calls `stories()`.
 *
 * Capability key: `ai_feed_content`.
 */
interface ContentCatalog
{
    /**
     * @return list<array<string,mixed>> already-shaped rows, ready to
     *                                    serialize as-is.
     */
    public function stories(): array;
}
