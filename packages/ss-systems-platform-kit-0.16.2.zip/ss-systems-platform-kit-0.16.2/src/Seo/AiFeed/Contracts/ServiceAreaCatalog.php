<?php

namespace SsSystems\Platform\Seo\AiFeed\Contracts;

/**
 * The AI feed's `service_area_matrix` array — per-place URLs, coordinates,
 * ZIP codes and per-service area-scoped URLs, used by AI Overviews to
 * answer "<service> in <place>" with a citation. The two current adopters
 * shape this completely differently (gs.construction: a flat suburb list;
 * jpeterson-design: markets with their towns nested under each) — the kit
 * only ever calls `serviceAreaMatrix()` and does not know or care which
 * shape it gets back.
 *
 * A site that also wants a flat `service_area` list alongside the matrix
 * (gs.construction does) builds that itself and passes it through
 * `AiFeedBuilder`'s `$extra` constructor argument — it is not this
 * contract's job, since jpeterson-design has no equivalent at all.
 *
 * Capability key: `ai_feed_service_areas`.
 */
interface ServiceAreaCatalog
{
    /**
     * @return list<array<string,mixed>> already-shaped rows, ready to
     *                                    serialize as-is.
     */
    public function serviceAreaMatrix(): array;
}
