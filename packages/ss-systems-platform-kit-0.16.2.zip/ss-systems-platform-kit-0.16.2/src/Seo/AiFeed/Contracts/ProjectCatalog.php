<?php

namespace SsSystems\Platform\Seo\AiFeed\Contracts;

/**
 * The AI feed's `projects` array. Each site keeps its own row shape and
 * selection/ordering rule (gs.construction: `is_published`, featured-then-
 * completed-date order; jpeterson-design: its own `published()`/`ordered()`
 * scopes) — the kit only ever calls `projects()`.
 *
 * **This is also where jpeterson-design's live bug gets fixed**: every row
 * must build its `url` from the project's OWN `url()` method (or
 * equivalent), never a fixed literal path — its previous adapter code sent
 * every single project to the exact same `/portfolio` URL because the
 * literal was typed once and never given the project's slug.
 *
 * Capability key: `ai_feed_projects`.
 */
interface ProjectCatalog
{
    /**
     * @return list<array<string,mixed>> already-shaped rows, ready to
     *                                    serialize as-is.
     */
    public function projects(): array;
}
