<?php

namespace SsSystems\Platform\Seo\Http\Concerns;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Symfony\Component\HttpFoundation\StreamedResponse;

/**
 * The "GSC Errors" admin-API screen's shared core — `index()`/`refresh()`/
 * `pruneRetired()`/`export()`/`stats()` plus their private helpers
 * (`serializeRow()`/`filteredQuery()`/`applyIssueFilter()`/`classifyIssue()`),
 * confirmed byte-identical (docblock/message wording aside) across
 * gs.construction, jpeterson-design.com, hive.contractors and ss.systems'
 * own `Api\Admin\V1\GscErrorController` on 2026-09-27 (see
 * docs/audit-2026-09-27/seo-pipeline-verify.md and seo-reports-family.md in
 * ss-platform-kit) — EXCEPT for two real divergences this trait resolves
 * deliberately rather than papering over:
 *
 * 1. **`pruneRetired()`'s `source` scoping was gsc-only.** gsc's own
 *    query started `GscCoverageState::query()->where('source', 'sitemap')`;
 *    jpeterson-design's, hive2025's and ss.systems' did not — meaning
 *    "Prune retired" on those three sites deleted ANY coverage row whose
 *    URL was absent from the sitemap set, including rows tagged
 *    `source=console` (a Search Console Page-indexing export import) or
 *    `source=tracked` (a Googlebot-404 path) — URLs that were never in the
 *    sitemap to begin with and are correctly tracked outside it. That is a
 *    real, live data-loss bug on three sites, not drift to preserve.
 *    **APPROVED FIX (Patryk, 2026-09-27 — CONSOLIDATION-PLAN.md §0/§6):**
 *    the `where('source', 'sitemap')` filter is MANDATORY here, not an
 *    opt-in — every adopter's "Prune retired" now only ever touches rows
 *    the nightly sitemap sweep itself wrote.
 * 2. **`stats()`'s shape was two different contracts, not one.** gsc/jp
 *    returned 7 keys (`tracked, problem, pass, retired, latest_inspected,
 *    sitemap_urls, inspection_coverage_pct`); hive2025/ss.systems returned
 *    4 (`tracked, problem, pass, latest_inspected`) and never called
 *    {@see sitemapUrlSet()} from `stats()` at all. This trait extends the
 *    4-key shape to the 7-key one ADDITIVELY (ss.systems' own
 *    `resources/views/livewire/admin/gsc-errors.blade.php` already reads
 *    every one of the 7 keys with a `?? 0` default, so hive2025/ss.systems
 *    gain real numbers where the screen previously always showed zero —
 *    nothing that screen reads vanishes). Consistent with fix #1 above,
 *    `retired`'s count (and therefore `inspection_coverage_pct`'s
 *    denominator-feeding numerator) is scoped to `source=sitemap` rows
 *    too — gsc's/jpeterson's ORIGINAL `stats()` counted every row
 *    regardless of source as "retired" if its URL left the sitemap, which
 *    (after fix #1) would have shown a bigger "Prune retired (N)" count
 *    than the button actually deletes. Scoping both to the same rule keeps
 *    the tile and the action honest about each other.
 *
 * The two gsc/jp-only extension tiers (`indexing()`/`importConsoleExport()`/
 * `inspect()`/`sitemaps()`/`submitSitemap()`/`deleteSitemap()`, and
 * `enhancementSnapshot()`/`latestReindexReport()`) stay on those sites'
 * own controllers, layered on TOP of this trait — they are not part of the
 * shared core (see CONSOLIDATION-PLAN.md's Kit 0.14.0 bullet).
 *
 * The using controller must also provide (duck-typed, `$this->`, never
 * imported here — same convention as {@see BuildsSeoSnapshot}):
 *   - `use SsSystems\Platform\Http\Admin\Concerns\BuildsApiResponses;`
 *     for `itemResponse()`/`paginatedResponse()`/`perPage()`.
 *
 * Three mandatory hooks, so this file never references an `App\*` class:
 *
 * ```php
 * protected function coverageStateModel(): string
 * {
 *     return \App\Models\GscCoverageState::class; // the site's OWN model —
 *     // never a kit-owned class, so gs.construction's BelongsToSite global
 *     // scope (Site::current()) keeps filtering every query this trait
 *     // runs; single-tenant sites' plain Eloquent model works unmodified.
 * }
 *
 * // Every site's own existing sitemapUrlSet() body, verbatim — gsc/jp parse
 * // a raw sitemap.xml file (different path helpers), hive2025 walks
 * // App\Support\MarketingSitemap, ss.systems walks App\Support\PublicPages.
 * // Kept as a per-site hook rather than routed through the kit's
 * // Inspection\Contracts\SitemapSource (used by the sweep, not this
 * // controller) — see seo-pipeline-verify.md §5: that swap would rehost
 * // gsc's/jpeterson's URLs onto the Search Console property's own host,
 * // a real behavior change outside this unit's brief.
 * protected function sitemapUrlSet(): array
 * {
 *     return [...];
 * }
 *
 * // Queue (or run detached) the full-sitemap URL Inspection sweep exactly
 * // the way this site already does: gsc/ss.systems dispatch their own
 * // App\Jobs\RunGscInspectBulkJob; jpeterson-design/hive2025 dispatch the
 * // kit's own Reports\Jobs\RunArtisanCommandDetached::dispatch(
 * // 'seo:gsc-inspect-bulk', ['--limit' => 0, '--markdown' => true]).
 * protected function dispatchGscInspectBulkSweep(): void
 * {
 *     \App\Jobs\RunGscInspectBulkJob::dispatch();
 * }
 * ```
 *
 * Two optional hooks, not abstract, with working defaults:
 *
 * ```php
 * // hive2025's/ss.systems' own wording differs from gsc's/jp's default
 * // below — overridden there so pruneRetired()'s "could not read" message
 * // stays byte-identical to what each site already says.
 * protected function sitemapUnreadableMessage(): string
 * {
 *     return 'Prune skipped: could not read the site\'s URL inventory.';
 * }
 *
 * // gsc/jpeterson merge two more keys into index()'s payload
 * // (`enhancements`, `reindex_report`) from their own extension-tier
 * // methods; hive2025/ss.systems have neither and use the default below.
 * protected function extraIndexPayload(): array
 * {
 *     return ['enhancements' => $this->enhancementSnapshot(), 'reindex_report' => $this->latestReindexReport()];
 * }
 * ```
 */
trait ServesGscErrors
{
    /**
     * @return class-string<Model> the site's OWN `GscCoverageState` model —
     *                              every query in this trait runs through
     *                              `($this->coverageStateModel())::query()`,
     *                              never a hardcoded class, so a tenant-scoped
     *                              adopter's global scope keeps firing.
     */
    abstract protected function coverageStateModel(): string;

    /**
     * The set of URLs {@see pruneRetired()} and {@see stats()} treat as
     * "still current" — keyed by URL for O(1) lookup. Each site's own
     * existing implementation (see this trait's class docblock).
     *
     * @return array<string, true>
     */
    abstract protected function sitemapUrlSet(): array;

    /** Queue (or run detached) the full-sitemap URL Inspection sweep, the site's own existing way. */
    abstract protected function dispatchGscInspectBulkSweep(): void;

    /** GET .../gsc-errors — filtered, paginated coverage rows plus {@see stats()} and any per-site extension keys. */
    public function index(Request $request): JsonResponse
    {
        $query = $this->filteredQuery($request);

        $paginator = (clone $query)
            ->orderByRaw('COALESCE(last_changed_at, inspected_at) DESC')
            ->paginate($this->perPage($request, 25));

        $response = $this->paginatedResponse($paginator, fn (Model $row) => $this->serializeRow($row));
        $payload = $response->getData(true);
        $payload['stats'] = $this->stats();
        $payload += $this->extraIndexPayload();

        return response()->json($payload);
    }

    /** POST .../gsc-errors/refresh — queue a full sitemap inspection sweep in the background. */
    public function refresh(Request $request): JsonResponse
    {
        try {
            $this->dispatchGscInspectBulkSweep();

            return $this->itemResponse(['message' => 'Queued full sitemap inspection in background. Data will update as the job writes new results.']);
        } catch (\Throwable $e) {
            return $this->itemResponse(['message' => 'Failed to queue background refresh: '.$e->getMessage()], 500);
        }
    }

    /**
     * POST .../gsc-errors/prune-retired — deletes coverage rows for URLs no
     * longer in this site's own URL inventory. **Only rows whose
     * `source` column is `'sitemap'` are ever candidates** — see this
     * trait's class docblock, item 1: a `console`- or `tracked`-sourced row
     * was never in the sitemap to begin with, so its absence from
     * {@see sitemapUrlSet()} is correct and permanent, never a reason to
     * delete it.
     */
    public function pruneRetired(Request $request): JsonResponse
    {
        $sitemapUrls = $this->sitemapUrlSet();
        if ($sitemapUrls === []) {
            return $this->itemResponse(['deleted' => 0, 'message' => $this->sitemapUnreadableMessage()]);
        }

        $model = $this->coverageStateModel();
        $deleted = 0;
        $model::query()->where('source', 'sitemap')
            ->select(['id', 'url'])
            ->chunkById(500, function ($rows) use ($model, $sitemapUrls, &$deleted): void {
                $ids = $rows->filter(fn ($r) => ! isset($sitemapUrls[(string) $r->url]))->pluck('id');
                if ($ids->isNotEmpty()) {
                    $deleted += $model::query()->whereIn('id', $ids)->delete();
                }
            });

        $message = $deleted > 0
            ? "Pruned {$deleted} retired URL(s) no longer in the sitemap."
            : 'Nothing to prune — every tracked URL is in the current sitemap.';

        return $this->itemResponse(['deleted' => $deleted, 'message' => $message]);
    }

    /** gsc's/jpeterson-design's own existing wording — hive2025/ss.systems override this to keep theirs. */
    protected function sitemapUnreadableMessage(): string
    {
        return 'Prune skipped: could not read sitemap.xml.';
    }

    /** Nothing extra by default (hive2025's/ss.systems' shape) — gsc/jpeterson override to add `enhancements`/`reindex_report`. */
    protected function extraIndexPayload(): array
    {
        return [];
    }

    /** GET .../gsc-errors/export — a CSV of the current filtered rows (same filters as {@see index()}), capped at 5,000. */
    public function export(Request $request): StreamedResponse
    {
        $filename = 'gsc-errors-'.now()->format('Ymd-His').'.csv';
        $rows = $this->filteredQuery($request)
            ->orderByRaw('COALESCE(last_changed_at, inspected_at) DESC')
            ->limit(5000)
            ->get();

        return response()->streamDownload(function () use ($rows): void {
            $out = fopen('php://output', 'w');
            fputcsv($out, [
                'url', 'path', 'issue', 'verdict', 'coverage_state', 'page_fetch_state',
                'robots_txt_state', 'indexing_state', 'last_crawl_time', 'inspected_at',
                'last_changed_at', 'consecutive_failures', 'user_canonical', 'google_canonical',
            ]);

            foreach ($rows as $row) {
                $path = parse_url((string) $row->url, PHP_URL_PATH) ?: '/';
                fputcsv($out, [
                    (string) $row->url,
                    (string) $path,
                    $this->classifyIssue((string) $row->coverage_state, (string) $row->page_fetch_state, (string) $row->verdict),
                    (string) ($row->verdict ?? 'UNKNOWN'),
                    (string) ($row->coverage_state ?? ''),
                    (string) ($row->page_fetch_state ?? ''),
                    (string) ($row->robots_txt_state ?? ''),
                    (string) ($row->indexing_state ?? ''),
                    optional($row->last_crawl_time)->toDateString(),
                    optional($row->inspected_at)->toDateTimeString(),
                    optional($row->last_changed_at)->toDateTimeString(),
                    (int) ($row->consecutive_failures ?? 0),
                    (string) ($row->user_canonical ?? ''),
                    (string) ($row->google_canonical ?? ''),
                ]);
            }

            fclose($out);
        }, $filename, ['Content-Type' => 'text/csv; charset=UTF-8']);
    }

    protected function serializeRow(Model $row): array
    {
        $path = parse_url((string) $row->url, PHP_URL_PATH) ?: '/';

        return [
            'id' => $row->id,
            'url' => (string) $row->url,
            'path' => (string) $path,
            'issue' => $this->classifyIssue((string) $row->coverage_state, (string) $row->page_fetch_state, (string) $row->verdict),
            'verdict' => (string) ($row->verdict ?? 'UNKNOWN'),
            'coverage_state' => (string) ($row->coverage_state ?? ''),
            'page_fetch_state' => (string) ($row->page_fetch_state ?? ''),
            'robots_txt_state' => (string) ($row->robots_txt_state ?? ''),
            'indexing_state' => (string) ($row->indexing_state ?? ''),
            'last_crawl_time' => $row->last_crawl_time?->toDateString(),
            'inspected_at' => $row->inspected_at?->toIso8601String(),
            'last_changed_at' => $row->last_changed_at?->toIso8601String(),
            'consecutive_failures' => (int) ($row->consecutive_failures ?? 0),
        ];
    }

    /**
     * @return array{tracked:int,problem:int,pass:int,retired:int,latest_inspected:?string,sitemap_urls:int,inspection_coverage_pct:int}
     */
    protected function stats(): array
    {
        $model = $this->coverageStateModel();

        $tracked = $model::query()->count();
        $problem = $model::query()->where(function ($q) {
            $q->where('verdict', '!=', 'PASS')
                ->orWhereNull('verdict')
                ->orWhereRaw('LOWER(COALESCE(coverage_state, "")) like ?', ['%forbidden%'])
                ->orWhereRaw('LOWER(COALESCE(coverage_state, "")) like ?', ['%not indexed%'])
                ->orWhereRaw('LOWER(COALESCE(coverage_state, "")) like ?', ['%duplicate%'])
                ->orWhereRaw('LOWER(COALESCE(coverage_state, "")) like ?', ['%soft 404%']);
        })->count();

        // Only source=sitemap rows feed retired/coverage math — the same
        // scoping pruneRetired() enforces, so the tile and the button never
        // disagree about what "retired" means (see class docblock, item 2).
        $sitemapUrls = $this->sitemapUrlSet();
        $trackedInSitemap = 0;
        $retired = 0;
        if ($sitemapUrls !== []) {
            $model::query()->where('source', 'sitemap')->select(['id', 'url'])
                ->chunkById(500, function ($rows) use ($sitemapUrls, &$trackedInSitemap, &$retired): void {
                    foreach ($rows as $r) {
                        isset($sitemapUrls[(string) $r->url]) ? $trackedInSitemap++ : $retired++;
                    }
                });
        }

        $stats = [
            'tracked' => (int) $tracked,
            'problem' => (int) $problem,
            'pass' => max(0, (int) $tracked - (int) $problem),
            'retired' => $retired,
            'latest_inspected' => ($latest = $model::query()->max('inspected_at'))
                ? Carbon::parse($latest)->diffForHumans()
                : null,
            'sitemap_urls' => count($sitemapUrls),
        ];

        $stats['inspection_coverage_pct'] = $stats['sitemap_urls'] > 0
            ? min(100, (int) round(($trackedInSitemap / max(1, $stats['sitemap_urls'])) * 100))
            : 0;

        return $stats;
    }

    protected function filteredQuery(Request $request): Builder
    {
        $scope = $request->string('scope', 'problems')->toString();
        $search = $request->string('search', '')->toString();
        $verdictFilter = $request->string('verdict', 'all')->toString();
        $issueFilter = $request->string('issue', 'all')->toString();

        $model = $this->coverageStateModel();
        $query = $model::query();

        if ($scope === 'problems') {
            $query->where(function ($q) {
                $q->where('verdict', '!=', 'PASS')
                    ->orWhereNull('verdict')
                    ->orWhereRaw('LOWER(COALESCE(coverage_state, "")) like ?', ['%forbidden%'])
                    ->orWhereRaw('LOWER(COALESCE(coverage_state, "")) like ?', ['%not indexed%'])
                    ->orWhereRaw('LOWER(COALESCE(coverage_state, "")) like ?', ['%duplicate%'])
                    ->orWhereRaw('LOWER(COALESCE(coverage_state, "")) like ?', ['%soft 404%'])
                    ->orWhereRaw('LOWER(COALESCE(page_fetch_state, "")) like ?', ['%server%'])
                    ->orWhereRaw('LOWER(COALESCE(page_fetch_state, "")) like ?', ['%not found%'])
                    ->orWhereRaw('LOWER(COALESCE(page_fetch_state, "")) like ?', ['%redirect%']);
            });
        }

        if ($search !== '') {
            $term = '%'.str_replace('%', '\\%', strtolower(trim($search))).'%';
            $query->where(function ($q) use ($term) {
                $q->whereRaw('LOWER(url) like ?', [$term])
                    ->orWhereRaw('LOWER(COALESCE(coverage_state, "")) like ?', [$term])
                    ->orWhereRaw('LOWER(COALESCE(page_fetch_state, "")) like ?', [$term])
                    ->orWhereRaw('LOWER(COALESCE(verdict, "")) like ?', [$term]);
            });
        }

        if ($verdictFilter !== 'all') {
            if ($verdictFilter === 'unknown') {
                $query->whereNull('verdict');
            } else {
                $query->where('verdict', strtoupper($verdictFilter));
            }
        }

        if ($issueFilter !== 'all') {
            $query->where(fn ($q) => $this->applyIssueFilter($q, $issueFilter));
        }

        return $query;
    }

    protected function applyIssueFilter(Builder $query, string $issueFilter): void
    {
        if ($issueFilter === 'blocked') {
            $query->where(function ($q) {
                $q->whereRaw('LOWER(COALESCE(coverage_state, "")) like ?', ['%forbidden%'])
                    ->orWhereRaw('LOWER(COALESCE(coverage_state, "")) like ?', ['%robots%'])
                    ->orWhereRaw('LOWER(COALESCE(page_fetch_state, "")) like ?', ['%robots%']);
            });

            return;
        }

        if ($issueFilter === 'not_indexed') {
            $query->whereRaw('LOWER(COALESCE(coverage_state, "")) like ?', ['%not indexed%']);

            return;
        }

        if ($issueFilter === 'duplicate') {
            $query->where(function ($q) {
                $q->whereRaw('LOWER(COALESCE(coverage_state, "")) like ?', ['%duplicate%'])
                    ->orWhereRaw('LOWER(COALESCE(coverage_state, "")) like ?', ['%canonical%']);
            });

            return;
        }

        if ($issueFilter === 'soft_404') {
            $query->whereRaw('LOWER(COALESCE(coverage_state, "")) like ?', ['%soft 404%']);

            return;
        }

        if ($issueFilter === 'fetch_error') {
            $query->where(function ($q) {
                $q->whereRaw('LOWER(COALESCE(coverage_state, "")) like ?', ['%server error%'])
                    ->orWhereRaw('LOWER(COALESCE(page_fetch_state, "")) like ?', ['%server%'])
                    ->orWhereRaw('LOWER(COALESCE(page_fetch_state, "")) like ?', ['%not found%'])
                    ->orWhereRaw('LOWER(COALESCE(page_fetch_state, "")) like ?', ['%redirect%']);
            });

            return;
        }

        if ($issueFilter === 'other') {
            $query->where(function ($q) {
                $q->whereRaw('LOWER(COALESCE(coverage_state, "")) not like ?', ['%forbidden%'])
                    ->whereRaw('LOWER(COALESCE(coverage_state, "")) not like ?', ['%not indexed%'])
                    ->whereRaw('LOWER(COALESCE(coverage_state, "")) not like ?', ['%duplicate%'])
                    ->whereRaw('LOWER(COALESCE(coverage_state, "")) not like ?', ['%soft 404%'])
                    ->whereRaw('LOWER(COALESCE(coverage_state, "")) not like ?', ['%canonical%'])
                    ->whereRaw('LOWER(COALESCE(page_fetch_state, "")) not like ?', ['%server%'])
                    ->whereRaw('LOWER(COALESCE(page_fetch_state, "")) not like ?', ['%not found%'])
                    ->whereRaw('LOWER(COALESCE(page_fetch_state, "")) not like ?', ['%redirect%']);
            });
        }
    }

    protected function classifyIssue(string $coverageState, string $pageFetchState, string $verdict): string
    {
        $text = strtolower(trim($coverageState.' '.$pageFetchState));

        if ($text === '' && strtoupper($verdict) === 'PASS') {
            return 'Indexed';
        }
        if (str_contains($text, 'forbidden') || str_contains($text, 'robots')) {
            return 'Blocked';
        }
        if (str_contains($text, 'not indexed')) {
            return 'Not indexed';
        }
        if (str_contains($text, 'duplicate') || str_contains($text, 'canonical')) {
            return 'Duplicate/canonical';
        }
        if (str_contains($text, 'soft 404')) {
            return 'Soft 404';
        }
        if (str_contains($text, 'server') || str_contains($text, 'not found') || str_contains($text, 'redirect')) {
            return 'Fetch error';
        }

        return strtoupper($verdict) === 'PASS' ? 'Indexed' : 'Other';
    }
}
