<?php

namespace SsSystems\Platform\Seo;

/**
 * The seo:gsc-submit-sitemaps loop — ported from gs.construction's and
 * jpeterson-design's identical command bodies (they differ only in how
 * each resolves its own property/base URL, which stays the site's own
 * command's job, not this shell's).
 *
 * Every sitemap in $sitemapUrls is submitted in order. The very first
 * failure that the client's own isAuthStandingCondition() recognizes as a
 * standing condition — not authorized, no grant yet, an unverified
 * property, whatever that site itself considers "someone has to finish
 * setup" — stops the run right there (later sitemaps are never attempted)
 * and comes back as SitemapSubmitResult::authStanding(), same as both
 * original commands' own early `return self::SUCCESS` inside their foreach
 * loop. Any OTHER failure is recorded and the loop continues to the next
 * sitemap, exactly like the originals' `$failures++` did.
 *
 * The kit itself never inspects an HTTP status or a message here — that
 * judgment is entirely isAuthStandingCondition()'s, on the site's own
 * client (see SearchConsoleClient's docblock for why).
 *
 * Deliberately does NOT warm SitemapStatus's cache itself: that call goes
 * through the Cache facade and a booted container, and this class stays
 * plain-PHP-testable (a fake SearchConsoleClient, nothing else) by leaving
 * "warm the Sitemaps card while already authenticated" to the site's own
 * thin command, same as both original commands — see docs on
 * SitemapSubmitResult::ok() for exactly when that call belongs (never
 * after an auth-standing skip).
 */
final class SitemapSubmitter
{
    public function __construct(private readonly SearchConsoleClient $client) {}

    /** @param  list<string>  $sitemapUrls */
    public function submit(string $siteUrl, array $sitemapUrls): SitemapSubmitResult
    {
        $submitted = [];
        $failures = [];

        foreach ($sitemapUrls as $sitemapUrl) {
            if ($this->client->submitSitemap($siteUrl, $sitemapUrl)) {
                $submitted[] = $sitemapUrl;

                continue;
            }

            $error = $this->client->getLastError();

            if ($this->client->isAuthStandingCondition($error)) {
                return SitemapSubmitResult::authStanding($submitted, $sitemapUrl, $error['message'] ?? 'Not authorized.');
            }

            $failures[$sitemapUrl] = $error['message'] ?? 'Unknown error.';
        }

        return SitemapSubmitResult::completed($submitted, $failures);
    }
}
