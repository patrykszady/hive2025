<?php

namespace SsSystems\Platform\Seo\Faq\Contracts;

/**
 * The Q&A list and the extra Organization-schema fields behind
 * `/geo/answers.json`'s FAQPage JSON-LD feed — see
 * {@see \SsSystems\Platform\Seo\Faq\Http\Concerns\BuildsFaqPageFeed}, which
 * builds the envelope from whatever this hands it. Bound once per site in
 * `AppServiceProvider`; how the list is assembled is exactly the part that
 * cannot be shared: gs.construction's is the fixed `config/geo-answers.php`
 * list alone, jpeterson-design's merges that same fixed list with every
 * switched-on `Service`'s and `Area`'s own `faqItems()` — that merge logic
 * stays the site's own, never the kit's. A kit class must never reference
 * `App\Models\*`; only this interface crosses the boundary.
 */
interface FaqCatalog
{
    /**
     * Every Q&A pair the feed should publish, already merged and filtered
     * (a switched-off FAQ section must already be excluded by the time this
     * returns — the kit does not know what "switched off" means).
     *
     * @return list<array{q: string, a: string, topics?: list<string>}>
     */
    public function items(): array;

    /**
     * Extra fields merged into the FAQPage envelope's `publisher` object,
     * after the common name/url/telephone/email/areaServed fields the kit
     * always sets — e.g. gs.construction's `knowsLanguage` (the languages
     * the crew speaks) or jpeterson-design's `employee` (the studio's two
     * designers, from `config('brand.people')`). A site with nothing extra
     * returns `[]`; naming a key here that the kit's own publisher fields
     * already use would silently overwrite one, so pick a name schema.org
     * doesn't already carry above.
     *
     * @return array<string, mixed>
     */
    public function publisherExtras(): array;
}
