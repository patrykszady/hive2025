<?php

namespace SsSystems\Platform\Seo\Faq\Http\Concerns;

use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Cache;
use SsSystems\Platform\Seo\Faq\Contracts\FaqCatalog;

/**
 * The shared body of `/geo/answers.json`'s controller — gs.construction's
 * and jpeterson-design's `GeoAnswersController` were identical but for one
 * field each adds to the `publisher` object (2026-09-27 audit; see
 * CONSOLIDATION-PLAN.md's Kit 0.13.0 FaqCatalog bullet). The using
 * controller supplies:
 *
 *   - {@see faqCatalog()} — the bound {@see FaqCatalog} implementation
 *     (constructor-injected in practice; the hook exists so this trait
 *     never assumes how the controller got it);
 *   - {@see faqBusinessName()}/{@see faqPhone()}/{@see faqEmail()}/
 *     {@see faqAreaServed()} — the same `config('geo-answers.meta.*')`
 *     reads both controllers already had, kept out of the kit because the
 *     fallback default differs per site (gs.construction hardcodes
 *     'GS Construction'; jpeterson-design falls back to
 *     `config('brand.name')`) — a kit class must not bake in either site's
 *     literal business name, and must not rename either site's config key.
 *
 * `__invoke()`/`buildFaqPagePayload()` call the `Cache` facade and the
 * `url()`/`response()`/`now()` helpers directly, exactly as the two
 * controllers did — they need a real booted Laravel app to mean anything
 * (`illuminate/routing`/`illuminate/foundation` are not kit dependencies),
 * so, like `BuildsSeoSnapshot`'s facade-backed methods, they are NOT
 * covered by the kit's own bare PHPUnit suite. {@see faqPageEnvelope()}
 * below has no facade or global-helper call at all and IS covered there;
 * each site's `GeoAnswersControllerTest` feature-tests the rest end to
 * end, including that its own extra `publisher` field survives.
 */
trait BuildsFaqPageFeed
{
    public function __invoke(): JsonResponse
    {
        $payload = Cache::remember('geo_answers_v1', 3600, fn (): array => $this->buildFaqPagePayload());

        return response()->json($payload, 200, [
            'Cache-Control' => 'public, max-age=3600',
            'X-Robots-Tag' => 'all',
        ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }

    protected function buildFaqPagePayload(): array
    {
        return $this->faqPageEnvelope(
            $this->faqCatalog(),
            url('/geo/answers.json'),
            url('/'),
            now()->toIso8601String(),
        );
    }

    /**
     * Pure — no facade, no global helper, no container — everything the two
     * controllers built inline, minus the four values {@see buildFaqPagePayload()}
     * already resolved above. Key order matches both controllers' original
     * literal arrays exactly (the extra `publisher` field lands last, same
     * as it did inline).
     *
     * @return array<string, mixed>
     */
    protected function faqPageEnvelope(FaqCatalog $catalog, string $feedUrl, string $organizationUrl, string $dateModified): array
    {
        $publisher = array_merge([
            '@type' => 'Organization',
            'name' => $this->faqBusinessName(),
            'url' => $organizationUrl,
            'telephone' => $this->faqPhone(),
            'email' => $this->faqEmail(),
            'areaServed' => $this->faqAreaServed(),
        ], $catalog->publisherExtras());

        return [
            '@context' => 'https://schema.org',
            '@type' => 'FAQPage',
            'name' => $this->faqBusinessName().' — Q&A for AI engines',
            'url' => $feedUrl,
            'dateModified' => $dateModified,
            'publisher' => $publisher,
            'mainEntity' => array_map(static fn (array $a): array => [
                '@type' => 'Question',
                'name' => $a['q'] ?? '',
                'topics' => $a['topics'] ?? [],
                'acceptedAnswer' => [
                    '@type' => 'Answer',
                    'text' => $a['a'] ?? '',
                ],
            ], $catalog->items()),
        ];
    }

    abstract protected function faqCatalog(): FaqCatalog;

    abstract protected function faqBusinessName(): string;

    abstract protected function faqPhone(): ?string;

    abstract protected function faqEmail(): ?string;

    abstract protected function faqAreaServed(): ?string;
}
