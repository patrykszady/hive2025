<?php

namespace SsSystems\Platform\Seo\Credentials\Contracts;

/**
 * The one seam CredentialEnvImport needs onto a site's own admin-saved-
 * credential storage. Every site already has this: gsc's is
 * site_id-scoped (BelongsToSite), the rest are plain — that tenancy
 * decision lives entirely in each site's own adapter, never here.
 *
 * Deliberately only get()/put(), not the site's whole PlatformSetting API
 * (no delete, no "with a default" read) — CredentialEnvImport's own "never
 * overwrite an admin-saved value" rule depends on get() answering null for
 * nothing-stored-yet, so an adapter must NOT fall back to config()/env()
 * inside get() (that would make every key look "already stored").
 */
interface CredentialStore
{
    /** Null when nothing is stored — never falls back to config()/env(). */
    public function get(string $key): ?string;

    public function put(string $key, string $value): void;
}
