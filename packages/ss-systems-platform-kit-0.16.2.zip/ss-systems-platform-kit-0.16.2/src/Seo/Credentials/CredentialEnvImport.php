<?php

namespace SsSystems\Platform\Seo\Credentials;

use SsSystems\Platform\Seo\Credentials\Contracts\CredentialStore;

/**
 * Copies whichever admin-storable SEO credential fields a site's own env/
 * config already has into that site's credential store, so the env values
 * can eventually be deleted once every tenant that needs them has its own
 * admin-stored row (Patryk's rule: "credentials must LEAVE the
 * environment").
 *
 * Ported from four near-identical site copies of
 * `App\Support\Seo\SeoCredentialsImport::run()` (gsc, jpeterson-design,
 * hive2025, dawnsellshomes) — the only thing that ever differed between
 * them was the TABLE of fields (which config key backs which storage key,
 * and which sources a site even has, e.g. dawn only ever had Bing). The
 * loop itself was byte-for-byte identical everywhere:
 *   - a value already stored wins, even when env also has one — this never
 *     overwrites a value an admin (or a prior import) already saved;
 *   - an env value is trimmed before being judged blank, so
 *     whitespace-only counts the same as unset;
 *   - a credential VALUE is never logged, printed, or returned — only
 *     which of three buckets each field's LABEL fell into.
 * Each site keeps its own `fields()`/SOURCES table (config-key names
 * genuinely differ per site — see the audit's naming-drift note, e.g.
 * `services.bing.*` vs `services.bing_wmt.*`) and a small CredentialStore
 * adapter over its own PlatformSetting model, and forwards both here.
 */
final class CredentialEnvImport
{
    public function __construct(private readonly CredentialStore $store)
    {
    }

    /**
     * @param  list<array{label: string, key: string, env: mixed, source?: string}>  $fields  In report order. Each row's optional `source` only groups fields for $onImported below — it never changes whether the row itself counts as imported/already_stored/absent.
     * @param  bool  $dryRun  Report what WOULD happen without writing anything — and without calling $onImported, since nothing actually changed.
     * @param  (callable(string $source): void)|null  $onImported  Called once per DISTINCT source that had at least one field actually imported (never for a source that was only already_stored or absent), and only on a real write. E.g. gsc's/jpeterson-design's `ClaritySettings::forgetProjectIdCache()`, so a freshly-imported project id is live on the very next page load instead of waiting out its cache TTL.
     * @return array{imported: list<string>, already_stored: list<string>, absent: list<string>}
     */
    public function run(array $fields, bool $dryRun = false, ?callable $onImported = null): array
    {
        $result = ['imported' => [], 'already_stored' => [], 'absent' => []];

        /** @var array<string, true> $touchedSources */
        $touchedSources = [];

        foreach ($fields as $row) {
            $label = $row['label'];
            $key = $row['key'];

            // Raw stored check — deliberately NOT a defaulted/config-falling
            // -back read, which would mask "nothing stored yet" behind the
            // env value and make every key look "already stored".
            if (filled($this->store->get($key))) {
                $result['already_stored'][] = $label;

                continue;
            }

            $envValue = $row['env'] ?? null;
            $envValue = filled($envValue) ? trim((string) $envValue) : '';

            if ($envValue === '') {
                $result['absent'][] = $label;

                continue;
            }

            $result['imported'][] = $label;

            if (! $dryRun) {
                $this->store->put($key, $envValue);

                if (isset($row['source'])) {
                    $touchedSources[$row['source']] = true;
                }
            }
        }

        if (! $dryRun && $onImported !== null) {
            foreach (array_keys($touchedSources) as $source) {
                $onImported($source);
            }
        }

        return $result;
    }
}
