<?php

namespace SsSystems\Platform\Citations;

use SsSystems\Platform\Citations\Contracts\CitationRecord;
use SsSystems\Platform\Citations\Contracts\KnownListingsSource;

/**
 * Bring the citations board in line with what a site already has: a
 * matched row's blank `listing_url` is filled, and a row still planned,
 * failed or waiting on a person is promoted to live — never a run in
 * progress or a deliberate decline. Moved verbatim from gsc's/jpeterson's/
 * hive's `App\Support\Citations\KnownListings::reconcile()` (2026-09-27
 * audit, citations.md #5: "divergent by design, but cleanly split
 * already" — this loop was already byte-identical in all three; only
 * `forCurrentSite()`, genuinely per-site, stays behind `KnownListingsSource`).
 *
 * Referenced but deliberately NOT built by `Citations\Sync`'s own
 * docblock ("a separate, later kit unit... 0.13.0's `CitationsAdminActions`
 * bullet") — this is that unit. Each site's `citations:sync` command keeps
 * calling its own `KnownListings::reconcile()` static wrapper unchanged;
 * that wrapper now delegates here instead of carrying its own copy of the
 * loop, so there is exactly one implementation, not two.
 *
 * Two seams, the same shape as `BatchRunner`'s/`Sync`'s own:
 *
 * - **`$baseQuery`** — gsc's binds the `site_id` filter, jpeterson's/
 *   hive's bind bare `Citation::query()`. Every row lookup goes through it.
 * - **`$sourceLabel`** — the noun in the log/note line ("Matched from what
 *   {$sourceLabel} already knows: ..."): gsc/jpeterson say "Platforms"
 *   (Houzz/Angi/Yelp/Meta all live there); hive says "Social Media" (its
 *   one overlap, `linkedin`, is a Social Media link, not a Platforms
 *   connection) — real, already-existing wording kept, not invented here.
 */
class KnownListingsReconciler
{
    /** Statuses a match may move to live — never a run in progress, a submission awaiting verification, or a deliberate decline. */
    protected const MOVABLE = [
        CitationRecord::STATUS_PLANNED, CitationRecord::STATUS_FAILED, CitationRecord::STATUS_NEEDS_HUMAN,
        CitationRecord::STATUS_UNREACHABLE, CitationRecord::STATUS_NO_MECHANISM,
    ];

    /**
     * @param  \Closure(): \Illuminate\Database\Eloquent\Builder  $baseQuery  Every
     *   row lookup below starts here — see this class's own docblock.
     */
    public function __construct(
        protected KnownListingsSource $source,
        protected \Closure $baseQuery,
        protected string $sourceLabel = 'Platforms',
    ) {}

    /**
     * @return int how many rows this call changed
     */
    public function reconcile(): int
    {
        $changed = 0;

        foreach ($this->source->forCurrentSite() as $slug => $known) {
            $row = ($this->baseQuery)()->where('slug', $slug)->first();
            if (! $row) {
                continue;
            }

            $dirty = false;
            if (blank($row->listing_url)) {
                $row->listing_url = $known['url'];
                $dirty = true;
            }
            if (in_array($row->status, self::MOVABLE, true)) {
                $row->status = CitationRecord::STATUS_LIVE;
                $row->live_at ??= now();
                $row->human_reason = null;
                $row->note = 'Listed already — '.$known['source'].'.';
                $dirty = true;
            }
            if ($dirty) {
                $row->addLog('Matched from what '.$this->sourceLabel.' already knows: '.$known['source'], 'sync');
                $row->save();
                $changed++;
            }
        }

        return $changed;
    }
}
