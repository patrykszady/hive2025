<?php

namespace SsSystems\Platform\Citations;

use SsSystems\Platform\Citations\Contracts\CitationRecord;
use SsSystems\Platform\Citations\Contracts\CitationSession;

/**
 * Bring the citations table in line with config('citations.directories'):
 * one row per directory, new ones planned, existing statuses untouched
 * (`register()`); then fold stale "running" rows and busy-slot/bot-wall
 * failure notes back onto the board (`cleanupStale()`). Moved from the
 * body of gsc's/jpeterson's `citations:sync` command (a 100%-cosmetic
 * diff between the two beyond the parameterization below — confirmed
 * with `diff -b -B`); each site's command is now a ~20-line wrapper that
 * supplies its own scoping/tier/known-profiles and prints the same table
 * it always did. hive's `citations:sync` is NOT ported onto this class —
 * its own docblock already explains why `cleanupStale()`'s two recovery
 * loops can never apply there (`UnavailableSession::start()` always
 * refuses before a row is ever marked running), and it never had the
 * known-profiles matching either.
 *
 * Three constructor seams replace what gsc's/jpeterson's inline command
 * body hardcoded, none of them changing what ends up in the database:
 *
 * - **`$baseQuery`** — same Closure-scoping contract as `BatchRunner`'s
 *   (see that class's docblock): gsc's binds the `site_id` filter,
 *   jpeterson's binds bare `Citation::query()`. Every read in this class
 *   goes through it; nothing here ever queries `Citation` on its own.
 * - **`$create`** — `(array $attrs): CitationRecord`, called only for a
 *   directory with no existing row. This (not a class-string) is the
 *   create-side counterpart to `$baseQuery`: gsc's Closure bakes in
 *   `'site_id' => Site::current()?->id` before calling
 *   `Citation::create()`; jpeterson's calls it with no such key. Kept
 *   separate from `$baseQuery` because a Closure returning a `Builder`
 *   has no `create()` of its own to call with extra attributes merged in.
 * - **`$defaultTier`/`$knownProfiles`** — gsc/jpeterson default an
 *   omitted directory's `tier` to `2` and prefill `listing_url` from
 *   their own `config('brand.profiles', [])` map (label => URL); hive's
 *   inline version (not ported here) defaults to `1` and never did the
 *   profile match at all — both are real per-site content the audit
 *   flagged as needing parameterization, not a bug either way.
 *
 * What is deliberately NOT here: the "matched from Platforms" count
 * (`App\Support\Citations\KnownListings::reconcile()`) is a separate,
 * later kit unit (`Citations\KnownListingsReconciler`, 0.13.0's
 * `CitationsAdminActions` bullet) — every site's command still calls its
 * own `KnownListings::reconcile()` right after `register()`, unchanged,
 * and folds that count into the same summary line it always printed.
 */
class Sync
{
    /**
     * @param  \Closure(): \Illuminate\Database\Eloquent\Builder  $baseQuery  Every
     *   read below starts here — see this class's own docblock.
     * @param  \Closure(array<string,mixed>): CitationRecord  $create  Creates
     *   one brand-new row (a site's own `Citation::create($attrs)`), with
     *   whatever extra attributes (e.g. `site_id`) that site's binding
     *   already closes over.
     * @param  array<string,string>  $knownProfiles  label => URL, this
     *   site's own already-connected profiles (gsc's/jpeterson's
     *   `config('brand.profiles', [])`) used to prefill a blank
     *   `listing_url`. A site with no such source passes `[]`.
     */
    public function __construct(
        protected CitationSession $sessions,
        protected \Closure $baseQuery,
        protected \Closure $create,
        protected int $defaultTier = 2,
        protected array $knownProfiles = [],
    ) {}

    /**
     * One row per configured directory: fills in name/tier/mechanism/
     * homepage/start_url on an existing row (status untouched), creates a
     * new one `STATUS_PLANNED` otherwise. A blank `listing_url` on either
     * path is prefilled from `$knownProfiles` when the slug or directory
     * name matches one, letter-and-digit-only, case-insensitive — exactly
     * gsc's/jpeterson's own `$norm` matching.
     *
     * @return array{created: int}
     */
    public function register(): array
    {
        $created = 0;
        $norm = fn ($v) => preg_replace('/[^a-z0-9]/', '', strtolower((string) $v));
        $known = [];
        foreach ($this->knownProfiles as $label => $url) {
            $known[$norm($label)] = (string) $url;
        }
        foreach ((array) config('citations.directories', []) as $slug => $def) {
            $row = ($this->baseQuery)()->where('slug', $slug)->first();
            $attrs = [
                'name' => $def['name'] ?? $slug, 'tier' => (int) ($def['tier'] ?? $this->defaultTier), 'mechanism' => (string) ($def['mechanism'] ?? 'form'),
                'homepage' => $def['homepage'] ?? null, 'start_url' => $def['start_url'] ?? ($def['homepage'] ?? null),
            ];
            $existingUrl = $known[$norm($slug)] ?? $known[$norm($def['name'] ?? '')] ?? null;
            if ($existingUrl && empty($row?->listing_url)) {
                $attrs['listing_url'] = $existingUrl;
            }
            if ($row) {
                $row->fill($attrs)->save();
            } else {
                ($this->create)($attrs + ['slug' => $slug, 'status' => CitationRecord::STATUS_PLANNED, 'note' => $def['note'] ?? null]);
                $created++;
            }
        }

        return ['created' => $created];
    }

    /**
     * Two recovery sweeps, both idempotent and both no-ops when nothing
     * needs them:
     *
     * - A row still `STATUS_RUNNING` with no live session behind it is one
     *   whose browser closed or whose viewer expired without anyone
     *   polling — fold in whatever the runner left behind
     *   (`CitationSession::syncCitation()`), and if it is STILL running
     *   after that, put it back on the board rather than leave it stuck.
     * - A `STATUS_FAILED` row whose note says the browser slot was simply
     *   busy goes back on the board (nothing about the directory itself
     *   failed); a `STATUS_UNREACHABLE` row whose note carries a bot-wall
     *   HTTP status (401/403/429/503) becomes `STATUS_NEEDS_HUMAN` instead
     *   of silently staying "unreachable" forever.
     *
     * @return int  How many rows this call changed.
     */
    public function cleanupStale(): int
    {
        $changed = 0;
        $live = $this->sessions->status();
        foreach (($this->baseQuery)()->where('status', CitationRecord::STATUS_RUNNING)->get() as $stale) {
            if (($live['running'] ?? false) && ($live['slug'] ?? null) === $stale->slug) {
                continue;
            }
            $this->sessions->syncCitation($stale);
            if ($stale->fresh()->status === CitationRecord::STATUS_RUNNING) {
                $stale->status = CitationRecord::STATUS_PLANNED;
                $stale->addLog('Session ended without a result; back on the board', 'sync');
                $stale->save();
                $changed++;
            }
        }
        foreach (($this->baseQuery)()->whereIn('status', [CitationRecord::STATUS_FAILED, CitationRecord::STATUS_UNREACHABLE])->get() as $row) {
            $note = (string) $row->note;
            if ($row->status === CitationRecord::STATUS_FAILED && str_starts_with($note, 'Another citation session is running')) {
                $row->status = CitationRecord::STATUS_PLANNED;
                $row->note = null;
                $row->addLog('Back on the board: the browser slot was busy at the time', 'sync');
                $row->save();
                $changed++;
            } elseif ($row->status === CitationRecord::STATUS_UNREACHABLE && preg_match('/HTTP (401|403|429|503)\b/', $note)) {
                $row->status = CitationRecord::STATUS_NEEDS_HUMAN;
                $row->human_reason = 'The site blocked the automated browser ('.(preg_match('/HTTP \d+/', $note, $m) ? $m[0] : 'bot wall').'). Open the session and do this one by hand.';
                $row->note = null;
                $row->save();
                $changed++;
            }
        }

        return $changed;
    }
}
