<?php

namespace SsSystems\Platform\Citations;

use Illuminate\Support\Collection;
use SsSystems\Platform\Citations\Contracts\CitationSession;

/**
 * The null object hive binds where gsc/jpeterson bind their own
 * `App\Services\Citations\CitationBatchRunner` (which extends
 * `BatchRunner`): hive has no automatic batch pipeline at all — its
 * controller's `batch()` action always answered "not set up on this host"
 * directly from `CitationSessionService::checkRequirements()`, never
 * touching a batch runner (2026-09-27 audit, citations.md #3/#8).
 *
 * Extends `BatchRunner` (rather than needing its own contract) so
 * `Citations\CitationsAdminActions` can keep a single `BatchRunner`-typed
 * dependency for every site — the same instance-method polymorphism
 * `isActive()`/`progressState()` were moved onto for. `$baseQuery` is
 * never called (`eligible()` is overridden below to return nothing, and
 * `CitationsAdminActions::batch()` never reaches `eligible()` once
 * `isAvailable()` says `false` first); the `throw` is a deliberate
 * "this should be unreachable" guard, not a real code path.
 */
class UnavailableBatchRunner extends BatchRunner
{
    public function __construct(CitationSession $sessions)
    {
        parent::__construct($sessions, fn () => throw new \LogicException('UnavailableBatchRunner has no directories to query; isAvailable() is always false.'));
    }

    public function isAvailable(): bool
    {
        return false;
    }

    public function eligible(array $tiers = [], array $only = [], int $limit = 100): Collection
    {
        return collect();
    }

    public function isActive(): bool
    {
        return false;
    }

    /** The exact shape hive's own controller hardcoded — no `updated_at` key, since nothing has ever run. */
    public function progressState(): array
    {
        return ['active' => false, 'remaining' => [], 'done' => 0, 'current' => null];
    }
}
