<?php

namespace SsSystems\Platform\Citations;

use SsSystems\Platform\Citations\Contracts\CitationLinkStore;
use SsSystems\Platform\Citations\Contracts\LinkTarget;

/**
 * Every citation carrying a listing URL, checked for a link back to us —
 * moved from gsc's/jpeterson's `citations:control check` sub-action and
 * hive2025's standalone `citations:check-links` command, which share this
 * exact loop body (confirmed 4-for-4 identical apart from tenancy
 * scoping and the status-transition block — see $transitionsStatus).
 *
 * **Decision already taken (owner's call, 2026-09-27): hive2025's
 * `citations:check-links` stays link-check-only.** It has never carried
 * the STATUS_LIVE/NEEDS_HUMAN/FAILED transitions gsc/jpeterson's
 * `citations:control check` does — that gap is not a bug to close here.
 * hive2025's console command constructs this class with
 * `$transitionsStatus: false`; gsc's/jpeterson's pass `true` (the
 * default). Zero behavior change on any site — see
 * `LinkCheckRunnerTransitionsStatusTest` for the pin.
 */
class LinkCheckRunner
{
    public function __construct(
        private readonly CitationLinkStore $store,
        private readonly LinkTarget $target,
        private readonly bool $transitionsStatus = true,
    ) {}

    /** @return list<array{slug: string, name: string, result: array{status: int, links_to_us: ?int, nofollow: ?int, note: ?string}}> */
    public function run(): array
    {
        $domain = $this->target->domain();
        $names = $this->target->businessNames();
        $out = [];

        foreach ($this->store->withListingUrl() as $row) {
            $result = LinkCheck::run($row['listing_url'], $domain, $names);
            [$status, $humanReason, $note] = $this->transitionsStatus
                ? $this->nextState($row['status'], $result)
                : [null, null, null];
            $this->store->recordLinkCheck($row['slug'], $result, $status, $humanReason, $note);
            $out[] = ['slug' => $row['slug'], 'name' => $row['name'], 'result' => $result];
        }

        return $out;
    }

    /**
     * The exact status-transition rules gsc's/jpeterson's
     * `citations:control check` action has always applied: a link found
     * promotes an open listing to live; a profile that exists but shows
     * no link at all asks a human to add one; a listing that returns
     * 404/410 while marked live is flagged failed.
     *
     * @param array{status: int, links_to_us: ?int, nofollow: ?int, note: ?string} $result
     * @return array{0: ?string, 1: ?string, 2: ?string} [status, humanReason, note]
     */
    private function nextState(string $currentStatus, array $result): array
    {
        $status = null;
        $humanReason = null;
        $note = null;

        if ($result['links_to_us'] === 1 && ! in_array($currentStatus, ['declined', 'live'], true)) {
            $status = 'live';
        } elseif ($result['links_to_us'] === 0 && in_array($currentStatus, ['planned', 'live', 'submitted', 'pending_verification'], true)) {
            // The profile is there but carries no website link — the one thing worth a person's minute.
            $status = 'needs_human';
            $humanReason = 'The profile exists but has no link to the website. Open it and add '.$this->target->siteUrl().'.';
        }

        if (in_array($result['status'], [404, 410], true) && $currentStatus === 'live') {
            $status = 'failed';
            $note = 'The listing URL returns HTTP '.$result['status'].'.';
        }

        return [$status, $humanReason, $note];
    }
}
