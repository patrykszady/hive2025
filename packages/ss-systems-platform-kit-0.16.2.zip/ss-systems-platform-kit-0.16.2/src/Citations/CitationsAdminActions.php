<?php

namespace SsSystems\Platform\Citations;

use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\URL;
use SsSystems\Platform\Citations\Contracts\CitationRecord;
use SsSystems\Platform\Citations\Contracts\CitationSession;
use SsSystems\Platform\Citations\Contracts\VerificationInbox as VerificationInboxContract;

/**
 * Every action behind `/api/admin/v1/citations`: the board (`index()`),
 * the automatic batch (`batch()`), the remote session
 * (`start()`/`poll()`/`resume()`/`stop()`), and the manual edit
 * (`update()`) — moved from gsc's/jpeterson's/hive's
 * `Api/Admin/V1/CitationsController`, which the 2026-09-27 audit found
 * cosmetic-only between gsc and jpeterson and, on hive, "~150 lines of
 * 'always answer ok:false' glue that would disappear entirely if it
 * delegated to the SAME service class ... bound to `UnavailableSession`"
 * (citations.md #8). `payload()` (per-site `ListingPayload::make()`,
 * genuinely different content per business — citations.md #7) and
 * `screenshot()` (an HTTP file response, not JSON) stay on each site's own
 * thin controller; every other action's body is here, unchanged.
 *
 * A plain service, never a controller — routing/middleware stays per-site
 * like every other ported family. Six constructor seams, none of them
 * `App\Models\*` or `config()` reads beyond `citations.directories` (the
 * one key already read directly by `BatchRunner`/`Sync`/
 * `RemoteBrowserSession`):
 *
 * - **`$sessions`/`$batch`/`$inbox`** — the same `Contracts\CitationSession`
 *   every site already binds, a `BatchRunner` (gsc's/jpeterson's own
 *   subclass, or hive's `UnavailableBatchRunner`), and a
 *   `Contracts\VerificationInbox` (the real `VerificationInbox`, or
 *   hive's `UnavailableVerificationInbox`). `isActive()`/`progressState()`/
 *   `isAvailable()` being INSTANCE methods on `BatchRunner` (the
 *   citations-batch-sync port, plus `isAvailable()` added alongside this
 *   class) is what makes gsc/jpeterson and hive's null object
 *   interchangeable here.
 * - **`$knownListings`** — a `KnownListingsReconciler`, this site's own
 *   `KnownListingsSource` behind it.
 * - **`$citationQuery`** — the same `\Closure(): Builder` scoping contract
 *   as `BatchRunner`'s/`Sync`'s: gsc binds `Citation::query()->
 *   where('site_id', Site::current()?->id)`, jpeterson/hive bind bare
 *   `Citation::query()`. Every row lookup in this class goes through it —
 *   `index()`, `find()`, `poll()`'s and `stop()`'s slug lookups, nothing
 *   queries `Citation` on its own.
 * - **`$viewerRouteParams`** — `\Closure(): array`, the FULL param array
 *   for `URL::temporarySignedRoute('admin.platforms.viewer', ...)`: gsc's
 *   closure returns `['site' => Site::current()->primary_host, 'provider'
 *   => 'citations']`, jpeterson's/hive's return `['provider' =>
 *   'citations']` (jpeterson's own route has no `{site}` segment — see
 *   `routes/platforms-viewer.php`). Never called on hive in practice
 *   (`UnavailableSession::start()` never returns a `url`, so `viewer()`
 *   returns early), but every site supplies one so the constructor shape
 *   stays identical.
 * - **`$dispatchBatch`** — `\Closure(list<string>): void`, the one thing
 *   this class cannot do itself: queue that site's OWN `Job` class (see
 *   `Citations\Sync`'s docblock and citations.md #13 for why the Job stays
 *   per-site — gsc's wraps its self-redispatch in `Tenancy::for()`).
 *   gsc's/jpeterson's bind `fn (array $slugs) => RunCitationsBatch::
 *   dispatch($slugs)`; hive's is never called (`batch()` always refuses
 *   before reaching it, `BatchRunner::isAvailable()` being `false`) but is
 *   still supplied, for the same reason as `$viewerRouteParams` above.
 *
 * **`batch()`'s `isAvailable()` gate is the one new thing this port adds,
 * not a byte-identical move**: gsc's/jpeterson's own `batch()` never
 * checked `CitationSession::checkRequirements()` at all before this port
 * (a real host missing a requirement would only fail row-by-row, deep
 * inside `BatchRunner::runOne()`). Checking `isAvailable()` FIRST costs
 * gsc/jpeterson nothing (`BatchRunner::isAvailable()` is hardcoded `true`,
 * so the check never even calls `CitationSession`) and is what lets
 * hive's `UnavailableBatchRunner` (`isAvailable(): false`) produce its
 * honest refusal through the exact same code path, rather than a
 * hive-specific `batch()` override. See `CitationsControllerAdminActions
 * Test` and each site's own controller test.
 *
 * **`resume()`/`stop()`/`poll()` unify cleanly on the `Contracts\
 * CitationSession` return values already in place**, with no new gate
 * needed: `resume()` branches on `CitationSession::resume()`'s own `bool`
 * (gsc's/jpeterson's real session's `@touch()` all but always succeeds;
 * hive's `UnavailableSession::resume()` always returns `false` — the
 * SAME "browser automation is not set up... continue this one by hand"
 * message hive's controller hardcoded falls out of that branch
 * naturally). `poll()`/`stop()` need no branch at all: hive's
 * `UnavailableSession::status()` always answers `slug: null`, so the
 * shared logic's "no active citation" path IS hive's old hardcoded
 * `emptySession()`/`'citation' => null` answer, by construction. The one
 * behavior this drops is hive's old `start()` logging a `'blocked'` entry
 * on every refused start (`Citation::addLog()`) — no test asserted it,
 * and the audit named this exact glue as what should disappear once hive
 * delegates to the same service gsc/jpeterson use; gsc's/jpeterson's own
 * `start()` never logged a failed attempt either, so this unifies onto
 * their existing shape rather than inventing a third one.
 */
class CitationsAdminActions
{
    protected const VIEWER_SIGNATURE_TTL_MINUTES = 30;

    protected const VIEWER_ROUTE = 'admin.platforms.viewer';

    protected const REMOTE_LOGIN_CACHE_KEY = 'platforms.remote_login_url.citations';

    /**
     * @param  \Closure(): \Illuminate\Database\Eloquent\Builder  $citationQuery  Every
     *   row lookup below starts here — see this class's own docblock.
     * @param  \Closure(): array<string,string>  $viewerRouteParams  The full
     *   signed-route param array for this site's noVNC viewer redirect.
     * @param  \Closure(list<string>): void  $dispatchBatch  Queues this
     *   site's own batch Job with the eligible slugs.
     */
    public function __construct(
        protected CitationSession $sessions,
        protected BatchRunner $batch,
        protected VerificationInboxContract $inbox,
        protected KnownListingsReconciler $knownListings,
        protected \Closure $citationQuery,
        protected \Closure $viewerRouteParams,
        protected \Closure $dispatchBatch,
    ) {}

    /** @return array<string,mixed> the citations board */
    public function index(): array
    {
        $this->ensureSynced();
        $this->knownListings->reconcile();
        $status = $this->sessions->status();
        $rows = ($this->citationQuery)()->orderBy('tier')->orderBy('name')->get();
        if ($status['slug'] ?? null) {
            $active = $rows->firstWhere('slug', $status['slug']);
            if ($active) {
                $this->sessions->syncCitation($active);
            }
        }

        return [
            'citations' => $rows->map(fn (CitationRecord $c) => $this->row($c))->values()->all(),
            'counts' => $rows->countBy('status')->all(),
            'session' => $this->sessionPayload($status),
            'inbox_configured' => $this->inbox->isConfigured(),
            'batch' => $this->batch->progressState(),
            'requirements' => $this->sessions->checkRequirements(),
        ];
    }

    /**
     * Queue the automatic run over every open directory (optionally some
     * tiers/slugs only) — or, on a host with no batch runner at all, the
     * one honest refusal saying so. See this class's own docblock for why
     * `isAvailable()` is checked first.
     *
     * @param  list<int>  $tiers
     * @param  list<string>  $only
     */
    public function batch(array $tiers, array $only): array
    {
        $this->ensureSynced();
        if (! $this->batch->isAvailable()) {
            $req = $this->sessions->checkRequirements(true);

            return ['ok' => false, 'error' => 'Browser automation is not set up on this host (missing: '.implode(', ', $req['missing']).'). Build listings by hand from the payload above.'];
        }
        if ($this->batch->isActive()) {
            return ['ok' => false, 'error' => 'An automatic run is already going. Let it finish; the board shows its progress.'];
        }
        if ($this->sessions->status()['running'] ?? false) {
            return ['ok' => false, 'error' => 'A browser session is running. Stop it first.'];
        }
        $slugs = $this->batch->eligible($tiers, $only)->pluck('slug')->all();
        if ($slugs === []) {
            return ['ok' => false, 'error' => 'Nothing to run: every directory is live, declined, parked for you, or waiting for verification.'];
        }
        BatchRunner::progress($slugs, 0);
        ($this->dispatchBatch)($slugs);

        return ['ok' => true, 'queued' => count($slugs), 'slugs' => $slugs];
    }

    public function start(string $slug, bool $headless): array
    {
        $citation = $this->find($slug);
        $result = $this->sessions->start($citation, $headless);
        if (! ($result['ok'] ?? false)) {
            return ['ok' => false, 'error' => $result['error'] ?? 'Could not start the session.'];
        }
        $citation->status = CitationRecord::STATUS_RUNNING;
        $citation->human_reason = null;
        $citation->last_run_at = now();
        $citation->addLog('Session started from the admin', 'start');
        $citation->save();

        return ['ok' => true, 'citation' => $this->row($citation)] + $this->viewer($result);
    }

    public function poll(): array
    {
        $status = $this->sessions->status();
        $citation = ($status['slug'] ?? null) ? $this->citationBySlug($status['slug']) : null;
        if ($citation) {
            $this->sessions->syncCitation($citation);
        }

        return [
            'session' => $this->sessionPayload($status),
            'citation' => $citation ? $this->row($citation) : null,
            'log_tail' => $this->sessions->tailLog(3000),
        ];
    }

    /** See this class's own docblock for why this branches on `resume()`'s own bool rather than always succeeding. */
    public function resume(string $slug): array
    {
        $citation = $this->find($slug);
        if (! $this->sessions->resume($citation)) {
            return ['ok' => false, 'error' => 'Browser automation is not set up on this host. Continue this one by hand.', 'citation' => $this->row($citation)];
        }
        $citation->addLog('Continued by the admin', 'resume');
        $citation->status = CitationRecord::STATUS_RUNNING;
        $citation->human_reason = null;
        $citation->save();

        return ['ok' => true, 'citation' => $this->row($citation)];
    }

    public function stop(): array
    {
        $status = $this->sessions->status();
        $this->sessions->stop();
        $citation = ($status['slug'] ?? null) ? $this->citationBySlug($status['slug']) : null;
        if ($citation) {
            $this->sessions->syncCitation($citation);
            if ($citation->status === CitationRecord::STATUS_RUNNING) {
                $citation->status = CitationRecord::STATUS_PLANNED;
                $citation->addLog('Session stopped by the admin', 'stop');
                $citation->save();
            }
        }
        Cache::forget(self::REMOTE_LOGIN_CACHE_KEY);

        return ['ok' => true, 'citation' => $citation ? $this->row($citation) : null];
    }

    /**
     * The manual edit form — a site's controller validates the request
     * (its own `Citation::STATUSES` list) and passes the already-validated
     * array through unchanged.
     *
     * @param  array{status?: ?string, listing_url?: ?string, note?: ?string, account_email?: ?string}  $data
     */
    public function update(string $slug, array $data): array
    {
        $citation = $this->find($slug);
        foreach (['listing_url', 'note', 'account_email'] as $f) {
            if (array_key_exists($f, $data)) {
                $citation->{$f} = $data[$f];
            }
        }
        if (! empty($data['status'])) {
            $citation->status = $data['status'];
            if ($data['status'] === CitationRecord::STATUS_LIVE) {
                $citation->live_at = $citation->live_at ?: now();
                $citation->human_reason = null;
            }
            $citation->addLog('Status set to '.$data['status'].' by the admin', 'manual');
        }
        $citation->save();

        return ['ok' => true, 'citation' => $this->row($citation)];
    }

    /** Public: a site's controller also calls this for its screenshot route. */
    public function find(string $slug): CitationRecord
    {
        $this->ensureSynced();

        return ($this->citationQuery)()->where('slug', $slug)->firstOrFail();
    }

    /** Where a session's own files for this citation live — a site's screenshot route joins '/shots/{file}' onto this. */
    public function sessionDir(CitationRecord $citation): string
    {
        return $this->sessions->dirFor($citation);
    }

    protected function citationBySlug(string $slug): ?CitationRecord
    {
        return ($this->citationQuery)()->where('slug', $slug)->first();
    }

    protected function row(CitationRecord $c): array
    {
        $def = $c->definition();

        return [
            'slug' => $c->slug, 'name' => $c->name, 'tier' => $c->tier, 'mechanism' => $c->mechanism,
            'homepage' => $c->homepage, 'start_url' => $c->start_url, 'listing_url' => $c->listing_url, 'status' => $c->status,
            'account_email' => $c->account_email, 'has_password' => $c->account_password !== null,
            'photos_uploaded' => $c->photos_uploaded, 'links_to_us' => $c->links_to_us, 'nofollow' => $c->nofollow,
            'human_reason' => $c->human_reason, 'note' => $c->note, 'definition_note' => $def['note'] ?? null,
            'needs' => $def['needs'] ?? [], 'photos' => (bool) ($def['photos'] ?? false),
            'log' => array_slice((array) ($c->log ?? []), -12), 'screenshots' => (array) ($c->screenshots ?? []),
            'verification' => (array) ($c->verification ?? []),
            'last_run_at' => $c->last_run_at?->toIso8601String(), 'submitted_at' => $c->submitted_at?->toIso8601String(),
            'live_at' => $c->live_at?->toIso8601String(), 'last_checked_at' => $c->last_checked_at?->toIso8601String(),
        ];
    }

    protected function sessionPayload(array $status): array
    {
        $out = ['running' => (bool) ($status['running'] ?? false), 'slug' => $status['slug'] ?? null, 'expires_at' => $status['expires_at'] ?? null, 'runner' => $status['runner'] ?? null, 'viewer_url' => null];
        if (! empty($status['viewer'])) {
            $out = $out + $this->viewer(['url' => $status['viewer'], 'expires_at' => $status['expires_at'] ?? null]);
        }

        return $out;
    }

    /** Cache the raw noVNC URL and hand back a signed redirect, exactly like the platforms viewer. */
    protected function viewer(array $result): array
    {
        if (empty($result['url'])) {
            return ['viewer_url' => null];
        }
        $expiresAt = $result['expires_at'] ?? null;
        Cache::put(self::REMOTE_LOGIN_CACHE_KEY, $result['url'], now()->addSeconds($expiresAt ? max(60, (int) $expiresAt - time()) : 1800));

        return [
            'viewer_url' => URL::temporarySignedRoute(self::VIEWER_ROUTE, now()->addMinutes(self::VIEWER_SIGNATURE_TTL_MINUTES), ($this->viewerRouteParams)()),
            'expires_at' => $expiresAt,
        ];
    }

    protected function ensureSynced(): void
    {
        $expected = count((array) config('citations.directories', []));
        if (($this->citationQuery)()->count() < $expected) {
            Artisan::call('citations:sync');
        }
    }
}
