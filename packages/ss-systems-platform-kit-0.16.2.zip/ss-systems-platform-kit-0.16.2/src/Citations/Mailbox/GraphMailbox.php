<?php

namespace SsSystems\Platform\Citations\Mailbox;

use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use SsSystems\Platform\Citations\Contracts\Mailbox;

/**
 * Microsoft 365 mailbox, read through Microsoft Graph with an Entra app
 * registration (application permission Mail.Read, admin-consented,
 * client-credentials flow) — moved verbatim from gsc's/jpeterson's
 * `App\Services\Citations\VerificationInbox::graphToken()`/
 * `graphMessages()`, with the four values that were `config('citations.
 * inbox.*')` reads inside that class now explicit constructor arguments
 * (the site's own factory reads them once — see `Contracts\Mailbox`'s
 * docblock).
 */
class GraphMailbox implements Mailbox
{
    public function __construct(
        private readonly string $mailbox,
        private readonly string $tenantId,
        private readonly string $clientId,
        private readonly string $clientSecret,
    ) {}

    public function mode(): ?string
    {
        return 'graph';
    }

    /** @return list<array{id: string, from_domain: string, subject: string, body: string}> */
    public function messagesSince(\DateTimeInterface $since): array
    {
        $url = sprintf('https://graph.microsoft.com/v1.0/users/%s/mailFolders/Inbox/messages', rawurlencode($this->mailbox));
        $resp = Http::withToken($this->token())->timeout(30)->get($url, [
            '$filter' => 'receivedDateTime ge '.$since->format('Y-m-d\TH:i:s\Z'),
            '$orderby' => 'receivedDateTime desc',
            '$top' => 50,
            '$select' => 'id,subject,from,receivedDateTime,body',
        ]);
        if (! $resp->successful()) {
            $err = $resp->json('error.message') ?? ('HTTP '.$resp->status());
            throw new \RuntimeException("Microsoft Graph could not read {$this->mailbox}: {$err}".($resp->status() === 403 ? ' (grant Mail.Read as an application permission and admin-consent it)' : ''));
        }
        $out = [];
        foreach ((array) $resp->json('value', []) as $m) {
            $address = strtolower((string) ($m['from']['emailAddress']['address'] ?? ''));
            $out[] = [
                'id' => (string) ($m['id'] ?? ''),
                'from_domain' => str_contains($address, '@') ? substr($address, strpos($address, '@') + 1) : '',
                'subject' => (string) ($m['subject'] ?? ''),
                'body' => (string) ($m['body']['content'] ?? ''),
            ];
        }

        return $out;
    }

    /** Client-credentials token for Graph, cached for its lifetime. */
    private function token(): string
    {
        $key = 'citations.graph_token.'.substr(sha1($this->clientId), 0, 8);
        $cached = Cache::get($key);
        if (is_string($cached) && $cached !== '') {
            return $cached;
        }
        $resp = Http::asForm()->timeout(20)->post(sprintf('https://login.microsoftonline.com/%s/oauth2/v2.0/token', rawurlencode($this->tenantId)), [
            'client_id' => $this->clientId,
            'client_secret' => $this->clientSecret,
            'scope' => 'https://graph.microsoft.com/.default',
            'grant_type' => 'client_credentials',
        ]);
        if (! $resp->successful() || ! is_string($resp->json('access_token'))) {
            throw new \RuntimeException('Microsoft 365 sign-in failed: '.($resp->json('error_description') ?? ('HTTP '.$resp->status())));
        }
        $token = (string) $resp->json('access_token');
        Cache::put($key, $token, Carbon::now()->addSeconds(max(60, (int) $resp->json('expires_in', 3600) - 120)));

        return $token;
    }
}
