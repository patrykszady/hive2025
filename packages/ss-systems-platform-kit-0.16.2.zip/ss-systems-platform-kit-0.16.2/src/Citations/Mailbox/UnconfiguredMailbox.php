<?php

namespace SsSystems\Platform\Citations\Mailbox;

use SsSystems\Platform\Citations\Contracts\Mailbox;

/**
 * The null object a site binds when neither Microsoft Graph nor IMAP is
 * set up — `VerificationInbox::run()` reads `mode() === null` as "nothing
 * usable is configured" and returns the same explanatory error it always
 * has, without ever calling messagesSince().
 */
class UnconfiguredMailbox implements Mailbox
{
    public function mode(): ?string
    {
        return null;
    }

    public function messagesSince(\DateTimeInterface $since): array
    {
        return [];
    }
}
