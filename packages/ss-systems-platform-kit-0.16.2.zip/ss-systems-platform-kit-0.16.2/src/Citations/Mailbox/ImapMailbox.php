<?php

namespace SsSystems\Platform\Citations\Mailbox;

use SsSystems\Platform\Citations\Contracts\Mailbox;

/**
 * Plain IMAP fallback for a mailbox hosted somewhere other than Microsoft
 * 365 — moved verbatim from gsc's/jpeterson's `App\Services\Citations\
 * VerificationInbox::imapMessages()`/`imapBody()`, with the five
 * `config('citations.inbox.*')` reads now explicit constructor arguments
 * (see `Contracts\Mailbox`'s docblock). Requires ext-imap; the site's own
 * factory only binds this class when `function_exists('imap_open')`.
 */
class ImapMailbox implements Mailbox
{
    public function __construct(
        private readonly string $host,
        private readonly int $port,
        private readonly string $folder,
        private readonly string $user,
        private readonly string $password,
    ) {}

    public function mode(): ?string
    {
        return 'imap';
    }

    /** @return list<array{id: string, from_domain: string, subject: string, body: string}> */
    public function messagesSince(\DateTimeInterface $since): array
    {
        $mailbox = sprintf('{%s:%d/imap/ssl}%s', $this->host, $this->port, $this->folder);
        $imap = @imap_open($mailbox, $this->user, $this->password, 0, 1);
        if (! $imap) {
            throw new \RuntimeException('IMAP login failed: '.(string) imap_last_error());
        }
        try {
            $ids = imap_search($imap, 'SINCE "'.$since->format('d-M-Y').'"') ?: [];
            $out = [];
            foreach (array_reverse($ids) as $id) {
                $header = imap_headerinfo($imap, $id);
                $out[] = [
                    'id' => 'imap:'.(string) ($header->message_id ?? $id),
                    'from_domain' => strtolower((string) ($header->from[0]->host ?? '')),
                    'subject' => (string) ($header->subject ?? ''),
                    'body' => $this->body($imap, $id),
                ];
            }

            return $out;
        } finally {
            imap_close($imap);
        }
    }

    private function body($imap, int $id): string
    {
        $structure = imap_fetchstructure($imap, $id);
        $text = '';
        if (isset($structure->parts) && is_array($structure->parts)) {
            foreach ($structure->parts as $i => $part) {
                if ((int) $part->type === 0) { // text
                    $chunk = (string) imap_fetchbody($imap, $id, (string) ($i + 1));
                    $text .= ((int) $part->encoding === 3 ? base64_decode($chunk) : ((int) $part->encoding === 4 ? quoted_printable_decode($chunk) : $chunk))."\n";
                }
            }
        }
        if ($text === '') {
            $chunk = (string) imap_body($imap, $id);
            $text = (int) ($structure->encoding ?? 0) === 3 ? base64_decode($chunk) : quoted_printable_decode($chunk);
        }

        return $text;
    }
}
