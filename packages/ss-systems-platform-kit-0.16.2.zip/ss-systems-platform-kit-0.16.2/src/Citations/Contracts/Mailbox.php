<?php

namespace SsSystems\Platform\Citations\Contracts;

/**
 * The business mailbox `VerificationInbox` reads the directories'
 * "confirm your email" messages from. Fed by explicit constructor
 * arguments on every implementation (`Mailbox\GraphMailbox`,
 * `Mailbox\ImapMailbox`) — never a `config()` read inside the kit;
 * credentials themselves stay on the site, read once by its own factory
 * (an `AppServiceProvider` binding closure, matching every other
 * credential boundary the kit keeps — e.g. `Seo\Credentials\
 * CredentialEnvImport`). `Mailbox\UnconfiguredMailbox` is the null
 * object a site binds when neither Microsoft Graph nor IMAP is set up
 * (or, for a site with no inbox feature at all, simply not bound —
 * hive2025 has none).
 */
interface Mailbox
{
    /** 'graph', 'imap', or null when this instance represents "nothing configured". */
    public function mode(): ?string;

    /**
     * Messages received since $since, newest first.
     *
     * @return list<array{id: string, from_domain: string, subject: string, body: string}>
     */
    public function messagesSince(\DateTimeInterface $since): array;
}
