<?php

namespace SsSystems\Platform\Citations\Contracts;

/**
 * The one thing `Citations\CitationsAdminActions` needs from a
 * verification inbox, polymorphically: whether one is set up at all — the
 * Citations admin screen's `inbox_configured` flag. `Citations\
 * VerificationInbox` (gsc, jpeterson — a real Graph/IMAP mailbox behind
 * it) implements this directly; hive (no verification inbox: see
 * `UnavailableVerificationInbox`) binds the null object instead, so the
 * shared service never has to special-case a site that has none.
 */
interface VerificationInbox
{
    public function isConfigured(): bool;
}
