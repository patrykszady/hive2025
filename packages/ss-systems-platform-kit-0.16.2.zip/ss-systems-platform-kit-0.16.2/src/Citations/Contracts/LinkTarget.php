<?php

namespace SsSystems\Platform\Citations\Contracts;

/**
 * What "us" means to the link-check sweep (`LinkCheckRunner`): the bare
 * domain `LinkCheck::run()` looks for a link to, the names it accepts as
 * "this page shows our business", and the exact URL text shown to a human
 * when a profile has no link to add.
 *
 * Each site reproduces its OWN existing fallback chain here — these are
 * NOT the same chain, by design, not a bug to unify:
 *   - gsc/jpeterson: `config('brand.display_name')` + `config('brand.name')`
 *     for names; `config('app.url')` (scheme stripped) for the domain, with
 *     a per-site literal fallback ('gs.construction' / 'jpeterson-design.com')
 *     when `app.url` is empty.
 *   - hive2025: `config('app.marketing_url', config('app.url'))` for the
 *     domain (its own admin host and its public marketing site are two
 *     different hosts) + `config('app.name')` and the literal 'Hive' for
 *     names.
 *
 * A kit class never reads `config()` itself (see RemoteBrowserSession's
 * node_packages docblock for the same posture) — the site's small adapter
 * class is where that chain lives, unchanged from today's console command.
 */
interface LinkTarget
{
    /** Bare domain (no scheme, no "www."), what LinkCheck::run() matches an anchor href against. */
    public function domain(): string;

    /**
     * The exact string shown to a human asked to add our link ("add
     * https://gs.construction.") — kept distinct from domain() because the
     * existing text is the full base URL, not the bare domain.
     */
    public function siteUrl(): string;

    /** @return list<string> names that count as "this page shows our business". */
    public function businessNames(): array;
}
