<?php

namespace SsSystems\Platform\Citations\Contracts;

/**
 * One remote-browser session for the citation builder, or the honest
 * absence of one. Every site binds this to whichever implementation fits
 * its host: `RemoteBrowserSession` (gsc, jpeterson — the real Xvfb/
 * Chromium/x11vnc/noVNC pipeline) or `UnavailableSession` (hive; dawn
 * until its pipeline is real) — a null object with the exact same eight
 * methods, so `Citations\CitationsController` (and everything else that
 * asks for `CitationSession`) never has to special-case a site that has
 * no browser automation.
 *
 * Retyped from the site's own `App\Models\Citation` to `CitationRecord`
 * (citations-batch-sync, the 0.11.0 follow-up `BatchRunner`/`Sync` forced):
 * kit 0.11.0 shipped this typed directly on `App\Models\Citation`, safe
 * only because this package runs INSIDE each site's app — but it broke
 * the "the kit never references App\Models\*" rule the moment BatchRunner
 * needed the identical object shape from a class that is never bound
 * per-site the way `CitationSession` is. Every site's `Citation` model
 * now `implements CitationRecord` (a one-line change; see that
 * interface's own docblock for exactly what it requires and why
 * properties are read/written untyped, same as before this retype).
 */
interface CitationSession
{
    /** @return array{ok: bool, missing: list<string>} */
    public function checkRequirements(bool $headless = false): array;

    public function dirFor(CitationRecord $citation): string;

    /** Start a session for one directory. Returns ['ok', 'url' (noVNC), 'expires_at', 'slug']. */
    public function start(CitationRecord $citation, bool $headless = false, bool $auto = false): array;

    /** Session status plus the runner's own state for the active directory. */
    public function status(): array;

    /** Let the runner continue after a human step. */
    public function resume(CitationRecord $citation): bool;

    public function stop(): array;

    /** Fold the runner's state into the citation row. */
    public function syncCitation(CitationRecord $citation): CitationRecord;

    public function tailLog(int $bytes = 4000): string;
}
