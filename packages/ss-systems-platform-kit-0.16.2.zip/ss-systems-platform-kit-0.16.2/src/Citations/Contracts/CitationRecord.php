<?php

namespace SsSystems\Platform\Citations\Contracts;

/**
 * The shape `Citations\BatchRunner`, `Citations\Sync` and (as of this same
 * port) `Citations\Contracts\CitationSession`'s two implementations need
 * from a site's `App\Models\Citation` — WITHOUT the kit ever naming that
 * class. Kit 0.11.0 shipped `CitationSession`/`RemoteBrowserSession`/
 * `UnavailableSession` type-hinted directly on `App\Models\Citation`
 * (defensible at the time — this package only ever runs inside a site's
 * own app, so that FQCN always resolves — but it broke the estate-wide
 * "the kit never references App\Models\*" rule the moment BatchRunner/Sync
 * needed the SAME object shape). This interface is that retype: every
 * site's `Citation` model now `implements` it (a one-line change — gsc's,
 * jpeterson's and hive's models already declare every method below
 * verbatim), and every kit Citations class was moved off `App\Models\
 * Citation` onto this interface instead. Nothing here changes behavior;
 * see BatchRunner's/Sync's own docblocks for what DOES need a real
 * adapter (site scoping, tier defaults, known-listing sources).
 *
 * Properties are intentionally NOT declared as interface methods (PHP
 * interfaces cannot require a property, and Eloquent's magic `__get`/
 * `__set` make a getter/setter pair here pure ceremony with no runtime
 * benefit) — the kit classes read/write them exactly as a site's own
 * Citation model already exposes them, which is safe because the object
 * behind this interface is always the SAME real Eloquent model, never a
 * kit-owned stand-in. The @property block below documents that shape for
 * whoever adapts a fifth site, the same way `Contracts\CoverageStore`
 * documents its array shapes instead of enforcing them by inheritance.
 *
 * @property string $slug
 * @property string $name
 * @property int $tier
 * @property string $status
 * @property ?string $listing_url
 * @property ?string $account_email
 * @property ?string $account_password
 * @property int $photos_uploaded
 * @property ?bool $links_to_us
 * @property ?bool $nofollow
 * @property ?string $human_reason
 * @property ?string $note
 * @property array $log
 * @property array $screenshots
 * @property ?array $verification
 * @property \Illuminate\Support\Carbon|string|null $last_run_at
 * @property \Illuminate\Support\Carbon|string|null $submitted_at
 * @property \Illuminate\Support\Carbon|string|null $live_at
 */
interface CitationRecord
{
    public const STATUS_PLANNED = 'planned';

    public const STATUS_RUNNING = 'running';

    public const STATUS_NEEDS_HUMAN = 'needs_human';

    public const STATUS_SUBMITTED = 'submitted';

    public const STATUS_PENDING_VERIFICATION = 'pending_verification';

    public const STATUS_LIVE = 'live';

    public const STATUS_FAILED = 'failed';

    public const STATUS_DECLINED = 'declined';

    public const STATUS_NO_MECHANISM = 'no_mechanism';

    public const STATUS_UNREACHABLE = 'unreachable';

    /**
     * The registry entry behind this row (each site's own
     * config('citations.directories.{slug}')). Identical on every site
     * today; not folded into a kit trait by this port — see the audit's
     * `Citations\Concerns\HasCitationLifecycle` proposal for that,
     * separate and not part of this unit.
     *
     * @return array<string, mixed>
     */
    public function definition(): array;

    /** Append a log line (every site keeps its own 200-line cap). */
    public function addLog(string $message, ?string $step = null): void;

    /**
     * No return type declared on purpose: `Illuminate\Database\Eloquent\
     * Model::save()` itself declares none (its signature also takes an
     * `array $options = []` this interface doesn't need to name — an
     * implementation may always add optional parameters). A `: bool`
     * return type here would make every real Citation model a FATAL
     * "declaration must be compatible" error the moment it added
     * `implements CitationRecord`, since PHP requires an override's
     * return type to be covariant with an ALREADY-typed parent method,
     * and Eloquent's own is untyped.
     */
    public function save();
}
