<?php

namespace SsSystems\Platform\Citations\Contracts;

/**
 * Listings a site already has, read from whatever THAT site considers
 * evidence — gsc's/jpeterson's Houzz/Angi review imports, Yelp-for-Business
 * connection and Meta page credentials; hive's own Social Media `linkedin`
 * link; a fifth site's own roster. Genuinely per-site content (2026-09-27
 * audit, citations.md #5: "divergent by design, but cleanly split
 * already") — the kit never guesses what counts as "already listed", only
 * `Citations\KnownListingsReconciler` owns the one loop every site ran
 * verbatim over whatever this returns.
 */
interface KnownListingsSource
{
    /**
     * @return array<string, array{url: string, source: string}> keyed by
     *   citation slug, `source` a short human sentence for the log/note
     *   ("Platforms: 12 reviews imported from this profile").
     */
    public function forCurrentSite(): array;
}
