<?php

namespace SsSystems\Platform\Citations\Contracts;

/**
 * The citations awaiting an email-verification link, and the two ways a
 * pass over the inbox can resolve one — never `App\Models\Citation` or a
 * static Eloquent call inside the kit.
 *
 * **This is the adapter boundary that fixes gsc's live bug**: gsc's own
 * `App\Services\Citations\VerificationInbox::run()` queried
 * `Citation::query()->where('status', Citation::STATUS_PENDING_VERIFICATION)`
 * with NO `site_id` filter — the only query in that whole class missing
 * one — so one tenant's inbox sweep could match and "verify" another
 * tenant's pending citation. gsc's `pending()` implementation now adds
 * `where('site_id', Site::current()?->id)`, the same scope every other
 * citations query on that site already carries; a two-`Site` test
 * (`VerificationInboxIsolationTest`) proves a message that matches one
 * tenant's homepage domain never touches the other tenant's row.
 */
interface PendingCitationRepository
{
    /**
     * Citations in STATUS_PENDING_VERIFICATION, each carrying whatever
     * inbox messages have already been matched against it in a previous
     * pass (so this run never re-follows the same message twice).
     *
     * @return list<array{slug: string, homepage: ?string, messages_seen: list<string>}>
     */
    public function pending(): array;

    /**
     * A message from this citation's own domain carried no verification
     * link: remember the message id (so it is never re-inspected) and log
     * it. No status change.
     *
     * @param list<string> $messagesSeen the citation's messages_seen list, with this message id appended and capped
     */
    public function recordNoLink(string $slug, array $messagesSeen, string $logMessage): void;

    /**
     * A verification link was followed successfully: remember the message
     * id, mark the email leg done, and advance the citation to
     * STATUS_SUBMITTED.
     *
     * @param list<string> $messagesSeen the citation's messages_seen list, with this message id appended and capped
     */
    public function recordVerified(string $slug, array $messagesSeen, string $logMessage): void;
}
