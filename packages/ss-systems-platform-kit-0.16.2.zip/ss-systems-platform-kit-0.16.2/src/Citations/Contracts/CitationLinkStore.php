<?php

namespace SsSystems\Platform\Citations\Contracts;

/**
 * The citations `LinkCheckRunner` reads and writes through — never
 * `App\Models\Citation` or any static Eloquent call directly, so the kit
 * carries no model and no tenancy knowledge of its own.
 *
 * gsc's implementation scopes both methods to `Site::current()` (the
 * SAME `where('site_id', ...)` gsc's own `citations:control check` action
 * already applied before this port — see LinkCheckRunner's docblock);
 * jpeterson's and hive2025's are unscoped (single tenant, no `site_id`
 * column at all).
 */
interface CitationLinkStore
{
    /**
     * Every citation that carries a listing URL, ready to be checked.
     *
     * @return list<array{slug: string, name: string, status: string, listing_url: string}>
     */
    public function withListingUrl(): array;

    /**
     * Persist one link-check result against its citation row: the raw
     * `LinkCheck::run()` result always; the status transition (with its
     * human_reason/note) only when the runner computed one (gsc/jpeterson's
     * `citations:control check` does; hive2025's link-check-only
     * `citations:check-links` never does — see LinkCheckRunner's
     * `$transitionsStatus` flag).
     *
     * @param array{status: int, links_to_us: ?int, nofollow: ?int, note: ?string} $result
     */
    public function recordLinkCheck(string $slug, array $result, ?string $status, ?string $humanReason, ?string $note): void;
}
