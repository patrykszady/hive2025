<?php

namespace SsSystems\Platform\Citations;

use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use SsSystems\Platform\Citations\Contracts\Mailbox;
use SsSystems\Platform\Citations\Contracts\PendingCitationRepository;

/**
 * Reads the business mailbox for the "confirm your email" messages the
 * directories send after a signup and follows their verification links,
 * so that step needs no human — moved from gsc's/jpeterson's
 * `App\Services\Citations\VerificationInbox` (100%-cosmetic diff between
 * the two apart from doc wording, per the 2026-09-27 audit).
 *
 * Two new contracts replace what that class read/touched directly:
 * `Contracts\Mailbox` (the transport — Graph or IMAP, fed credentials by
 * explicit constructor args, never a `config()` read inside the kit) and
 * `Contracts\PendingCitationRepository` (the site's own `Citation` query
 * and writes — never `App\Models\Citation` or a static Eloquent call
 * here). **`Contracts\PendingCitationRepository::pending()` is also
 * where gsc's real, currently-live bug gets fixed**: the site's OWN
 * `VerificationInbox::run()` today queries every tenant's pending
 * citations in one unscoped sweep (unlike every other query in that
 * class); gsc's repository adapter now adds the `site_id` scope every
 * other citations query already carries. See
 * `Contracts\PendingCitationRepository`'s docblock and gsc's
 * `VerificationInboxIsolationTest`.
 *
 * hive2025 has no verification inbox (`inbox_configured` is hardcoded
 * `false` on its admin screen) — this class is bound only on gsc and
 * jpeterson.
 *
 * `implements Contracts\VerificationInbox` (citations-admin-actions,
 * 2026-09-27): `Citations\CitationsAdminActions` needs `isConfigured()`
 * polymorphically across this real class and hive's
 * `UnavailableVerificationInbox` — a one-line addition, nothing below it
 * changed.
 */
class VerificationInbox implements Contracts\VerificationInbox
{
    public function __construct(
        private readonly Mailbox $mailbox,
        private readonly PendingCitationRepository $citations,
        private readonly int $lookbackDays = 7,
    ) {}

    /** 'graph', 'imap' or null when nothing usable is configured. */
    public function mode(): ?string
    {
        return $this->mailbox->mode();
    }

    public function isConfigured(): bool
    {
        return $this->mode() !== null;
    }

    /**
     * @return array{checked: int, verified: list<string>, errors: list<string>}
     */
    public function run(): array
    {
        $out = ['checked' => 0, 'verified' => [], 'errors' => []];
        $mode = $this->mode();
        if ($mode === null) {
            $out['errors'][] = 'Mailbox not connected: set CITATIONS_M365_TENANT_ID, CITATIONS_M365_CLIENT_ID and CITATIONS_M365_CLIENT_SECRET (Microsoft 365), or the IMAP settings.';

            return $out;
        }
        $pending = $this->citations->pending();
        if ($pending === []) {
            return $out;
        }
        // Local copy of each citation's messages_seen, mutated as this pass
        // processes messages — mirrors the original code's aliasing of the
        // same in-memory Eloquent model across the whole loop, so two
        // qualifying messages for the same citation in one pass still
        // can't double-process one another.
        $seenByCitation = [];
        foreach ($pending as $p) {
            $seenByCitation[$p['slug']] = $p['messages_seen'];
        }

        $since = Carbon::now()->subDays($this->lookbackDays);
        try {
            $messages = $this->mailbox->messagesSince($since);
        } catch (\Throwable $e) {
            $out['errors'][] = mb_substr($e->getMessage(), 0, 300);

            return $out;
        }

        foreach ($messages as $message) {
            $fromDomain = self::registrable($message['from_domain']);
            $match = null;
            foreach ($pending as $p) {
                if (self::registrable((string) parse_url((string) $p['homepage'], PHP_URL_HOST)) === $fromDomain
                    && ! in_array($message['id'], $seenByCitation[$p['slug']], true)) {
                    $match = $p;
                    break;
                }
            }
            if (! $match) {
                continue;
            }
            $out['checked']++;
            $links = self::extractVerificationLinks($message['body'], $fromDomain);
            if ($links === []) {
                $seenByCitation[$match['slug']] = array_slice([...$seenByCitation[$match['slug']], $message['id']], -50);
                $this->citations->recordNoLink(
                    $match['slug'],
                    $seenByCitation[$match['slug']],
                    sprintf('Mail from %s ("%s") carried no verification link', $fromDomain, mb_substr((string) $message['subject'], 0, 60)),
                );

                continue;
            }
            foreach (array_slice($links, 0, 2) as $link) {
                try {
                    $resp = Http::withHeaders(['User-Agent' => 'Mozilla/5.0 (X11; Linux x86_64) Chrome/128.0'])->timeout(20)->get($link);
                } catch (\Throwable $e) {
                    // Matches the original class's behavior: a failed follow
                    // is not persisted at all when every attempt for this
                    // message fails (no save happens on the failure path) —
                    // not something this port changes.
                    continue;
                }
                $seenByCitation[$match['slug']] = array_slice([...$seenByCitation[$match['slug']], $message['id']], -50);
                $this->citations->recordVerified(
                    $match['slug'],
                    $seenByCitation[$match['slug']],
                    sprintf('Followed verification link from "%s": HTTP %d', mb_substr((string) $message['subject'], 0, 80), $resp->status()),
                );
                $out['verified'][] = $match['slug'];
                break;
            }
        }
        Log::info('citations: inbox pass', $out + ['mode' => $mode]);

        return $out;
    }

    /**
     * Links in an email body that look like "verify / confirm / activate" on
     * the sender's own domain (or its known link-tracking subdomains).
     *
     * @return list<string>
     */
    public static function extractVerificationLinks(string $body, string $senderDomain): array
    {
        // Transfer encoding is already undone by the transport; only HTML entities remain.
        preg_match_all('#https?://[^\s"\'<>)\]]+#i', $body, $m);
        $links = [];
        foreach (array_unique($m[0]) as $raw) {
            $url = html_entity_decode(rtrim($raw, '.,;'));
            $host = strtolower((string) parse_url($url, PHP_URL_HOST));
            if ($host === '' || self::registrable($host) !== self::registrable($senderDomain)) {
                continue;
            }
            $probe = strtolower((string) parse_url($url, PHP_URL_PATH).'?'.(string) parse_url($url, PHP_URL_QUERY));
            if (preg_match('/verif|confirm|activat|validate|token=|key=|code=/', $probe) && ! preg_match('/unsubscribe|preferences|privacy|terms|logo|\.(png|jpg|gif|css|js)(\?|$)/', $probe)) {
                $links[] = $url;
            }
        }

        return array_values($links);
    }

    public static function registrable(string $host): string
    {
        $parts = explode('.', strtolower(trim($host, '.')));
        $n = count($parts);
        if ($n <= 2) {
            return implode('.', $parts);
        }
        // co.uk-style suffixes are rare among US directories; keep two labels unless the TLD is a country code + generic pair.
        if (strlen($parts[$n - 1]) === 2 && in_array($parts[$n - 2], ['co', 'com', 'net', 'org'], true)) {
            return implode('.', array_slice($parts, -3));
        }

        return implode('.', array_slice($parts, -2));
    }
}
