<?php

namespace SsSystems\Platform\Citations;

/**
 * The null object hive binds where gsc/jpeterson bind a real
 * `VerificationInbox`: hive has no Graph/IMAP mailbox at all — its
 * `App\Http\Controllers\Api\Admin\V1\CitationsController::index()`
 * hardcoded `'inbox_configured' => false` rather than resolving a
 * `VerificationInbox` from the container (2026-09-27 audit, citations.md
 * #4/#8). This class exists purely so `Citations\CitationsAdminActions`
 * can ask any bound `Contracts\VerificationInbox` for `isConfigured()`
 * without special-casing hive — the answer is always `false`, honestly,
 * since there is nothing behind it to be configured.
 */
class UnavailableVerificationInbox implements Contracts\VerificationInbox
{
    public function isConfigured(): bool
    {
        return false;
    }
}
