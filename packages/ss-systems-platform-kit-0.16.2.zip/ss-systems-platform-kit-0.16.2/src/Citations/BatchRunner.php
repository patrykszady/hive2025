<?php

namespace SsSystems\Platform\Citations;

use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;
use SsSystems\Platform\Citations\Contracts\CitationRecord;
use SsSystems\Platform\Citations\Contracts\CitationSession;

/**
 * Runs directories one after another in automatic (headless) mode: the
 * runner submits plain listing forms itself and parks everything that
 * needs a person. One remote browser at a time, so the batch is strictly
 * sequential; progress lives in the cache for the admin board.
 *
 * Moved verbatim from gsc's/jpeterson's app/Services/Citations/
 * CitationBatchRunner.php (the only diff between the two was gsc's
 * `where('site_id', Site::current()?->id)` — see $baseQuery below).
 *
 * Two changes from those site copies, both required by this port:
 *
 * - **`$baseQuery`, a required constructor Closure `(): Builder`,
 *   replaces every bare `Citation::query()`.** The kit cannot reference
 *   `App\Models\Citation` (see `Contracts\CitationRecord`), so a site's
 *   own thin subclass captures its own scoping instead — gsc's binds
 *   `fn () => Citation::query()->where('site_id', Site::current()?->id)`,
 *   jpeterson's binds `fn () => Citation::query()` — and this class never
 *   has to know a `site_id` column exists. This is the one thing every
 *   query in this class must run through; dropping it on gsc would let
 *   one tenant's automatic run read or write another tenant's rows (see
 *   `CONSOLIDATION-PLAN.md` §6's tenancy risk note) — `BatchRunnerTest`'s
 *   two-fixture isolation test (mirrored by gsc's own Feature test with
 *   two real `Site` rows) pins that this Closure is the ONLY source of
 *   scoping in `eligible()`/`runOne()`/the stale-row queries.
 * - **`isActive()`/`progressState()` moved from static to instance
 *   methods** (`progress()` itself stays static — see below). A later
 *   kit unit (0.13.0's `CitationsAdminActions`) needs to call these two
 *   polymorphically across a real `BatchRunner` (gsc/jpeterson) and a
 *   hive/dawn null object that always answers "not running" — that is
 *   only possible once they are on an instance, not a same-named static
 *   method with no shared base class to call it through. `progress()`
 *   stays static because nothing needs to call it polymorphically: only
 *   the concrete runner that is actually driving a batch ever calls it,
 *   and hive/dawn (today: no batch runner at all) never will.
 * - **`isActive()`/`progressState()` wrap their `diffInMinutes()`/
 *   `diffInHours()` calls in `abs()` (2026-09-27, this port).** gsc's and
 *   jpeterson's live `CitationBatchRunner` (the file this class moved
 *   from, verbatim, byte-for-byte on this point) call `now()->diffInMinutes(
 *   Carbon::parse($p['updated_at'])) < 10` with no `abs()` — harmless
 *   under Carbon 2's always-positive-magnitude default, but Carbon 3.x
 *   (which gsc/jpeterson/hive already run) made `diffInMinutes()`/
 *   `diffInHours()` return a SIGNED difference by default, negative
 *   whenever the argument is chronologically before the receiver. Since
 *   `$p['updated_at']` is always in the past here, the un-wrapped call
 *   returns a negative number, and `< 10`/`>= 6` (inverted below) is then
 *   true/false for ANY age, however stale — both staleness guards were
 *   silent dead code in production on all three sites before this fix.
 *   `abs()` restores the intended "how long ago" magnitude regardless of
 *   Carbon major version; this is the one deliberate behavior change in
 *   this port (a bug fix, not a byte-identical move) — see
 *   `BatchRunnerTest::test_is_active_is_false_ten_minutes_after_the_last_update()`/
 *   `test_progress_state_marks_a_six_hour_stale_run_inactive_even_if_the_file_still_says_active()`.
 *
 * **`isAvailable()` (citations-admin-actions, 2026-09-27):** always `true`
 * on this real runner. `Citations\CitationsAdminActions::batch()` checks
 * it FIRST, before `isActive()`/session-running/`eligible()`, so it can
 * ask hive's `UnavailableBatchRunner` (always `false`) for the one honest
 * refusal that class needs to produce — the same "browser automation is
 * not set up on this host" message hive's own controller used to build by
 * hand — without adding a real requirements check to gsc's/jpeterson's
 * path at all (their `isAvailable()` never touches `CitationSession`).
 *
 * `runOne()` (like `RemoteBrowserSession::start()`/`stop()`) is not
 * exercised by the kit's own bare-PHPUnit suite: it drives a live
 * `CitationSession` poll loop and its `sleep()` helper calls the
 * `app()->runningUnitTests()` Laravel helper this package deliberately
 * has no Illuminate\Foundation dependency to provide (see
 * `tests/bootstrap-globals.php`) — verbatim from the site copies, where
 * a real app is always booted. `eligible()`/`isActive()`/
 * `progressState()` are pure query-shape/file-state logic and ARE
 * covered here; `runOne()` stays covered by each site's own Feature
 * suite, exactly as before this port.
 */
class BatchRunner
{
    public const CACHE_KEY = 'citations.batch';

    public const ELIGIBLE = [CitationRecord::STATUS_PLANNED, CitationRecord::STATUS_FAILED, CitationRecord::STATUS_UNREACHABLE];

    /**
     * @param  \Closure(): \Illuminate\Database\Eloquent\Builder  $baseQuery  Every
     *   query below starts here — see this class's own docblock for why.
     */
    public function __construct(
        protected CitationSession $sessions,
        protected \Closure $baseQuery,
    ) {}

    /** Directories a batch would touch, in tier order. */
    public function eligible(array $tiers = [], array $only = [], int $limit = 100): Collection
    {
        return ($this->baseQuery)()
            ->whereIn('status', self::ELIGIBLE)
            ->when($tiers !== [], fn ($q) => $q->whereIn('tier', array_map('intval', $tiers)))
            ->when($only !== [], fn ($q) => $q->whereIn('slug', $only))
            ->orderBy('tier')->orderBy('name')->limit($limit)->get();
    }

    /**
     * Run one directory to completion (done, parked, or timed out).
     *
     * @return array{slug: string, status: string, note: ?string, reason: ?string, seconds: int}
     */
    public function runOne(CitationRecord $citation): array
    {
        $started = time();
        $ttl = (int) config('citations.session.auto_ttl_seconds', 240);
        // One browser slot: if a session is still winding down (or a person
        // has the viewer open), wait for it rather than failing this row.
        $waitUntil = time() + $ttl + 60;
        while (($this->sessions->status()['running'] ?? false) && time() < $waitUntil) {
            $this->sleep(5);
        }
        if ($this->sessions->status()['running'] ?? false) {
            $citation->addLog('Skipped: another browser session was still running', 'batch');
            $citation->save();

            return ['slug' => $citation->slug, 'status' => $citation->status, 'note' => 'Another browser session was still running; left on the board.', 'reason' => null, 'seconds' => time() - $started];
        }
        $result = $this->sessions->start($citation, true, true);
        if (! ($result['ok'] ?? false)) {
            $citation->status = CitationRecord::STATUS_FAILED;
            $citation->note = (string) ($result['error'] ?? 'Could not start the session.');
            $citation->addLog('Automatic run could not start: '.$citation->note, 'batch');
            $citation->save();

            return ['slug' => $citation->slug, 'status' => $citation->status, 'note' => $citation->note, 'reason' => null, 'seconds' => 0];
        }
        $citation->status = CitationRecord::STATUS_RUNNING;
        $citation->human_reason = null;
        $citation->last_run_at = now();
        $citation->addLog('Automatic run started', 'batch');
        $citation->save();

        $deadline = $started + $ttl + 45;
        while (time() < $deadline) {
            $this->sleep(3);
            $status = $this->sessions->status();
            if (! ($status['running'] ?? false)) {
                break;
            }
        }
        if (($this->sessions->status()['running'] ?? false)) {
            $this->sessions->stop();
        }
        $this->sessions->syncCitation($citation->refresh());
        if ($citation->status === CitationRecord::STATUS_RUNNING) {
            $citation->status = CitationRecord::STATUS_FAILED;
            $citation->note = 'The automatic run ended without a result.';
            $citation->save();
        }

        return ['slug' => $citation->slug, 'status' => $citation->status, 'note' => $citation->note, 'reason' => $citation->human_reason, 'seconds' => time() - $started];
    }

    /**
     * Batch progress lives in the shared storage/app (like the session state),
     * not the cache: a deploy clears the cache mid-batch, the job chain does not care.
     *
     * @param  list<string>  $remaining
     */
    public static function progress(?array $remaining, int $done, ?string $current = null, bool $active = true): void
    {
        $file = self::progressFile();
        @mkdir(dirname($file), 0775, true);
        file_put_contents($file, json_encode(['active' => $active, 'remaining' => $remaining ?? [], 'done' => $done, 'current' => $current, 'updated_at' => now()->toDateTimeString()]));
        Cache::forget(self::CACHE_KEY);
    }

    /**
     * A batch is in flight when its progress file says so and moved within
     * the last ten minutes. Instance method — see this class's own
     * docblock for why.
     */
    public function isActive(): bool
    {
        $p = $this->progressState();

        return ! empty($p['active']) && ! empty($p['updated_at']) && abs(now()->diffInMinutes(Carbon::parse($p['updated_at']))) < 10;
    }

    /** Always true here — see this class's own docblock for why. */
    public function isAvailable(): bool
    {
        return true;
    }

    /** Instance method — see this class's own docblock for why. */
    public function progressState(): array
    {
        $file = self::progressFile();
        $p = is_file($file) ? json_decode((string) file_get_contents($file), true) : null;
        // A batch that has not moved for six hours is over, whatever the file says.
        if (is_array($p) && ! empty($p['active']) && ! empty($p['updated_at']) && abs(now()->diffInHours(Carbon::parse($p['updated_at']))) >= 6) {
            $p['active'] = false;
        }

        return is_array($p) ? $p : ['active' => false, 'remaining' => [], 'done' => 0, 'current' => null, 'updated_at' => null];
    }

    protected static function progressFile(): string
    {
        return rtrim((string) (config('citations.storage_dir') ?: storage_path('app/citations')), '/').'/batch.json';
    }

    protected function sleep(int $seconds): void
    {
        if (! app()->runningUnitTests()) {
            sleep($seconds);
        }
    }
}
