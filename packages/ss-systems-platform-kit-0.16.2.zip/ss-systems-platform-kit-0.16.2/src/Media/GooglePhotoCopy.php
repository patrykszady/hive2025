<?php

namespace SsSystems\Platform\Media;

use DateTimeInterface;
use Intervention\Image\Drivers\Gd\Driver;
use Intervention\Image\Encoders\JpegEncoder;
use Intervention\Image\ImageManager;

/**
 * The copy of a project photo that goes to Google Business Profile
 * (0.3.0, 2026-09-22): scaled to fit Google's fetch (it takes at most
 * 5 MB and fetches the URL itself), encoded as JPEG, and stamped with the
 * project's completion date and the market's coordinates — see
 * JpegExifTagger. One code path for every tenant: the central admin sends
 * the date and coordinates, the site calls this and serves the result.
 *
 * fingerprint() names the copy: the same source, date and place give the
 * same name, so a copy is made once and re-made only when one of them
 * changes.
 */
final class GooglePhotoCopy
{
    public const MAX_EDGE = 2400;

    /** Google's largest COVER photo, width then height ("Image too large … max: 2120px/1192px w/h"). */
    public const COVER_MAX_WIDTH = 2120;

    public const COVER_MAX_HEIGHT = 1192;

    public const QUALITY = 88;

    /** @return string JPEG bytes */
    public static function make(string $sourceBytes, ?float $latitude, ?float $longitude, ?DateTimeInterface $takenAt): string
    {
        $image = self::decode($sourceBytes)->scaleDown(width: self::MAX_EDGE, height: self::MAX_EDGE);

        return self::encode($image, $latitude, $longitude, $takenAt);
    }

    /**
     * The copy for a listing's COVER slot (0.14.1, 2026-09-29). Google takes
     * an ADDITIONAL photo up to MAX_EDGE on either side, but refuses a cover
     * larger than 2120×1192: jpeterson-design.com's portrait project photo
     * (1825×2400) came back "Image too large". So the cover is cropped
     * around its centre to 16:9, the shape Google shows a cover in, and
     * scaled to fit those limits. Never enlarged: a small photo is only
     * cropped.
     *
     * @return string JPEG bytes
     */
    public static function makeCover(string $sourceBytes, ?float $latitude, ?float $longitude, ?DateTimeInterface $takenAt): string
    {
        $image = self::decode($sourceBytes);

        $width = min(self::COVER_MAX_WIDTH, $image->width(), intdiv($image->height() * 16, 9));
        $height = min(self::COVER_MAX_HEIGHT, intdiv($width * 9, 16));

        return self::encode($image->coverDown($width, $height), $latitude, $longitude, $takenAt);
    }

    /**
     * Intervention Image v3 (gs.construction) reads with read() and encodes
     * with toJpeg(); v4 (jpeterson-design) renamed them to decode() and
     * encode(). One kit serves both, so it asks which.
     */
    private static function decode(string $sourceBytes): mixed
    {
        $manager = new ImageManager(new Driver());

        return method_exists($manager, 'read') ? $manager->read($sourceBytes) : $manager->decode($sourceBytes);
    }

    private static function encode(mixed $image, ?float $latitude, ?float $longitude, ?DateTimeInterface $takenAt): string
    {
        $encoded = method_exists($image, 'toJpeg')
            ? $image->toJpeg(self::QUALITY)
            : $image->encode(new JpegEncoder(quality: self::QUALITY));

        return (new JpegExifTagger())->stamp((string) $encoded, $latitude, $longitude, $takenAt);
    }

    /**
     * A short stable name for the copy of one source with one date and
     * place; $cover names makeCover()'s copy, which is a different image.
     */
    public static function fingerprint(string $sourceKey, ?float $latitude, ?float $longitude, ?DateTimeInterface $takenAt, bool $cover = false): string
    {
        return substr(sha1(implode('|', array_filter([
            $sourceKey,
            $latitude === null ? '' : number_format($latitude, 5, '.', ''),
            $longitude === null ? '' : number_format($longitude, 5, '.', ''),
            $takenAt?->format('Y-m-d') ?? '',
            'v1',
            $cover ? 'cover' : null,
        ], fn (?string $part) => $part !== null))), 0, 12);
    }
}
