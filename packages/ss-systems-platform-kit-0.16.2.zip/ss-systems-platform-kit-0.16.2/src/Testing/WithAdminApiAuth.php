<?php

namespace SsSystems\Platform\Testing;

/**
 * Shared setup for /api/admin/v1 tests: a bearer token (never set in
 * phpunit.xml, so config it per-test) plus the header every request needs.
 *
 * Ported verbatim from gsc's tests/Feature/Api/Admin/V1/Concerns/WithAdminApiAuth
 * (jpeterson's and dawnsellshomes' copies were already byte-identical bar
 * docblocks). Ships in the kit's MAIN autoload (SsSystems\Platform\, not the
 * Tests\ autoload-dev namespace) because it is consumed by each site's own
 * test suite, not the kit's — a consuming site's tests can't reach a class
 * the kit only exposes to itself.
 *
 * Each site keeps its own trait file at its own namespace/filename (so none
 * of its test files need a `use` edit) with a one-line body:
 *
 *     trait WithAdminApiAuth
 *     {
 *         use \SsSystems\Platform\Testing\WithAdminApiAuth;
 *     }
 *
 * This trait deliberately takes nothing from the app via config()/env() —
 * the token is a plain property a test can override before calling
 * setUpAdminApiAuth(), never read from the environment.
 */
trait WithAdminApiAuth
{
    protected string $adminApiToken = 'test-admin-api-token';

    protected function setUpAdminApiAuth(): void
    {
        config(['services.admin_api.token' => $this->adminApiToken]);
    }

    /** @return array<string, string> */
    protected function adminApiHeaders(): array
    {
        return ['Authorization' => 'Bearer '.$this->adminApiToken];
    }
}
