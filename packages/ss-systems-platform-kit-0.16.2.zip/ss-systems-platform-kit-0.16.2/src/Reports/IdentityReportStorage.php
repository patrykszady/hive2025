<?php

namespace SsSystems\Platform\Reports;

use SsSystems\Platform\Reports\Contracts\ReportStorage;

/**
 * The single-tenant default: a generated artefact's path is exactly what was
 * asked for, no scoping applied. jpeterson-design's and hive2025's own
 * `SeoStorage`/nothing-at-all were this exact shape (one site, one set of
 * report files, nothing to prefix) before this moved into the kit.
 *
 * `Reports\Console\ReportRun::run()` falls back to this whenever the host
 * app has not bound `Contracts\ReportStorage` itself, so a single-tenant
 * site adopting the kit's report plumbing needs zero container wiring to
 * get correct (identity) behaviour. A multi-tenant site (gsc) MUST bind its
 * own tenant-scoped implementation explicitly — this default would silently
 * defeat that site's tenant isolation if it were ever picked up by mistake.
 */
final class IdentityReportStorage implements ReportStorage
{
    public function path(string $relative): string
    {
        return $relative;
    }
}
