<?php

namespace SsSystems\Platform\Reports\Console;

use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use SsSystems\Platform\Reports\Contracts\ReportStorage;
use SsSystems\Platform\Reports\IdentityReportStorage;
use Symfony\Component\Console\Exception\CommandNotFoundException;
use Throwable;

/**
 * Runs one SEO report's artisan command for the admin's "Run" button and
 * writes the whole attempt, start to finish, to the 'seo-reports' log
 * channel. Before this existed on jpeterson-design (whose shape this is —
 * byte-identical to hive2025's own copy, docblock-only diffs), a report
 * whose command isn't ported on a given site failed silently inside a 200
 * response and left no trace anywhere; this makes that failure loud in the
 * log and honest in what it hands back to the controller.
 *
 * Ported from three identical per-site `SeoReportRun` classes
 * (jpeterson-design, hive2025) AND from gs.construction's own earlier,
 * independently-evolved version of the same idea (different private method
 * names, `Site::current()?->slug` folded into every log line). gsc adopts
 * this class too — its tenancy is carried entirely through the `$context`
 * array below, which this class only ever merges into a log payload and
 * never inspects. The kit does not know what a "site" is.
 *
 * @see \SsSystems\Platform\Reports\Contracts\ReportStorage the report-file
 *      path binding — gsc supplies its own tenant-scoped implementation via
 *      its container; every other site gets the identity default for free.
 */
class ReportRun
{
    public const LOG_CHANNEL = 'seo-reports';

    /**
     * @param  array{label: string, command: string, description?: string}  $meta
     * @param  array<string, mixed>  $context  Extra fields merged into every
     *         log line this run writes (start, finish, error) — the seam a
     *         multi-tenant site uses to add its own identity (e.g.
     *         `['site' => Site::current()?->slug]`) without this class ever
     *         knowing tenancy exists.
     * @return array{status: string, ok: bool, message: string, started_at: string, finished_at: string, duration_ms: int, exit_code: ?int, output_tail: string, log_channel: string}
     */
    public static function run(
        string $key,
        array $meta,
        Request $request,
        int $trendDays,
        array $context = [],
        ?ReportStorage $storage = null,
    ): array {
        $storage ??= self::defaultStorage();

        $label = $meta['label'];
        $command = $meta['command'];
        $commandName = strtok($command, ' ') ?: $command;

        $startedAt = Carbon::now();
        $start = microtime(true);

        Log::channel(self::LOG_CHANNEL)->info('report run started', $context + [
            'key' => $key,
            'label' => $label,
            'command' => $command,
            'trend_days' => $trendDays,
            'requested_by' => $request->header('X-Admin-User'),
            'screen' => $request->header('X-Admin-Screen'),
            'ip' => $request->ip(),
        ]);

        $status = 'ok';
        $exitCode = null;
        $output = '';
        $errorContext = [];

        try {
            $exitCode = Artisan::call($command);
            $output = (string) Artisan::output();
            if ($exitCode !== 0) {
                // A non-zero exit with the report freshly written is a health
                // signal, not a broken run: seo:health exits 1 when it finds
                // something wrong. The operator gets the report and the warning.
                $status = self::writtenSince($storage, $key, $startedAt) ? 'warning' : 'failed';
            }
        } catch (CommandNotFoundException $e) {
            $status = 'missing-command';
            $errorContext = [
                'error' => "The command {$commandName} is not installed on this site",
                'exception_message' => $e->getMessage(),
            ];
        } catch (Throwable $e) {
            $status = 'failed';
            $errorContext = [
                'exception_class' => get_class($e),
                'exception_message' => $e->getMessage(),
                'stack' => self::stackFrames($e),
            ];
        }

        $finishedAt = Carbon::now();
        $durationMs = (int) round((microtime(true) - $start) * 1000);
        $file = self::fileState($storage, $key);

        $logContext = $context + [
            'key' => $key,
            'status' => $status,
            'exit_code' => $exitCode,
            'duration_ms' => $durationMs,
            'output_tail' => self::tail($output, 4000),
            'file' => $file,
        ] + $errorContext;

        Log::channel(self::LOG_CHANNEL)->{match ($status) { 'ok' => 'info', 'warning' => 'warning', default => 'error' }}('report run finished', $logContext);

        return [
            'status' => $status,
            'ok' => in_array($status, ['ok', 'warning'], true),
            'message' => self::buildMessage($status, $label, $commandName, $durationMs, $errorContext['exception_message'] ?? null, $exitCode),
            'started_at' => $startedAt->toIso8601String(),
            'finished_at' => $finishedAt->toIso8601String(),
            'duration_ms' => $durationMs,
            'exit_code' => $exitCode,
            'output_tail' => self::tail($output, 2000),
            'log_channel' => self::LOG_CHANNEL,
        ];
    }

    public static function formatSeconds(int $ms): string
    {
        return number_format($ms / 1000, 1).' s';
    }

    /**
     * The owner-facing sentence for every status this run can end in — pulled
     * out of run() so it is testable with no Artisan/Log/Storage facade in
     * play (those need a booted container; this is pure string formatting).
     */
    public static function buildMessage(
        string $status,
        string $label,
        string $commandName,
        int $durationMs,
        ?string $errorMessage,
        ?int $exitCode,
    ): string {
        return match ($status) {
            'missing-command' => "Could not run {$label}: the command {$commandName} is not installed on this site.",
            'warning' => sprintf('%s regenerated in %s, but the command reported problems (exit %d). See what it printed.', $label, self::formatSeconds($durationMs), $exitCode),
            'failed' => "{$label} failed: ".($errorMessage ?? "exit code {$exitCode}").'.',
            default => sprintf('%s regenerated in %s.', $label, self::formatSeconds($durationMs)),
        };
    }

    private static function defaultStorage(): ReportStorage
    {
        // A site that never bound Contracts\ReportStorage itself gets the
        // identity default — correct for every single-tenant site. A
        // multi-tenant site MUST bind its own tenant-scoped implementation
        // (see this class's docblock); this fallback exists so adopting this
        // class costs a single-tenant site zero container wiring, not so a
        // multi-tenant site can skip binding one.
        if (function_exists('app') && app()->bound(ReportStorage::class)) {
            return app(ReportStorage::class);
        }

        return new IdentityReportStorage;
    }

    private static function tail(string $text, int $chars): string
    {
        return mb_strlen($text) > $chars ? mb_substr($text, -$chars) : $text;
    }

    /** @return array<int, string> */
    private static function stackFrames(Throwable $e): array
    {
        return collect($e->getTrace())
            ->take(5)
            ->map(function (array $frame): string {
                $location = ($frame['file'] ?? '[internal]').':'.($frame['line'] ?? '?');
                $call = ($frame['class'] ?? '').($frame['type'] ?? '').($frame['function'] ?? '');

                return trim($location.' '.$call);
            })
            ->all();
    }

    /** Whether the report file was (re)written during this run. */
    private static function writtenSince(ReportStorage $storage, string $key, Carbon $startedAt): bool
    {
        $disk = Storage::disk('local');
        $path = $storage->path("reports/{$key}.md");

        return $disk->exists($path) && $disk->lastModified($path) >= $startedAt->getTimestamp() - 1;
    }

    /**
     * The same file fileEntry() reads, after the run — so the "finished" log
     * line and the API response agree on whether the run actually produced
     * (or updated) the report file.
     *
     * @return array{path: string, exists: bool, size: ?int, modified_at: ?string}
     */
    private static function fileState(ReportStorage $storage, string $key): array
    {
        $disk = Storage::disk('local');
        $path = $storage->path("reports/{$key}.md");
        $exists = $disk->exists($path);

        return [
            'path' => $path,
            'exists' => $exists,
            'size' => $exists ? $disk->size($path) : null,
            'modified_at' => $exists ? Carbon::createFromTimestamp($disk->lastModified($path))->toIso8601String() : null,
        ];
    }
}
