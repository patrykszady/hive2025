<?php

namespace SsSystems\Platform\Reports\Console;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;
use SsSystems\Platform\Reports\Contracts\ReportStorage;
use SsSystems\Platform\Reports\Report;
use SsSystems\Platform\Reports\ReportRegistry;
use SsSystems\Platform\Reports\ReportResult;

/**
 * Thin artisan wrapper shared by the ten seo:* report commands — see
 * docs/REPORTS-PORTING.md, "How a site wraps a report". The kit owns the
 * algorithm (thresholds, markdown wording, scoring); this class and its ten
 * per-site subclasses own turning a ReportResult back into console output, a
 * saved markdown file and an exit code, exactly like gsc's original ten
 * commands each did for themselves before this shape existed.
 *
 * Ported byte-for-byte from jpeterson-design's and hive2025's identical
 * `App\Console\Commands\Seo\KitReportCommand` (dawnsellshomes' copy too,
 * per the audit — jp/hive/dawn differ only in docblock wording, confirmed
 * by full diff before this port). gsc is excluded from this move: its own
 * pre-refactor design exposes saveMarkdown()/logAlert()/unavailable()/
 * reportError()/renderRows() as protected helpers its ten commands call
 * directly, not this reportKey()/reportClass()/handle() dispatch shape —
 * porting gsc is a separate Phase-2 (docs/CONSOLIDATION-PLAN.md, Kit 0.12.0).
 *
 * The one real change from the site copies: `maybeSaveMarkdown()` resolved
 * `App\Support\SeoStorage::path()` directly (each site's own static,
 * effectively-identity helper); here it resolves the {@see ReportStorage}
 * contract through the container instead, exactly like `reportClass()` is
 * already resolved via `$this->laravel->make(...)` below — a site binds
 * ReportStorage once (its own SeoStorage-backed implementation, or gsc's
 * tenant-scoped one) and every report command picks it up unchanged. The
 * markdown path and file content this produces are identical to before.
 *
 * Exit-code shape, the same for every report unless a subclass overrides
 * exitCode() (health-check and health both do — see their own docblocks):
 *   - STATUS_ERROR       -> print the error, FAILURE.
 *   - STATUS_UNAVAILABLE -> print the reason; FAILURE when a capability is
 *     missing, SUCCESS when the report simply found nothing. Never reached
 *     from the admin's "Run" button (SeoReportController::regenerate()
 *     checks App\Support\Seo\Reports\ReportCapabilities FIRST and never
 *     calls an unavailable report's command at all) but a report can still
 *     decide this for itself mid-run (e.g. ContentGapReport with nothing in
 *     the rank band) when the command is run directly.
 *   - STATUS_OK / STATUS_DEGRADED -> the summary line, a console table, any
 *     alert logging, the markdown file when --markdown was passed, then
 *     SUCCESS.
 */
abstract class KitReportCommand extends Command
{
    /** The registry key — also the markdown filename (reports/{key}.md) and ReportRegistry::REPORTS' own key. */
    abstract protected function reportKey(): string;

    /** @return class-string<Report> */
    abstract protected function reportClass(): string;

    public function handle(): int
    {
        /** @var Report $report */
        $report = $this->laravel->make($this->reportClass());
        $result = $report->generate($this->reportOptions());

        return $this->respond($result);
    }

    protected function respond(ReportResult $result): int
    {
        if ($result->status === ReportResult::STATUS_ERROR) {
            $this->error($result->error ?? $result->summary);

            return self::FAILURE;
        }

        if ($result->status === ReportResult::STATUS_UNAVAILABLE) {
            $this->warn($result->summary);

            // A missing capability is a real refusal (exit 1 so a schedule
            // notices); an empty `missing` means the report ran and found
            // nothing to report on, which gsc's old commands treated as a
            // warning and exit 0, so a quiet week never logs a failure.
            return $result->missing === [] ? self::SUCCESS : self::FAILURE;
        }

        $this->line($result->summary);
        $this->renderTable($result->data);
        $this->logAlerts($result->data);
        $this->maybeSaveMarkdown($result->markdown);

        return $this->exitCode($result);
    }

    /**
     * Every artisan --flag this report's ReportRegistry entry documents,
     * dashes -> underscores, read straight off this command's own CLI
     * options. Every one of the ten commands' flag names is exactly
     * str_replace('_', '-', $key) for its registry options (verified
     * against gsc's own committed signatures), so this one generic
     * implementation covers all ten without repeating the list per class.
     * A flag never passed on the CLI (null, or false for a boolean flag)
     * is left out of $options entirely — the kit report's own `?? default`
     * fallback applies, same as docs/REPORTS-PORTING.md's example wrapper.
     *
     * @return array<string, mixed>
     */
    protected function reportOptions(): array
    {
        $options = [];

        foreach (array_keys(ReportRegistry::get($this->reportKey())['options']) as $key) {
            $flag = str_replace('_', '-', $key);
            if (! $this->hasOption($flag)) {
                continue;
            }

            $value = $this->option($flag);
            if ($value === null || $value === false) {
                continue;
            }

            $options[$key] = $value;
        }

        return $options;
    }

    /** SUCCESS for both ok and degraded, unless a subclass's original exit rule cared about the distinction (health-check, health). */
    protected function exitCode(ReportResult $result): int
    {
        return self::SUCCESS;
    }

    /** Nothing extra beyond the summary line, unless a subclass's original printed a console table. */
    protected function renderTable(array $data): void
    {
        //
    }

    /** No alert shape for this report, unless a subclass's original decided (and logged) something about its own findings. */
    protected function logAlerts(array $data): void
    {
        //
    }

    protected function maybeSaveMarkdown(string $markdown): void
    {
        if (! $this->hasOption('markdown') || ! $this->option('markdown')) {
            return;
        }

        $path = $this->laravel->make(ReportStorage::class)->path("reports/{$this->reportKey()}.md");
        Storage::disk('local')->put($path, $markdown);
        $this->info("Saved: {$path}");
    }

    /**
     * The three-key data['alert'] shape ContentDecayReport, CwvTemplateReport
     * and SchemaAuditReport all produce — docs/REPORTS-PORTING.md's own
     * example wrapper for exactly this.
     *
     * @param  array<string, mixed>  $data
     */
    protected function logGenericAlert(array $data): void
    {
        $alert = $data['alert'] ?? null;
        if (! is_array($alert) || ($alert['suppressed'] ?? false) || ! ($alert['message'] ?? null)) {
            return;
        }

        if (($alert['level'] ?? null) === 'warning') {
            logger()->warning($alert['message'], $data);
        } elseif (($alert['level'] ?? null) === 'info') {
            logger()->info($alert['message'], $data);
        }
    }
}
