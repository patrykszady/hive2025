<?php

namespace SsSystems\Platform\Reports\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Process\PhpExecutableFinder;

/**
 * Runs a long artisan command on the queue with a realistic timeout, falling
 * back to a detached shell process when there is no queue worker to hand it
 * to. Ported verbatim from three byte-identical per-site jobs
 * (jpeterson-design's and hive2025's `RunSeoChannelSyncJob`, plus both
 * sites' thin `RunGscInspectBulkJob` — which did nothing but pick a command
 * name and delegate to this same detached runner) — a generic command
 * string plus an options array, with zero model, config-key, or tenant
 * reference anywhere in the class.
 *
 * A default QueuedCommand inherits the worker's short timeout and default
 * retry count — a full paginated GSC pull or a full-sitemap inspection sweep
 * takes minutes, so it would be killed and retried into
 * MaxAttemptsExceeded. And whether or not a queue worker is actually
 * running, a job dispatched with no worker running would otherwise sit
 * forever: `handle()` detects that case (`queue.default === 'sync'`, the
 * common shape for a site with no worker process) and runs the command as a
 * detached `nohup` process instead, with its output kept in
 * storage/logs/{command}.log for the record.
 *
 * NOT used by gs.construction's own `App\Jobs\RunSeoChannelSyncJob` — that
 * class shares this one's name but is a genuinely different feature (the
 * Houzz/Angi review-import job, wrapped in `Tenancy::for()` because a job
 * queued with no HTTP request has no `Site::current()` to fall back on
 * except the default tenant). It has no detached-shell fallback at all and
 * stays exactly as it is; gsc is free to start using this generic kit job
 * for a future single-tenant-shaped need without touching its existing one.
 *
 * No `Dispatchable` trait: that lives in `illuminate/foundation`, which this
 * kit deliberately does not depend on (see tests/bootstrap-globals.php's own
 * docblock for why). `dispatch()` below calls the global `dispatch()`
 * helper directly — every consumer of this class is a real Laravel app
 * where that helper is already loaded, and it returns the identical
 * `PendingDispatch` the trait's own `dispatch()` would.
 */
class RunArtisanCommandDetached implements ShouldQueue
{
    use InteractsWithQueue, Queueable, SerializesModels;

    public int $timeout = 900;

    public int $tries = 1;

    /**
     * @param  array<string, mixed>  $options
     */
    public function __construct(
        public string $command,
        public array $options = [],
    ) {}

    /**
     * @param  array<string, mixed>  $options
     */
    public static function dispatch(string $command, array $options = []): mixed
    {
        return dispatch(new self($command, $options));
    }

    public function handle(): void
    {
        // This site has no queue worker (QUEUE_CONNECTION=sync): a job runs
        // inside the admin's request, and a browser scrape or a full GSC/Bing
        // pull takes minutes the request cannot wait. So the command runs as
        // a detached process instead, its output kept in
        // storage/logs/{command}.log for the record.
        if (config('queue.default') === 'sync' && ! app()->runningUnitTests()) {
            $this->runDetached();

            return;
        }

        $exit = Artisan::call($this->command, $this->options);
        if ($exit !== 0) {
            Log::warning('RunArtisanCommandDetached command exited non-zero', [
                'command' => $this->command,
                'exit' => $exit,
            ]);
        }
    }

    /** `nohup {php} artisan {command} {options} >> storage/logs/{slug}.log &` */
    protected function runDetached(): void
    {
        $log = $this->detachedLogPath();

        file_put_contents($log, '['.now()->toDateTimeString().'] starting '.$this->command."\n", FILE_APPEND);
        Log::info('RunArtisanCommandDetached started detached', ['command' => $this->command, 'log' => $log]);
        exec($this->detachedShellCommand());
    }

    public function detachedLogPath(): string
    {
        return storage_path('logs/'.preg_replace('/[^a-z0-9]+/', '-', $this->command).'.log');
    }

    /**
     * The shell line the detached run uses. The PHP binary is found the way
     * Symfony does, never PHP_BINARY: under PHP-FPM that constant is php-fpm
     * itself, which only prints its usage text when handed `artisan`.
     */
    public function detachedShellCommand(): string
    {
        $args = [];
        foreach ($this->options as $name => $value) {
            if ($value === false || $value === null) {
                continue;
            }
            $args[] = $value === true ? $name : $name.'='.escapeshellarg((string) $value);
        }

        $php = (new PhpExecutableFinder)->find(false) ?: 'php';

        return sprintf(
            'nohup %s %s %s %s >> %s 2>&1 &',
            escapeshellarg($php),
            escapeshellarg(base_path('artisan')),
            escapeshellarg($this->command),
            implode(' ', $args),
            escapeshellarg($this->detachedLogPath()),
        );
    }
}
