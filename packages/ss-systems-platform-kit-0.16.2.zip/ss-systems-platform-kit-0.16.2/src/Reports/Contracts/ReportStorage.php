<?php

namespace SsSystems\Platform\Reports\Contracts;

/**
 * Where generated SEO artefacts (markdown reports, recommendations.json)
 * live on the local disk, relative to the app's `local` filesystem disk.
 *
 * A single-tenant site's implementation is the identity function — there is
 * nothing to scope, so `path('reports/health.md')` returns exactly that. A
 * multi-tenant site's implementation (gsc's `TenantScopedReportStorage`)
 * prefixes every non-default site's path with `tenants/{slug}/`, because one
 * codebase serving many `Site` rows would otherwise let every tenant's admin
 * read another tenant's generated report from the same bare path — the DB
 * side never had this problem (Eloquent models scope themselves), only the
 * file-based half of the reports family does.
 *
 * This interface is defined identically here and by the kit's
 * `Reports\Console\KitReportCommand` unit (same signature, same intent) so
 * the two land as a no-op merge: whichever ships first, the other's copy of
 * this file is byte-identical.
 *
 * The kit never implements tenancy itself — it only ever receives a
 * ReportStorage instance (or resolves the interface from the site's own
 * container binding) and calls `path()`. Whether "tenant" means anything at
 * all is entirely the binding site's business.
 *
 * Capability key: n/a — this is infrastructure, not a per-site capability.
 */
interface ReportStorage
{
    public function path(string $relative): string;
}
