<?php

namespace SsSystems\Platform\Dashboard;

/**
 * The one piece of the dashboard-stats tile logic every site's
 * `DashboardStatsController::deltaPct()` implemented byte-for-byte
 * identically (gsc, jpeterson-design, hive2025, ss-systems all diffed the
 * same on 2026-09-27) — signed percentage change of a tile's current window
 * vs its prior same-length window, for the green/red chevron every tile
 * shows (ss-systems CLAUDE.md: "dashboards show trends, not lone numbers").
 *
 * This is deliberately the ONLY piece extracted here. The rest of what the
 * consolidation plan calls `Dashboard\CommonTileBuilder` — the shared tile
 * assembly, the 4-contract data sourcing (leads/volume is a real 4th
 * contract the original proposal missed), and `search_clicks`'s genuinely
 * two-phase algorithm — is deferred (kit 0.14.0 plan, "will ship as
 * 0.13.0") pending a dashboard-stats multi-tenant isolation test that does
 * not exist anywhere in the estate today. `pct()` has zero coupling to any
 * of that: it takes two numbers and returns a number, so it ships now.
 *
 * No behaviour change: a prior of zero or less (no prior-window data, or a
 * tile that fell to/below zero) returns null — every site's admin already
 * renders a null delta as "no comparison available" rather than a
 * divide-by-zero or a misleading +/-∞.
 */
final class Delta
{
    public static function pct(int|float $current, int|float $prior): ?float
    {
        if ($prior <= 0) {
            return null;
        }

        return round((($current - $prior) / $prior) * 100, 1);
    }
}
