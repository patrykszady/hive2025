<?php

namespace SsSystems\Platform\Projects;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;

/**
 * The cache-backed "is this project's photos-first details draft running,
 * and did it fail" status — ported from jpeterson-design.com's
 * `App\Jobs\GenerateProjectDetailsJob`'s own flagKey()/errorKey()/status()/
 * (half of) launch(). Same split as `AreaDescriptionStatus` (area
 * descriptions): the cache bookkeeping is identical on every site; the
 * actual AI call, the prompt/house-style text, and the job's own
 * dispatch/queue mechanics stay per-site — see docs/PROJECT-DETAILS.md.
 *
 * `status()` is what a site's own `withCrmFields()`/`toApiArray()`-layering
 * reads for the project payload's "details" key; `markGenerating()`/
 * `recordError()`/`clearGenerating()` are what the site's own job calls
 * (flag before dispatch, clear in a `finally`, record on failure) so every
 * site's cache keys — and therefore the admin's polling — line up exactly.
 */
final class ProjectDetailsStatus
{
    public static function flagKey(int $projectId): string
    {
        return "projects.details-generating.{$projectId}";
    }

    public static function errorKey(int $projectId): string
    {
        return "projects.details-error.{$projectId}";
    }

    /** @return array{generating: bool, error: ?string} */
    public static function status(Model $project): array
    {
        return [
            'generating' => Cache::has(self::flagKey((int) $project->getKey())),
            'error' => Cache::get(self::errorKey((int) $project->getKey())),
        ];
    }

    /**
     * Flag first, dispatch after the response — the site's own job calls
     * this, then dispatches itself (`dispatchAfterResponse`/`afterResponse()`
     * — the kit never dispatches a site's job for it).
     */
    public static function markGenerating(Model $project): void
    {
        $id = (int) $project->getKey();
        Cache::forget(self::errorKey($id));
        Cache::put(self::flagKey($id), now()->toDateTimeString(), now()->addMinutes(10));
    }

    public static function recordError(int $projectId, string $message): void
    {
        Cache::put(self::errorKey($projectId), $message, now()->addDay());
    }

    public static function clearGenerating(int $projectId): void
    {
        Cache::forget(self::flagKey($projectId));
    }
}
