<?php

namespace SsSystems\Platform\Projects\Contracts;

use Illuminate\Database\Eloquent\Model;

/**
 * How a site remembers that a project's old address should keep working.
 * jpeterson-design stores this as a `project_slug_redirects` row (slug,
 * project_id, optional anchor, optional source_project_id) consulted before
 * a 404 — see resources/stubs/projects/ProjectSlugRedirect.php.stub and the
 * sibling migration stubs. A site is free to record it any other way (a
 * history table with no anchor concept, like gs.construction's
 * `ProjectSlugHistory` + `RenamedProjectRedirector`, which redirects whole
 * paths rather than consulting a dedicated row at request time) — nothing
 * in `Concerns\HasProjectAreas` or `ProjectMerger` assumes a particular
 * storage shape, only that these three operations exist.
 */
interface RecordsProjectSlugRedirect
{
    /**
     * Ensure $oldSlug redirects to $project (optionally at #$anchor),
     * WITHOUT overwriting a redirect already recorded for that slug.
     * Called by `Concerns\HasProjectAreas`'s own slug-rename hook — a plain
     * rename never has an anchor to give, but a rename that races a merge
     * (which records the authoritative row itself, with an anchor, via
     * recordRedirect() below, just before renaming the target) must not
     * clobber what the merge just wrote.
     */
    public function recordRedirectIfAbsent(string $oldSlug, Model $project, ?string $anchor = null): void;

    /**
     * Set (overwriting) that $oldSlug now redirects to $project at #$anchor,
     * optionally noting the id of the source project that no longer exists
     * (so an API request for that id can answer with "moved to" rather than
     * a bare 404 — see `MergedProjectRedirectResponse`). Called by
     * `ProjectMerger`, which is always the authority on a merge's redirects.
     */
    public function recordRedirect(string $oldSlug, Model $project, ?string $anchor = null, ?int $sourceProjectId = null): void;

    /**
     * Drop any redirect now stale because $slug is live again (a project
     * reclaimed it as its own current address).
     */
    public function forgetRedirect(string $slug): void;

    /**
     * Re-point every EXISTING redirect/history row that currently targets
     * $source over to $target instead — called by `ProjectMerger` BEFORE
     * $source is deleted, so a site whose storage references the source by
     * foreign key with an `onDelete('cascade')` (gs.construction's
     * `project_slug_history`, one row per address the project has ever
     * had) does not lose every earlier address the merged-away project
     * answered on just because the row cascaded away with it. jpeterson-
     * design's own `project_slug_redirects` references only the
     * DESTINATION project (never the source) and has nothing pre-existing
     * to re-point, so its adapter makes this a no-op — see
     * `Projects\ProjectSlugRedirectRecorder` in jpeterson-design for that
     * shape and `docs/PROJECT-AREAS.md` for gs.construction's.
     */
    public function repointRedirects(Model $source, Model $target): void;

    /**
     * The project (and anchor, if any) a deleted source project — identified
     * by the numeric id it used to have — now redirects to, or null when
     * nothing matches. Powers the "moved to" 409 a site's `bootstrap/app.php`
     * renders for an admin-API request naming a project id that no longer
     * resolves — see `MergedProjectRedirectResponse`, which calls this
     * rather than querying a redirect model directly, so a site whose
     * storage shape (or lookup column) differs from jpeterson-design's
     * `source_project_id` only ever has to change this one method.
     *
     * @return array{project: Model, anchor: ?string}|null
     */
    public function findBySourceProjectId(int $sourceProjectId): ?array;
}
