<?php

namespace SsSystems\Platform\Projects\Contracts;

use Illuminate\Database\Eloquent\Model;

/**
 * The actual AI call behind a per-area description draft — deliberately
 * NOT orchestrated by any kit job or base class (see
 * `docs/PROJECT-AREAS.md` for why): a site's own queued job stays entirely
 * its own class, so it can wrap its execution however its platform needs
 * (jpeterson-design calls its `AiContentService`/Gemini directly;
 * gs.construction's AI jobs run inside `Tenancy::for($project->site)`,
 * which only the site's own job can know to do). Implementing this
 * interface is optional — it exists only to give the one real seam (area +
 * its photos in, drafted text out) a shared name and shape, for a site
 * that wants its AI call behind a swappable/testable boundary rather than
 * inlined in the job's `handle()`.
 *
 * $images is whatever `AreaPhotoSelection::choose()` (or the site's own
 * equivalent ordering/cap) already selected and resolved to bytes/parts —
 * this contract has no opinion on that shape, only that the implementation
 * returns the drafted description text, or throws (the job records the
 * failure via `AreaDescriptionStatus::recordError()`).
 */
interface DraftsAreaDescription
{
    /**
     * @param  iterable<mixed>  $images
     *
     * @throws \Throwable when the draft could not be produced
     */
    public function draft(Model $area, iterable $images): string;
}
