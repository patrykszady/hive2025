<?php

namespace SsSystems\Platform\Projects\Contracts;

use Illuminate\Database\Eloquent\Model;

/**
 * Everything a merged-away project owns besides its photos and its own
 * project_type/description (already folded into its new area by
 * `ProjectMerger` itself, which needs no hook for that part — see its
 * docblock). On jpeterson-design this is the testimonials pivot,
 * collaborators, before/afters, timelapses and its blog post; a site is
 * free to move whatever else it has, or nothing at all, by writing a
 * different adapter, since `ProjectMerger` only ever treats the return
 * value of relocate() as an opaque bag it hands back through its own
 * result array for `describeMoved()`/the console command to read.
 */
interface RelocatesProjectOwnedRows
{
    /**
     * Move everything $source owns (besides photos/areas) onto $target,
     * then return whatever counts are worth reporting — describeMoved()
     * below turns them into the one line `projects:merge` prints per
     * source. The shape is entirely up to the implementation.
     *
     * @return array<string, mixed>
     */
    public function relocate(Model $source, Model $target): array;

    /**
     * One human-readable fragment summarizing $project's own owned rows
     * (testimonials, collaborators, …) — printed in `projects:merge --dry`'s
     * plan, before anything has moved. E.g. "2 testimonial(s), 1
     * collaborator(s), 0 before/after(s), 1 timelapse(s), a blog post".
     */
    public function describe(Model $project): string;

    /**
     * The same kind of fragment, but read back out of a relocate() result
     * after the fact — printed by `projects:merge`'s real (non-dry) run.
     *
     * @param  array<string, mixed>  $relocated  relocate()'s own return value
     */
    public function describeMoved(array $relocated): string;
}
