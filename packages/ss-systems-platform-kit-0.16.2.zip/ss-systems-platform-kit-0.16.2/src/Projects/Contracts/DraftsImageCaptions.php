<?php

namespace SsSystems\Platform\Projects\Contracts;

use Illuminate\Database\Eloquent\Model;

/**
 * The per-photo caption/alt-text step that follows a successful (or even a
 * failed — jpeterson-design.com runs it either way) project details draft.
 * Deliberately a seam, not a kit-owned flow: every site's own pipeline
 * looks nothing alike —
 *
 * - jpeterson-design's `GenerateImageCaptionsJob` writes `caption`/
 *   `alt_text`/`gbp_caption`, runs synchronously in the SAME
 *   after-response pass as the details job (a nested
 *   `dispatchAfterResponse` would never fire — see that job's own
 *   docblock), and is also launched per photo upload;
 * - gs.construction's `GenerateAiContentJob` writes `alt_text`/
 *   `seo_alt_text`/`caption`, is a real queued, rate-limited, retrying job
 *   per image, and itself chains a project-description regeneration once
 *   every photo is done — the inverse direction from jpeterson-design's
 *   "details first, then captions".
 *
 * This interface exists only so a site's own "launch the caption step"
 * call, wherever it sits in that site's details job, has a name — nothing
 * in the kit calls it for you.
 */
interface DraftsImageCaptions
{
    /** Draft (or refresh) captions/alt text for every one of $project's own photos that still needs it — entirely up to the implementation which fields it writes, in what order, or whether it runs inline vs. queues itself. */
    public function draft(Model $project): void;
}
