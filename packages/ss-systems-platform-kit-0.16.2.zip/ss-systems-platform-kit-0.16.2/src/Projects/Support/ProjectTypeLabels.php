<?php

namespace SsSystems\Platform\Projects\Support;

/**
 * The one fallback rule every site's own `projectTypeLabel()` hook
 * (`Concerns\HasProjectAreas`, `Concerns\IsProjectArea`) uses for a category
 * slug with no entry in that site's own vocabulary (jpeterson-design's
 * `Project::projectTypes()` / Service table, gs.construction's own
 * equivalent): title-case the slug's words. Pulled out so both hooks —
 * and both sites — spell the exact same fallback the exact same way,
 * without either one needing to import the other's Project class.
 */
final class ProjectTypeLabels
{
    public static function fallback(string $type): string
    {
        return ucwords(str_replace('-', ' ', $type));
    }
}
