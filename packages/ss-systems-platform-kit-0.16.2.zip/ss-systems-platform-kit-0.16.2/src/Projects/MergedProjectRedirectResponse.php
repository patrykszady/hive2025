<?php

namespace SsSystems\Platform\Projects;

use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\JsonResponse;
use SsSystems\Platform\Projects\Contracts\RecordsProjectSlugRedirect;

/**
 * The 409 "moved_to" answer for an admin-API request naming a project id
 * that `php artisan projects:merge` folded into another — see
 * `ProjectMerger`. A site wires this into its own `bootstrap/app.php`
 * exception render hook in one line:
 *
 *     $exceptions->render(fn (NotFoundHttpException $e, Request $request) =>
 *         $request->is('api/admin/*') && $e->getPrevious() instanceof ModelNotFoundException
 *             ? MergedProjectRedirectResponse::forMissingProject($e->getPrevious(), Project::class, app(ProjectSlugRedirectRecorder::class))
 *             : null);
 *
 * Goes through the site's own `RecordsProjectSlugRedirect` adapter
 * (`findBySourceProjectId()`) rather than querying a redirect model
 * directly — see that contract method's docblock for why.
 */
final class MergedProjectRedirectResponse
{
    /**
     * @param  class-string  $projectModel  the site's own Project model — only a
     *                                       "not found" for THIS model is ever a merge candidate.
     */
    public static function forMissingProject(ModelNotFoundException $missing, string $projectModel, RecordsProjectSlugRedirect $redirects): ?JsonResponse
    {
        if ($missing->getModel() !== $projectModel) {
            return null;
        }

        foreach ($missing->getIds() as $id) {
            $found = $redirects->findBySourceProjectId((int) $id);
            if ($found !== null) {
                return new JsonResponse([
                    'message' => 'This project was merged into "'.$found['project']->title.'".',
                    'moved_to' => [
                        'id' => $found['project']->getKey(),
                        'title' => $found['project']->title,
                        'anchor' => $found['anchor'],
                    ],
                ], 409);
            }
        }

        return null;
    }
}
