<?php

namespace SsSystems\Platform\Projects\Console;

use Closure;
use Illuminate\Console\Command;
use Illuminate\Database\Eloquent\Model;
use SsSystems\Platform\Projects\Contracts\RecordsProjectSlugRedirect;
use SsSystems\Platform\Projects\Contracts\RelocatesProjectOwnedRows;
use SsSystems\Platform\Projects\ProjectMerger;

/**
 * `php artisan projects:merge` — ported from jpeterson-design.com's
 * `App\Console\Commands\ProjectsMerge`. A site registers it with a one-line
 * subclass, exactly like every other kit console command
 * (`Http\Admin\Console\CacheAdminDomainsCommand`):
 *
 *     // app/Console/Commands/ProjectsMerge.php
 *     class ProjectsMerge extends \SsSystems\Platform\Projects\Console\MergeProjectsCommand
 *     {
 *         protected function projectModel(): string { return Project::class; }
 *         protected function defaultMergeType(): string { return 'full-home'; }
 *         protected function relocator(): RelocatesProjectOwnedRows { return new ProjectOwnedRowsRelocator(); }
 *         protected function slugRedirects(): RecordsProjectSlugRedirect { return new ProjectSlugRedirectRecorder(); }
 *     }
 *
 * See `docs/PROJECT-AREAS.md` for the full hook list, including the
 * optional `runQuietly()` a site with expensive model-save side effects
 * (gs.construction's sitemap regeneration) overrides.
 */
abstract class MergeProjectsCommand extends Command
{
    protected $signature = 'projects:merge
        {target : Project id or slug that everything folds into}
        {sources* : Project id(s) or slug(s) that become areas of the target}
        {--type= : The target\'s new project_type once merged; defaults to this site\'s own default}
        {--title= : The target\'s new title; omit to keep its current one}
        {--slug= : The target\'s new address (its old one redirects); omit to keep it}
        {--dry : Print the plan without changing anything}';

    protected $description = 'Fold one or more projects into another as areas of it';

    public function handle(): int
    {
        $projectModel = $this->projectModel();
        $targetIdentifier = (string) $this->argument('target');
        $target = ProjectMerger::resolveProject($projectModel, $targetIdentifier);

        if (! $target) {
            $this->error("No project found for target \"{$targetIdentifier}\".");

            return self::FAILURE;
        }

        /** @var array<int, string> $sourceIdentifiers */
        $sourceIdentifiers = $this->argument('sources');

        if (array_intersect([(string) $target->getKey(), $target->slug], $sourceIdentifiers) !== []) {
            $this->error('A project cannot be merged into itself.');

            return self::FAILURE;
        }

        $slug = $this->option('slug');
        if (filled($slug) && $slug !== $target->slug) {
            if (! preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/', $slug)) {
                $this->error('The slug may only hold lowercase letters, digits and single hyphens.');

                return self::FAILURE;
            }
            if (($projectModel)::query()->where('slug', $slug)->whereKeyNot($target->getKey())->exists()) {
                $this->error("Another project already uses the slug \"{$slug}\".");

                return self::FAILURE;
            }
        }

        $type = (string) ($this->option('type') ?: $this->defaultMergeType());
        $title = $this->option('title');

        $merger = new ProjectMerger(
            $target,
            $sourceIdentifiers,
            $type,
            $title,
            $this->relocator(),
            $this->slugRedirects(),
            $slug,
            $this->runQuietly(),
        );

        if ($this->option('dry')) {
            $this->printPlan($merger->plan(), $type, $title);

            return self::SUCCESS;
        }

        $this->printResult($merger->apply());

        return self::SUCCESS;
    }

    /** @return class-string<Model> the site's own Project model. */
    abstract protected function projectModel(): string;

    /** The site's own default --type when none is given on the command line (jpeterson-design: 'full-home'). */
    abstract protected function defaultMergeType(): string;

    abstract protected function relocator(): RelocatesProjectOwnedRows;

    abstract protected function slugRedirects(): RecordsProjectSlugRedirect;

    /**
     * Wraps the whole merge transaction — override when model-saving side
     * effects (an Observer regenerating a sitemap on every save, say)
     * should be suppressed for the duration, e.g.
     * `fn (Closure $work) => Model::withoutEvents($work)`. Null (the
     * default) runs the merge with no suppression — see `ProjectMerger`.
     *
     * @return ?Closure(Closure): mixed
     */
    protected function runQuietly(): ?Closure
    {
        return null;
    }

    /**
     * @param  array{target: Model, self_area_needed: bool, sources: array<int, array{identifier: string, project: ?Model, already_merged: bool}>}  $plan
     */
    protected function printPlan(array $plan, string $type, ?string $title): void
    {
        $target = $plan['target'];
        $this->line("Target: #{$target->getKey()} {$target->title} ({$target->slug})");
        $this->line('  -> project_type becomes "'.$type.'"'.($title ? ', title becomes "'.$title.'"' : ''));

        $slugOption = $this->option('slug');
        if (filled($slugOption) && $slugOption !== $target->slug) {
            $this->line('  -> address changes to slug "'.$slugOption.'"; '.$target->url().' redirects there');
        }

        $this->line($plan['self_area_needed']
            ? "  -> its own current facts (project_type \"{$target->project_type}\", description) become its own area — first merge into this target"
            : '  -> already has areas from an earlier merge; its own facts are not re-captured');

        $anyNew = false;
        foreach ($plan['sources'] as $entry) {
            if ($entry['already_merged']) {
                $this->line("  - {$entry['identifier']}: already merged, skipping");

                continue;
            }

            $anyNew = true;
            /** @var Model $source */
            $source = $entry['project'];
            $this->line("  - #{$source->getKey()} {$source->title} ({$source->slug}) -> area \"{$source->project_type}\", {$source->images()->count()} photo(s)");
            $this->line('      + '.$this->relocator()->describe($source));
            // The exact anchor (with any "-2" de-dup suffix) is decided at
            // merge time from the areas actually created, so this is the
            // plain slug — accurate unless two sources share one type.
            $this->line("      + slug \"{$source->slug}\" will redirect to {$target->url()}#area-{$source->project_type}");
        }

        if (! $anyNew) {
            $this->comment('Nothing to do — every source is already merged.');
        }

        $this->comment('Dry run — nothing was changed.');
    }

    /**
     * @param  array{target: Model, areas_created: int, sources: array<int, array<string, mixed>>}  $result
     */
    protected function printResult(array $result): void
    {
        $target = $result['target'];

        if ($result['areas_created'] === 0) {
            $this->comment("Nothing to do — {$target->title} is already merged with every given source.");

            return;
        }

        $this->info("Merged into #{$target->getKey()} {$target->title} ({$target->slug}): {$result['areas_created']} area(s) total.");

        foreach ($result['sources'] as $entry) {
            if ($entry['already_merged']) {
                $this->line("  - {$entry['identifier']}: already merged, skipped");

                continue;
            }

            /** @var Model $area */
            $area = $entry['area'];
            $this->line("  - {$entry['identifier']} -> area #{$area->getKey()} (\"{$area->anchor()}\"), {$entry['images_moved']} photo(s), ".$this->relocator()->describeMoved($entry));
        }
    }
}
