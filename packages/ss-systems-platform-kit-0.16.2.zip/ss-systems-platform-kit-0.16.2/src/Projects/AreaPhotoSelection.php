<?php

namespace SsSystems\Platform\Projects;

use Illuminate\Support\Collection;

/**
 * Which of a set of photos go to an AI drafter, and in what order: the
 * cover first (so the model sees the admin's best shot first), then the
 * rest by sort order, capped at a limit — the one piece of both
 * jpeterson-design.com's `GenerateAreaDescriptionJob::imageParts()` (an
 * area's own photos, $cover = that area's own `cover()`) and
 * `GenerateProjectDetailsJob::imageParts()` (a project's whole photo set,
 * $cover = that project's own `cover()`) that is pure selection logic with
 * no Storage read, no image decode/encode and no AI call in it (those
 * three stay per-site — see docs/PROJECT-AREAS.md / docs/PROJECT-DETAILS.md).
 * A site's job calls `choose()` to get the ordered, capped list, then does
 * its own disk-read/downscale/encode over it exactly as it already does
 * today. The name predates the project-details reuse; kept as-is rather
 * than renamed, since every adopting site already references it.
 */
final class AreaPhotoSelection
{
    /**
     * @param  iterable<object{id: mixed, sort_order: mixed}>  $images
     * @param  object{id: mixed}|null  $cover
     * @return Collection<int, object>
     */
    public static function choose(iterable $images, ?object $cover, int $limit): Collection
    {
        return collect($images)
            ->sortBy(fn (object $image) => [$cover && $image->id === $cover->id ? 0 : 1, $image->sort_order])
            ->take(max(0, $limit))
            ->values();
    }
}
