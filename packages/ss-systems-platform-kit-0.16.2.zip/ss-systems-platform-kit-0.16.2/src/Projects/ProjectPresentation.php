<?php

namespace SsSystems\Platform\Projects;

use Illuminate\Database\Eloquent\Model;

/**
 * How one project shows on a card listed under a given category.
 *
 * A project reaches a category two ways: directly (its own project_type)
 * or through one of its areas. Listed under its own category — or on an
 * unfiltered listing, like the portfolio — it presents as the whole
 * project: its own cover, its own title, its own page. Listed under a
 * category it reaches only through an area (e.g. a "Kitchens" service page
 * showing a project whose Kitchen is one room of a larger job), it presents
 * as that area: the area's own cover, a title naming both the project and
 * the area, and a link to that area's section of the project's page.
 *
 * Built by `Concerns\HasProjectAreas::presentFor()` — every card that
 * renders a project listed under a category should go through it, so the
 * two can never disagree about which projects present as areas.
 *
 * $project and $area are left as plain `Model` — never a kit-owned Project/
 * ProjectArea class — so this class never has to know a site's own model
 * namespace. In practice $project is the site's own Project model (`use`s
 * `Concerns\HasProjectAreas`, and already has its own `title`, `project_type`,
 * `cover(): ?Model` and `url(): string`) and $area, when given, its own
 * ProjectArea (`use`s `Concerns\IsProjectArea`, giving `heading()`,
 * `cover()`, `typeLabel()` and `anchor()`).
 */
final class ProjectPresentation
{
    private function __construct(
        public readonly Model $project,
        public readonly ?Model $area,
    ) {}

    public static function wholeProject(Model $project): self
    {
        return new self($project, null);
    }

    public static function forArea(Model $project, Model $area): self
    {
        return new self($project, $area);
    }

    public function isArea(): bool
    {
        return $this->area !== null;
    }

    /** "Inverness Full-Home Remodel — Kitchen" for an area; the plain project title otherwise. */
    public function title(): string
    {
        return $this->area ? $this->project->title.' — '.$this->area->heading() : $this->project->title;
    }

    /** The area's own cover when presenting an area, else the whole project's. */
    public function cover(): ?Model
    {
        return $this->area ? $this->area->cover() : $this->project->cover();
    }

    /** The category label a "towns"-less caption shows: the area's, else the project's own. */
    public function typeLabel(): string
    {
        return $this->area ? $this->area->typeLabel() : $this->project->typeLabel();
    }

    /** The project's page, with the area's section anchor appended when presenting an area. */
    public function url(): string
    {
        return $this->area ? $this->project->url().'#'.$this->area->anchor() : $this->project->url();
    }
}
