<?php

namespace SsSystems\Platform\Projects\Concerns;

/**
 * One merged-away (or renamed-away) project slug, pointing at the project —
 * and, when relevant, that project's section anchor — it now lives at. The
 * using class (the site's own redirect model, e.g. `ProjectSlugRedirect`)
 * keeps its own `project(): BelongsTo` relation and its own `anchor`
 * attribute; this trait only needs those two things to exist.
 *
 * Entirely optional: a site whose own `Contracts\RecordsProjectSlugRedirect`
 * adapter doesn't store redirects this way (gs.construction's
 * `ProjectSlugHistory` has no anchor column and resolves full paths, not a
 * single project url, at request time) has no use for it.
 */
trait IsProjectSlugRedirect
{
    /** Where a visitor to the old slug should land: the target project's page, with the anchor appended when there is one. */
    public function url(): string
    {
        $url = $this->project->url();

        return $this->anchor ? $url.'#'.$this->anchor : $url;
    }
}
