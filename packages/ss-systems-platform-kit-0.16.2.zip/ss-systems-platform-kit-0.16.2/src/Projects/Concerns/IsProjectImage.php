<?php

namespace SsSystems\Platform\Projects\Concerns;

/**
 * The category a single photo belongs to, and a query scope for finding
 * photos "of" a category — the photo-level counterpart to
 * `HasProjectAreas::scopeOfType()`'s project-level answer. A project-level
 * "ofType" is deliberately too coarse for an image picker (a hero/OG/cover
 * image pool, gs.construction's `ProjectImage::curatedCovers($type)`): it
 * would happily hand back a Mudroom photo from a project whose Kitchen area
 * also matches the requested category. This trait answers at the photo's
 * own granularity instead.
 *
 * The using class (the site's own ProjectImage model) keeps its own, thin
 * `area(): BelongsTo` and `project(): BelongsTo` relations and its own
 * `project_area_id` column (resources/stubs/projects/
 * add_project_area_id_to_project_images_table.php.stub) — this trait only
 * ever calls those two relations by name, never a hardcoded related class.
 */
trait IsProjectImage
{
    /** This photo's own category: its area's project_type when it belongs to one, else its project's own. */
    public function categoryType(): ?string
    {
        return $this->area?->project_type ?? $this->project?->project_type;
    }

    /**
     * Photos belonging to category $type: through their OWN area, or, for
     * an area-less photo, through its project's own project_type. Never a
     * photo whose only connection to $type is that some OTHER area of the
     * same project happens to be that category.
     *
     * @param  \Illuminate\Database\Eloquent\Builder<static>  $query
     * @return \Illuminate\Database\Eloquent\Builder<static>
     */
    public function scopeOfType($query, string $type)
    {
        return $query->where(function ($q) use ($type) {
            $q->whereHas('area', fn ($area) => $area->where('project_type', $type))
                ->orWhere(function ($q2) use ($type) {
                    $q2->whereNull('project_area_id')
                        ->whereHas('project', fn ($project) => $project->where('project_type', $type));
                });
        });
    }
}
