<?php

namespace SsSystems\Platform\Projects\Concerns;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

/**
 * One area of a Project — see `HasProjectAreas`'s docblock for the feature
 * as a whole. Ported from jpeterson-design.com's `App\Models\ProjectArea`
 * (2026-09-30, project-areas; cover_image_id addendum 2026-10-01).
 *
 * The using class (the site's own ProjectArea model) keeps its own, thin
 * relations — `project(): BelongsTo`, `images(): HasMany`, `coverImage():
 * BelongsTo` — exactly as it already does today; this trait never needs to
 * know their related classes by name, only that `images` resolves to a
 * collection of rows shaped like the project-areas contract's "images"
 * entries (id, is_cover, sort_order, url) and that the table has
 * `project_id`/`project_type`/`title`/`description`/`sort_order`/
 * `cover_image_id` columns (see resources/stubs/projects/
 * create_project_areas_table.php.stub and the cover_image_id stub). It must
 * implement:
 *
 *     protected function projectTypeLabel(string $type): string
 *     {
 *         return Project::projectTypes()[$type] ?? ProjectTypeLabels::fallback($type);
 *     }
 *
 *     protected function descriptionStatus(): array
 *     {
 *         return GenerateAreaDescriptionJob::status($this); // or AreaDescriptionStatus::status($this) directly
 *     }
 */
trait IsProjectArea
{
    /**
     * The image this area leads with: the admin-chosen `cover_image_id`,
     * when it still belongs to this area, else the area's `is_cover` image,
     * else its first by sort order. Reads the already-loaded `images`
     * relation (never a fresh query), so "still belongs to this area" falls
     * out for free: an image reassigned elsewhere simply isn't in the
     * collection any more.
     */
    public function cover(): ?Model
    {
        if ($this->cover_image_id) {
            $chosen = $this->images->firstWhere('id', $this->cover_image_id);
            if ($chosen) {
                return $chosen;
            }
        }

        return $this->images->firstWhere('is_cover', true) ?? $this->images->first();
    }

    /**
     * Clear $projectId's areas' chosen cover wherever it currently points
     * at one of $imageIds, except $exceptAreaId (the images' own new area,
     * if any) — called whenever a photo leaves the area that chose it as
     * cover: reassigned to another area, to the project as a whole, or
     * moved to another project outright.
     *
     * @param  array<int, int>  $imageIds
     */
    public static function clearStaleCovers(int $projectId, array $imageIds, ?int $exceptAreaId = null): void
    {
        if ($imageIds === []) {
            return;
        }

        static::query()
            ->where('project_id', $projectId)
            ->when($exceptAreaId !== null, fn ($query) => $query->where('id', '!=', $exceptAreaId))
            ->whereIn('cover_image_id', $imageIds)
            ->update(['cover_image_id' => null]);
    }

    /** The service label for this area's category. */
    public function typeLabel(): string
    {
        return $this->projectTypeLabel((string) $this->project_type);
    }

    /** What the project page prints as this area's section heading: the admin-entered title, else the category's label. */
    public function heading(): string
    {
        return $this->title ?: $this->typeLabel();
    }

    /**
     * This area's stable anchor id on its project's page, e.g. "area-kitchen".
     * De-duplicated across sibling areas of the same project_type (an edge
     * case nothing prevents at the data level): the first area of a type
     * keeps the plain slug, later ones get "-2", "-3"...
     */
    public function anchor(): string
    {
        $base = 'area-'.Str::slug((string) $this->project_type);

        $siblingIds = static::query()
            ->where('project_id', $this->project_id)
            ->where('project_type', $this->project_type)
            ->orderBy('sort_order')
            ->orderBy('id')
            ->pluck('id')
            ->all();

        $position = array_search($this->id, $siblingIds, true);

        return $position > 0 ? $base.'-'.($position + 1) : $base;
    }

    /**
     * Shape embedded in the site's Project::toApiArray() "areas" list — see
     * the project-areas admin-API contract. Callers should eager-load
     * 'areas.images' (or at least this area's 'images') to avoid an N+1 on
     * cover()/image_count.
     *
     * @return array<string, mixed>
     */
    public function toApiArray(): array
    {
        return [
            'id' => $this->id,
            'project_type' => $this->project_type,
            'type_label' => $this->typeLabel(),
            'title' => $this->title,
            'description' => $this->description,
            'sort_order' => $this->sort_order,
            'cover_image_id' => $this->cover_image_id,
            'cover_url' => $this->cover()?->url,
            'image_count' => $this->images->count(),
            'details' => $this->descriptionStatus(),
        ];
    }

    /** The label for category slug $type — Project::projectTypes()[$type], falling back to ProjectTypeLabels::fallback(). */
    abstract protected function projectTypeLabel(string $type): string;

    /** @return array{generating: bool, error: ?string} this area's AI-description draft status — see AreaDescriptionStatus. */
    abstract protected function descriptionStatus(): array;
}
