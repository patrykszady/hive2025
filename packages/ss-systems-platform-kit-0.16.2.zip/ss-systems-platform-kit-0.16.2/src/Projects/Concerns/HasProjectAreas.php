<?php

namespace SsSystems\Platform\Projects\Concerns;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use SsSystems\Platform\Projects\Contracts\RecordsProjectSlugRedirect;
use SsSystems\Platform\Projects\ProjectPresentation;

/**
 * One real job (a Project) split into areas — Kitchen, Mudroom, Living
 * Space… — each with its own category (project_type), optional heading and
 * description, and its own photos. A project belongs to its own
 * project_type AND every one of its areas' (scopeOfType()/belongsToType()),
 * and a card listed under a category it reaches only through an area
 * presents as that area, not the whole project (presentFor(), see
 * `ProjectPresentation`).
 *
 * Ported from jpeterson-design.com's `App\Models\Project` (2026-09-30,
 * project-areas) — see docs/PROJECT-AREAS.md for the adoption steps. The
 * using class (the site's own Project model) must implement:
 *
 *     protected function projectAreaModel(): string
 *     {
 *         return ProjectArea::class; // the site's own model, `use`ing IsProjectArea
 *     }
 *
 *     protected function projectSlugRedirects(): RecordsProjectSlugRedirect
 *     {
 *         return new ProjectSlugRedirectRecorder(); // the site's own adapter
 *     }
 *
 * and already needs its own `project_type` column, its own `slug` column,
 * and (unrelated to this trait, kept per-site business logic) its own
 * `cover()`/`url()`/`typeLabel()`/`projectTypes()`.
 *
 * `bootHasProjectAreas()` runs automatically — Eloquent calls `boot{Trait}`
 * for every trait a model uses, the same mechanism `Illuminate\Database\
 * Eloquent\SoftDeletes` relies on — so a consuming model needs no `booted()`
 * override of its own just to pick up the slug-rename-keeps-working hook.
 * A model with its OWN `booted()` method (as every site's Project already
 * has, for slug generation and cascade-deleting children) is unaffected:
 * `booted()` and `boot{Trait}()` are both called by Eloquent's own `boot()`,
 * never one instead of the other.
 */
trait HasProjectAreas
{
    public static function bootHasProjectAreas(): void
    {
        static::updated(function (Model $project) {
            $old = (string) $project->getOriginal('slug');
            if (! $project->wasChanged('slug') || $old === '' || $old === $project->slug) {
                return;
            }

            $project->projectSlugRedirects()->recordRedirectIfAbsent($old, $project);
        });
    }

    /**
     * This project's areas, in admin order. The foreign key is spelled out
     * explicitly ('project_id', matching resources/stubs/projects/
     * create_project_areas_table.php.stub) rather than left to Eloquent's
     * convention — that convention is keyed off the DECLARING class's own
     * name (`Str::snake(class_basename(static::class)).'_id'`), which only
     * happens to come out as "project_id" because every adopting site
     * names its own class `Project`; spelling it out keeps that an
     * intentional fact of the schema, not an accident of a class name.
     */
    public function areas(): HasMany
    {
        return $this->hasMany($this->projectAreaModel(), 'project_id')->orderBy('sort_order')->orderBy('id');
    }

    /**
     * The one rule for "does this project belong to category $type": its
     * own project_type, OR any of its areas' project_type. Every
     * public-facing and content-generation read that used to filter
     * projects by a bare `where('project_type', …)` should go through this
     * scope, so a project reaches a category through an area exactly the
     * same way it reaches one directly — see belongsToType() for the
     * in-memory equivalent on an already-loaded model.
     *
     * @param  Builder<static>  $query
     * @return Builder<static>
     */
    public function scopeOfType(Builder $query, string $type): Builder
    {
        return $query->where(function (Builder $q) use ($type) {
            $q->where('project_type', $type)
                ->orWhereHas('areas', fn (Builder $areas) => $areas->where('project_type', $type));
        });
    }

    /**
     * Every category slug this project belongs to: its own project_type
     * plus each of its areas' — the in-memory equivalent of scopeOfType(),
     * for a project already loaded (with 'areas') rather than a fresh
     * query.
     *
     * @return array<int, string>
     */
    public function types(): array
    {
        return $this->areas->pluck('project_type')
            ->push($this->project_type)
            ->filter()
            ->unique()
            ->values()
            ->all();
    }

    /** Does this project belong to category $type — directly, or through one of its areas? */
    public function belongsToType(string $type): bool
    {
        return in_array($type, $this->types(), true);
    }

    /**
     * How this project should present on a card listed under category
     * $type: itself, when $type is its own project_type (or null — an
     * unfiltered listing, e.g. the portfolio), or the matching area's
     * cover/heading when it reaches that category only through an area.
     */
    public function presentFor(?string $type): ProjectPresentation
    {
        if ($type === null || $type === $this->project_type) {
            return ProjectPresentation::wholeProject($this);
        }

        $area = $this->areas->firstWhere('project_type', $type);

        return $area ? ProjectPresentation::forArea($this, $area) : ProjectPresentation::wholeProject($this);
    }

    /**
     * The "areas" array embedded in the site's own Project::toApiArray() —
     * see the project-areas admin-API contract. Callers should eager-load
     * 'areas.images' to avoid an N+1 on each area's cover()/image_count.
     *
     * @return array<int, array<string, mixed>>
     */
    public function areasApiPayload(): array
    {
        return $this->areas->map(fn (Model $area) => $area->toApiArray())->all();
    }

    /** @return class-string<Model> the site's own ProjectArea model (`use`s Concerns\IsProjectArea). */
    abstract protected function projectAreaModel(): string;

    /** The site's own adapter recording that an old slug now redirects elsewhere — see Contracts\RecordsProjectSlugRedirect. */
    abstract protected function projectSlugRedirects(): RecordsProjectSlugRedirect;
}
