<?php

namespace SsSystems\Platform\Projects;

/**
 * The "required, unless this is a partial update" presence pair every
 * site's own `ProjectController::rules($ignoreId, $partial)` repeats per
 * field — ported from jpeterson-design.com's own `$presence = $partial ?
 * 'sometimes' : 'required';` plus the literal `'required'` rule that
 * follows it in the same array.
 *
 * The two rules stacked together are the whole trick: 'sometimes' means
 * "only validate if the key is present at all" (so a partial update that
 * never resends, say, "title" leaves it untouched); the literal 'required'
 * that follows still 422s a key that WAS sent but empty — "sent but blank"
 * is refused on a partial update exactly as it is on a full one. On a
 * non-partial request the pair is `['required', 'required']`, redundant
 * but harmless (same as jpeterson-design's own non-partial branch).
 *
 * Usage, in a site's own `rules()`:
 *
 *     'title' => [...PartialUpdateRules::presence($partial), 'string', 'max:255'],
 */
final class PartialUpdateRules
{
    /** @return array{0: 'sometimes'|'required', 1: 'required'} */
    public static function presence(bool $partial): array
    {
        return [$partial ? 'sometimes' : 'required', 'required'];
    }
}
