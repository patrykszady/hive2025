<?php

namespace SsSystems\Platform\Projects;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;

/**
 * The cache-backed "is this area's AI description draft running, and did
 * it fail" status every per-area description job rides — ported from
 * jpeterson-design.com's `App\Jobs\GenerateAreaDescriptionJob`'s own
 * flagKey()/errorKey()/status()/launch() (2026-10-01 addendum). Kept
 * separate from the job itself (which stays per-site — see
 * docs/PROJECT-AREAS.md for why the actual AI call does not move here):
 * this class is the one piece of that job that is pure cache bookkeeping,
 * identical on every site.
 *
 * `status()` is what `Concerns\IsProjectArea::toApiArray()`'s "details" key
 * reads through the site's own `descriptionStatus()` hook; `markGenerating()`/
 * `recordError()`/`clearGenerating()` are what the site's own job calls
 * (flag before dispatch, clear in a `finally`, record on failure) so every
 * site's cache keys — and therefore the admin's polling — line up exactly.
 */
final class AreaDescriptionStatus
{
    public static function flagKey(int $areaId): string
    {
        return "project-areas.description-generating.{$areaId}";
    }

    public static function errorKey(int $areaId): string
    {
        return "project-areas.description-error.{$areaId}";
    }

    /** @return array{generating: bool, error: ?string} */
    public static function status(Model $area): array
    {
        return [
            'generating' => Cache::has(self::flagKey((int) $area->getKey())),
            'error' => Cache::get(self::errorKey((int) $area->getKey())),
        ];
    }

    /**
     * Flag first, dispatch after the response — the site's own job calls
     * this, then dispatches itself (`dispatchAfterResponse`/`afterResponse()`
     * — the kit never dispatches a site's job for it).
     */
    public static function markGenerating(Model $area): void
    {
        $id = (int) $area->getKey();
        Cache::forget(self::errorKey($id));
        Cache::put(self::flagKey($id), now()->toDateTimeString(), now()->addMinutes(10));
    }

    public static function recordError(int $areaId, string $message): void
    {
        Cache::put(self::errorKey($areaId), $message, now()->addDay());
    }

    public static function clearGenerating(int $areaId): void
    {
        Cache::forget(self::flagKey($areaId));
    }
}
