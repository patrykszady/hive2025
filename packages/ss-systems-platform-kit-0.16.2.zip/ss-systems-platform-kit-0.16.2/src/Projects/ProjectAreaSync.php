<?php

namespace SsSystems\Platform\Projects;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Validation\Rule;

/**
 * The project-areas admin-API contract's "areas" key on `PUT projects/{id}`:
 * a whole-list sync, in order — a row carrying the id of one of the
 * project's own areas updates it; without one (or with an id that isn't one
 * of this project's own areas) creates a new one; any existing area not
 * present in the list is deleted, its images becoming area-less
 * (never deleted themselves). Ported verbatim from jpeterson-design.com's
 * `ProjectController::syncAreas()`/`pullAreas()` — $project is a plain
 * `Model` (the site's own Project, `use`s `Concerns\HasProjectAreas`); this
 * class only ever calls its `areas()`/`images()` relations, never a
 * hardcoded model class.
 */
final class ProjectAreaSync
{
    /**
     * null when "areas" was absent from $rows's source payload — an update
     * must leave existing areas alone; an explicit [] clears them.
     *
     * @param  array<string, mixed>  $data  mutated by reference: "areas" is removed either way
     * @return array<int, array<string, mixed>>|null
     */
    public static function pull(array &$data): ?array
    {
        $rows = array_key_exists('areas', $data) ? ($data['areas'] ?? []) : null;
        unset($data['areas']);

        return $rows;
    }

    /**
     * Replace $project's area list with $rows, in order. A no-op when $rows
     * is null (the key was absent from the update payload).
     *
     * @param  array<int, array{id?: int, project_type: string, title?: ?string, description?: ?string}>|null  $rows
     */
    public static function apply(Model $project, ?array $rows): void
    {
        if ($rows === null) {
            return;
        }

        $existing = $project->areas()->get();
        $keep = [];

        foreach (array_values($rows) as $i => $row) {
            $attrs = [
                'project_type' => $row['project_type'],
                'title' => filled($row['title'] ?? null) ? trim((string) $row['title']) : null,
                'description' => filled($row['description'] ?? null) ? trim((string) $row['description']) : null,
                'sort_order' => $i,
            ];

            $area = isset($row['id']) ? $existing->firstWhere('id', (int) $row['id']) : null;
            if ($area) {
                $area->update($attrs);
            } else {
                $area = $project->areas()->create($attrs);
            }

            $keep[] = $area->getKey();
        }

        $removedIds = $existing->whereNotIn('id', $keep)->pluck('id');
        if ($removedIds->isNotEmpty()) {
            $project->images()->whereIn('project_area_id', $removedIds)->update(['project_area_id' => null]);
            $project->areas()->whereIn('id', $removedIds)->delete();
        }
    }

    /**
     * The "areas.*" validation rules for the site's own project update Form
     * Request / inline `rules()` to merge in.
     *
     * @param  array<int, string>  $projectTypeKeys  array_keys(Project::projectTypes())
     * @return array<string, array<int, mixed>>
     */
    public static function validationRules(array $projectTypeKeys): array
    {
        return [
            'areas' => ['sometimes', 'nullable', 'array'],
            'areas.*.id' => ['sometimes', 'integer'],
            'areas.*.project_type' => ['required', 'string', Rule::in($projectTypeKeys)],
            'areas.*.title' => ['nullable', 'string', 'max:255'],
            'areas.*.description' => ['nullable', 'string', 'max:10000'],
        ];
    }

    /**
     * The "area_id" validation rule for the site's own photo-upload
     * endpoint: null/absent leaves the photo belonging to the project as a
     * whole; given, it must be one of THIS project's own areas.
     *
     * @return array<int, mixed>
     */
    public static function imageAreaIdRule(Model $project): array
    {
        return ['sometimes', 'nullable', 'integer', Rule::exists($project->areas()->getRelated()->getTable(), 'id')->where('project_id', $project->getKey())];
    }
}
