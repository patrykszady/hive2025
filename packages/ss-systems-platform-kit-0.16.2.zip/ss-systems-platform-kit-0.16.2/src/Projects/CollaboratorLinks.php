<?php

namespace SsSystems\Platform\Projects;

use Illuminate\Support\HtmlString;

/**
 * A project's written text with every collaborator who has a website
 * linked by name — "Jennifer Peterson worked with GS Construction on this
 * project." links GS Construction, the same way a project page's "Worked
 * with" line does. The text is escaped first; only those names become
 * links. Ported verbatim from jpeterson-design.com's `App\Support\Projects\
 * CollaboratorLinks` — zero site-specific logic, so there was nothing to
 * hook: any `iterable` of objects exposing `name`/`url` works (the site's
 * own collaborator model, e.g. `ProjectCollaborator`).
 */
class CollaboratorLinks
{
    /**
     * @param  iterable<object{name: ?string, url: ?string}>  $collaborators
     */
    public static function linkify(string $text, iterable $collaborators): HtmlString
    {
        $html = e($text);

        // Longest names first, so "Victoria Renovations Group" is not
        // half-linked as "Victoria Renovations".
        $linkable = collect($collaborators)
            ->filter(fn ($c) => filled($c->name) && self::safeUrl($c->url) !== null)
            ->sortByDesc(fn ($c) => mb_strlen((string) $c->name))
            ->values();

        $anchors = [];
        foreach ($linkable as $i => $collaborator) {
            $name = e((string) $collaborator->name);
            $html = preg_replace_callback('/(?<![\pL\pN])'.preg_quote($name, '/').'(?![\pL\pN])/u', function (array $match) use (&$anchors, $collaborator, $i): string {
                $anchors[$i] = '<a href="'.e(self::safeUrl($collaborator->url)).'" target="_blank" rel="noopener" class="underline underline-offset-4 transition hover:text-brand-700">'.$match[0].'</a>';

                return "\u{0}{$i}\u{0}";
            }, $html) ?? $html;
        }

        foreach ($anchors as $i => $anchor) {
            $html = str_replace("\u{0}{$i}\u{0}", $anchor, $html);
        }

        return new HtmlString($html);
    }

    /** Only a plain web address is ever linked. */
    protected static function safeUrl(?string $url): ?string
    {
        $url = trim((string) $url);

        return preg_match('#^https?://#i', $url) ? $url : null;
    }
}
