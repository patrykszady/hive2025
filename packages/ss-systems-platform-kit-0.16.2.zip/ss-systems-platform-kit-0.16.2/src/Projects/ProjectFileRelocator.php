<?php

namespace SsSystems\Platform\Projects;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Storage;

/**
 * Carries a project photo's original and every rendition into another
 * project's folder, keeping names unless one is taken — the file-moving
 * half of jpeterson-design.com's `App\Support\Projects\ImageMover`
 * (`relocateFiles()`), pulled out on its own because `ProjectMerger` needs
 * it too (folding a merged-away project's photos into the target) and the
 * rest of `ImageMover` (creating a draft project, reassigning covers after
 * a same-site move) is a distinct, still-per-site feature — see
 * docs/PROJECT-AREAS.md.
 *
 * $image and $target are plain `Model`: this only ever reads `disk`,
 * `project_id`, `path`, `thumbnails`, `id` off $image and `id` off $target,
 * exactly the columns resources/stubs/projects/
 * add_project_area_id_to_project_images_table.php.stub's sibling
 * (project_images itself) already has on every adopting site.
 */
final class ProjectFileRelocator
{
    public static function relocate(Model $image, Model $target): void
    {
        $disk = Storage::disk($image->disk ?? 'public');
        $from = 'projects/'.$image->project_id.'/';
        $to = 'projects/'.$target->getKey().'/';

        $suffix = '';
        $newPath = $to.basename($image->path);
        if ($disk->exists($newPath)) {
            $suffix = '-m'.$image->getKey();
            $newPath = $to.self::withSuffix(basename($image->path), $suffix);
        }

        if ($disk->exists($image->path)) {
            $disk->move($image->path, $newPath);
        }

        $thumbnails = [];
        foreach ($image->thumbnails ?? [] as $key => $path) {
            $relative = str_starts_with($path, $from) ? substr($path, strlen($from)) : basename($path);
            $dir = dirname($relative) === '.' ? '' : dirname($relative).'/';
            $newThumb = $to.$dir.self::withSuffix(basename($relative), $suffix);
            if ($disk->exists($path)) {
                $disk->move($path, $newThumb);
            }
            $thumbnails[$key] = $newThumb;
        }

        $image->forceFill([
            'path' => $newPath,
            'filename' => basename($newPath),
            'thumbnails' => $thumbnails ?: $image->thumbnails,
        ]);
    }

    private static function withSuffix(string $filename, string $suffix): string
    {
        if ($suffix === '') {
            return $filename;
        }

        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $name = pathinfo($filename, PATHINFO_FILENAME);

        return $ext !== '' ? "{$name}{$suffix}.{$ext}" : "{$name}{$suffix}";
    }
}
