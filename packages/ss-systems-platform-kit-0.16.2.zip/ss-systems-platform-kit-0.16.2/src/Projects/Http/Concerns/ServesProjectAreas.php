<?php

namespace SsSystems\Platform\Projects\Http\Concerns;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

/**
 * The per-area admin-API endpoints that don't ride the plain `projects`
 * resource — ported from jpeterson-design.com's `ProjectAreaController`
 * plus `ProjectImageController::assignArea()`. See
 * `routes/api-admin/project-areas.php`'s own docblock in jpeterson-design
 * for the route list and the project-areas admin-API contract (`docs/
 * PROJECT-AREAS.md`) for the exact payload/status-code shape every one of
 * these must keep.
 *
 * A consuming controller already `use`s the kit's `Http\Admin\Concerns\
 * BuildsApiResponses` (every site's admin controller does) — this trait
 * calls `$this->itemResponse()`/`$this->acceptedResponse()` on it rather
 * than pulling it in a second time, same as `Pages\Http\Concerns\
 * ServesPages`. It must also implement:
 *
 *     protected function projectModel(): string { return Project::class; }
 *     protected function projectAreaModel(): string { return ProjectArea::class; }
 *     protected function projectTypeKeys(): array { return array_keys(Project::projectTypes()); }
 *     protected function projectAreaPayload(Model $project): array
 *     {
 *         // the site's own eager-load list + any extra fields layered onto
 *         // toApiArray() (gs.construction's withCrmFields()) — exactly what
 *         // ProjectController's OWN update()/show() already return.
 *         return $this->withCrmFields($project->fresh(['images.tags', 'areas.images', 'testimonials'])->toApiArray(), $project);
 *     }
 *     protected function launchAreaDescriptionDraft(Model $area): void { GenerateAreaDescriptionJob::launch($area); }
 */
trait ServesProjectAreas
{
    /**
     * POST projects/{project}/areas — a new area, last in order, holding
     * the given photos straight away (the admin's "New area…" when
     * assigning selected photos). Only the new area and those photos
     * change; the project's other fields and areas are left as they are.
     */
    public function storeArea(Request $request, int $project): JsonResponse
    {
        $model = ($this->projectModel())::findOrFail($project);

        $data = $request->validate([
            'project_type' => ['required', 'string', Rule::in($this->projectTypeKeys())],
            'title' => ['nullable', 'string', 'max:255'],
            'image_ids' => ['sometimes', 'array'],
            'image_ids.*' => ['integer', Rule::exists($model->images()->getRelated()->getTable(), 'id')->where('project_id', $model->getKey())],
        ]);

        $imageIds = array_values(array_unique(array_map('intval', $data['image_ids'] ?? [])));

        DB::transaction(function () use ($model, $data, $imageIds): void {
            $area = $model->areas()->create([
                'project_type' => $data['project_type'],
                'title' => $data['title'] ?? null,
                'sort_order' => (int) $model->areas()->max('sort_order') + 1,
            ]);

            if ($imageIds !== []) {
                ($this->projectAreaModel())::clearStaleCovers($model->getKey(), $imageIds, $area->getKey());
                $model->images()->whereIn('id', $imageIds)->update(['project_area_id' => $area->getKey()]);
            }
        });

        return $this->itemResponse($this->projectAreaPayload($model), 201);
    }

    /**
     * PUT projects/{project}/areas/{area}/cover — set (or, with a null
     * image_id, clear back to the automatic choice) this area's own cover
     * photo. The image must already belong to this area.
     */
    public function updateAreaCover(Request $request, int $project, int $area): JsonResponse
    {
        $model = ($this->projectModel())::findOrFail($project);
        $projectArea = $model->areas()->findOrFail($area);

        $data = $request->validate([
            'image_id' => ['nullable', 'integer', Rule::exists($model->images()->getRelated()->getTable(), 'id')->where('project_area_id', $projectArea->getKey())],
        ]);

        $projectArea->update(['cover_image_id' => $data['image_id'] ?? null]);

        return $this->itemResponse($this->projectAreaPayload($model));
    }

    /**
     * POST projects/{project}/areas/{area}/generate-description — draft
     * this area's description from its own photos. 202 at once; the admin
     * polls the area's `details` block (inside the project payload's
     * "areas" list) until `generating` clears. Refuses when the area has no
     * photos yet — there would be nothing to show the model.
     */
    public function generateAreaDescription(int $project, int $area): JsonResponse
    {
        $model = ($this->projectModel())::findOrFail($project);
        $projectArea = $model->areas()->with('images')->findOrFail($area);

        if ($projectArea->images->isEmpty()) {
            return new JsonResponse(['message' => 'This area has no photos yet.'], 422);
        }

        $this->launchAreaDescriptionDraft($projectArea);

        return $this->acceptedResponse(['generating' => true]);
    }

    /**
     * POST projects/{project}/images/area — assign (or, with a null
     * area_id, unassign) a batch of this project's own photos to one of
     * its areas.
     *
     * A photo that leaves the area that had chosen it as its cover
     * (reassigned to another area, or back to the project as a whole)
     * clears that cover first — see `Concerns\IsProjectArea::
     * clearStaleCovers()`.
     */
    public function assignImagesToArea(Request $request, int $project): JsonResponse
    {
        $model = ($this->projectModel())::findOrFail($project);

        $data = $request->validate([
            'image_ids' => ['required', 'array', 'min:1'],
            'image_ids.*' => ['integer'],
            'area_id' => ['nullable', 'integer', Rule::exists($model->areas()->getRelated()->getTable(), 'id')->where('project_id', $model->getKey())],
        ]);

        $imageIds = array_map('intval', $data['image_ids']);
        $matched = $model->images()->whereIn('id', $imageIds)->pluck('id');
        if ($matched->count() !== count(array_unique($imageIds))) {
            throw ValidationException::withMessages(['image_ids' => 'Every photo must belong to this project.']);
        }

        $newAreaId = $data['area_id'] ?? null;
        ($this->projectAreaModel())::clearStaleCovers($model->getKey(), $imageIds, $newAreaId);
        $model->images()->whereIn('id', $imageIds)->update(['project_area_id' => $newAreaId]);

        return $this->itemResponse($this->projectAreaPayload($model));
    }

    /** @return class-string<Model> the site's own Project model. */
    abstract protected function projectModel(): string;

    /** @return class-string<Model> the site's own ProjectArea model (`use`s Concerns\IsProjectArea). */
    abstract protected function projectAreaModel(): string;

    /** @return array<int, string> array_keys(Project::projectTypes()). */
    abstract protected function projectTypeKeys(): array;

    /**
     * The final response payload after any of this trait's actions — the
     * site's own eager-load list plus whatever it layers onto
     * toApiArray() (gs.construction's withCrmFields()).
     *
     * @return array<string, mixed>
     */
    abstract protected function projectAreaPayload(Model $project): array;

    /** Flags and queues the area's AI description draft — e.g. `GenerateAreaDescriptionJob::launch($area)`. */
    abstract protected function launchAreaDescriptionDraft(Model $area): void;
}
