<?php

namespace SsSystems\Platform\Projects\Http\Concerns;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * `POST projects/{project}/generate-details` — the photos-first create
 * flow's one server-side action. Ported from jpeterson-design.com's
 * `ProjectController::generateDetails()`. A consuming controller already
 * `use`s the kit's `Http\Admin\Concerns\BuildsApiResponses` — this trait
 * calls `$this->acceptedResponse()` on it rather than pulling it in a
 * second time, same as `Projects\Http\Concerns\ServesProjectAreas`. It
 * must also implement:
 *
 *     protected function findProjectForDetails(int $project): Model
 *     {
 *         // whatever YOUR payload needs eager-loaded — must include 'images'
 *         // at minimum, for the no-photos-yet check below.
 *         return Project::with(['images.tags', 'testimonials', 'collaborators'])->findOrFail($project);
 *     }
 *
 *     protected function projectDetailsPayload(Model $project): array
 *     {
 *         return $this->withCrmFields($project->toApiArray(), $project); // or just toApiArray()
 *     }
 *
 *     protected function launchProjectDetailsDraft(Model $project, bool $force): void
 *     {
 *         GenerateProjectDetailsJob::launch($project, $force);
 *     }
 */
trait ServesProjectDetails
{
    public function generateDetails(Request $request, int $project): JsonResponse
    {
        $model = $this->findProjectForDetails($project);

        if ($model->images->isEmpty()) {
            return new JsonResponse(['message' => 'Add at least one photo before generating the details.'], 422);
        }

        // force: rewrite even where a title/description already exists
        // (the admin's "Try again" after editing the facts).
        $this->launchProjectDetailsDraft($model, $request->boolean('force'));

        return $this->acceptedResponse($this->projectDetailsPayload($model));
    }

    /** @return Model with at least 'images' eager-loaded */
    abstract protected function findProjectForDetails(int $project): Model;

    /** @return array<string, mixed> */
    abstract protected function projectDetailsPayload(Model $project): array;

    abstract protected function launchProjectDetailsDraft(Model $project, bool $force): void;
}
