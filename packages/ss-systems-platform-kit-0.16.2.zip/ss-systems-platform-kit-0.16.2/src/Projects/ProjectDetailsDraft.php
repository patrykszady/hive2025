<?php

namespace SsSystems\Platform\Projects;

use Illuminate\Database\Eloquent\Model;

/**
 * The two rules every site's own "photos-first" details job applies once
 * it has a drafted {title, description} in hand — ported from
 * jpeterson-design.com's `App\Jobs\GenerateProjectDetailsJob::handle()`:
 *
 * - a placeholder title (or an explicit `--force`/"Try again") is replaced
 *   by the draft, and ONLY then does the slug get regenerated to match —
 *   a real, admin-given title/slug is never touched by a re-run that
 *   wasn't forced;
 * - a blank description (or force) is filled; a real one is left alone.
 *
 * `project_type` is deliberately not handled here: jpeterson-design's own
 * job never takes it from the model (the admin's facts step already chose
 * it, and a chosen type beats a classified one) — a site that DOES want to
 * accept a classified type applies that itself, outside this helper.
 */
final class ProjectDetailsDraft
{
    /** Is $title "no real title yet" — blank, or still the site's own placeholder? */
    public static function isPlaceholderTitle(?string $title, string $placeholder): bool
    {
        return trim((string) $title) === '' || $title === $placeholder;
    }

    /**
     * Which attributes to write onto $project for this draft — never
     * applied here; the caller still does `$project->forceFill($attrs)->
     * save()` (or an equivalent that fits its own events/observers).
     *
     * @param  ?callable(string $title): string  $regenerateSlug  called only when the title is
     *         being replaced — pass the site's own `Project::generateUniqueSlug($title, $project->id)`,
     *         or null to leave the slug alone even when the title changes.
     * @return array<string, mixed>
     */
    public static function attributesToApply(
        Model $project,
        string $draftTitle,
        string $draftDescription,
        bool $titleIsPlaceholder,
        bool $force,
        ?callable $regenerateSlug = null,
    ): array {
        $attrs = [];

        if ($titleIsPlaceholder || $force) {
            $attrs['title'] = $draftTitle;
            if ($regenerateSlug !== null) {
                $attrs['slug'] = $regenerateSlug($draftTitle);
            }
        }

        if (blank($project->description) || $force) {
            $attrs['description'] = $draftDescription;
        }

        return $attrs;
    }
}
