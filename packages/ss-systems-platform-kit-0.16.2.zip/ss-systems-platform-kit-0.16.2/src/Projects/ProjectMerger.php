<?php

namespace SsSystems\Platform\Projects;

use Closure;
use Illuminate\Database\Eloquent\Model;
use SsSystems\Platform\Projects\Contracts\RecordsProjectSlugRedirect;
use SsSystems\Platform\Projects\Contracts\RelocatesProjectOwnedRows;

/**
 * One real job folded into several — see `docs/PROJECT-AREAS.md` and the
 * project-areas admin-API contract's "Merge" section. Ported from
 * jpeterson-design.com's `App\Support\Projects\ProjectMerger`.
 *
 * Each of the target and its sources becomes one area of the target
 * (area.project_type = that project's old project_type, area.description =
 * its old description, area.title = null); each one's area-less photos
 * move into that area WITHOUT being re-created — a Google/Yelp upload
 * record references a photo's id, so the row is always updated in place
 * (project_id + project_area_id), never dropped and remade — see
 * `ProjectFileRelocator`. Everything else a source owns (its
 * `RelocatesProjectOwnedRows` adapter decides what that is) moves to the
 * target; the source's slug becomes a redirect to the target's page at the
 * new area's anchor (`RecordsProjectSlugRedirect`); the source row is then
 * deleted.
 *
 * Idempotent by construction, not by a tombstone table: a source
 * identifier that no longer resolves to a project (an earlier run already
 * deleted it) is treated as already merged and skipped, and the target's
 * own pre-merge facts are only folded into a "self" area the first time a
 * merge ever runs against it (guarded by `$target->areas()->doesntExist()`,
 * since later merges into an already-merged target must not re-snapshot it
 * or duplicate that area). Running the same command twice with the same
 * arguments is therefore a no-op the second time.
 *
 * $target (and, through it, every source `ProjectMerger` resolves) is the
 * site's own Project model — `use`s `Concerns\HasProjectAreas` — so this
 * class never imports a site's model namespace; it only calls `areas()`/
 * `images()`/`testimonials()`-shaped relations that `RelocatesProjectOwnedRows`
 * (never this class itself) actually touches beyond areas/images.
 */
final class ProjectMerger
{
    /**
     * @param  array<int, string>  $sourceIdentifiers  ids or slugs, as typed on the command line
     * @param  ?Closure(Closure): mixed  $runQuietly  wraps apply()'s whole transaction — a site whose
     *         model observers do expensive work on every save (gs.construction's `ProjectObserver`
     *         regenerating the sitemap) passes e.g. `fn (Closure $work) => Model::withoutEvents($work)`.
     *         Defaults to running the work directly, with no suppression.
     */
    public function __construct(
        private readonly Model $target,
        private readonly array $sourceIdentifiers,
        private readonly string $type,
        private readonly ?string $title,
        private readonly RelocatesProjectOwnedRows $relocator,
        private readonly RecordsProjectSlugRedirect $redirects,
        private readonly ?string $slug = null,
        private readonly ?Closure $runQuietly = null,
    ) {}

    /** A project by numeric id or by slug — whichever $identifier looks like. */
    public static function resolveProject(string $projectModel, string $identifier): ?Model
    {
        return ctype_digit($identifier)
            ? ($projectModel)::find((int) $identifier)
            : ($projectModel)::where('slug', $identifier)->first();
    }

    /**
     * Read-only: what this run would do. Never writes anything — safe to
     * call for `--dry`, and reused by apply() to decide what to do.
     *
     * @return array{
     *     target: Model,
     *     self_area_needed: bool,
     *     sources: array<int, array{identifier: string, project: ?Model, already_merged: bool}>,
     * }
     */
    public function plan(): array
    {
        $projectModel = $this->target::class;

        $sources = array_map(
            fn (string $identifier): array => [
                'identifier' => $identifier,
                'project' => $project = self::resolveProject($projectModel, $identifier),
                'already_merged' => $project === null,
            ],
            $this->sourceIdentifiers
        );

        return [
            'target' => $this->target,
            'self_area_needed' => $this->target->areas()->doesntExist(),
            'sources' => $sources,
        ];
    }

    /**
     * Execute the plan inside one transaction.
     *
     * @return array{
     *     target: Model,
     *     areas_created: int,
     *     sources: array<int, array{identifier: string, already_merged: bool, area: ?Model, images_moved: int}&array<string, mixed>>,
     * }
     */
    public function apply(): array
    {
        $runQuietly = $this->runQuietly ?? static fn (Closure $work) => $work();

        // The target's own connection, not the `DB` facade's default one —
        // works identically for a site's real app and for a kit unit test
        // wiring up a bare Eloquent connection with no container `db`
        // binding at all.
        return $runQuietly(fn () => $this->target->getConnection()->transaction(fn () => $this->applyWithinTransaction()));
    }

    /**
     * @return array{target: Model, areas_created: int, sources: array<int, array<string, mixed>>}
     */
    private function applyWithinTransaction(): array
    {
        $plan = $this->plan();
        $areasCreated = 0;
        $sortOrder = (int) $this->target->areas()->max('sort_order');

        $selfArea = null;
        if ($plan['self_area_needed']) {
            $selfArea = $this->fold($this->target, ++$sortOrder)['area'];
            $areasCreated++;
            // Its description now belongs to its own area; left on the
            // project too, the page would print it twice.
            $this->target->forceFill(['description' => null])->save();
        }

        $sources = [];
        foreach ($plan['sources'] as $entry) {
            if ($entry['already_merged']) {
                $sources[] = $entry + ['area' => null, 'images_moved' => 0];

                continue;
            }

            /** @var Model $source */
            $source = $entry['project'];
            ['area' => $area, 'images_moved' => $imagesMoved] = $this->fold($source, ++$sortOrder);
            $areasCreated++;

            $owned = $this->relocator->relocate($source, $this->target);

            $this->redirects->recordRedirect($source->slug, $this->target, $area->anchor(), (int) $source->getKey());
            $this->redirects->repointRedirects($source, $this->target);

            $source->delete();

            $sources[] = $entry + ['area' => $area, 'images_moved' => $imagesMoved] + $owned;
        }

        // Only when something actually changes — a re-run with the same
        // --type/--title would otherwise still fire an UPDATE (bumping
        // updated_at) even though every value is already in place.
        $changes = array_filter([
            'project_type' => $this->target->project_type !== $this->type ? $this->type : null,
            'title' => filled($this->title) && $this->target->title !== $this->title ? $this->title : null,
            'slug' => filled($this->slug) && $this->target->slug !== $this->slug ? $this->slug : null,
        ]);
        if (isset($changes['slug'])) {
            // The old address keeps working: it leads to the part of the
            // page the project used to be about.
            $this->redirects->recordRedirect(
                $this->target->slug,
                $this->target,
                ($selfArea ?? $this->target->areas()->orderBy('sort_order')->first())?->anchor()
            );
            $this->redirects->forgetRedirect($changes['slug']);
        }
        if ($changes !== []) {
            $this->target->update($changes);
        }

        return ['target' => $this->target->fresh(), 'areas_created' => $areasCreated, 'sources' => $sources];
    }

    /**
     * Turn $project's own pre-merge facts (project_type, description) into
     * one new area of the target, and move its area-less photos into it
     * (in place — see `ProjectFileRelocator`). $project may be the target
     * itself (capturing its identity before project_type/title are
     * overwritten below) or a source (whose OTHER owned rows move
     * separately via `RelocatesProjectOwnedRows`).
     *
     * @return array{area: Model, images_moved: int}
     */
    private function fold(Model $project, int $sortOrder): array
    {
        $area = $this->target->areas()->create([
            'project_type' => $project->project_type,
            'title' => null,
            'description' => $project->description,
            'sort_order' => $sortOrder,
        ]);

        $isSelf = $project->is($this->target);
        $images = $isSelf ? $this->target->images()->whereNull('project_area_id')->get() : $project->images()->get();

        foreach ($images as $image) {
            if (! $isSelf) {
                ProjectFileRelocator::relocate($image, $this->target);
            }
            $image->forceFill(['project_id' => $this->target->getKey(), 'project_area_id' => $area->getKey()])->save();
        }

        return ['area' => $area, 'images_moved' => $images->count()];
    }
}
