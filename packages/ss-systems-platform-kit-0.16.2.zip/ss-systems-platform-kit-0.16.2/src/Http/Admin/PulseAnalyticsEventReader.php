<?php

namespace SsSystems\Platform\Http\Admin;

use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use SsSystems\Platform\Http\Admin\Contracts\AnalyticsEventReader;
use SsSystems\Platform\Pulse\Contracts\PulseStorage;

/**
 * AnalyticsEventReader over the kit's own Pulse `site_events` table
 * (hive.contractors/ss.systems today — neither has a dedicated TrackedEvent
 * ingest table). The `site_events.event` -> this screen's fixed
 * phone_click/email_click/form_submit/cta_click map is supplied BY THE
 * SITE, never hardcoded here: hive.contractors' `signup` event is that
 * site's only cta_click source, ss.systems maps no event to cta_click at
 * all (it has no delegated sign-up-link listener) — both are simply
 * different `$eventTypes` arrays passed to the same class, and an event key
 * the map omits never appears in a row at all (see rowsSince()'s `since()`
 * call, which asks PulseStorage for exactly the mapped keys).
 */
class PulseAnalyticsEventReader implements AnalyticsEventReader
{
    /**
     * @param  array<string,string>  $eventTypes  site_events.event => phone_click|email_click|form_submit|cta_click.
     * @param  (\Closure(string $event, array<string,mixed> $meta): ?string)|null  $labelResolver  Defaults to the
     *         delegated-click beacon's own convention — `meta['n']` when it is a string, else null. A site whose
     *         event carries no such field (hive's `signup`, which has no meta at all) passes its own closure
     *         instead of forcing a fake meta shape onto an event that never had one.
     */
    public function __construct(
        protected PulseStorage $storage,
        protected array $eventTypes,
        protected ?\Closure $labelResolver = null,
    ) {
    }

    public function rowsSince(Carbon $start): Collection
    {
        $rows = collect($this->storage->since($start, array_keys($this->eventTypes)));

        // PulseStorage::since() answers oldest first; this contract promises newest first.
        return $rows->map(fn (array $row) => $this->normalize($row))->sortByDesc('created_at')->values();
    }

    /**
     * @param  array{id: int, event: string, path: ?string, meta: ?string, vhash: string, city: ?string, mobile: bool, created_at: \DateTimeInterface}  $row
     * @return array<string,mixed>
     */
    protected function normalize(array $row): array
    {
        $meta = json_decode((string) ($row['meta'] ?? ''), true);
        $meta = is_array($meta) ? $meta : [];

        $label = $this->labelResolver !== null
            ? ($this->labelResolver)($row['event'], $meta)
            : (is_string($meta['n'] ?? null) ? $meta['n'] : null);

        $createdAt = $row['created_at'] instanceof Carbon ? $row['created_at'] : Carbon::parse($row['created_at']);

        return [
            'id' => "se-{$row['id']}",
            'type' => $this->eventTypes[$row['event']] ?? $row['event'],
            'label' => $label,
            'page_path' => $this->normalizePath($row['path'] ?? null),
            // Never captured by the kit's own beacon (Pulse\BeaconScript).
            'referrer' => null,
            'utm_source' => null,
            'utm_medium' => null,
            'utm_campaign' => null,
            'country' => null,
            'created_at' => $createdAt,
        ];
    }

    protected function normalizePath(?string $path): ?string
    {
        if ($path === null || $path === '') {
            return null;
        }

        return '/'.ltrim($path, '/');
    }
}
