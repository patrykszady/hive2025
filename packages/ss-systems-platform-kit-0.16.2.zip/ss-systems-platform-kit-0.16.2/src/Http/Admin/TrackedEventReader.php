<?php

namespace SsSystems\Platform\Http\Admin;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use SsSystems\Platform\Http\Admin\Contracts\AnalyticsEventReader;

/**
 * AnalyticsEventReader over a site's own TrackedEvent-shaped Eloquent model
 * (gs.construction/jpeterson-design.com today). Resolved fresh on every
 * call — never cached on this object — so gsc's `BelongsToSite` global
 * scope (bound to `Site::current()` at query time) fires exactly the way a
 * bare `TrackedEvent::query()` call site already would. The kit must never
 * reference `App\Models\TrackedEvent` directly (CLAUDE.md/RULES.md): each
 * site supplies either the class-string (the common case — the model's own
 * global scope, if any, is enough) or a closure when a site needs to seed
 * the query with something beyond what the model's own boot method adds.
 *
 * The model only needs to expose `id`, `type`, `label`, `page_path`,
 * `referrer`, `utm_source`, `utm_medium`, `utm_campaign`, `country` and
 * `created_at` — exactly `TrackedEvent`'s own columns on every site that
 * has one.
 */
class TrackedEventReader implements AnalyticsEventReader
{
    /**
     * @param  class-string<Model>|(\Closure(): Builder)  $model  e.g. `\App\Models\TrackedEvent::class`,
     *                                                             or a closure returning a fresh `Builder` when a site needs to seed the
     *                                                             query beyond the model's own global scope.
     */
    public function __construct(protected string|\Closure $model)
    {
    }

    public function rowsSince(Carbon $start): Collection
    {
        return $this->query()
            ->where('created_at', '>=', $start)
            ->latest()
            ->get(['id', 'type', 'label', 'page_path', 'referrer', 'utm_source', 'utm_medium', 'utm_campaign', 'country', 'created_at'])
            ->map(fn (Model $event) => [
                'id' => $event->getKey(),
                'type' => $event->type,
                'label' => $event->label,
                'page_path' => $event->page_path,
                'referrer' => $event->referrer,
                'utm_source' => $event->utm_source,
                'utm_medium' => $event->utm_medium,
                'utm_campaign' => $event->utm_campaign,
                'country' => $event->country,
                'created_at' => $event->created_at instanceof Carbon ? $event->created_at : Carbon::parse($event->created_at),
            ])
            ->values();
    }

    protected function query(): Builder
    {
        return is_string($this->model) ? $this->model::query() : ($this->model)();
    }
}
