<?php

namespace SsSystems\Platform\Http\Admin;

use Closure;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Bearer-token guard for /api/admin/v1 — the management API ss-systems
 * (and only ss-systems) talks to on a site's behalf. Byte-identical body
 * across gs.construction, jpeterson-design.com, hive.contractors and
 * dawnsellshomes.com before this move (confirmed by diff: only their
 * docblocks differed): a single trusted server-to-server caller, so a
 * constant-time comparison against one expected token is enough. No
 * Sanctum — there is no per-user identity to model here, just "is this
 * ss-systems". Builds the JSON response directly (`new JsonResponse(...)`,
 * same as `Pulse\BeaconController`) rather than through the `response()`
 * helper, so this class needs nothing beyond illuminate/http — no
 * illuminate/foundation, no booted container, to unit-test it.
 *
 * ss.systems' own admin (`sssystems`, a connected site of its own admin,
 * 2026-09-27) does NOT read a config value — it validates the bearer
 * against its own `ConnectedSite::forKey('sssystems')` row instead, and
 * says so in its 503 body. That is the one axis every other site never
 * needs, so it is a constructor hook, not a second implementation: pass a
 * `$tokenResolver` (and, if the wording needs to differ too,
 * `$unregisteredMessage`) to get that behaviour. Every other site aliases
 * straight to THIS class with zero constructor wiring — the container
 * falls back to the parameter defaults below when nothing binds one — so
 * `admin.api.auth => AuthenticateAdminApi::class` is the whole change.
 * ss.systems keeps a two-line subclass instead (see its own
 * App\Http\Middleware\AuthenticateAdminApi) precisely so this file never
 * has to import `App\Models\ConnectedSite`.
 */
class AuthenticateAdminApi
{
    /**
     * @param  (Closure(): string)|null  $tokenResolver  returns the expected bearer token; null = config('services.admin_api.token')
     * @param  string  $unregisteredMessage  the 503 body when no token is configured/registered yet
     */
    public function __construct(
        private readonly ?Closure $tokenResolver = null,
        private readonly string $unregisteredMessage = 'The admin API is not enabled on this server.',
    ) {
    }

    public function handle(Request $request, Closure $next): Response
    {
        $resolver = $this->tokenResolver ?? fn (): string => (string) config('services.admin_api.token');
        $expected = (string) $resolver();

        if ($expected === '') {
            return new JsonResponse(['message' => $this->unregisteredMessage], 503);
        }

        if (! hash_equals($expected, (string) $request->bearerToken())) {
            return new JsonResponse(['message' => 'Unauthenticated.'], 401);
        }

        return $next($request);
    }
}
