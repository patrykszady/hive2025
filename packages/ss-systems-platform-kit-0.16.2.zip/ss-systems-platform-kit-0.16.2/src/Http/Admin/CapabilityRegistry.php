<?php

namespace SsSystems\Platform\Http\Admin;

/**
 * The admin API's capability registry. Each site's `routes/api-admin/
 * {domain}.php` file (or, for a domain still registered inline in
 * `routes/api.php`, the block that defines its routes) calls
 * `CapabilityRegistry::declare('x')` for the domain it serves, and
 * `PingController` reports the union to ss-systems, whose sidebar and
 * screens read it — so a new screen is a new `declare()` call sitting
 * right next to the routes that back it, never an edit to a
 * hand-maintained array somewhere else. A route file that stops declaring
 * its domain silently un-declares it too — the failure mode this replaces
 * (a `PingController` array drifting from what a site's routes actually
 * serve, confirmed live on jpeterson-design's `js-errors` entry once) is
 * now structurally impossible AS LONG AS the route file that calls
 * `declare()` actually runs on every request.
 *
 * Ported verbatim from hive.contractors' `App\Support\AdminApi` (the same
 * registry ss.systems' own `App\Support\AdminApi` already copies for its
 * `sssystems` tenant) — `declare()`/`domains()` are byte-identical in
 * behaviour to that class. The one addition is `persist()`/`persisted()`,
 * needed because of a real production hazard hive's original never faced:
 *
 * ROUTE CACHING. `declare()` is a *side effect of loading a route file* —
 * it only runs when Laravel actually executes `routes/api.php` and
 * whatever it `require`s. The moment a site's deploy runs `route:cache`,
 * every later request boots from `bootstrap/cache/routes-v7.php` instead
 * (`RouteServiceProvider::loadCachedRoutes()`), which restores the
 * compiled route table WITHOUT re-executing the PHP that built it — so
 * `declare()` never fires again and `domains()` would silently report `[]`
 * forever, exactly the kind of silent drift this whole registry exists to
 * prevent. gs.construction's real Forge deploy runs `artisan optimize`,
 * which caches routes; the 2026-09-27 decision (see docs/ADMIN-API.md) is
 * for that deploy script to stop doing so, which is the real fix — but
 * this class does not assume every site's deploy will always get that
 * right, today or in the future, so it never lets a cached-routes request
 * answer with a bare lie. `domains()` falls back to whatever `persist()`
 * last wrote to disk (`bootstrap/cache/admin-domains.php` by default) the
 * moment THIS run declared nothing at all. That snapshot is written by the
 * `admin-api:cache` artisan command (`Console\CacheAdminDomainsCommand`),
 * which a deploy runs BEFORE `route:cache` — see that class and
 * docs/ADMIN-API.md for the exact ordering and why running it after
 * `route:cache` would just persist an empty list.
 *
 * Still tenancy-agnostic, still a bare static array: nothing here reads a
 * site's own config or model layer.
 */
final class CapabilityRegistry
{
    /** @var array<string, string> */
    private static array $domains = [];

    public static function declare(string ...$domains): void
    {
        foreach ($domains as $domain) {
            self::$domains[$domain] = $domain;
        }
    }

    /**
     * What ss-systems reads. Prefers whatever THIS run's route files
     * declared; only when that is empty (a cached-routes request, or one
     * before any route file has run yet) falls back to the last persisted
     * snapshot. Returns `[]`, honestly, when neither source has anything —
     * never fabricates a domain nobody declared.
     *
     * @return array<int, string>
     */
    public static function domains(): array
    {
        if (self::$domains !== []) {
            return self::sorted(self::$domains);
        }

        return self::persisted() ?? [];
    }

    /**
     * Only what THIS run's `declare()` calls produced — never the
     * persisted fallback. `persist()` snapshots this, and a caller that
     * wants to know whether route files ran at all (rather than the
     * ping-facing, fallback-aware answer) reads this directly.
     *
     * @return array<int, string>
     */
    public static function declared(): array
    {
        return self::sorted(self::$domains);
    }

    /**
     * Snapshots `declared()` to a plain PHP file `domains()` falls back to
     * once route caching skips every `declare()` call. Refuses (throws)
     * when `declared()` is empty, rather than silently overwriting a good
     * snapshot from an earlier run with an empty one — the one way this
     * safety net could itself go silently wrong is running it AFTER
     * `route:cache` (or against a request that already loaded cached
     * routes), which is exactly what would make `declared()` empty here.
     *
     * @return array<int, string> what was written (sorted, deduped)
     *
     * @throws \RuntimeException when nothing is currently declared
     */
    public static function persist(?string $path = null): array
    {
        $domains = self::declared();

        if ($domains === []) {
            throw new \RuntimeException(
                'CapabilityRegistry has nothing declared to persist — refusing to '.
                'overwrite the existing snapshot with an empty one. This almost '.
                'always means routes were already served from a cache when this ran '.
                '(declare() never fires for a cached route table): run `route:clear` '.
                '(or make sure this runs before `route:cache`) and try again.'
            );
        }

        $file = $path ?? self::defaultCachePath();
        $dir = dirname($file);
        if (! is_dir($dir)) {
            mkdir($dir, 0755, true);
        }

        $export = var_export($domains, true);
        $php = "<?php\n\n".
            "// Written by SsSystems\\Platform\\Http\\Admin\\CapabilityRegistry::persist()\n".
            "// (php artisan admin-api:cache) — the snapshot domains() falls back to\n".
            "// when a cached-routes request never re-runs a single declare() call.\n".
            "// Safe to delete: the next admin-api:cache run, or any request that loads\n".
            "// routes fresh, replaces it.\n".
            "return {$export};\n";

        file_put_contents($file, $php, LOCK_EX);

        return $domains;
    }

    /**
     * The last snapshot `persist()` wrote, or null when the file does not
     * exist (or does not evaluate to an array — never fatal on a corrupt
     * or hand-edited file).
     *
     * @return array<int, string>|null
     */
    public static function persisted(?string $path = null): ?array
    {
        $file = $path ?? self::defaultCachePath();

        if (! is_file($file)) {
            return null;
        }

        $data = include $file;

        return is_array($data) ? self::sorted($data) : null;
    }

    /**
     * `config('admin-api.cache_path')` when a site sets one (e.g. to point
     * at a hand-maintained file instead of one `persist()` writes),
     * otherwise `bootstrap/cache/admin-domains.php` — the same
     * `bootstrap/cache` directory Laravel's own `route:cache`/`config:
     * cache` write to, so it survives a deploy's `cache:clear` sweep the
     * same way those do. Falls back to a bare temp path only when neither
     * Laravel helper is defined at all (the kit's own framework-free unit
     * tests).
     */
    public static function defaultCachePath(): string
    {
        if (function_exists('config')) {
            $configured = config('admin-api.cache_path');
            if (is_string($configured) && $configured !== '') {
                return $configured;
            }
        }

        return function_exists('base_path')
            ? base_path('bootstrap/cache/admin-domains.php')
            : sys_get_temp_dir().'/admin-domains.php';
    }

    /** @param  array<string>  $domains  @return array<int, string> */
    private static function sorted(array $domains): array
    {
        $domains = array_values(array_unique($domains));
        sort($domains);

        return $domains;
    }
}
