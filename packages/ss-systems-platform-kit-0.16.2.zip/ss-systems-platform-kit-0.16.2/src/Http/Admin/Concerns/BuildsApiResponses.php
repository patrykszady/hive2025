<?php

namespace SsSystems\Platform\Http\Admin\Concerns;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Carbon;

/**
 * Shared response/query shaping for every /api/admin/v1 controller, so the
 * envelope and the '-field' sort convention stay identical across
 * endpoints. Tenancy-agnostic — nothing here reads a site's own config.
 * Builds responses with `new JsonResponse(...)` directly (same as
 * `Http\Admin\AuthenticateAdminApi`, `Pulse\BeaconController`) rather than
 * the `response()` helper, and reads the clock through
 * `Illuminate\Support\Carbon` rather than the global `now()`/`today()`
 * helpers, so this trait needs nothing beyond illuminate/http +
 * illuminate/database — no illuminate/foundation, no booted container —
 * to unit-test it. Every site already resolves both helper pairs to the
 * exact same calls (none swaps Laravel's `Date` facade), so this is not a
 * behaviour change.
 *
 * `itemResponse()`/`paginatedResponse()`/`perPage()` were byte-identical
 * across all five sites already (gs.construction, jpeterson-design.com,
 * hive.contractors, dawnsellshomes.com, ss-systems' own new code);
 * `acceptedResponse()`/`applySort()` existed only on gsc/jpeterson (hive,
 * dawn and ss-systems hadn't needed them yet — nothing here changes for
 * them by gaining access to the two extra methods). `applyDateRange()` is
 * lifted verbatim from every site's `LeadController::applyDateRange()`
 * (also byte-identical bar a `Builder` type hint two of the four lacked).
 *
 * Do NOT delete hive2025's or dawnsellshomes' local `applySort()` override
 * on `TestimonialController` when adopting this trait there: it whitelists
 * a real, narrower set of sortable columns than this trait's
 * pass-anything-through version, and PHP quietly lets a class's own method
 * win over a trait method of the same name (no signature check, no
 * conflict) — so the override keeps working unmodified once the `use`
 * statement here is swapped in, and removing it would let an
 * unrecognised `sort` query param reach `orderBy()` unfiltered.
 */
trait BuildsApiResponses
{
    /**
     * {"data": [...], "meta": {current_page, per_page, total, last_page}}
     */
    protected function paginatedResponse(LengthAwarePaginator $paginator, callable $transform): JsonResponse
    {
        return new JsonResponse([
            'data' => $paginator->getCollection()->map($transform)->values()->all(),
            'meta' => [
                'current_page' => $paginator->currentPage(),
                'per_page' => $paginator->perPage(),
                'total' => $paginator->total(),
                'last_page' => $paginator->lastPage(),
            ],
        ]);
    }

    /** {"data": {...}} */
    protected function itemResponse(array $item, int $status = 200): JsonResponse
    {
        return new JsonResponse(['data' => $item], $status);
    }

    /**
     * 202 for an endpoint that queues work with dispatchAfterResponse().
     * Explicit Content-Length (and Connection: close) so the caller can
     * stop reading the moment the body is complete: under php-fpm the
     * response is flushed before the job runs anyway, but PHP's built-in
     * dev server has no fastcgi_finish_request — without a length the
     * central admin's HTTP client would sit on the open connection for
     * the whole Gemini call and time out on a request that had succeeded.
     */
    protected function acceptedResponse(array $item): JsonResponse
    {
        $response = $this->itemResponse($item, 202);

        return $response
            ->header('Content-Length', (string) strlen((string) $response->getContent()))
            ->header('Connection', 'close');
    }

    /**
     * Apply a '-field' / 'field' sort query param ('-' = descending) to a
     * query, falling back to $default (also '-field' / 'field' style)
     * when $sort is absent.
     */
    protected function applySort(Builder $query, ?string $sort, string $default): Builder
    {
        $spec = $sort ?: $default;
        $direction = str_starts_with($spec, '-') ? 'desc' : 'asc';
        $column = ltrim($spec, '-');

        return $query->orderBy($column, $direction);
    }

    /** Clamp a requested per_page to a sane range. */
    protected function perPage(Request $request, int $default = 20, int $max = 100): int
    {
        return max(1, min($max, (int) $request->integer('per_page', $default)));
    }

    /**
     * 'today' / 'week' / 'month' filters on created_at; any other value
     * (including the default "all time") applies no filter at all.
     */
    protected function applyDateRange(Builder $query, string $range): void
    {
        match ($range) {
            'today' => $query->whereDate('created_at', Carbon::today()),
            'week' => $query->where('created_at', '>=', Carbon::now()->subWeek()),
            'month' => $query->where('created_at', '>=', Carbon::now()->subMonth()),
            default => null,
        };
    }
}
