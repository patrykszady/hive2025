<?php

namespace SsSystems\Platform\Http\Admin\Console;

use Illuminate\Console\Command;
use RuntimeException;
use SsSystems\Platform\Http\Admin\CapabilityRegistry;

/**
 * `php artisan admin-api:cache` — snapshots whatever THIS run's
 * `routes/api-admin/*.php` files declared through
 * `CapabilityRegistry::declare()` to `bootstrap/cache/admin-domains.php`
 * (or `config('admin-api.cache_path')`), so `PingController`'s `domains()`
 * still answers truthfully after a deploy runs `route:cache` — see
 * `CapabilityRegistry`'s own docblock and docs/ADMIN-API.md for the full
 * "why".
 *
 * ORDER MATTERS: this command's own boot loads routes exactly like any
 * other artisan invocation does — from `bootstrap/cache/routes-v7.php`
 * when one already exists, in which case `declare()` never runs for THIS
 * process either, and there is nothing fresh to persist. A deploy MUST
 * run this — and, if a previous `route:cache` is still sitting there,
 * `route:clear` first — BEFORE its own `route:cache` step, never after.
 * `CapabilityRegistry::persist()` refuses (this command then exits
 * non-zero with its message) rather than silently freezing an empty list.
 *
 * A site registers this the same way it registers any other kit console
 * command (see `Reports\Console\KitReportCommand`'s per-site subclasses):
 * a thin `App\Console\Commands\AdminApiCache extends CacheAdminDomainsCommand
 * {}` under `app/Console/Commands/`, auto-discovered by Laravel — nothing
 * to wire in `bootstrap/app.php`.
 */
class CacheAdminDomainsCommand extends Command
{
    /** @var string */
    protected $signature = 'admin-api:cache';

    /** @var string */
    protected $description = "Snapshot this site's declared admin-api domains so PingController still answers truthfully once routes are cached";

    public function handle(): int
    {
        try {
            $domains = CapabilityRegistry::persist();
        } catch (RuntimeException $e) {
            $this->error($e->getMessage());

            return self::FAILURE;
        }

        $this->info('Cached '.count($domains).' admin-api domain(s): '.implode(', ', $domains));

        return self::SUCCESS;
    }
}
