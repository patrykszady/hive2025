<?php

namespace SsSystems\Platform\Http\Admin\Contracts;

use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;

/**
 * One normalized event source for `Concerns\BuildsAnalyticsScreen` (the
 * `/api/admin/v1/analytics/events` + `/summary` backend every kit site's
 * `Livewire\Admin\SiteAnalytics` screen reads). Two real implementations
 * ship in the kit, and neither is "the" one:
 *
 *   - `TrackedEventReader` — gs.construction/jpeterson-design.com, over
 *     each site's own `App\Models\TrackedEvent` table (its own ingest
 *     endpoint writes rows there). Eloquent-`Builder`-based so gsc's
 *     `BelongsToSite` global scope keeps firing on every query.
 *   - `PulseAnalyticsEventReader` — hive.contractors/ss.systems, over the
 *     kit's own Pulse `site_events` table (no dedicated ingest — a click a
 *     site already beacons, e.g. `call`/`email`, IS the row).
 *
 * The rest of the screen (windowing, the four-tile breakdown, the trend
 * chart, top pages, pagination, response shape) is identical either way —
 * only the row source differs, which is exactly why this is the one
 * contract `BuildsAnalyticsScreen` needs.
 */
interface AnalyticsEventReader
{
    /**
     * Every normalized row created at or after $start, newest first. Rows
     * are plain arrays (never Eloquent models — a Pulse-backed reader has
     * none to return), each shaped:
     *
     * @return Collection<int, array{
     *     id: string|int,
     *     type: string,
     *     label: ?string,
     *     page_path: ?string,
     *     referrer: ?string,
     *     utm_source: ?string,
     *     utm_medium: ?string,
     *     utm_campaign: ?string,
     *     country: ?string,
     *     created_at: Carbon,
     * }>
     */
    public function rowsSince(Carbon $start): Collection;
}
