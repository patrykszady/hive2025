<?php

namespace SsSystems\Platform\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Symfony\Component\HttpFoundation\Response;

/**
 * The visitor's country, from Cloudflare's CF-IPCountry header.
 *
 * One implementation for every site the ss.systems admin drives: the
 * contact form's Turnstile check is SILENT for visitors we have no reason
 * to doubt and a visible challenge for the rest, and that decision needs a
 * country.
 *
 * Cloudflare adds CF-IPCountry to every proxied request as an ISO 3166-1
 * alpha-2 code. Without Cloudflare in front — a local run, a direct origin
 * hit — the header is absent and this reads 'XX', which counts as US: better
 * to wave through a visitor we cannot place than to put a challenge in front
 * of a homeowner because our own edge is misconfigured.
 *
 * @see https://developers.cloudflare.com/fundamentals/reference/http-request-headers/#cf-ipcountry
 *
 * Ported from jpeterson-design 2026-09-27 (kit 0.11.0), the site that had
 * already fixed the bug gs.construction was still carrying: a site's own
 * `/admin/{path?}` route proxies straight through to ss-systems and runs the
 * `web` group WITHOUT `StartSession` (ss-systems' own session is the one
 * that matters there, not this site's), and this middleware used to write
 * to the session unconditionally. `hasSession()` FIRST, and never
 * `session()?->` — `Request::session()` THROWS when no store is set, so the
 * null-safe operator does nothing for us. jpeterson's admin took a live 500
 * from exactly this before the guard below was added; gs.construction never
 * hit it only because its route's `withoutMiddleware()` list happened to
 * name this class too — one future middleware append away from the same
 * crash. The guard removes the whole class of bug for every site that
 * takes this from the kit, not just the two that had already found it.
 */
class DetectCountry
{
    /** The US and its territories, which Cloudflare reports separately. */
    public const US = ['US', 'PR', 'VI', 'GU', 'AS', 'MP'];

    public function handle(Request $request, Closure $next): Response
    {
        $country = $request->header('CF-IPCountry', 'XX');
        $isUS = $country === 'XX' || in_array($country, self::US, true);

        // Session as well as request: Livewire's later round trips are their
        // own requests, and the one that submits the form still has to know
        // whether this visitor needed a challenge.
        if ($request->hasSession()) {
            $request->session()->put('visitor_country', $country);
        }

        $request->attributes->set('visitor_country', $country);
        $request->attributes->set('is_us_visitor', $isUS);

        View::share('visitorCountry', $country);
        View::share('isUSVisitor', $isUS);

        return $next($request);
    }
}
