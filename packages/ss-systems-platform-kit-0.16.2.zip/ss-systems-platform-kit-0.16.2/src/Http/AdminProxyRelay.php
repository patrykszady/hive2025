<?php

namespace SsSystems\Platform\Http;

use Closure;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Http\Client\PendingRequest;
use Illuminate\Http\Client\Response as ClientResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response as HttpResponse;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\View;
use Symfony\Component\HttpFoundation\Cookie;
use Symfony\Component\HttpFoundation\Response;

/**
 * Transparent relay of a site's /admin/* to the ss-systems central admin —
 * the ONE implementation for every site, constructed from
 * `config('services.ss.*')` by each site's own ~15-line AdminProxyController
 * (see ss-systems/CLAUDE.md's "What this app is" for the proxy contract this
 * class exists to serve).
 *
 * Consolidated 2026-09-27 (kit 0.13.0) from four independently-hand-patched
 * copies — gs.construction, jpeterson-design.com, hive.contractors and
 * dawnsellshomes.com (dawn not ported this round) — that had each picked up
 * a DIFFERENT subset of bug fixes over time (see
 * ss-platform-kit/docs/audit-2026-09-27/admin-api-skeleton.md unit #1):
 *
 *  - **Header replace-not-append is now the only implementation** (was
 *    jpeterson-only; gsc and hive both still shipped the bug). A fresh
 *    `Illuminate\Http\Response` starts with Laravel's own default headers
 *    — Cache-Control "no-cache, private", Date — and blindly APPENDING the
 *    upstream's own Cache-Control value onto that (the old `set($name,
 *    $value, false)` for every header) merges into something that still
 *    carries `no-cache` alongside `public`, which wins: every full page
 *    load re-downloaded the admin stylesheet and the Flux bundle (~1MB)
 *    before first paint on every site except jpeterson. Below, only the
 *    FIRST value of a given header REPLACES; later values (a genuinely
 *    multi-valued header like Vary) still APPEND, so nothing multi-valued
 *    is lost.
 *  - **`$circuitBreaker`** (was hive/dawn-only, and hardcoded on with no
 *    way to turn it off) is now an explicit, named constructor flag every
 *    site passes. It gates BOTH of hive's original paired checks — an
 *    empty `$serviceSecret` (nothing to authenticate with, so no outbound
 *    call can ever succeed) and a 60-second "just failed, don't try again
 *    yet" cache flag — since hive's own code treated them as one feature
 *    ("never open an outbound call when the relay can't succeed anyway").
 *    Passing `true` for gsc/jpeterson (who never had this at all) is a
 *    REAL behaviour change, called out in each site's own controller
 *    docblock, not folded in silently; hive keeps passing `true` too, and
 *    for hive the behaviour is unchanged — just visible here now, instead
 *    of the checks being unconditionally baked into what used to be its
 *    own private copy of this file.
 *  - **`$beforeDown` fires on every path that can produce the down page**:
 *    the circuit-breaker's cached-open return, the empty-secret return,
 *    AND the `ConnectionException` catch — not only the last one, which is
 *    all any of the four sites' old code called it from. gsc's own hook
 *    binds `Site`/`Theme`/`SiteConfig` before the down page renders (this
 *    route runs without `ResolveSite`), so the error page still wears the
 *    visiting host's brand. Missing any one of the three paths means that
 *    overlay silently stops applying the instant the breaker trips or the
 *    secret is blank — the down page keeps rendering (no request ever
 *    fails), it would just wear the wrong site's brand, or none.
 *  - **`$forwardPort`** (default true) is the one place a site's own
 *    divergence is kept on purpose, not "cleaned up": jpeterson has never
 *    sent `X-Forwarded-Port` and nothing there depends on it (a single
 *    production port); gsc and hive both need it — ss-systems'
 *    `trustProxies` only recovers a port from `X-Forwarded-Host` when no
 *    forwarded port is present, and both apps run on non-default ports in
 *    local dev, where a dropped port silently breaks every relayed
 *    redirect. Each site passes its own existing value.
 *
 * The inbound header allowlist and the outbound-stripped-header list were
 * byte-identical across all four sites already and are not configurable —
 * nothing has ever needed them to differ.
 */
class AdminProxyRelay
{
    /** Inbound headers relayed to ss-systems, verbatim. Never the full set. */
    protected const ALLOWED_INBOUND_HEADERS = [
        'accept',
        'accept-language',
        'content-type',
        'cookie',
        'x-csrf-token',
        'x-livewire',
        'user-agent',
        'referer',
    ];

    /** Response headers never copied back: hop-by-hop, or recomputed by this leg. */
    protected const STRIPPED_RESPONSE_HEADERS = [
        'connection',
        'keep-alive',
        'transfer-encoding',
        'upgrade',
        'content-length',
        'content-encoding',
        'set-cookie',
    ];

    /** The one down-page view name every site renders this under. */
    protected const DOWN_VIEW = 'errors.admin-proxy-down';

    /** Set for 60s after an upstream failure: serve the down page without another outbound call. */
    protected const DOWN_CACHE_KEY = 'admin-proxy-down';

    /**
     * @param  string  $baseUrl  config('services.ss.url')
     * @param  string  $adminPrefix  config('services.ss.admin_prefix') — the identical literal path segment on both apps
     * @param  string  $siteKey  config('services.ss.site_key') — sent as X-Site-Key, never taken from the client
     * @param  string  $serviceSecret  config('services.ss.service_secret') — sent as X-Ss-Service-Secret
     * @param  int  $timeout  config('services.ss.timeout', 30)
     * @param  int  $connectTimeout  config('services.ss.connect_timeout', 5)
     * @param  bool  $circuitBreaker  named, explicit — see class docblock. false preserves a site that never had this.
     * @param  bool  $forwardPort  named, explicit — see class docblock. Each site keeps its own existing value.
     * @param  (Closure(Request $request): void)|null  $beforeDown  runs on EVERY path that produces the down page
     */
    public function __construct(
        protected readonly string $baseUrl,
        protected readonly string $adminPrefix,
        protected readonly string $siteKey,
        protected readonly string $serviceSecret,
        protected readonly int $timeout = 30,
        protected readonly int $connectTimeout = 5,
        protected readonly bool $circuitBreaker = false,
        protected readonly bool $forwardPort = true,
        protected readonly ?Closure $beforeDown = null,
    ) {
    }

    public function handle(Request $request, string $path = ''): Response
    {
        // /admin is the most-probed path on the internet: never open an
        // outbound call when the relay can't succeed anyway (no service
        // secret configured yet) or just failed (breaker open) — but only
        // for a site that asked for this protection; see class docblock.
        if ($this->circuitBreaker && ($this->serviceSecret === '' || Cache::get(self::DOWN_CACHE_KEY))) {
            return $this->downResponse($request);
        }

        $target = $this->targetUrl($request, $path);
        $contentType = (string) $request->headers->get('content-type');
        $isMultipart = str_starts_with(strtolower($contentType), 'multipart/form-data');

        $client = Http::withoutRedirecting()
            ->timeout($this->timeout)
            ->connectTimeout($this->connectTimeout)
            ->withHeaders($this->outboundHeaders($request, $isMultipart));

        try {
            $upstream = $isMultipart
                ? $this->sendMultipart($client, $request, $target)
                : $this->sendStandard($client, $request, $target, $contentType);
        } catch (ConnectionException $e) {
            Log::warning('Admin proxy: could not reach ss-systems', [
                'target' => $target,
                'message' => $e->getMessage(),
            ]);

            if ($this->circuitBreaker) {
                // Carbon::now(), not the ambient now() helper: that helper
                // lives in illuminate/foundation (every real site has it,
                // the kit's own bare PHPUnit run does not) — Carbon is
                // already a hard kit dependency via illuminate/support.
                Cache::put(self::DOWN_CACHE_KEY, true, Carbon::now()->addSeconds(60));
            }

            return $this->downResponse($request);
        }

        return $this->relayResponse($upstream, $request);
    }

    /**
     * Every path that can produce the down page runs through here — the
     * circuit-breaker/empty-secret early return above, and the
     * ConnectionException catch below both call this, never build the
     * response inline. See class docblock for why that matters.
     */
    protected function downResponse(Request $request): Response
    {
        if ($this->beforeDown !== null) {
            ($this->beforeDown)($request);
        }

        $html = View::make(self::DOWN_VIEW)->render();

        return (new HttpResponse($html, 502))
            ->header('X-Robots-Tag', 'noindex, nofollow');
    }

    protected function targetUrl(Request $request, string $path): string
    {
        $base = rtrim($this->baseUrl, '/');
        $prefix = trim($this->adminPrefix, '/');
        $target = $base.'/'.$prefix.'/'.ltrim($path, '/');

        $query = $request->getQueryString();

        return $query ? $target.'?'.$query : $target;
    }

    /**
     * @return array<string, string>
     */
    protected function outboundHeaders(Request $request, bool $isMultipart): array
    {
        $headers = [];

        foreach (self::ALLOWED_INBOUND_HEADERS as $name) {
            // Multipart bodies are rebuilt from scratch with a fresh boundary
            // (see sendMultipart) — the inbound Content-Type's boundary no
            // longer matches, and Guzzle only sets the correct one itself
            // when this header is left unset on the outbound request.
            if ($isMultipart && $name === 'content-type') {
                continue;
            }

            $value = $request->headers->get($name);
            if ($value !== null) {
                $headers[$name] = $value;
            }
        }

        // Authoritative — never derived from anything the client sent, so a
        // browser can never forge the identity ss-systems trusts these for.
        //
        // getHttpHost(), not getHost(): Symfony's getHost() strips the port,
        // but X-Forwarded-Host is conventionally the original Host header
        // verbatim (host[:port]) — and ss-systems' own trustProxies is
        // configured to read a port back out of it. In local dev, where
        // both apps run on non-default ports, getHost() alone silently
        // drops the port and every relayed redirect ends up pointed at the
        // wrong one.
        $headers['X-Forwarded-Host'] = $request->getHttpHost();

        if ($this->forwardPort) {
            // Explicit, even though X-Forwarded-Host carries host:port:
            // Symfony only recovers a port from the forwarded HOST when no
            // forwarded PORT is present. See class docblock — one site
            // deliberately does not send this.
            $headers['X-Forwarded-Port'] = (string) $request->getPort();
        }

        $headers['X-Forwarded-Proto'] = $request->getScheme();
        $headers['X-Forwarded-For'] = (string) $request->ip();
        $headers['X-Site-Key'] = $this->siteKey;
        $headers['X-Ss-Service-Secret'] = $this->serviceSecret;

        return $headers;
    }

    protected function sendStandard(PendingRequest $client, Request $request, string $target, string $contentType): ClientResponse
    {
        $body = $request->getContent();

        if ($body !== '') {
            $client->withBody($body, $contentType ?: 'application/octet-stream');
        }

        return $client->send($request->method(), $target);
    }

    /**
     * php://input is empty for multipart/form-data requests (PHP consumes it
     * into $_POST/$_FILES), so the outbound multipart body is rebuilt from
     * the parsed request rather than relayed as raw bytes.
     */
    protected function sendMultipart(PendingRequest $client, Request $request, string $target): ClientResponse
    {
        $client->asMultipart();

        $fileKeys = [];

        foreach ($this->flatten($request->allFiles()) as $name => $file) {
            $fileKeys[explode('[', $name, 2)[0]] = true;

            $client->attach(
                $name,
                fopen($file->getRealPath(), 'r'),
                $file->getClientOriginalName(),
                ['Content-Type' => $file->getClientMimeType()],
            );
        }

        $fields = $request->except(array_keys($fileKeys));
        $parts = [];

        foreach ($this->flatten($fields) as $name => $value) {
            $parts[] = ['name' => $name, 'contents' => (string) $value];
        }

        return $client->send($request->method(), $target, ['multipart' => $parts]);
    }

    /**
     * Flatten a nested array (as produced by $request->allFiles() /
     * $request->except()) into bracket-notation names: ['files' => [0 =>
     * $file]] becomes ['files[0]' => $file].
     *
     * @return array<string, mixed>
     */
    protected function flatten(array $data, string $prefix = ''): array
    {
        $flat = [];

        foreach ($data as $key => $value) {
            $name = $prefix === '' ? (string) $key : $prefix.'['.$key.']';

            if (is_array($value)) {
                $flat += $this->flatten($value, $name);
            } else {
                $flat[$name] = $value;
            }
        }

        return $flat;
    }

    protected function relayResponse(ClientResponse $upstream, Request $request): Response
    {
        $response = new HttpResponse($upstream->body(), $upstream->status());

        foreach ($upstream->headers() as $name => $values) {
            if (in_array(strtolower($name), self::STRIPPED_RESPONSE_HEADERS, true)) {
                continue;
            }

            // First value REPLACES, later values append — see class
            // docblock: this is the fix that used to be jpeterson-only.
            // response() starts with Laravel's own default headers
            // (Cache-Control "no-cache, private", Date, …); appending onto
            // those instead of replacing merged the asset routes' "public,
            // max-age=31536000, immutable" into a Cache-Control that still
            // carried "no-cache" alongside "public" — every full page load
            // re-downloaded the admin stylesheet and the Flux bundle before
            // first paint. A genuinely multi-valued header (Vary, Link)
            // still arrives intact: only the FIRST of its values replaces,
            // the rest still append.
            foreach (array_values((array) $values) as $i => $value) {
                $response->headers->set($name, $value, $i === 0);
            }
        }

        // A naive header set collapses repeated Set-Cookie lines into one —
        // this is load-bearing for login, which sets both the session cookie
        // and the CSRF cookie in the same response.
        foreach ($upstream->toPsrResponse()->getHeader('Set-Cookie') as $raw) {
            $response->headers->setCookie(Cookie::fromString($raw));
        }

        if ($response->isRedirection() && $response->headers->has('Location')) {
            $response->headers->set('Location', $this->rewriteLocation($response->headers->get('Location'), $request));
        }

        $response->headers->set('X-Robots-Tag', 'noindex, nofollow');

        return $response;
    }

    /**
     * Rewrite ONLY an absolute Location that points back at ss-systems'
     * own origin, so a redirect lands on this site's origin instead — the
     * browser never has a reason to know ss-systems exists.
     *
     * In practice ss-systems forces its own URL root to this site's base_url
     * for proxied requests (see VerifyAdminProxyOrigin on that side), so
     * Location already comes back client-origin. This is a safety net for
     * the case where it doesn't.
     */
    protected function rewriteLocation(string $location, Request $request): string
    {
        $ssOrigin = rtrim($this->baseUrl, '/');

        if ($ssOrigin !== '' && str_starts_with($location, $ssOrigin)) {
            return $request->getSchemeAndHttpHost().substr($location, strlen($ssOrigin));
        }

        return $location;
    }
}
