<?php

namespace SsSystems\Platform\Google\Http;

use Illuminate\Http\Client\ConnectionException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Psr\Log\LoggerInterface;
use SsSystems\Platform\Auth\OAuthState;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * The `/admin-oauth/{provider}/callback` every site registers — Google (and
 * Meta) send the browser here after the consent screen, with no session:
 * the whole /admin surface is a stateless proxy to ss.systems, so the
 * request is authenticated by the signed, 15-minute `Auth\OAuthState` the
 * oauth-url endpoint minted, verified BEFORE any code is exchanged.
 *
 * One implementation of the closure six sites carried, with
 * deerfield-furniture's hardening (2026-09-28) for everyone:
 *
 * - query values are taken as strings only — a crafted `state[]=` /
 *   `code[]=` is the calm "expired" line, not a TypeError 500;
 * - Google's own `error_description`/`error` is passed on, capped at 300
 *   characters;
 * - an unknown provider is a 404 (as the route constraint would give);
 * - new here: an exchange that throws (Google did not answer) is a calm
 *   "try again" line instead of an error page, and never loses the
 *   Platforms screen.
 *
 * The outcome travels back to the proxied Platforms screen as
 * `?connected={provider}` or `?error={message}` (a session flash cannot
 * cross to ss.systems). Register it in routes/web.php, a sibling of /admin
 * so the proxy never swallows it:
 *
 *     Route::get('/admin-oauth/{provider}/callback', fn (Request $request, string $provider) =>
 *         (new OAuthCallback('/admin/'.config('services.ss.site_key').'/platforms', Log::channel('gbp')))
 *             ->handle($request, $provider, route(OAuthClient::CALLBACK_ROUTE, ['provider' => $provider]), [
 *                 'gbp' => fn (string $code, string $redirectUri) => app(Client::class)->exchangeCodeAndStore($code, $redirectUri),
 *                 'meta' => fn (string $code, string $redirectUri) => app(MetaSocialService::class)
 *                     ->exchangeCodeAndStore($code, $redirectUri, MetaSocialService::OAUTH_SCOPES),
 *             ])
 *     )->whereIn('provider', ['gbp', 'meta'])->name(OAuthClient::CALLBACK_ROUTE);
 */
final class OAuthCallback
{
    public function __construct(
        private readonly string $platformsPath,
        private readonly ?LoggerInterface $log = null,
    ) {}

    /**
     * @param  array<string, callable(string $code, string $redirectUri): array{success?: bool, error?: ?string}>  $exchangers  provider => the code exchange
     */
    public function handle(Request $request, string $provider, string $redirectUri, array $exchangers): RedirectResponse
    {
        if (! isset($exchangers[$provider])) {
            throw new NotFoundHttpException;
        }

        $query = static function (string $key) use ($request): ?string {
            $value = $request->query($key);

            return is_string($value) && $value !== '' ? $value : null;
        };

        if (! OAuthState::verify($query('state'), $provider)) {
            return $this->back(['error' => 'Sign-in link expired or was invalid. Try connecting again.']);
        }

        $code = $query('code');

        if ($code === null) {
            $reason = $query('error_description') ?? $query('error') ?? 'Authorization cancelled or failed — no code returned.';

            return $this->back(['error' => mb_substr($reason, 0, 300)]);
        }

        try {
            $result = ($exchangers[$provider])($code, $redirectUri);
        } catch (ConnectionException $e) {
            $this->log?->warning('OAuth callback: the provider did not answer the code exchange', ['provider' => $provider, 'error' => $e->getMessage()]);

            return $this->back(['error' => 'The sign-in could not be finished: the provider did not answer. Try connecting again.']);
        } catch (\Throwable $e) {
            $this->log?->error('OAuth callback: the code exchange failed', ['provider' => $provider, 'error' => $e->getMessage()]);

            return $this->back(['error' => 'The sign-in could not be finished. Try connecting again.']);
        }

        if ($result['success'] ?? false) {
            return $this->back(['connected' => $provider]);
        }

        return $this->back(['error' => mb_substr('OAuth failed: '.(($result['error'] ?? null) ?: 'Unknown error'), 0, 300)]);
    }

    /**
     * Encoded exactly as every site's closure did (`urlencode()`), so a
     * site's existing redirect assertions keep matching.
     *
     * @param  array<string, string>  $params
     */
    private function back(array $params): RedirectResponse
    {
        return new RedirectResponse($this->platformsPath.'?'.http_build_query($params));
    }
}
