<?php

namespace SsSystems\Platform\Google;

use Illuminate\Http\Client\Factory;
use Psr\Log\LoggerInterface;
use Psr\SimpleCache\CacheInterface;

/**
 * A Google OAuth2 access token for a service account, obtained through the
 * JWT-bearer grant (RFC 7523) — no google/apiclient dependency. Ported from
 * hive.contractors' identical class (itself "ported verbatim from
 * dawnsellshomes'", which this class now supersedes: dawn's copy only ever
 * read its credential as a literal file path; hive added the inline-JSON
 * and base64 forms below and that fix never made it back to dawn — this is
 * the fix landing once, for every site, instead of a third copy drifting
 * the same way).
 *
 * The kit has no illuminate/foundation, so this never reads config() or a
 * facade: the credential value, the scope(s), a PSR-16 cache and Laravel's
 * HTTP client factory all arrive through the constructor. A site's own
 * binding is the one place that still calls config() — see
 * docs/SEARCH-CONSOLE-SERVICE-ACCOUNT.md.
 *
 * Every caller that needs a different scope (webmasters for sitemap
 * submission and search-analytics, the same scope covers URL Inspection
 * too) builds its own instance rather than sharing one — two different
 * scopes must never share a cached token, since Google mints one per
 * scope-set.
 *
 * The access token is cached until shortly before Google's own expiry
 * (typically 3600s), keyed on the credential + scopes, so a command that
 * asks for a token many times in one run (or across runs within the hour)
 * does not re-sign a fresh JWT and round-trip to Google every time.
 *
 * Never logs the credential itself, in any form — only a short, fixed
 * reason string ends up in lastError() or the optional logger.
 */
class ServiceAccountToken
{
    protected ?string $lastError = null;

    /**
     * @param  ?string  $credential  A service-account JSON: a path to the
     *   file, the JSON itself, or the JSON base64-encoded on one line (so it
     *   fits a single .env value in production, where a key file placed on
     *   the server by hand is the thing to avoid).
     * @param  list<string>  $scopes  One or more OAuth scope URLs; Google
     *   accepts a space-delimited list in a single JWT, so multiple scopes
     *   still mean one token, one cache entry.
     */
    public function __construct(
        protected readonly ?string $credential,
        protected readonly array $scopes,
        protected readonly CacheInterface $cache,
        protected readonly Factory $http,
        protected readonly ?LoggerInterface $log = null,
    ) {}

    /** A credential is present — a readable file, or the key itself — cheap, no network call. */
    public function isConfigured(): bool
    {
        return $this->rawCredential() !== null;
    }

    /**
     * A valid access token for these scopes, from cache when not yet
     * expired, otherwise freshly minted and cached. Null (with lastError()
     * set) when the credential is missing, unreadable, malformed, or Google
     * refuses the exchange — never throws, so a caller can always turn this
     * into an owner-facing message instead of a stack trace.
     */
    public function get(): ?string
    {
        $this->lastError = null;

        if (! $this->isConfigured()) {
            $this->lastError = 'No service-account credential is configured.';

            return null;
        }

        $cacheKey = $this->cacheKey();
        $cached = $this->cache->get($cacheKey);
        if (is_string($cached) && $cached !== '') {
            return $cached;
        }

        $fetched = $this->fetch();
        if ($fetched === null) {
            return null;
        }

        $this->cache->set($cacheKey, $fetched['access_token'], max($fetched['expires_in'] - 120, 60));

        return $fetched['access_token'];
    }

    /** Why the last get() returned null. Null after a successful call. */
    public function lastError(): ?string
    {
        return $this->lastError;
    }

    /**
     * The credential JSON's raw text, however it arrived. Returns null for
     * anything that isn't a readable file, a JSON object, or base64 that
     * decodes to one — never for want of trying every form before giving
     * up.
     */
    protected function rawCredential(): ?string
    {
        $value = trim((string) $this->credential);

        if ($value === '') {
            return null;
        }

        if (is_file($value)) {
            $raw = @file_get_contents($value);

            return $raw === false ? null : $raw;
        }

        if (str_starts_with($value, '{')) {
            return $value;
        }

        $decoded = base64_decode($value, true);

        return is_string($decoded) && str_starts_with(ltrim($decoded), '{') ? $decoded : null;
    }

    /**
     * @return array{access_token: string, expires_in: int}|null
     */
    protected function fetch(): ?array
    {
        $raw = $this->rawCredential();
        $sa = $raw !== null ? json_decode($raw, true) : null;

        if (! is_array($sa) || empty($sa['client_email']) || empty($sa['private_key'])) {
            $this->lastError = 'The service-account credential is missing client_email or private_key.';
            $this->log?->warning('ServiceAccountToken: malformed credential (missing client_email/private_key).');

            return null;
        }

        $b64 = fn (string $d): string => rtrim(strtr(base64_encode($d), '+/', '-_'), '=');
        $now = time();
        $unsigned = $b64(json_encode(['alg' => 'RS256', 'typ' => 'JWT'])).'.'
            .$b64(json_encode([
                'iss' => $sa['client_email'],
                'scope' => $this->scopeString(),
                'aud' => 'https://oauth2.googleapis.com/token',
                'iat' => $now, 'exp' => $now + 3600,
            ]));

        if (! openssl_sign($unsigned, $signature, $sa['private_key'], 'sha256WithRSAEncryption')) {
            $this->lastError = 'Could not sign the JWT with the service account\'s private key.';
            $this->log?->warning('ServiceAccountToken: openssl_sign failed — private key rejected.');

            return null;
        }

        $response = $this->http->asForm()->timeout(20)->post('https://oauth2.googleapis.com/token', [
            'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
            'assertion' => $unsigned.'.'.$b64($signature),
        ]);

        if (! $response->successful()) {
            $this->lastError = 'Google refused the token exchange ('.$response->status().'): '
                .mb_substr((string) ($response->json('error_description') ?? $response->body()), 0, 300);
            $this->log?->warning('ServiceAccountToken: token exchange failed.', ['status' => $response->status()]);

            return null;
        }

        $accessToken = $response->json('access_token');
        if (! $accessToken) {
            $this->lastError = 'Google did not return an access token.';

            return null;
        }

        return [
            'access_token' => $accessToken,
            'expires_in' => (int) ($response->json('expires_in') ?? 3600),
        ];
    }

    protected function scopeString(): string
    {
        return implode(' ', $this->scopes);
    }

    /**
     * Keyed on the credential + scopes, never logged or exposed — only used
     * as a cache lookup key, so a sha1 (not reversible in practice for a
     * ~2KB JSON key) is enough; nothing here needs it to be cryptographically
     * secure, only stable per (credential, scopes) pair.
     */
    protected function cacheKey(): string
    {
        return 'google-sa-token:'.sha1(($this->credential ?? '').'|'.$this->scopeString());
    }
}
