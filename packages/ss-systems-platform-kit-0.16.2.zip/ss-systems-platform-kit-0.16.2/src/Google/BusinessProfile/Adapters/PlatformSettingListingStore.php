<?php

namespace SsSystems\Platform\Google\BusinessProfile\Adapters;

use SsSystems\Platform\Google\BusinessProfile\Client;
use SsSystems\Platform\Google\BusinessProfile\Contracts\ListingStore;

/**
 * `ListingStore` over a site's own `PlatformSetting` model — the same
 * `gbp.*` keys every site's `App\Support\GoogleBusinessListing` already
 * writes, so a site adopting this reads the listing it already chose, with
 * no data migration:
 *
 *   gbp.account_id, gbp.location_id     every site
 *   gbp.place_id                        gs.construction, deerfield-furniture
 *   gbp.maps_url, gbp.new_review_url    deerfield-furniture (now everyone)
 *
 * The model is resolved by class-string and only its static `get(string
 * $key): ?string` / `put(string $key, ?string $value)` pair is called — the
 * API all six sites' `PlatformSetting` share (a null or '' put deletes the
 * row) — so gs.construction's `BelongsToSite` scope keeps every key to the
 * current tenant. The env values are resolved by the site's binding
 * (GOOGLE_BUSINESS_PROFILE_ACCOUNT_ID/LOCATION_ID/PLACE_ID) and used only
 * while nothing is stored; on a multi-tenant site pass them for the tenant
 * they belong to and null for every other (gs.construction's place-id env
 * value is GS Construction's own — another tenant must never inherit it).
 */
final class PlatformSettingListingStore implements ListingStore
{
    public const ACCOUNT_ID = 'gbp.account_id';

    public const LOCATION_ID = 'gbp.location_id';

    public const PLACE_ID = 'gbp.place_id';

    public const MAPS_URL = 'gbp.maps_url';

    public const NEW_REVIEW_URL = 'gbp.new_review_url';

    /**
     * @param  class-string  $settingModel  the site's PlatformSetting (static get()/put())
     */
    public function __construct(
        private readonly string $settingModel,
        private readonly ?string $envAccountId = null,
        private readonly ?string $envLocationId = null,
        private readonly ?string $envPlaceId = null,
    ) {}

    public function selected(): array
    {
        $account = $this->get(self::ACCOUNT_ID);
        $location = $this->get(self::LOCATION_ID);

        if ($location !== null) {
            return ['account_id' => $account, 'location_id' => $location, 'source' => 'admin'];
        }

        $envAccount = $this->clean($this->envAccountId);
        $envLocation = $this->clean($this->envLocationId);

        return [
            'account_id' => $account ?? $envAccount,
            'location_id' => $envLocation,
            'source' => $envLocation !== null ? 'env' : null,
        ];
    }

    public function link(string $accountId, string $locationId): void
    {
        $locationId = Client::bareId($locationId);

        if ($this->get(self::LOCATION_ID) !== $locationId) {
            $this->rememberLinks(null, null, null);
        }

        $this->put(self::ACCOUNT_ID, Client::bareId($accountId));
        $this->put(self::LOCATION_ID, $locationId);
    }

    public function unlink(): void
    {
        $this->put(self::ACCOUNT_ID, null);
        $this->put(self::LOCATION_ID, null);
        $this->rememberLinks(null, null, null);
    }

    public function rememberLinks(?string $placeId, ?string $mapsUrl, ?string $newReviewUrl): void
    {
        $this->put(self::PLACE_ID, $this->clean($placeId));
        $this->put(self::MAPS_URL, $this->https($mapsUrl));
        $this->put(self::NEW_REVIEW_URL, $this->https($newReviewUrl));
    }

    public function placeId(): ?string
    {
        return $this->get(self::PLACE_ID) ?? $this->clean($this->envPlaceId);
    }

    public function mapsUrl(): ?string
    {
        $stored = $this->get(self::MAPS_URL);

        if ($stored !== null) {
            return $stored;
        }

        $placeId = $this->placeId();

        return $placeId === null ? null : 'https://www.google.com/maps/place/?q=place_id:'.rawurlencode($placeId);
    }

    public function newReviewUrl(): ?string
    {
        return $this->get(self::NEW_REVIEW_URL);
    }

    private function get(string $key): ?string
    {
        try {
            return $this->clean(($this->settingModel)::get($key));
        } catch (\Throwable) {
            return null; // no table yet (mid-install) — public pages read this too
        }
    }

    private function put(string $key, ?string $value): void
    {
        ($this->settingModel)::put($key, $value);
    }

    private function clean(mixed $value): ?string
    {
        return is_string($value) && trim($value) !== '' ? trim($value) : null;
    }

    /** Only an https link is kept: these are printed as public links. */
    private function https(?string $value): ?string
    {
        $value = $this->clean($value);

        return $value !== null && str_starts_with($value, 'https://') ? $value : null;
    }
}
