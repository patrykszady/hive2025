<?php

namespace SsSystems\Platform\Google\BusinessProfile;

use Illuminate\Http\Client\ConnectionException;
use Illuminate\Http\Client\Factory;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Carbon;
use Psr\Log\LoggerInterface;
use Psr\SimpleCache\CacheInterface;
use SsSystems\Platform\Google\Contracts\TokenStore;
use SsSystems\Platform\Google\OAuthClient;
use SsSystems\Platform\Google\StoredGrant;

/**
 * THE Google Business Profile implementation — one for every tenant,
 * replacing six `App\Services\GoogleBusinessProfileService` copies
 * (gs.construction 2,022 lines, jpeterson-design, deerfield-furniture,
 * hive.contractors, ss.systems, dawnsellshomes). It is the union of the
 * fixes each copy proved and of every call any of them makes:
 *
 * - gs.construction's token handling (2026-09-27 ports on the others):
 *   a refreshed access token is PERSISTED to the site's token row (a cache
 *   clear no longer forces a refresh round trip), a ROTATED refresh token
 *   is persisted (even over an env-only grant, which becomes a row), the
 *   scopes Google states on every refresh repair the row, and an
 *   `invalid_grant` starts a 6-hour cooldown — logged once — instead of
 *   hammering the token endpoint with a grant already known to be dead.
 * - jpeterson-design's `forgetGrantsFromThePreviousClient()`: a grant
 *   belongs to the OAuth client that issued it. Every grant now records its
 *   issuing client (`StoredGrant::$clientId`); one recorded against a
 *   client other than the server's is forgotten on sight, and a pre-0.14
 *   row with no record is forgotten the first time Google answers
 *   `unauthorized_client` for it — so the Platforms card asks for the
 *   reconnect that is required anyway instead of reading "Connected".
 * - jpeterson-design's `describeFailure()`, for Business Profile: every
 *   failure carries a reason code and an owner-safe sentence
 *   (`Failure`), read by `lastErrorDescription()`.
 * - dawnsellshomes' branch fix (ss-systems/kit/google-fixes) is the same
 *   gs.construction port, and is therefore in here by construction.
 *
 * Tenancy: nothing here is cached across tenants. The grant comes from the
 * site's `TokenStore` on every call (gs.construction's scope fires there),
 * and every cache key — the access token, the cooldown — is derived from
 * the grant's own refresh token, so two tenants can never read each
 * other's entries even on one shared cache store (the old copies cached
 * the access token under one fixed key). Bind this per resolution, not as
 * a process-wide singleton, on a multi-tenant site.
 *
 * Every account/location is passed in (`…For()` methods): the grant is the
 * site's, the listing is the caller's — ss.systems keeps one listing per
 * market and reads/writes each through the site's `platforms/gbp/*`
 * endpoints (`Http\Concerns\ServesGbpPlatform`). Ids may be bare ("123")
 * or Google's resource names ("accounts/123"); both work.
 *
 * Never throws for a Google failure or a Google that did not answer: a
 * method returns null/[]/false and `getLastError()` says why. Tests fake
 * every host through the injected HTTP factory; nothing here may be run
 * against the real API outside a fake.
 */
class Client
{
    public const PROVIDER = 'google_business_profile';

    public const BUSINESS_SCOPE = OAuthClient::SCOPE_BUSINESS_PROFILE;

    /** @var list<string> business.manage plus who granted it */
    public const SCOPES = [OAuthClient::SCOPE_BUSINESS_PROFILE, 'openid', 'email'];

    /** The `state` provider name the admin's Connect button and the callback use. */
    public const STATE_PROVIDER = 'gbp';

    public const MEDIA_API_BASE = 'https://mybusiness.googleapis.com/v4';

    public const ACCOUNT_API_BASE = 'https://mybusinessaccountmanagement.googleapis.com/v1';

    public const INFO_API_BASE = 'https://mybusinessbusinessinformation.googleapis.com/v1';

    /** storefrontAddress: the listings card prints it. metadata: the public Maps link and place id ss.systems keeps per market. */
    public const LOCATION_READ_MASK = 'name,title,storeCode,websiteUri,storefrontAddress,metadata';

    public const INVALID_GRANT_COOLDOWN_SECONDS = 6 * 3600;

    /**
     * Google's media categories. ADDITIONAL is the default everywhere: it is
     * the one tag every listing accepts (INTERIOR/EXTERIOR are storefront
     * tags a service-area listing refuses — production, 2026-09-22).
     */
    public const MEDIA_CATEGORIES = [
        'COVER', 'PROFILE', 'LOGO', 'EXTERIOR', 'INTERIOR', 'PRODUCT',
        'AT_WORK', 'FOOD_AND_DRINK', 'MENU', 'COMMON_AREA', 'ROOMS', 'TEAMS', 'ADDITIONAL',
    ];

    /** Google's review star enum, as a number. */
    public const STAR_RATINGS = ['ONE' => 1, 'TWO' => 2, 'THREE' => 3, 'FOUR' => 4, 'FIVE' => 5];

    /** A runaway nextPageToken can never loop forever. */
    protected const MAX_PAGES = 50;

    /** @var array<string, mixed>|null */
    protected ?array $lastError = null;

    /**
     * @param  ?string  $fallbackRefreshToken  a server-held grant (GOOGLE_BUSINESS_PROFILE_REFRESH_TOKEN), used only
     *   while nothing is stored. On a multi-tenant site pass it for the tenant it belongs to and null for every other.
     */
    public function __construct(
        protected readonly OAuthClient $oauth,
        protected readonly TokenStore $tokens,
        protected readonly CacheInterface $cache,
        protected readonly Factory $http,
        protected readonly ?LoggerInterface $log = null,
        protected readonly ?string $fallbackRefreshToken = null,
        protected readonly string $provider = self::PROVIDER,
    ) {}

    public function oauth(): OAuthClient
    {
        return $this->oauth;
    }

    public function provider(): string
    {
        return $this->provider;
    }

    /* ------------------------------------------------------------------ */
    /*  The grant                                                          */
    /* ------------------------------------------------------------------ */

    /**
     * The stored grant, or null. A grant recorded against a different OAuth
     * client than the server's is forgotten here, on sight — it can never
     * refresh again, and reporting it "Connected" is the bug
     * jpeterson-design's forgetGrantsFromThePreviousClient() fixed. With no
     * client configured at all nothing is judged (a missing env value must
     * never delete anyone's grant).
     */
    public function grant(): ?StoredGrant
    {
        $grant = $this->tokens->get($this->provider);

        if ($grant !== null && $this->issuedByAnotherClient($grant)) {
            $this->forgetForeignGrant($grant, 'recorded');

            return null;
        }

        return $grant;
    }

    /** The refresh token in use: the stored grant's, else the server-held fallback. */
    public function refreshToken(): ?string
    {
        return $this->grant()?->refreshToken ?? $this->fallback();
    }

    public function hasRefreshToken(): bool
    {
        return $this->refreshToken() !== null;
    }

    /** Connected = a grant exists to act with. Whether it can manage a listing is hasBusinessScope(). */
    public function isConnected(): bool
    {
        return $this->hasRefreshToken();
    }

    /** 'oauth' for a stored grant, 'env' for the server-held fallback, null when neither. */
    public function source(?StoredGrant $grant = null): ?string
    {
        $grant ??= $this->grant();

        return $grant !== null ? 'oauth' : ($this->fallback() !== null ? 'env' : null);
    }

    /** @return list<string> the scopes recorded against the stored grant */
    public function grantedScopes(?StoredGrant $grant = null): array
    {
        return ($grant ?? $this->grant())?->scopes ?? [];
    }

    /**
     * Whether the grant carries business.manage. Without it the connection
     * signs someone in and nothing else: every listing, photo and post call
     * comes back 403.
     */
    public function hasBusinessScope(?StoredGrant $grant = null): bool
    {
        return in_array(self::BUSINESS_SCOPE, $this->grantedScopes($grant), true);
    }

    /**
     * The grant half of platforms/status' `gbp` block — every key the
     * admin's Business Profile card reads about the connection itself (the
     * listing half is `Http\Concerns\ServesGbpPlatform::gbpStatus()`'s).
     * One store read. `reconnect_required` is new: the grant is in its
     * invalid_grant cooldown, i.e. Google already said it is dead.
     *
     * @return array<string, mixed>
     */
    public function grantStatus(): array
    {
        $grant = $this->grant();
        $refreshToken = $grant?->refreshToken ?? $this->fallback();
        $iso = static fn (?\DateTimeInterface $at): ?string => $at === null ? null : Carbon::instance($at)->toIso8601String();

        return [
            'connected' => $refreshToken !== null,
            'source' => $grant !== null ? 'oauth' : ($refreshToken !== null ? 'env' : null),
            'email' => $grant?->grantedByEmail,
            'granted_at' => $iso($grant?->createdAt),
            'updated_at' => $iso($grant?->updatedAt),
            'access_token_expires_at' => $iso($grant?->accessTokenExpiresAt),
            'scopes' => $grant?->scopes,
            'business_scope_granted' => in_array(self::BUSINESS_SCOPE, $grant?->scopes ?? [], true),
            'refresh_token_present' => $refreshToken !== null,
            // The one shared OAuth client is what "configured" means here; the
            // refresh token is what connecting produces, reported above.
            'app_credentials_configured' => $this->oauth->isConfigured(),
            'client_id_configured' => $this->oauth->isConfigured(),
            'client_secret_configured' => $this->oauth->isConfigured(),
            'reconnect_required' => $refreshToken !== null && (bool) $this->cache->get($this->key('invalid_grant', $refreshToken)),
        ];
    }

    /* ------------------------------------------------------------------ */
    /*  Connect / disconnect                                               */
    /* ------------------------------------------------------------------ */

    /** The consent-screen URL with a freshly signed `state` (see OAuthClient::authorizeUrl()). */
    public function authorizeUrl(string $redirectUri): string
    {
        return $this->oauth->authorizeUrl(self::STATE_PROVIDER, $redirectUri, self::SCOPES);
    }

    /** The shape every site's service already had: the caller mints the state. */
    public function getOAuthUrl(string $redirectUri, ?string $state = null): string
    {
        return $this->oauth->authorizeUrlWithState($redirectUri, self::SCOPES, $state);
    }

    /**
     * Trade the callback's code for a grant and store it, recording the
     * client that issued it and the scopes Google actually granted.
     *
     * @return array{success: bool, error?: string}
     */
    public function exchangeCodeAndStore(string $code, string $redirectUri): array
    {
        if (! $this->oauth->isConfigured()) {
            return ['success' => false, 'error' => Failure::make(Failure::CLIENT_MISSING)['description']];
        }

        $result = $this->oauth->exchangeCode($code, $redirectUri);

        if (! $result['ok']) {
            $this->log?->error('GBP: OAuth code exchange failed', ['status' => $result['status'], 'error' => $result['error']]);

            return ['success' => false, 'error' => (string) ($result['error_description'] ?: $result['error'] ?: 'Google refused the sign-in.')];
        }

        if ($result['refresh_token'] === null) {
            return ['success' => false, 'error' => 'No refresh token returned. Try again with prompt=consent.'];
        }

        $previous = $this->tokens->get($this->provider);
        $expiresIn = $result['expires_in'];

        $this->tokens->put($this->provider, new StoredGrant(
            refreshToken: $result['refresh_token'],
            accessToken: $result['access_token'],
            accessTokenExpiresAt: $result['access_token'] !== null ? $this->expiry($expiresIn) : null,
            scopes: $result['scopes'] ?? self::SCOPES,
            grantedByEmail: $result['email'] ?? $previous?->grantedByEmail,
            clientId: $this->oauth->clientId(),
        ));

        $this->clearCaches($previous?->refreshToken);
        $this->clearCaches($result['refresh_token']);

        $this->log?->info('GBP: OAuth tokens stored via web flow', ['email' => $result['email']]);

        return ['success' => true];
    }

    /** Forget the stored grant and everything cached for it. */
    public function disconnect(): void
    {
        $refreshToken = $this->tokens->get($this->provider)?->refreshToken;

        $this->tokens->forget($this->provider);
        $this->clearCaches($refreshToken);

        $this->log?->info('GBP: Disconnected (tokens removed)');
    }

    /* ------------------------------------------------------------------ */
    /*  Access token: cache -> stored token -> refresh (with the fixes)    */
    /* ------------------------------------------------------------------ */

    /**
     * A usable access token, or null with getLastError() saying why. The
     * public accessor sibling services use (gs.construction's Performance
     * service) instead of re-implementing the refresh.
     */
    public function accessToken(): ?string
    {
        $this->lastError = null;
        $grant = $this->grant();
        $refreshToken = $grant?->refreshToken ?? $this->fallback();

        if ($refreshToken === null) {
            // grant() may just have forgotten a grant from another client —
            // that is the reason worth reporting, not "never connected".
            if (($this->lastError['reason'] ?? null) !== Failure::CLIENT_CHANGED) {
                $this->setError('No Google authorization on file', Failure::make(Failure::NO_GRANT), ['reauthorization_required' => true]);
            }

            return null;
        }

        $accessKey = $this->key('access_token', $refreshToken);
        $cached = $this->cache->get($accessKey);

        if (is_string($cached) && $cached !== '') {
            return $cached;
        }

        if ($grant !== null && $grant->hasValidAccessToken()) {
            $secondsLeft = $grant->accessTokenExpiresAt->getTimestamp() - Carbon::now()->getTimestamp();
            $this->cache->set($accessKey, $grant->accessToken, max(1, $secondsLeft));

            return $grant->accessToken;
        }

        if ($this->cache->get($this->key('invalid_grant', $refreshToken))) {
            $this->setError('Token refresh blocked: re-authorization required', Failure::make(Failure::INVALID_GRANT), [
                'status' => 400,
                'error' => 'invalid_grant',
                'error_description' => 'Refresh token has expired or been revoked.',
                'reauthorization_required' => true,
            ]);

            return null;
        }

        if (! $this->oauth->isConfigured()) {
            $this->setError('No OAuth client configured', Failure::make(Failure::CLIENT_MISSING));

            return null;
        }

        $result = $this->oauth->refresh($refreshToken);

        if (! $result['ok']) {
            $this->refreshFailed($result, $refreshToken, $grant, $accessKey);

            return null;
        }

        $this->cache->delete($this->key('invalid_grant', $refreshToken));
        $this->cache->delete($this->key('invalid_grant_logged', $refreshToken));

        $token = $result['access_token'];
        $expiresIn = $result['expires_in'];
        $rotated = $result['refresh_token'] !== null && $result['refresh_token'] !== $refreshToken ? $result['refresh_token'] : null;

        if ($grant !== null) {
            $updated = $grant->withAccessToken($token, $this->expiry($expiresIn));
            // Every refresh states the scopes the grant really carries; recording
            // them repairs a row written when the REQUESTED set was stored.
            if ($result['scopes'] !== null && $result['scopes'] !== [] && $result['scopes'] !== $grant->scopes) {
                $updated = $updated->withScopes($result['scopes']);
            }
            if ($rotated !== null) {
                $updated = $updated->withRefreshToken($rotated);
            }
            // A pre-0.14 row just proved which client it belongs to.
            if ($grant->clientId === null) {
                $updated = $updated->withClientId($this->oauth->clientId());
            }
            $this->tokens->put($this->provider, $updated);
        } elseif ($rotated !== null) {
            // A server-held grant Google rotated: the new token exists nowhere
            // else, so it becomes a stored grant rather than being dropped.
            $this->tokens->put($this->provider, new StoredGrant(
                refreshToken: $rotated,
                accessToken: $token,
                accessTokenExpiresAt: $this->expiry($expiresIn),
                scopes: $result['scopes'] ?? [],
                clientId: $this->oauth->clientId(),
            ));
        }

        if ($rotated !== null) {
            $this->log?->info('GBP: Refresh token rotated and persisted.');
        }

        $this->cache->set($this->key('access_token', $rotated ?? $refreshToken), $token, max(60, $expiresIn - 120));
        $this->lastError = null;

        return $token;
    }

    /** gs.construction's public name for accessToken(). */
    public function getAuthorizedToken(): ?string
    {
        return $this->accessToken();
    }

    /* ------------------------------------------------------------------ */
    /*  Accounts and locations                                             */
    /* ------------------------------------------------------------------ */

    /**
     * Every Business Profile account the grant can see, all pages. [] with
     * getLastError() set on failure — most often a 403 scope_missing (the
     * consent did not include business.manage).
     *
     * @return list<array<string, mixed>>
     */
    public function listAccounts(): array
    {
        return $this->paged(self::ACCOUNT_API_BASE.'/accounts', ['pageSize' => 20], 'accounts', 20, 'List accounts failed') ?? [];
    }

    /**
     * Every listing under one account, all pages.
     *
     * @return list<array<string, mixed>>
     */
    public function listLocations(string $accountId, string $readMask = self::LOCATION_READ_MASK): array
    {
        $accountId = self::bareId($accountId);

        return $this->paged(self::INFO_API_BASE."/accounts/{$accountId}/locations", [
            'readMask' => $readMask,
            'pageSize' => 100,
        ], 'locations', 20, 'List locations failed', ['account_id' => $accountId]) ?? [];
    }

    /**
     * One listing's details (default: name, title and metadata — placeId,
     * mapsUri, newReviewUri). Null with getLastError() set when refused.
     *
     * @return array<string, mixed>|null
     */
    public function getLocation(string $locationId, string $readMask = 'name,title,metadata'): ?array
    {
        $locationId = self::bareId($locationId);
        $response = $this->send('GET', self::INFO_API_BASE."/locations/{$locationId}", ['readMask' => $readMask], 30);

        if (! $this->ok($response, 'Get location failed', ['location_id' => $locationId])) {
            return null;
        }

        return (array) $response->json() ?: null;
    }

    /**
     * Patch one listing (Business Information API): $updateMask names the
     * fields, $payload carries them — categories, profile.description,
     * serviceArea, serviceItems. Building those payloads is the site's own
     * business (gs.construction's category ids, service items and geocoded
     * service areas stay there); the call is shared.
     *
     * @param  array<string, mixed>  $payload
     * @return array<string, mixed>|null the updated location
     */
    public function updateLocation(string $locationId, string $updateMask, array $payload): ?array
    {
        $locationId = self::bareId($locationId);
        $url = self::INFO_API_BASE."/locations/{$locationId}?".http_build_query(['updateMask' => $updateMask]);
        $response = $this->send('PATCH', $url, $payload, 60);

        if (! $this->ok($response, 'Update location failed', ['location_id' => $locationId, 'update_mask' => $updateMask])) {
            return null;
        }

        return (array) $response->json();
    }

    /**
     * Business categories matching $query (for a categories picker).
     *
     * @return list<array<string, mixed>>|null
     */
    public function searchCategories(string $query, string $regionCode = 'US', string $languageCode = 'en'): ?array
    {
        $response = $this->send('GET', self::INFO_API_BASE.'/categories', [
            'regionCode' => $regionCode,
            'languageCode' => $languageCode,
            'filter' => 'categoryName="'.str_replace('"', '', $query).'"',
            'pageSize' => 20,
        ], 30);

        if (! $this->ok($response, 'Search categories failed')) {
            return null;
        }

        return array_values((array) $response->json('categories', []));
    }

    /* ------------------------------------------------------------------ */
    /*  Reviews                                                            */
    /* ------------------------------------------------------------------ */

    /**
     * One page of one listing's reviews (Google pages at 50;
     * nextPageToken continues).
     *
     * @return array{reviews: array, totalReviewCount: int, averageRating: float, nextPageToken: ?string}|null
     */
    public function fetchReviewsFor(string $accountId, string $locationId, ?string $pageToken = null, int $pageSize = 50): ?array
    {
        $accountId = self::bareId($accountId);
        $locationId = self::bareId($locationId);

        $response = $this->send('GET', self::MEDIA_API_BASE."/accounts/{$accountId}/locations/{$locationId}/reviews", array_filter([
            'pageSize' => $pageSize,
            'pageToken' => $pageToken,
        ]), 30);

        if (! $this->ok($response, 'Fetch reviews failed', ['account_id' => $accountId, 'location_id' => $locationId])) {
            return null;
        }

        return [
            'reviews' => array_values((array) $response->json('reviews', [])),
            'totalReviewCount' => (int) ($response->json('totalReviewCount') ?? 0),
            'averageRating' => (float) ($response->json('averageRating') ?? 0),
            'nextPageToken' => is_string($response->json('nextPageToken')) && $response->json('nextPageToken') !== '' ? $response->json('nextPageToken') : null,
        ];
    }

    /**
     * Every review of one listing, all pages. Null when the first page
     * fails; a later failure keeps what was read and leaves getLastError()
     * set.
     *
     * @return list<array<string, mixed>>|null
     */
    public function fetchAllReviewsFor(string $accountId, string $locationId): ?array
    {
        $all = [];
        $pageToken = null;
        $pages = 0;

        do {
            $page = $this->fetchReviewsFor($accountId, $locationId, $pageToken);

            if ($page === null) {
                return $pages === 0 ? null : $all;
            }

            array_push($all, ...$page['reviews']);
            $pageToken = $page['nextPageToken'];
        } while ($pageToken !== null && ++$pages < self::MAX_PAGES);

        return $all;
    }

    /**
     * Reply to (or replace the reply on) one review.
     *
     * @param  string  $reviewName  accounts/{a}/locations/{l}/reviews/{id}
     * @return array<string, mixed>|null
     */
    public function replyToReview(string $reviewName, string $comment): ?array
    {
        $response = $this->send('PUT', self::MEDIA_API_BASE.'/'.ltrim($reviewName, '/').'/reply', ['comment' => $comment], 30);

        if (! $this->ok($response, 'Review reply failed', ['review' => $reviewName])) {
            return null;
        }

        return (array) $response->json();
    }

    /* ------------------------------------------------------------------ */
    /*  Media                                                              */
    /* ------------------------------------------------------------------ */

    /**
     * Every media item Google holds for one listing, all pages, flattened to
     * the five fields ss.systems reads (its hourly reconcile matches
     * `source_url` against its own upload ledger — Google may swap a media
     * `name` after upload, so the name alone is never the truth).
     *
     * @return list<array{name: string, source_url: ?string, google_url: ?string, category: ?string, create_time: ?string}>|null
     */
    public function listMediaFor(string $accountId, string $locationId): ?array
    {
        $accountId = self::bareId($accountId);
        $locationId = self::bareId($locationId);

        $items = $this->paged(self::MEDIA_API_BASE."/accounts/{$accountId}/locations/{$locationId}/media", ['pageSize' => 100], 'mediaItems', 30, 'List media failed', ['account_id' => $accountId, 'location_id' => $locationId]);

        if ($items === null) {
            return null;
        }

        return array_map(static fn (array $item) => [
            'name' => (string) ($item['name'] ?? ''),
            'source_url' => $item['sourceUrl'] ?? null,
            'google_url' => $item['googleUrl'] ?? null,
            'category' => $item['locationAssociation']['category'] ?? null,
            'create_time' => $item['createTime'] ?? null,
        ], $items);
    }

    /**
     * One media item as Google returns it.
     *
     * @return array<string, mixed>|null
     */
    public function getMediaItem(string $mediaName): ?array
    {
        $response = $this->send('GET', self::MEDIA_API_BASE.'/'.ltrim($mediaName, '/'), [], 20);

        if (! $this->ok($response, 'Get media failed', ['media_name' => $mediaName])) {
            return null;
        }

        return (array) $response->json();
    }

    /**
     * Upload one photo Google fetches from $sourceUrl (a public URL — for a
     * project photo, the site's `Media\GooglePhotoCopy` copy). `url` is
     * Google's rendition sized for the original (sizedMediaUrl()), `raw` the
     * whole media resource.
     *
     * @return array{name: string, url: ?string, google_url: ?string, raw: array<string, mixed>}|null
     */
    public function uploadMediaFor(string $accountId, string $locationId, string $sourceUrl, string $category = 'ADDITIONAL', ?string $description = null): ?array
    {
        $accountId = self::bareId($accountId);
        $locationId = self::bareId($locationId);

        $response = $this->send('POST', self::MEDIA_API_BASE."/accounts/{$accountId}/locations/{$locationId}/media", array_filter([
            'mediaFormat' => 'PHOTO',
            'locationAssociation' => ['category' => $category],
            'sourceUrl' => $sourceUrl,
            'description' => $description,
        ], static fn ($value) => $value !== null), 60);

        if (! $this->ok($response, 'Upload media failed', ['account_id' => $accountId, 'location_id' => $locationId])) {
            return null;
        }

        $data = (array) $response->json();
        $name = (string) ($data['name'] ?? '');

        if ($name === '') {
            $this->setError('Upload media returned no name', ['reason' => Failure::ERROR, 'description' => 'Google accepted the photo but did not say where it is.'], ['status' => $response->status()]);

            return null;
        }

        $googleUrl = $data['googleUrl'] ?? $data['thumbnailUrl'] ?? null;

        $this->log?->info('GBP: Uploaded media', ['location_id' => $locationId, 'media_name' => $name, 'category' => $category]);

        return [
            'name' => $name,
            'url' => self::sizedMediaUrl(is_string($googleUrl) ? $googleUrl : null),
            'google_url' => is_string($googleUrl) ? $googleUrl : null,
            'raw' => $data,
        ];
    }

    /**
     * Remove one media item. A 404 is success: the item is already gone (a
     * retry, or Google's own cleanup), so a delete is idempotent.
     */
    public function deleteMediaFor(string $mediaName): bool
    {
        $response = $this->send('DELETE', self::MEDIA_API_BASE.'/'.ltrim($mediaName, '/'), [], 30);

        if ($response !== null && $response->status() === 404) {
            $this->lastError = null;

            return true;
        }

        if (! $this->ok($response, 'Delete media failed', ['media_name' => $mediaName])) {
            return false;
        }

        $this->log?->info('GBP: Deleted media', ['media_name' => $mediaName]);

        return true;
    }

    /* ------------------------------------------------------------------ */
    /*  Local posts ("Updates" on the listing)                             */
    /* ------------------------------------------------------------------ */

    /**
     * One post on a listing — gs.construction's call shape (v4
     * localPosts.create: a photo Google fetches, the text cut to Google's
     * 1,500 characters, a call-to-action button, STANDARD topic), which
     * jpeterson-design's per-market posts and deerfield-furniture's
     * new-listing posts (SHOP, en-US, a 40 s budget) also use. `state` is
     * Google's post state (LIVE / PROCESSING / REJECTED).
     *
     * @param  string  $ctaType  BOOK, ORDER, SHOP, LEARN_MORE, SIGN_UP or CALL
     * @return array{name: string, searchUrl: ?string, state: ?string}|null
     */
    public function createLocalPostFor(
        string $accountId,
        string $locationId,
        string $imageUrl,
        string $summary,
        string $ctaUrl,
        string $ctaType = 'LEARN_MORE',
        string $languageCode = 'en',
        int $timeout = 60,
    ): ?array {
        $accountId = self::bareId($accountId);
        $locationId = self::bareId($locationId);

        if ($accountId === '' || $locationId === '') {
            $this->setError('No listing chosen', Failure::make(Failure::NOT_FOUND), ['status' => 0]);

            return null;
        }

        $response = $this->send('POST', self::MEDIA_API_BASE."/accounts/{$accountId}/locations/{$locationId}/localPosts", [
            'languageCode' => $languageCode,
            'summary' => mb_substr($summary, 0, 1500),
            'callToAction' => ['actionType' => $ctaType, 'url' => $ctaUrl],
            'media' => [['mediaFormat' => 'PHOTO', 'sourceUrl' => $imageUrl]],
            'topicType' => 'STANDARD',
        ], $timeout);

        if (! $this->ok($response, 'Create post failed', ['account_id' => $accountId, 'location_id' => $locationId])) {
            return null;
        }

        $this->log?->info('GBP: Created local post', ['location_id' => $locationId, 'name' => $response->json('name')]);

        return [
            'name' => (string) ($response->json('name') ?? ''),
            'searchUrl' => is_string($response->json('searchUrl')) ? $response->json('searchUrl') : null,
            'state' => is_string($response->json('state')) ? $response->json('state') : null,
        ];
    }

    /**
     * Every post on a listing, all pages.
     *
     * @return list<array<string, mixed>>|null
     */
    public function listLocalPostsFor(string $accountId, string $locationId): ?array
    {
        $accountId = self::bareId($accountId);
        $locationId = self::bareId($locationId);

        return $this->paged(self::MEDIA_API_BASE."/accounts/{$accountId}/locations/{$locationId}/localPosts", ['pageSize' => 100], 'localPosts', 30, 'List local posts failed', ['location_id' => $locationId]);
    }

    /** Delete one post (accounts/{a}/locations/{l}/localPosts/{p}); a 404 is success. */
    public function deleteLocalPost(string $postName): bool
    {
        $response = $this->send('DELETE', self::MEDIA_API_BASE.'/'.ltrim($postName, '/'), [], 30);

        if ($response !== null && $response->status() === 404) {
            $this->lastError = null;

            return true;
        }

        return $this->ok($response, 'Delete local post failed', ['post_name' => $postName]);
    }

    /* ------------------------------------------------------------------ */
    /*  Errors                                                             */
    /* ------------------------------------------------------------------ */

    /**
     * Why the last call failed: `message` (technical), `status`, `reason`
     * (a `Failure` code), `description` (the owner-safe sentence), `body`
     * (Google's answer, trimmed) and — for a refused refresh — `error`,
     * `error_description`, `reauthorization_required`. Null after success.
     *
     * @return array<string, mixed>|null
     */
    public function getLastError(): ?array
    {
        return $this->lastError;
    }

    /** The owner-safe sentence for the last failure, or null after success. */
    public function lastErrorDescription(): ?string
    {
        return $this->lastError['description'] ?? null;
    }

    /**
     * jpeterson-design's describeFailure(), for Business Profile.
     *
     * @return array{reason: string, description: string}
     */
    public function describeFailure(int $status, string $body): array
    {
        return Failure::forApi($status, $body);
    }

    /* ------------------------------------------------------------------ */
    /*  Helpers every site had its own copy of                             */
    /* ------------------------------------------------------------------ */

    /** "accounts/123" and "accounts/123/locations/456" both reduce to the last segment. */
    public static function bareId(string $value): string
    {
        $parts = array_values(array_filter(explode('/', trim($value)), static fn (string $p) => $p !== ''));

        return $parts === [] ? '' : (string) end($parts);
    }

    /**
     * A googleusercontent URL asking for the original rendition (`=s0`).
     * Google hands back a bare URL, which renders as a 512px thumbnail.
     * Only googleusercontent understands the suffix; an already sized URL
     * and every other host pass through unchanged.
     */
    public static function sizedMediaUrl(?string $url, string $size = 's0'): ?string
    {
        $url = trim((string) $url);

        if ($url === '') {
            return null;
        }

        if (! str_contains($url, 'googleusercontent.com') || preg_match('/=[a-z0-9-]+$/i', $url)) {
            return $url;
        }

        return $url.'='.$size;
    }

    /* ------------------------------------------------------------------ */
    /*  Internals                                                          */
    /* ------------------------------------------------------------------ */

    /**
     * One authorized call. Null when there is no token (getLastError() set
     * by accessToken()) or Google did not answer; otherwise the response,
     * successful or not.
     *
     * @param  array<string, mixed>  $params  query for GET/DELETE, JSON body otherwise
     */
    protected function send(string $method, string $url, array $params, int $timeout): ?Response
    {
        $token = $this->accessToken();

        if ($token === null) {
            return null;
        }

        try {
            $request = $this->http->withToken($token)->timeout($timeout);

            $response = match ($method) {
                'GET' => $request->get($url, $params),
                'POST' => $request->post($url, $params),
                'PUT' => $request->put($url, $params),
                'PATCH' => $request->patch($url, $params),
                'DELETE' => $request->delete($url, $params),
            };
        } catch (ConnectionException $e) {
            $this->setError('Google did not answer', Failure::make(Failure::NO_ANSWER), ['status' => 0, 'body' => mb_substr($e->getMessage(), 0, 300)]);
            $this->log?->warning('GBP: Google did not answer', ['url' => $url, 'error' => $e->getMessage()]);

            return null;
        }

        // A revoked or expired access token: never serve it from cache again.
        if ($response->status() === 401) {
            $refreshToken = $this->refreshToken();
            if ($refreshToken !== null) {
                $this->cache->delete($this->key('access_token', $refreshToken));
            }
        }

        return $response;
    }

    /**
     * True for a successful response (clears getLastError()); false — with
     * the failure described and logged — for anything else.
     *
     * @param  array<string, mixed>  $context
     */
    protected function ok(?Response $response, string $message, array $context = []): bool
    {
        if ($response === null) {
            return false;
        }

        if ($response->successful()) {
            $this->lastError = null;

            return true;
        }

        $body = (string) $response->body();
        $described = Failure::forApi($response->status(), $body);

        $this->setError($message, $described, $context + [
            'status' => $response->status(),
            'body' => mb_substr($body, 0, 2000),
            'reauthorization_required' => $response->status() === 401,
        ]);

        $this->log?->warning('GBP: '.$message, $context + [
            'status' => $response->status(),
            'reason' => $described['reason'],
            'body' => mb_substr($body, 0, 500),
        ]);

        return false;
    }

    /**
     * Every page of a Google list endpoint, the items under $itemsKey. Null
     * when the first page fails; a later failure keeps what was read.
     *
     * @param  array<string, mixed>  $params
     * @param  array<string, mixed>  $context
     * @return list<array<string, mixed>>|null
     */
    protected function paged(string $url, array $params, string $itemsKey, int $timeout, string $message, array $context = []): ?array
    {
        $items = [];
        $pageToken = null;
        $pages = 0;

        do {
            $response = $this->send('GET', $url, $params + array_filter(['pageToken' => $pageToken]), $timeout);

            if (! $this->ok($response, $message, $context)) {
                return $pages === 0 ? null : $items;
            }

            foreach ((array) $response->json($itemsKey, []) as $item) {
                if (is_array($item)) {
                    $items[] = $item;
                }
            }

            $next = $response->json('nextPageToken');
            $pageToken = is_string($next) && $next !== '' ? $next : null;
        } while ($pageToken !== null && ++$pages < self::MAX_PAGES);

        return $items;
    }

    /**
     * @param  array{ok: false, status: int, error: ?string, error_description: ?string, body: string}  $result
     */
    protected function refreshFailed(array $result, string $refreshToken, ?StoredGrant $grant, string $accessKey): void
    {
        $described = Failure::forToken($result['status'], $result['error']);
        $isInvalidGrant = $result['status'] === 400 && $result['error'] === 'invalid_grant';
        $isForeign = $result['error'] === 'unauthorized_client';

        $this->setError('Token refresh failed', $described, [
            'status' => $result['status'],
            'body' => $result['body'],
            'error' => $result['error'],
            'error_description' => $result['error_description'],
            'reauthorization_required' => $isInvalidGrant || $isForeign,
        ]);

        if (! $isInvalidGrant && ! $isForeign) {
            $this->log?->warning('GBP: Access token refresh failed', ['status' => $result['status'], 'error' => $result['error']]);

            return;
        }

        $this->cache->delete($accessKey);
        $this->cache->set($this->key('invalid_grant', $refreshToken), true, self::INVALID_GRANT_COOLDOWN_SECONDS);

        // A pre-0.14 grant from another client: Google will never refresh it
        // here. Forget it so the card asks for the reconnect it needs.
        if ($isForeign && $grant !== null && $grant->refreshToken === $refreshToken) {
            $this->forgetForeignGrant($grant, 'refused');

            return;
        }

        $loggedKey = $this->key('invalid_grant_logged', $refreshToken);
        if (! $this->cache->has($loggedKey)) {
            $this->cache->set($loggedKey, true, self::INVALID_GRANT_COOLDOWN_SECONDS);
            $this->log?->error($isForeign
                ? 'GBP: The server-held refresh token belongs to a different OAuth client (unauthorized_client). Reconnect from the Platforms screen.'
                : 'GBP: Refresh token invalid_grant (expired/revoked). Reconnect from the Platforms screen.', [
                'status' => $result['status'],
                'error' => $result['error'],
                'error_description' => $result['error_description'],
            ]);
        }
    }

    protected function issuedByAnotherClient(StoredGrant $grant): bool
    {
        $current = $this->oauth->clientId();

        return $current !== null && $grant->clientId !== null && $grant->clientId !== $current;
    }

    protected function forgetForeignGrant(StoredGrant $grant, string $how): void
    {
        $this->tokens->forget($this->provider);
        $this->cache->delete($this->key('access_token', $grant->refreshToken));

        $this->setError('Grant issued by another OAuth client', Failure::make(Failure::CLIENT_CHANGED), ['reauthorization_required' => true]);
        $this->log?->notice('GBP: Forgot a grant issued by a different OAuth client; reconnect to use the current one.', [
            'provider' => $this->provider,
            'detected' => $how,
        ]);
    }

    /** Forget the cached access token and the cooldown for one refresh token. */
    protected function clearCaches(?string $refreshToken): void
    {
        if ($refreshToken === null || $refreshToken === '') {
            return;
        }

        $this->cache->delete($this->key('access_token', $refreshToken));
        $this->cache->delete($this->key('invalid_grant', $refreshToken));
        $this->cache->delete($this->key('invalid_grant_logged', $refreshToken));
    }

    /**
     * Every cache key is derived from the grant's own refresh token: tenant-
     * safe on a shared store, and invalidated by a reconnect or a rotation.
     * Dots only — PSR-16 reserves ':' and friends.
     */
    protected function key(string $what, string $refreshToken): string
    {
        return $this->provider.'.'.$what.'.'.sha1($refreshToken);
    }

    /** The stored expiry: Google's lifetime minus a two-minute buffer. */
    protected function expiry(int $expiresIn): Carbon
    {
        return Carbon::now()->addSeconds(max(0, $expiresIn - 120));
    }

    protected function fallback(): ?string
    {
        $token = trim((string) $this->fallbackRefreshToken);

        return $token === '' ? null : $token;
    }

    /**
     * @param  array{reason: string, description: string}  $described
     * @param  array<string, mixed>  $extra
     */
    protected function setError(string $message, array $described, array $extra = []): void
    {
        $this->lastError = ['message' => $message] + $described + $extra;
    }
}
