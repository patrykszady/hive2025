<?php

namespace SsSystems\Platform\Google\BusinessProfile;

/**
 * Turns a Google failure into a reason code and one owner-safe sentence —
 * what the Platforms card, the review import and the photo pipeline show,
 * instead of "List accounts failed" or a JSON body.
 *
 * Google answers several very different problems with the same HTTP
 * status, and only the body tells them apart (the lesson of
 * jpeterson-design's Search Console `describeFailure()`, ported here for
 * Business Profile): a 403 is "this grant only signs in" OR "the API is
 * switched off in the Cloud project" OR "that account can't manage the
 * listing"; a 429 is ordinary rate limiting OR — the one that matters for a
 * shared client — a Cloud project Google has not granted Business Profile
 * API access yet (quota limit 0). Sentences for problems on OUR side (the
 * client, the Cloud project) say so and ask nothing of the owner; sentences
 * for problems the owner can fix say what to press.
 */
final class Failure
{
    public const NO_GRANT = 'no_grant';

    public const CLIENT_MISSING = 'client_missing';

    public const INVALID_GRANT = 'invalid_grant';

    public const CLIENT_CHANGED = 'client_changed';

    public const CLIENT_REJECTED = 'client_rejected';

    public const SCOPE_MISSING = 'scope_missing';

    public const API_DISABLED = 'api_disabled';

    public const NO_API_ACCESS = 'no_api_access';

    public const RATE_LIMITED = 'rate_limited';

    public const PERMISSION_DENIED = 'permission_denied';

    public const NOT_FOUND = 'not_found';

    public const INVALID_REQUEST = 'invalid_request';

    public const UNAVAILABLE = 'unavailable';

    public const NO_ANSWER = 'no_answer';

    public const ERROR = 'error';

    /**
     * Classify one Google API answer (never the token endpoint — see
     * forToken()).
     *
     * @return array{reason: string, description: string}
     */
    public static function forApi(int $status, string $body): array
    {
        $json = json_decode($body, true);
        $error = is_array($json) && is_array($json['error'] ?? null) ? $json['error'] : [];
        $googleMessage = is_string($error['message'] ?? null) ? $error['message'] : '';
        $googleStatus = is_string($error['status'] ?? null) ? $error['status'] : '';
        $reasons = [];
        $quotaZero = false;

        foreach ((array) ($error['details'] ?? []) as $detail) {
            if (is_array($detail) && is_string($detail['reason'] ?? null)) {
                $reasons[] = $detail['reason'];
            }
            if (is_array($detail) && (string) (($detail['metadata'] ?? [])['quota_limit_value'] ?? '') === '0') {
                $quotaZero = true;
            }
        }
        foreach ((array) ($error['errors'] ?? []) as $legacy) {
            if (is_array($legacy) && is_string($legacy['reason'] ?? null)) {
                $reasons[] = $legacy['reason'];
            }
        }

        $has = static fn (string ...$needles): bool => array_intersect($needles, $reasons) !== [];
        $project = preg_match('/project[ _:](?:number:)?(\d+)/i', $googleMessage.' '.$body, $m) ? $m[1] : null;

        return match (true) {
            $status === 0 => self::make(self::NO_ANSWER),
            $status === 401 => self::make(self::INVALID_GRANT),
            $status === 403 && ($has('ACCESS_TOKEN_SCOPE_INSUFFICIENT', 'insufficientPermissions') || str_contains($googleMessage, 'insufficient authentication scopes'))
                => self::make(self::SCOPE_MISSING),
            $status === 403 && ($has('SERVICE_DISABLED', 'accessNotConfigured') || str_contains($body, 'has not been used in project'))
                => self::make(self::API_DISABLED, $project),
            $status === 429 && ($quotaZero || str_contains($body, "quota_limit_value\":\"0\""))
                => self::make(self::NO_API_ACCESS, $project),
            $status === 429 || $googleStatus === 'RESOURCE_EXHAUSTED' => self::make(self::RATE_LIMITED),
            $status === 403 => self::make(self::PERMISSION_DENIED),
            $status === 404 => self::make(self::NOT_FOUND),
            $status === 400 && $googleMessage !== '' => [
                'reason' => self::INVALID_REQUEST,
                'description' => 'Google refused the request: '.rtrim(mb_substr($googleMessage, 0, 200), '.').'.',
            ],
            $status >= 500 => self::make(self::UNAVAILABLE),
            default => ['reason' => self::ERROR, 'description' => "Google refused the request (HTTP {$status})."],
        };
    }

    /**
     * Classify a refused refresh (the token endpoint's OAuth error codes).
     *
     * @return array{reason: string, description: string}
     */
    public static function forToken(int $status, ?string $error): array
    {
        return match (true) {
            $status === 0 => self::make(self::NO_ANSWER),
            $error === 'invalid_grant' => self::make(self::INVALID_GRANT),
            $error === 'unauthorized_client' => self::make(self::CLIENT_CHANGED),
            $error === 'invalid_client' => self::make(self::CLIENT_REJECTED),
            $status >= 500 => self::make(self::UNAVAILABLE),
            default => ['reason' => self::ERROR, 'description' => "Google refused to renew the connection (HTTP {$status})."],
        };
    }

    /**
     * The sentence for a reason code.
     *
     * @return array{reason: string, description: string}
     */
    public static function make(string $reason, ?string $project = null): array
    {
        $inProject = $project ? " (Google Cloud project {$project})" : '';

        return ['reason' => $reason, 'description' => match ($reason) {
            self::NO_GRANT => 'Google Business Profile is not connected yet.',
            self::CLIENT_MISSING => 'Google sign-in is not set up on the server yet. This is on our side; nothing for you to do.',
            self::INVALID_GRANT => 'Google no longer accepts this connection (it was revoked or has expired). Reconnect Google Business Profile.',
            self::CLIENT_CHANGED => 'This connection was made through a Google sign-in this site no longer uses. Reconnect Google Business Profile.',
            self::CLIENT_REJECTED => 'Google refused the server\'s sign-in client. This is on our side; nothing for you to do.',
            self::SCOPE_MISSING => 'This connection was approved for signing in only. Reconnect and leave "Manage this business on Google" ticked.',
            self::API_DISABLED => "The Business Profile API is switched off for the sign-in client{$inProject}. This is on our side; nothing for you to do.",
            self::NO_API_ACCESS => "Google has not given the sign-in client{$inProject} access to the Business Profile API yet. This is on our side; nothing for you to do.",
            self::RATE_LIMITED => 'Google is limiting how often we can ask right now. Try again in a few minutes.',
            self::PERMISSION_DENIED => 'The connected Google account cannot manage that listing. Reconnect with an account that manages it.',
            self::NOT_FOUND => 'Google has no such listing, or it has been removed.',
            self::UNAVAILABLE => 'Google had a problem answering. Try again shortly.',
            self::NO_ANSWER => 'Google did not answer. Try again shortly.',
            default => 'Google refused the request.',
        }];
    }
}
