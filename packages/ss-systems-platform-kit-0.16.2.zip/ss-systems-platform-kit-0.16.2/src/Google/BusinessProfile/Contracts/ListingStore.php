<?php

namespace SsSystems\Platform\Google\BusinessProfile\Contracts;

/**
 * Which Business Profile listing a site's own posting reads — the
 * `GoogleBusinessListing` shape every site already keeps (hive.contractors,
 * dawnsellshomes, deerfield-furniture and ss.systems byte-for-byte;
 * gs.construction and jpeterson-design with a few extras): the chosen
 * account and location ids (stored bare), plus the listing's public links
 * Google reports once it is chosen (place id, Maps page, "write a review").
 *
 * ss.systems owns the per-market listings now (`gbp_listings` there); this
 * is the one listing it keeps each site in step with — POST
 * platforms/gbp/listing, its first market's — as the bridge while a site's
 * own posting tick still reads one listing.
 *
 * Tenant-scoped like `Google\Contracts\TokenStore`: an implementation
 * answers for the current tenant only (gs.construction's `PlatformSetting`
 * carries `BelongsToSite`). `Adapters\PlatformSettingListingStore` is the
 * implementation over the `platform_settings` keys every site uses.
 */
interface ListingStore
{
    /**
     * The chosen listing: a stored one wins, else the server's env values.
     *
     * @return array{account_id: ?string, location_id: ?string, source: 'admin'|'env'|null}
     */
    public function selected(): array;

    /** Choose a listing; ids are stored bare. A different location forgets the previous one's links. */
    public function link(string $accountId, string $locationId): void;

    /** Forget the chosen listing (and its links). */
    public function unlink(): void;

    /** The chosen listing's public links, as Google reports them (null clears each). */
    public function rememberLinks(?string $placeId, ?string $mapsUrl, ?string $newReviewUrl): void;

    public function placeId(): ?string;

    /** The listing's public Maps page — Google's own link, else one built from the place id. */
    public function mapsUrl(): ?string;

    /** Google's "write a review" link for the listing. */
    public function newReviewUrl(): ?string;
}
