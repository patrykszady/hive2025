<?php

namespace SsSystems\Platform\Google\BusinessProfile\Http\Concerns;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\URL;
use LogicException;
use Illuminate\Container\Container;
use SsSystems\Platform\Google\Adapters\PlatformSettingSharedClient;
use SsSystems\Platform\Google\BusinessProfile\Client;
use SsSystems\Platform\Google\BusinessProfile\Contracts\ListingStore;
use SsSystems\Platform\Google\BusinessProfile\Failure;
use SsSystems\Platform\Google\OAuthClient;

/**
 * The site side of ss.systems' Google cards — the `platforms/gbp/*` and
 * `platforms/google/*` admin-API endpoints, one implementation for every
 * tenant. The consumer contract is ss.systems' `App\Livewire\Admin\
 * PlatformsSettings` (listings, "Add", "Import reviews", Connect,
 * Disconnect, the Google sign-in card) and its photo pipeline
 * (`UploadImageToGbpListing`, `RemoveImageFromGbpListing`,
 * `GbpReconcilePhotos`, `GbpCoverRotation`, `GbpMediaLedgerSync`); every
 * response here has the exact shape those read.
 *
 * A site's `Api\Admin\V1\PlatformsController` uses this trait and routes:
 *
 *     GET    platforms/gbp/listings      gbpListings        (?all=1 — the platform admin's "Show every listing")
 *     POST   platforms/gbp/listing       saveGbpListing
 *     GET    platforms/gbp/reviews       gbpReviews         (?account_id&location_id[&page_token])
 *     GET    platforms/gbp/media         gbpListMedia       (?account_id&location_id)
 *     POST   platforms/gbp/media         uploadGbpMedia     (405 unless the site sends photos)
 *     DELETE platforms/gbp/media         deleteGbpMedia     (405 unless the site sends photos)
 *     PUT    platforms/gbp/media/ledger  saveGbpMediaLedger (405 unless the site sends photos)
 *     POST   platforms/google/credentials   saveGoogleCredentials  (a refusal: see below)
 *     DELETE platforms/google/credentials   clearGoogleCredentials (a refusal)
 *
 * and, inside its own `{provider}` dispatch (which also carries Meta, and on
 * gs.construction/jpeterson-design the OAuth Search Console):
 *
 *     GET    platforms/{provider}/oauth-url  'gbp' => $this->gbpOauthUrl()
 *     DELETE platforms/{provider}            'gbp' => $this->disconnectGbp()
 *
 * and puts `'google' => $this->googleStatus()`, `'gbp' => $this->gbpStatus()`
 * into its platforms/status payload.
 *
 * Two hooks are required — `gbpClient()` and `gbpListingStore()` (both
 * resolved from the container in practice). Everything else a site differs
 * on is an optional hook below, defaulting to the single-tenant, no-photos
 * shape hive.contractors, deerfield-furniture and ss.systems have:
 * gs.construction filters listings to its own hosts (`gbpSiteHosts()`) and
 * runs `adoptAsSocialUrl()` after a save (`gbpListingSaved()`); sites with
 * testimonials flag reviews already imported (`gbpImportedReviewIds()`) and
 * count them (`gbpReviewStats()`); gs.construction and jpeterson-design send
 * project photos (`gbpAcceptsMediaWrites()` + the three media hooks);
 * jpeterson-design reports its markets (`gbpStatusExtras()`).
 *
 * The Google sign-in client is shared server configuration since 0.14.0
 * (`OAuthClient`), so POST/DELETE platforms/google/credentials refuse with a
 * sentence — a 422 whose `errors.client_id` the admin's card shows on the
 * field — and never store a per-site client again.
 *
 * Validation is hand-rolled (the kit has no illuminate/validation) with
 * Laravel's own 422 shape, so the admin's validation handling is unchanged;
 * a crafted array where a string belongs is a 422, never a 500. Responses
 * are built with `new JsonResponse(...)` — no `BuildsApiResponses`
 * dependency, testable without a booted app.
 */
trait ServesGbpPlatform
{
    /** The one Business Profile client, bound for the current tenant. */
    abstract protected function gbpClient(): Client;

    /** Which listing this site's own posting reads. */
    abstract protected function gbpListingStore(): ListingStore;

    /* ------------------------------------------------------------------ */
    /*  platforms/status blocks                                            */
    /* ------------------------------------------------------------------ */

    /**
     * The `google` block: the shared client's presence and provenance and
     * this tenant's callback URIs — the ones to add to the shared client.
     *
     * @return array<string, mixed>
     */
    protected function googleStatus(): array
    {
        $uris = [];
        foreach ($this->googleRedirectProviders() as $provider) {
            $uris[$provider] = $this->googleRedirectUri($provider);
        }

        return $this->gbpClient()->oauth()->status($uris);
    }

    /**
     * The `gbp` block: the grant (Client::grantStatus()), the chosen listing,
     * and the reviews held from Google.
     *
     * @return array<string, mixed>
     */
    protected function gbpStatus(): array
    {
        $client = $this->gbpClient();
        $store = $this->gbpListingStore();
        $grant = $client->grantStatus();
        $listing = $store->selected();
        $reviews = $this->gbpReviewStats();

        return $grant + [
            'fully_configured' => $grant['connected'] && $grant['app_credentials_configured'] && $listing['account_id'] !== null && $listing['location_id'] !== null,
            'account_id_configured' => $listing['account_id'] !== null,
            'location_id_configured' => $listing['location_id'] !== null,
            'listing_source' => $listing['source'],
            'maps_url' => $store->mapsUrl(),
            'reviews_count' => (int) ($reviews['count'] ?? 0),
            'latest_review_date' => $reviews['latest'] ?? null,
        ] + $this->gbpStatusExtras();
    }

    /* ------------------------------------------------------------------ */
    /*  Google sign-in: shared server configuration                        */
    /* ------------------------------------------------------------------ */

    /** POST platforms/google/credentials — refused: the client is shared server configuration. */
    public function saveGoogleCredentials(Request $request): JsonResponse
    {
        $message = $this->googleClientIsSharedMessage();

        return new JsonResponse(['message' => $message, 'errors' => ['client_id' => [$message]]], 422);
    }

    /** DELETE platforms/google/credentials — refused, as a calm notice (a message and no errors). */
    public function clearGoogleCredentials(): JsonResponse
    {
        return new JsonResponse(['message' => $this->googleClientIsSharedMessage()], 422);
    }

    /**
     * PUT platforms/google/shared-client {client_id, client_secret,
     * project_id?} — ss.systems provisions the one Google sign-in client it
     * owns (0.15.0). Stored encrypted in the site's PlatformSetting; the
     * site's OAuthClient reads it first. 405 on a site that binds no
     * PlatformSettingSharedClient, which ss.systems reads as "not offered".
     */
    public function saveSharedGoogleClient(Request $request): JsonResponse
    {
        $store = $this->googleSharedClient();

        if ($store === null) {
            return $this->sharedClientNotOffered();
        }

        $clientId = $request->input('client_id');
        $clientSecret = $request->input('client_secret');
        $projectId = $request->input('project_id');
        $errors = [];

        if (! is_string($clientId) || ! str_ends_with(trim($clientId), '.apps.googleusercontent.com')) {
            $errors['client_id'] = ['A Google OAuth client id ends with .apps.googleusercontent.com.'];
        }
        if (! is_string($clientSecret) || trim($clientSecret) === '') {
            $errors['client_secret'] = ['The client secret is required.'];
        }
        if ($projectId !== null && ! is_string($projectId)) {
            $errors['project_id'] = ['The project id must be text.'];
        }

        if ($errors !== []) {
            return new JsonResponse(['message' => 'The Google client was not stored.', 'errors' => $errors], 422);
        }

        $store->put($clientId, $clientSecret, $projectId);

        return new JsonResponse(['data' => ['stored' => true, 'client_id' => trim($clientId)]]);
    }

    /** DELETE platforms/google/shared-client — forget the provisioned client (the site falls back to its config). */
    public function forgetSharedGoogleClient(): JsonResponse
    {
        $store = $this->googleSharedClient();

        if ($store === null) {
            return $this->sharedClientNotOffered();
        }

        $store->forget();

        return new JsonResponse(['data' => ['stored' => false]]);
    }

    /**
     * Where ss.systems' provisioned client is kept: the site binds
     * PlatformSettingSharedClient over its own PlatformSetting. Null (the
     * shared-client endpoints answer 405) on a site that binds none.
     */
    protected function googleSharedClient(): ?PlatformSettingSharedClient
    {
        $container = Container::getInstance();

        return $container->bound(PlatformSettingSharedClient::class)
            ? $container->make(PlatformSettingSharedClient::class)
            : null;
    }

    private function sharedClientNotOffered(): JsonResponse
    {
        return new JsonResponse(['message' => 'This site does not take the Google client from ss.systems.'], 405);
    }

    /* ------------------------------------------------------------------ */
    /*  Connect / disconnect                                               */
    /* ------------------------------------------------------------------ */

    /**
     * GET platforms/gbp/oauth-url. With no client on the server this answers
     * 200 with `url: null` and a sentence (deerfield-furniture's refinement)
     * rather than sending the browser to a Google error page.
     */
    public function gbpOauthUrl(): JsonResponse
    {
        $client = $this->gbpClient();

        if (! $client->oauth()->isConfigured()) {
            return new JsonResponse(['data' => ['url' => null, 'message' => Failure::make(Failure::CLIENT_MISSING)['description']]]);
        }

        return new JsonResponse(['data' => ['url' => $client->authorizeUrl($this->googleRedirectUri(Client::STATE_PROVIDER))]]);
    }

    /** DELETE platforms/gbp — forget the grant. */
    public function disconnectGbp(): Response
    {
        $this->gbpClient()->disconnect();

        return new Response('', 204);
    }

    /* ------------------------------------------------------------------ */
    /*  Listings                                                           */
    /* ------------------------------------------------------------------ */

    /**
     * GET platforms/gbp/listings — the accounts and listings the grant can
     * see, so ss.systems offers them instead of asking for ids nobody has.
     * On a site that filters (`gbpSiteHosts()`), only listings whose website
     * is one of the site's hosts are shown, plus the one already linked; the
     * rest are counted in `hidden_count` and returned with `?all=1`.
     */
    public function gbpListings(Request $request): JsonResponse
    {
        $client = $this->gbpClient();
        $grant = $client->grant();

        if (! $client->hasRefreshToken()) {
            return new JsonResponse(['message' => 'Connect Google Business Profile first.'], 422);
        }

        if (! $client->hasBusinessScope($grant)) {
            return new JsonResponse([
                'message' => 'This authorisation only covers signing in. Reconnect and allow Business Profile access.',
                'data' => ['business_scope_granted' => false, 'accounts' => []],
            ], 422);
        }

        $hosts = $this->gbpSiteHosts();
        $filtering = $hosts !== null;
        $showAll = $request->boolean('all');
        $selected = $this->gbpListingStore()->selected();
        $accounts = [];
        $hidden = 0;

        foreach ($client->listAccounts() as $account) {
            $accountId = Client::bareId((string) ($account['name'] ?? ''));

            if ($accountId === '') {
                continue;
            }

            $locations = [];

            foreach ($client->listLocations($accountId) as $location) {
                $locationId = Client::bareId((string) ($location['name'] ?? ''));
                $isLinked = $locationId !== '' && $locationId === $selected['location_id'];

                if ($filtering && ! $showAll && ! $isLinked && ! $this->gbpLocationVisible($location, $hosts)) {
                    $hidden++;

                    continue;
                }

                $locations[] = $this->gbpLocationRow($locationId, $location);
            }

            // An account with nothing of this site's left in it is noise on the card.
            if ($filtering && ! $showAll && $locations === []) {
                continue;
            }

            $accounts[] = [
                'account_id' => $accountId,
                'name' => $account['accountName'] ?? $account['name'] ?? $accountId,
                'type' => $account['type'] ?? null,
                'locations' => $locations,
            ];
        }

        if ($accounts === [] && $client->getLastError() !== null) {
            return new JsonResponse([
                'message' => 'Google refused the listing lookup: '.$client->lastErrorDescription(),
            ], 422);
        }

        return new JsonResponse(['data' => [
            'business_scope_granted' => true,
            'accounts' => $accounts,
            'filtered' => $filtering && ! $showAll,
            'hidden_count' => $hidden,
            ...($filtering ? ['site_hosts' => $hosts] : []),
            'selected' => [
                'account_id' => $selected['account_id'],
                'location_id' => $selected['location_id'],
            ],
        ]]);
    }

    /**
     * POST platforms/gbp/listing {account_id, location_id} — the listing this
     * site's own posting reads (ss.systems keeps it on its first market's).
     * Ids are stored bare; then Google is asked ONCE for the listing's public
     * links (place id, Maps page, "write a review"), which never fails the
     * save — the listing is linked either way (deerfield-furniture's
     * refinement, now everyone's).
     */
    public function saveGbpListing(Request $request): JsonResponse
    {
        $input = $this->gbpValidate($request, [
            'account_id' => 'required|string|max:191',
            'location_id' => 'required|string|max:191',
        ]);

        if ($input instanceof JsonResponse) {
            return $input;
        }

        $store = $this->gbpListingStore();
        $accountId = Client::bareId($input['account_id']);
        $locationId = Client::bareId($input['location_id']);

        $store->link($accountId, $locationId);

        $location = null;
        try {
            $location = $this->gbpClient()->getLocation($locationId);

            if ($location !== null) {
                $metadata = is_array($location['metadata'] ?? null) ? $location['metadata'] : [];
                $store->rememberLinks(
                    is_string($metadata['placeId'] ?? null) ? $metadata['placeId'] : null,
                    is_string($metadata['mapsUri'] ?? null) ? $metadata['mapsUri'] : null,
                    is_string($metadata['newReviewUri'] ?? null) ? $metadata['newReviewUri'] : null,
                );
            }
        } catch (\Throwable) {
            // The links are a nicety; the listing is linked regardless.
        }

        $this->gbpListingSaved($accountId, $locationId, $location);

        return new JsonResponse(['data' => $this->gbpStatus()]);
    }

    /* ------------------------------------------------------------------ */
    /*  Reviews                                                            */
    /* ------------------------------------------------------------------ */

    /**
     * GET platforms/gbp/reviews?account_id=&location_id=[&page_token=] — one
     * page of one listing's Google reviews, for ss.systems' per-market
     * import. `imported` marks a review this site already holds (by Google
     * review id) so only new ones are created. A Google refusal is a 422
     * whose `errors.google` carries the reason — what the admin shows.
     */
    public function gbpReviews(Request $request): JsonResponse
    {
        $input = $this->gbpValidate($request, [
            'account_id' => 'required|string|max:191',
            'location_id' => 'required|string|max:191',
            'page_token' => 'nullable|string|max:2048',
        ]);

        if ($input instanceof JsonResponse) {
            return $input;
        }

        $client = $this->gbpClient();

        if (! $client->hasRefreshToken()) {
            return new JsonResponse(['message' => 'Connect Google Business Profile first.'], 422);
        }

        $page = $client->fetchReviewsFor($input['account_id'], $input['location_id'], $input['page_token'] ?? null);

        if ($page === null) {
            return $this->gbpRefused('Google refused the review lookup: ', $client);
        }

        $reviews = [];
        foreach ($page['reviews'] as $review) {
            $id = Client::bareId((string) ($review['name'] ?? ''));
            if ($id !== '') {
                $reviews[$id] = $review;
            }
        }

        $held = array_flip(array_map('strval', $reviews === [] ? [] : $this->gbpImportedReviewIds(array_keys($reviews))));

        return new JsonResponse(['data' => [
            'reviews' => array_values(array_map(static fn (string $id, array $review) => [
                'id' => $id,
                'reviewer' => $review['reviewer']['displayName'] ?? 'Google Reviewer',
                'rating' => Client::STAR_RATINGS[$review['starRating'] ?? ''] ?? null,
                'comment' => (string) ($review['comment'] ?? ''),
                'created_at' => $review['createTime'] ?? null,
                'url' => 'https://www.google.com/maps/reviews?reviewid='.$id,
                'imported' => isset($held[$id]),
            ], array_map('strval', array_keys($reviews)), $reviews)),
            'next_page_token' => $page['nextPageToken'],
            'total_review_count' => $page['totalReviewCount'],
            'average_rating' => $page['averageRating'],
        ]]);
    }

    /* ------------------------------------------------------------------ */
    /*  Media                                                              */
    /* ------------------------------------------------------------------ */

    /**
     * GET platforms/gbp/media?account_id=&location_id= — every media item on
     * one listing (ss.systems' reconcile and cover rotation read it). Read-
     * only, so every site answers it.
     */
    public function gbpListMedia(Request $request): JsonResponse
    {
        $input = $this->gbpValidate($request, [
            'account_id' => 'required|string|max:191',
            'location_id' => 'required|string|max:191',
        ]);

        if ($input instanceof JsonResponse) {
            return $input;
        }

        $client = $this->gbpClient();

        if (! $client->hasRefreshToken()) {
            return new JsonResponse(['message' => 'Connect Google Business Profile first.'], 422);
        }

        $items = $client->listMediaFor($input['account_id'], $input['location_id']);

        if ($items === null) {
            return $this->gbpRefused('Google refused the media lookup: ', $client);
        }

        return new JsonResponse(['data' => ['items' => $items, 'count' => count($items)]]);
    }

    /**
     * POST platforms/gbp/media {account_id, location_id, image_id,
     * category?, description?, captured_at?, latitude?, longitude?} — upload
     * one of this site's photos to a listing, for ss.systems' per-market
     * photo pipeline. The HTTP half is shared; which photo, its Google copy
     * and its caption are the site's (`gbpMediaPhoto()`), and so is the
     * record of the upload (`gbpMediaUploaded()`). A site without photos
     * answers 405 — "not offered here" to the admin.
     */
    public function uploadGbpMedia(Request $request): JsonResponse
    {
        if (! $this->gbpAcceptsMediaWrites()) {
            return $this->gbpMediaRefused();
        }

        $input = $this->gbpValidate($request, [
            'account_id' => 'required|string|max:191',
            'location_id' => 'required|string|max:191',
            'category' => 'nullable|in:'.implode(',', Client::MEDIA_CATEGORIES),
            'description' => 'nullable|string|max:1000',
            'captured_at' => 'nullable|date',
            'latitude' => 'nullable|numeric|between:-90,90',
            'longitude' => 'nullable|numeric|between:-180,180',
        ]);

        if ($input instanceof JsonResponse) {
            return $input;
        }

        $client = $this->gbpClient();

        if (! $client->hasRefreshToken()) {
            return new JsonResponse(['message' => 'Connect Google Business Profile first.'], 422);
        }

        $photo = $this->gbpMediaPhoto($request, $input);

        if ($photo instanceof JsonResponse) {
            return $photo;
        }

        $accountId = Client::bareId($input['account_id']);
        $locationId = Client::bareId($input['location_id']);

        $media = $client->uploadMediaFor(
            $accountId,
            $locationId,
            (string) $photo['source_url'],
            (string) ($photo['category'] ?? $input['category'] ?? 'ADDITIONAL'),
            $photo['description'] ?? $input['description'] ?? null,
        );

        if ($media === null) {
            return $this->gbpRefused('Google refused the photo: ', $client);
        }

        $this->gbpMediaUploaded($photo, $media, $accountId, $locationId);

        return new JsonResponse(['data' => [
            'ok' => true,
            'image_id' => $photo['image_id'] ?? null,
            'media_name' => $media['name'],
            'media_url' => $media['url'],
        ]]);
    }

    /**
     * DELETE platforms/gbp/media {media_name, image_id?} — undo an upload. A
     * media item Google no longer has counts as deleted, so a retry after a
     * partial failure never gets stuck.
     */
    public function deleteGbpMedia(Request $request): JsonResponse|Response
    {
        if (! $this->gbpAcceptsMediaWrites()) {
            return $this->gbpMediaRefused();
        }

        $input = $this->gbpValidate($request, [
            'media_name' => 'required|string|max:500',
            'image_id' => 'nullable|integer',
        ]);

        if ($input instanceof JsonResponse) {
            return $input;
        }

        $client = $this->gbpClient();

        if (! $client->hasRefreshToken()) {
            return new JsonResponse(['message' => 'Connect Google Business Profile first.'], 422);
        }

        if (! $client->deleteMediaFor($input['media_name'])) {
            return $this->gbpRefused('Google refused the delete: ', $client);
        }

        $this->gbpMediaDeleted($input['media_name'], isset($input['image_id']) ? (int) $input['image_id'] : null);

        return new Response('', 204);
    }

    /**
     * PUT platforms/gbp/media/ledger {uploads: [{image_id, media_name,
     * media_url?, uploaded_at?}]} — ss.systems' whole upload ledger after its
     * hourly reconcile, which the site's own records are replaced to match
     * (`gbpReplaceMediaLedger()`).
     */
    public function saveGbpMediaLedger(Request $request): JsonResponse
    {
        if (! $this->gbpAcceptsMediaWrites()) {
            return $this->gbpMediaRefused();
        }

        $uploads = $request->input('uploads');
        $errors = [];

        if (! is_array($uploads) || ! array_is_list($uploads)) {
            $errors['uploads'] = ['The uploads field must be a list.'];
        } elseif (count($uploads) > 10000) {
            $errors['uploads'] = ['The uploads field must not have more than 10000 items.'];
        } else {
            $seen = [];
            foreach ($uploads as $i => $upload) {
                $imageId = is_array($upload) ? ($upload['image_id'] ?? null) : null;
                $mediaName = is_array($upload) ? ($upload['media_name'] ?? null) : null;
                $mediaUrl = is_array($upload) ? ($upload['media_url'] ?? null) : null;
                $uploadedAt = is_array($upload) ? ($upload['uploaded_at'] ?? null) : null;

                if (! is_int($imageId) && ! (is_string($imageId) && ctype_digit($imageId))) {
                    $errors["uploads.{$i}.image_id"] = ["The uploads.{$i}.image_id field must be an integer."];
                } elseif (isset($seen[(int) $imageId])) {
                    $errors["uploads.{$i}.image_id"] = ["The uploads.{$i}.image_id field has a duplicate value."];
                } else {
                    $seen[(int) $imageId] = true;
                }
                if (! is_string($mediaName) || $mediaName === '' || mb_strlen($mediaName) > 500) {
                    $errors["uploads.{$i}.media_name"] = ["The uploads.{$i}.media_name field is required (at most 500 characters)."];
                }
                if ($mediaUrl !== null && (! is_string($mediaUrl) || mb_strlen($mediaUrl) > 2000)) {
                    $errors["uploads.{$i}.media_url"] = ["The uploads.{$i}.media_url field must be a string of at most 2000 characters."];
                }
                if ($uploadedAt !== null && ! $this->gbpIsDate($uploadedAt)) {
                    $errors["uploads.{$i}.uploaded_at"] = ["The uploads.{$i}.uploaded_at field must be a valid date."];
                }
            }
        }

        if ($errors !== []) {
            return $this->gbpInvalid($errors);
        }

        $clean = array_map(static fn (array $u) => [
            'image_id' => (int) $u['image_id'],
            'media_name' => (string) $u['media_name'],
            'media_url' => $u['media_url'] ?? null,
            'uploaded_at' => $u['uploaded_at'] ?? null,
        ], $uploads);

        return new JsonResponse(['data' => $this->gbpReplaceMediaLedger($clean)]);
    }

    /* ------------------------------------------------------------------ */
    /*  Optional hooks                                                     */
    /* ------------------------------------------------------------------ */

    /**
     * This tenant's `/admin-oauth/{provider}/callback`, on the host
     * ss.systems called — what goes on the shared client's redirect-URI list.
     */
    protected function googleRedirectUri(string $provider): string
    {
        return URL::route(OAuthClient::CALLBACK_ROUTE, ['provider' => $provider]);
    }

    /**
     * The providers whose callback URIs the `google` block lists.
     * gs.construction and jpeterson-design add 'gsc' until their Search
     * Console moves to the shared service account.
     *
     * @return list<string>
     */
    protected function googleRedirectProviders(): array
    {
        return [Client::STATE_PROVIDER];
    }

    /** What the refused credentials endpoints say (read by platform admins only). */
    protected function googleClientIsSharedMessage(): string
    {
        return 'Every site signs in to Google through the one shared Google sign-in client, which ss.systems provides to each site, '
            .'so there is nothing to save per site. Add this site\'s redirect URIs to that client instead.';
    }

    /**
     * The hosts a listing's website must point at to be offered to this site
     * (gs.construction: one Google account manages several clients'
     * businesses, and each is that client's to disclose). Null — the default
     * — offers every listing the grant can see.
     *
     * @return list<string>|null
     */
    protected function gbpSiteHosts(): ?array
    {
        return null;
    }

    /**
     * Whether one Google location belongs to this site: its website's host,
     * without scheme or www, is one of $hosts. A listing with no website
     * matches nothing.
     *
     * @param  array<string, mixed>  $location  a location as Google returns it
     * @param  list<string>  $hosts
     */
    protected function gbpLocationVisible(array $location, array $hosts): bool
    {
        $host = static function (string $value): string {
            $value = trim($value);
            $host = str_contains($value, '//') ? (string) parse_url($value, PHP_URL_HOST) : $value;

            return (string) preg_replace('/^www\./', '', strtolower(trim($host, '/')));
        };

        $website = $host((string) ($location['websiteUri'] ?? ''));

        return $website !== '' && in_array($website, array_map($host, $hosts), true);
    }

    /**
     * Of these Google review ids, the ones this site already holds (a
     * testimonial carrying that id). None, by default.
     *
     * @param  list<string>  $reviewIds
     * @return list<string>
     */
    protected function gbpImportedReviewIds(array $reviewIds): array
    {
        return [];
    }

    /**
     * Google reviews held as testimonials, site-wide — the number the Houzz
     * and Angi cards report beside it.
     *
     * @return array{count: int, latest: ?string} latest as Y-m-d
     */
    protected function gbpReviewStats(): array
    {
        return ['count' => 0, 'latest' => null];
    }

    /** @return array<string, mixed> merged into the gbp status block (jpeterson-design: 'markets') */
    protected function gbpStatusExtras(): array
    {
        return [];
    }

    /**
     * After POST platforms/gbp/listing (gs.construction fills its Social
     * Media Google link from the new listing here).
     *
     * @param  array<string, mixed>|null  $location  Google's answer for the listing, when it gave one
     */
    protected function gbpListingSaved(string $accountId, string $locationId, ?array $location): void {}

    /** Whether this site sends photos to Google (gs.construction, jpeterson-design). */
    protected function gbpAcceptsMediaWrites(): bool
    {
        return false;
    }

    protected function gbpMediaRefusal(): string
    {
        return "This site's photos are not sent to Google from here.";
    }

    /**
     * Which photo to upload: validate the site's own `image_id`, build its
     * Google copy and caption. Return `source_url` (public), `category`,
     * `description` and `image_id` — or a JsonResponse (e.g. a 422 for an
     * unpublished project) to answer with instead.
     *
     * @param  array<string, mixed>  $input  the validated shared fields
     * @return array{source_url: string, category?: ?string, description?: ?string, image_id?: ?int}|JsonResponse
     */
    protected function gbpMediaPhoto(Request $request, array $input): array|JsonResponse
    {
        throw new LogicException(static::class.' accepts media writes but does not implement gbpMediaPhoto().');
    }

    /**
     * Record a successful upload (the site's ImagePlatformUpload row).
     *
     * @param  array<string, mixed>  $photo  what gbpMediaPhoto() returned
     * @param  array{name: string, url: ?string, google_url: ?string, raw: array<string, mixed>}  $media
     */
    protected function gbpMediaUploaded(array $photo, array $media, string $accountId, string $locationId): void {}

    /** Forget the record of a deleted upload. */
    protected function gbpMediaDeleted(string $mediaName, ?int $imageId): void {}

    /**
     * Replace this site's upload records with ss.systems' ledger.
     *
     * @param  list<array{image_id: int, media_name: string, media_url: ?string, uploaded_at: ?string}>  $uploads
     * @return array{recorded: int, removed: int}
     */
    protected function gbpReplaceMediaLedger(array $uploads): array
    {
        throw new LogicException(static::class.' accepts media writes but does not implement gbpReplaceMediaLedger().');
    }

    /* ------------------------------------------------------------------ */
    /*  Internals                                                          */
    /* ------------------------------------------------------------------ */

    /**
     * @param  array<string, mixed>  $location
     * @return array<string, mixed>
     */
    private function gbpLocationRow(string $locationId, array $location): array
    {
        $address = is_array($location['storefrontAddress'] ?? null) ? $location['storefrontAddress'] : [];
        $metadata = is_array($location['metadata'] ?? null) ? $location['metadata'] : [];

        return [
            'location_id' => $locationId,
            'title' => $location['title'] ?? null,
            'website' => $location['websiteUri'] ?? null,
            'maps_url' => $metadata['mapsUri'] ?? null,
            'place_id' => $metadata['placeId'] ?? null,
            'address' => implode(', ', array_filter([
                implode(' ', (array) ($address['addressLines'] ?? [])),
                $address['locality'] ?? null,
                $address['administrativeArea'] ?? null,
            ])) ?: null,
        ];
    }

    /** A 422 whose message AND errors.google carry the owner-safe reason (the admin reads errors). */
    private function gbpRefused(string $prefix, Client $client): JsonResponse
    {
        $message = $prefix.($client->lastErrorDescription() ?? 'unknown error');

        return new JsonResponse(['message' => $message, 'errors' => ['google' => [$message]]], 422);
    }

    private function gbpMediaRefused(): JsonResponse
    {
        return new JsonResponse(['message' => $this->gbpMediaRefusal()], 405);
    }

    /**
     * Laravel's validator for the handful of rules these endpoints use:
     * required / nullable, string, integer, numeric, date, max:N (characters),
     * between:a,b, in:a,b,…; latitude and longitude only as a pair.
     *
     * @param  array<string, string>  $rules
     * @return array<string, mixed>|JsonResponse
     */
    private function gbpValidate(Request $request, array $rules): array|JsonResponse
    {
        $data = [];
        $errors = [];

        foreach ($rules as $field => $spec) {
            $parts = explode('|', $spec);
            $label = str_replace('_', ' ', $field);
            $value = $request->input($field);

            if ($value === null || $value === '') {
                if (in_array('required', $parts, true)) {
                    $errors[$field] = ["The {$label} field is required."];
                } elseif ($request->exists($field)) {
                    $data[$field] = null;
                }

                continue;
            }

            foreach ($parts as $part) {
                [$rule, $arg] = array_pad(explode(':', $part, 2), 2, null);

                $error = match ($rule) {
                    'string' => is_string($value) ? null : "The {$label} field must be a string.",
                    'integer' => (is_int($value) || (is_string($value) && preg_match('/^-?\d+$/', $value))) ? null : "The {$label} field must be an integer.",
                    'numeric' => is_numeric($value) ? null : "The {$label} field must be a number.",
                    'date' => $this->gbpIsDate($value) ? null : "The {$label} field must be a valid date.",
                    'max' => (is_string($value) && mb_strlen($value) > (int) $arg) ? "The {$label} field must not be greater than {$arg} characters." : null,
                    'between' => (function () use ($value, $arg, $label) {
                        [$min, $max] = array_map('floatval', explode(',', (string) $arg));

                        return is_numeric($value) && ((float) $value < $min || (float) $value > $max)
                            ? "The {$label} field must be between {$min} and {$max}." : null;
                    })(),
                    'in' => in_array($value, explode(',', (string) $arg), true) ? null : "The selected {$label} is invalid.",
                    default => null,
                };

                if ($error !== null) {
                    $errors[$field] = [$error];

                    break;
                }
            }

            if (! isset($errors[$field])) {
                $data[$field] = $value;
            }
        }

        foreach ([['latitude', 'longitude'], ['longitude', 'latitude']] as [$one, $other]) {
            if (isset($rules[$one]) && ($data[$one] ?? null) !== null && ($data[$other] ?? null) === null && ! isset($errors[$other])) {
                $errors[$other] = ["The {$other} field is required when {$one} is present."];
            }
        }

        return $errors === [] ? $data : $this->gbpInvalid($errors);
    }

    /** @param  array<string, list<string>>  $errors */
    private function gbpInvalid(array $errors): JsonResponse
    {
        $first = reset($errors)[0];
        $more = count($errors) - 1;

        return new JsonResponse([
            'message' => $more > 0 ? $first.' (and '.$more.' more '.($more === 1 ? 'error' : 'errors').')' : $first,
            'errors' => $errors,
        ], 422);
    }

    private function gbpIsDate(mixed $value): bool
    {
        if (! is_string($value) || trim($value) === '') {
            return false;
        }

        try {
            Carbon::parse($value);

            return true;
        } catch (\Throwable) {
            return false;
        }
    }
}
