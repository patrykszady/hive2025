<?php

namespace SsSystems\Platform\Google;

use DateTimeInterface;
use Illuminate\Support\Carbon;

/**
 * One stored Google OAuth grant — what every site's `oauth_tokens` row holds
 * for a provider, as a value the kit can reason about without knowing which
 * model (or which tenant) it came from. `Contracts\TokenStore` hands these
 * out and takes them back; nothing in the kit ever touches the row itself.
 *
 * `clientId` is new in 0.14.0: the OAuth client that ISSUED the grant. A
 * refresh token belongs to that client and no other (Google answers
 * `unauthorized_client` for it anywhere else), so a grant recorded against
 * a different client than the one the server is configured with is dead
 * weight — `BusinessProfile\Client` forgets it instead of reporting
 * "Connected" over a grant that can never refresh (jpeterson-design's
 * `forgetGrantsFromThePreviousClient()`, now keyed on the grant itself
 * rather than on an admin "save" event that no longer exists: the client is
 * server configuration). A row written before 0.14.0 has no record (null)
 * and is stamped the first time it refreshes successfully.
 */
final class StoredGrant
{
    /**
     * @param  list<string>  $scopes  what Google GRANTED, never what was requested
     */
    public function __construct(
        public readonly string $refreshToken,
        public readonly ?string $accessToken = null,
        public readonly ?DateTimeInterface $accessTokenExpiresAt = null,
        public readonly array $scopes = [],
        public readonly ?string $grantedByEmail = null,
        public readonly ?string $clientId = null,
        public readonly ?DateTimeInterface $createdAt = null,
        public readonly ?DateTimeInterface $updatedAt = null,
    ) {}

    /** A stored access token that has not reached its (already buffered) expiry. */
    public function hasValidAccessToken(): bool
    {
        return $this->accessToken !== null
            && $this->accessToken !== ''
            && $this->accessTokenExpiresAt !== null
            && Carbon::instance($this->accessTokenExpiresAt)->isFuture();
    }

    public function withAccessToken(string $accessToken, DateTimeInterface $expiresAt): self
    {
        return $this->copy(['accessToken' => $accessToken, 'accessTokenExpiresAt' => $expiresAt]);
    }

    public function withRefreshToken(string $refreshToken): self
    {
        return $this->copy(['refreshToken' => $refreshToken]);
    }

    /** @param  list<string>  $scopes */
    public function withScopes(array $scopes): self
    {
        return $this->copy(['scopes' => array_values($scopes)]);
    }

    public function withClientId(?string $clientId): self
    {
        return $this->copy(['clientId' => $clientId]);
    }

    /** @param  array<string, mixed>  $changes */
    private function copy(array $changes): self
    {
        return new self(
            refreshToken: $changes['refreshToken'] ?? $this->refreshToken,
            accessToken: array_key_exists('accessToken', $changes) ? $changes['accessToken'] : $this->accessToken,
            accessTokenExpiresAt: array_key_exists('accessTokenExpiresAt', $changes) ? $changes['accessTokenExpiresAt'] : $this->accessTokenExpiresAt,
            scopes: $changes['scopes'] ?? $this->scopes,
            grantedByEmail: $this->grantedByEmail,
            clientId: array_key_exists('clientId', $changes) ? $changes['clientId'] : $this->clientId,
            createdAt: $this->createdAt,
            updatedAt: $this->updatedAt,
        );
    }
}
