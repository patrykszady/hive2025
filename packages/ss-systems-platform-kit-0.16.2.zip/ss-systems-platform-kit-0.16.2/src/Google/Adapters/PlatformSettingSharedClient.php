<?php

namespace SsSystems\Platform\Google\Adapters;

use Throwable;

/**
 * The one Google sign-in client, as ss.systems provisions it to a site
 * (0.15.0, 2026-09-30): ss.systems owns the client and sends it to every
 * connected site through PUT platforms/google/shared-client, so no tenant
 * keeps Google keys in its own .env. Stored in the site's PlatformSetting
 * (encrypted, like every value there) under the keys below, and read by the
 * site's OAuthClient binding: OAuthClient::fromConfig($google, $http,
 * provisioned: $store->get()) prefers it over any config value.
 *
 * Only the model's static get()/put() pair is called, the API every site's
 * PlatformSetting shares (a null or '' put deletes the row), so
 * gs.construction's BelongsToSite scope keeps it to the current tenant.
 */
final class PlatformSettingSharedClient
{
    public const CLIENT_ID = 'google.shared.client_id';

    public const CLIENT_SECRET = 'google.shared.client_secret';

    public const PROJECT_ID = 'google.shared.project_id';

    /**
     * @param  class-string  $settingModel  the site's PlatformSetting (static get()/put())
     */
    public function __construct(private readonly string $settingModel) {}

    /**
     * The provisioned client, whole or not at all.
     *
     * @return array{client_id: string, client_secret: string, project_id: ?string}|null
     */
    public function get(): ?array
    {
        $id = $this->read(self::CLIENT_ID);
        $secret = $this->read(self::CLIENT_SECRET);

        if ($id === null || $secret === null) {
            return null;
        }

        return ['client_id' => $id, 'client_secret' => $secret, 'project_id' => $this->read(self::PROJECT_ID)];
    }

    public function put(string $clientId, string $clientSecret, ?string $projectId = null): void
    {
        $model = $this->settingModel;
        $model::put(self::CLIENT_ID, trim($clientId));
        $model::put(self::CLIENT_SECRET, trim($clientSecret));
        $model::put(self::PROJECT_ID, $projectId !== null && trim($projectId) !== '' ? trim($projectId) : null);
    }

    public function forget(): void
    {
        $model = $this->settingModel;
        foreach ([self::CLIENT_ID, self::CLIENT_SECRET, self::PROJECT_ID] as $key) {
            $model::put($key, null);
        }
    }

    /** A value that cannot be read (no table yet on a fresh install) reads as absent, never a failed request. */
    private function read(string $key): ?string
    {
        try {
            $value = ($this->settingModel)::get($key);
        } catch (Throwable) {
            return null;
        }

        return is_string($value) && trim($value) !== '' ? trim($value) : null;
    }
}
