<?php

namespace SsSystems\Platform\Google\Adapters;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Carbon;
use SsSystems\Platform\Google\Contracts\TokenStore;
use SsSystems\Platform\Google\StoredGrant;

/**
 * `Contracts\TokenStore` over a site's own `oauth_tokens` Eloquent model —
 * the shape every site already has (gs.construction, jpeterson-design,
 * hive.contractors, deerfield-furniture, ss.systems, dawnsellshomes:
 * provider, access_token, refresh_token, access_token_expires_at,
 * refresh_token_expires_at, scopes json, granted_by_email, metadata json,
 * timestamps), or the kit's `resources/stubs/google/` copy of it.
 *
 * The model is resolved by class-string on every call, never imported or
 * cached, so whatever global scope it carries fires on every read, write
 * and delete here — gs.construction's `BelongsToSite` filters each query to
 * `Site::current()` and stamps each insert with it, which is exactly what
 * keeps one tenant's grant from another's. Encryption stays the model's
 * too: the tokens are written through its attribute mutators and read
 * through its accessors, so rows written before this adapter existed read
 * back unchanged.
 *
 * The issuing client lives under one key of the row's `metadata` JSON
 * (`oauth_client_id` by default), MERGED into whatever else is there —
 * gs.construction's and jpeterson-design's Search Console rows keep their
 * sync bookkeeping in the same column, and a put() must never drop it.
 */
final class EloquentTokenStore implements TokenStore
{
    /**
     * @param  class-string<Model>  $model  the site's own OAuthToken model
     */
    public function __construct(
        private readonly string $model,
        private readonly string $clientKey = 'oauth_client_id',
    ) {}

    public function get(string $provider): ?StoredGrant
    {
        $row = $this->row($provider);

        if (! $row) {
            return null;
        }

        $refreshToken = (string) ($row->refresh_token ?? '');

        if ($refreshToken === '') {
            return null;
        }

        $metadata = is_array($row->metadata ?? null) ? $row->metadata : [];
        $clientId = $metadata[$this->clientKey] ?? null;

        return new StoredGrant(
            refreshToken: $refreshToken,
            accessToken: ($row->access_token ?? null) ?: null,
            accessTokenExpiresAt: $this->date($row->access_token_expires_at ?? null),
            scopes: array_values(array_filter((array) ($row->scopes ?? []), 'is_string')),
            grantedByEmail: ($row->granted_by_email ?? null) ?: null,
            clientId: is_string($clientId) && $clientId !== '' ? $clientId : null,
            createdAt: $this->date($row->created_at ?? null),
            updatedAt: $this->date($row->updated_at ?? null),
        );
    }

    public function put(string $provider, StoredGrant $grant): void
    {
        $row = $this->row($provider) ?? new ($this->model);

        $metadata = is_array($row->metadata ?? null) ? $row->metadata : [];
        if ($grant->clientId !== null) {
            $metadata[$this->clientKey] = $grant->clientId;
        } else {
            unset($metadata[$this->clientKey]);
        }

        $row->provider = $provider;
        $row->refresh_token = $grant->refreshToken;
        $row->access_token = $grant->accessToken;
        $row->access_token_expires_at = $grant->accessTokenExpiresAt;
        $row->scopes = $grant->scopes;
        $row->granted_by_email = $grant->grantedByEmail;
        $row->metadata = $metadata === [] ? null : $metadata;
        $row->save();
    }

    public function forget(string $provider): void
    {
        ($this->model)::query()->where('provider', $provider)->delete();
    }

    private function row(string $provider): ?Model
    {
        return ($this->model)::query()->where('provider', $provider)->first();
    }

    private function date(mixed $value): ?Carbon
    {
        if ($value === null || $value === '') {
            return null;
        }

        return $value instanceof \DateTimeInterface ? Carbon::instance($value) : Carbon::parse((string) $value);
    }
}
