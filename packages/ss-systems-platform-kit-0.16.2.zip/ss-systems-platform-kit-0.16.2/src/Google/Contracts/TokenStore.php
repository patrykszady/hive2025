<?php

namespace SsSystems\Platform\Google\Contracts;

use SsSystems\Platform\Google\StoredGrant;

/**
 * Where a site keeps its Google OAuth grants — one per provider
 * (`google_business_profile`, and on gs.construction/jpeterson-design until
 * their Search Console moves to the shared service account,
 * `google_search_console`).
 *
 * Deliberately over each site's OWN token storage, never a kit-owned model:
 * gs.construction's `App\Models\OAuthToken` carries `BelongsToSite`, whose
 * global scope filters every query (and stamps every insert) with
 * `Site::current()`, and that scope is what keeps one tenant's Google grant
 * away from another's. An implementation must answer for "the current
 * tenant" exactly as the site's own model does — `Adapters\
 * EloquentTokenStore` does this by resolving the model by class-string, so
 * the scope fires on every call without the kit knowing tenancy exists.
 *
 * `put()` is an upsert and the grant it is given is the whole truth for the
 * token fields — except anything else the row stores beside them (gsc's and
 * jpeterson-design's Search Console rows keep their sync bookkeeping in
 * `metadata`), which an implementation must leave alone.
 */
interface TokenStore
{
    /** The current tenant's grant for $provider, or null when none is stored. */
    public function get(string $provider): ?StoredGrant;

    /** Create or replace the current tenant's grant for $provider. */
    public function put(string $provider, StoredGrant $grant): void;

    /** Delete the current tenant's grant for $provider (a no-op when none is stored). */
    public function forget(string $provider): void;
}
