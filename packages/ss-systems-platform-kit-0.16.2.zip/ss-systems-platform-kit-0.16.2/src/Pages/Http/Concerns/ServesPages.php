<?php

namespace SsSystems\Platform\Pages\Http\Concerns;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use SsSystems\Platform\Pages\Contracts\PageOverrideStore;
use SsSystems\Platform\Pages\PageOverrideRefused;

/**
 * The six `/api/admin/v1/pages*` actions (index/types/show/update/store/
 * destroy) ported verbatim from gs.construction's and jpeterson-design's
 * near-byte-identical controllers (hive.contractors' is the same shape over
 * a `Collection` instead of a raw array) — see `Contracts\PageOverrideStore`
 * for why storage itself stays four different designs and is never this
 * trait's concern.
 *
 * A consuming controller needs exactly one thing of its own: implement
 * `pageOverrideStore()`. It must also already `use BuildsApiResponses` (the
 * kit's `Http\Admin\Concerns\BuildsApiResponses`, already present on every
 * site's `PageController` before this trait existed) — `paginatedResponse()`/
 * `itemResponse()`/`perPage()` are called here as `$this->...()` rather than
 * pulled in a second time, exactly like every other kit HTTP trait.
 *
 *     class PageController extends Controller
 *     {
 *         use BuildsApiResponses, ServesPages;
 *
 *         protected function pageOverrideStore(): PageOverrideStore
 *         {
 *             return new GscPageOverrideStore(...);
 *         }
 *     }
 *
 * `update()`/`store()` call `Illuminate\Http\Request::validate()` directly —
 * a real macro `Illuminate\Foundation\Providers\FoundationServiceProvider`
 * registers in every one of the four sites' fully-booted apps, exactly as
 * each site's own hand-written `update()`/`store()` already did. The kit
 * itself deliberately carries no `illuminate/foundation`/`illuminate/
 * validation` dependency (see `Pulse\BeaconController`'s docblock for the
 * same rule applied to a different controller), so this trait's OWN unit
 * test cannot drive `update()`/`store()` end-to-end in the kit's bare-
 * PHPUnit process — it instead calls the `applyPageUpdate()`/
 * `applyPageCreate()` halves directly with a pre-built `$data` array, which
 * is the entire piece this trait actually owns; the `->validate()` line
 * itself is exercised for real by each site's own booted-app Feature tests
 * (`PageControllerTest`, `AdminPagesTest`, …), unchanged by this port.
 */
trait ServesPages
{
    abstract protected function pageOverrideStore(): PageOverrideStore;

    /** Override for a site whose own default differs (dawn: 25). */
    protected function pagesDefaultPerPage(): int
    {
        return 20;
    }

    protected function pagesMaxPerPage(): int
    {
        return 100;
    }

    public function index(Request $request): JsonResponse
    {
        $filters = [
            'search' => trim((string) $request->string('search')),
            'type' => trim((string) $request->string('type')),
            'exclude_types' => array_values(array_filter(array_map(
                'trim',
                explode(',', (string) $request->string('exclude_types'))
            ))),
            'sitemap' => ($sitemap = (string) $request->string('sitemap')) !== '' ? $sitemap : null,
            'sort' => (string) $request->string('sort', 'updated'),
            'dir' => strtolower((string) $request->string('dir', 'desc')) === 'asc' ? 'asc' : 'desc',
        ];

        $page = max(1, (int) $request->integer('page', 1));
        $perPage = $this->perPage($request, $this->pagesDefaultPerPage(), $this->pagesMaxPerPage());

        $paginator = $this->pageOverrideStore()->paginate($filters, $page, $perPage);

        return $this->paginatedResponse($paginator, static fn (array $row) => $row);
    }

    public function types(): JsonResponse
    {
        return $this->itemResponse($this->pageOverrideStore()->typeCounts());
    }

    public function show(int|string $page): JsonResponse
    {
        return $this->itemResponse($this->pageOverrideStore()->find($page));
    }

    public function update(Request $request, int|string $page): JsonResponse
    {
        $data = $request->validate($this->pageOverrideStore()->updateRules($page));

        return $this->applyPageUpdate($page, $data);
    }

    /**
     * A refusal here (ss.systems' own pages: no writable override at all,
     * every PUT refuses exactly like its store()/destroy()) gets the same
     * {"message": ...} 422 treatment as create()/destroy() — see
     * PageOverrideRefused's own docblock.
     *
     * @param  array<string, mixed>  $data  already validated against updateRules()
     */
    protected function applyPageUpdate(int|string $page, array $data): JsonResponse
    {
        try {
            $row = $this->pageOverrideStore()->update($page, $data);
        } catch (PageOverrideRefused $e) {
            return new JsonResponse(['message' => $e->getMessage()], 422);
        }

        return $this->itemResponse($row);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate($this->pageOverrideStore()->createRules());

        return $this->applyPageCreate($data);
    }

    /**
     * The `{"message": ...}` 422 (no `errors` key) this returns on a refusal
     * is exactly the shape every site hand-rolled with
     * `response()->json([...], 422)` before adopting this trait — see
     * `PageOverrideRefused`'s own docblock.
     *
     * @param  array<string, mixed>  $data  already validated against createRules()
     */
    protected function applyPageCreate(array $data): JsonResponse
    {
        try {
            $result = $this->pageOverrideStore()->create($data);
        } catch (PageOverrideRefused $e) {
            return new JsonResponse(['message' => $e->getMessage()], 422);
        }

        return new JsonResponse([
            'data' => $result['data'],
            'listed_on_index' => $result['listed_on_index'] ?? true,
        ], 201);
    }

    public function destroy(int|string $page): JsonResponse|Response
    {
        try {
            $this->pageOverrideStore()->delete($page);
        } catch (PageOverrideRefused $e) {
            return new JsonResponse(['message' => $e->getMessage()], 422);
        }

        return new Response('', 204);
    }
}
