<?php

namespace SsSystems\Platform\Pages\Contracts;

use Illuminate\Pagination\LengthAwarePaginator;
use SsSystems\Platform\Pages\PageOverrideRefused;

/**
 * ss.systems' "Pages" screen (`App\Livewire\Admin\PageList` there) over
 * whatever a site actually keeps its editable page/article metadata in.
 * FOUR real, and genuinely different, backing designs sit behind the same
 * six-endpoint HTTP surface (GET pages, GET pages/types, GET pages/{id},
 * PUT pages/{id}, POST pages, DELETE pages/{id}) — this interface is the
 * seam `Http\Concerns\ServesPages` calls through, so only the HTTP-shaping/
 * response-envelope/refusal-formatting layer is shared; storage stays:
 *
 * - gs.construction: `App\Models\SeoPathOverride` — a path-keyed, 6h-cached,
 *   TENANT-SCOPED (`BelongsToSite`) row created only once an admin actually
 *   edits a page. The site's public pages are routes/views, not rows, so
 *   `create()`/`delete()` always throw `PageOverrideRefused`.
 * - jpeterson-design.com: the same polymorphic `seo` table
 *   `SeoOverrideController` writes, addressed either through a Service/Area
 *   model's `->seo()` morphOne or, for the six top-level pages, a fixed
 *   model_type/model_id pair. Also always refuses create/delete.
 * - hive.contractors: `App\Models\PageSeoOverride`, keyed by route_name +
 *   a deterministic params_key (marketing pages take route params), row
 *   LAZILY CREATED the first time the index is listed. Also always refuses.
 * - dawnsellshomes.com: `App\Models\Page` — a real ~500-row CMS table, the
 *   one adapter that actually creates (a new blog/article row) and
 *   conditionally deletes (only a blog/article row; every imported
 *   city/neighborhood/condo page refuses `delete()` with its own message).
 *
 * Two execution strategies for `paginate()`, by necessity, not preference:
 * gsc/jpeterson/hive's page sets are a small, code-enumerated list (home,
 * about, each service, each area/market — never more than a few hundred),
 * so they build the FULL row set in memory and filter/sort/slice it in PHP
 * (an array or a `Collection`, either is fine — nothing here mandates one);
 * dawn's ~500-row real table instead builds an `Eloquent\Builder`, applies
 * `$filters` as `where()`/`orderBy()`, and calls `$query->paginate()` —
 * SQL-level, because building 500 rows in memory on every list request to
 * save one query is the wrong trade for a real table. `paginate()` hides
 * this choice entirely: it always returns a ready `LengthAwarePaginator`
 * of already-shaped row arrays (the same shape `find()` uses for the
 * detail row, minus whatever detail-only keys a site's row omits from the
 * list for size), and `ServesPages::index()` never knows which strategy
 * produced it.
 *
 * A row's `in_sitemap` is `null`, not a fabricated boolean, on every site
 * that has no per-page sitemap-exclusion mechanism (gsc, jpeterson, hive —
 * see ss-systems' CLAUDE.md "Pages screen contract"): PageList reads `null`
 * as "hide the switch", not "off". Only dawn's rows carry a real boolean.
 *
 * Validation rules are adapter-owned and CAN vary per-row, not just
 * per-site: dawn's `canonical` rule is `url` (its rows are real published
 * pages) where gsc/jpeterson's is a bare `string` (their "pages" are a
 * mix of code-rendered routes with no real canonical mechanism yet); dawn's
 * `updateRules()` also only allows `body_html` at all for a row whose
 * `isEditableBody()` is true, so `updateRules($id)` takes the id — a static
 * rule array is not expressive enough for that one adapter, even though
 * every other adapter's implementation ignores the argument.
 *
 * `find()`/`update()` throw the framework's own 404 exactly as each site
 * did before adopting this contract (`abort(404, 'Unknown page.')`,
 * `Page::findOrFail()`, …) when `$id` names no real row — `ServesPages`
 * never inspects that exception, and this interface does not name a
 * not-found return value (no nullable `find()`) so an adapter is never
 * tempted to invent a new 404 message: see `PageOverrideRefused`'s own
 * docblock for why a 404's exact wording is load-bearing on the ss.systems
 * side (`App\Exceptions\SiteApiNotSupported`).
 */
interface PageOverrideStore
{
    /**
     * The already-parsed, already-defaulted list filters `ServesPages::
     * index()` builds from the request — every key is always present so an
     * adapter never has to guard with `?? null` on a missing filter.
     *
     * @param  array{
     *     search: string,
     *     type: string,
     *     exclude_types: array<int, string>,
     *     sitemap: string|null,
     *     sort: string,
     *     dir: string,
     * }  $filters  search/type: '' means no filter. exclude_types: rows of
     *              this type are dropped (dawn's Blog-screen split; a site
     *              with no type ever equal to one of these names has
     *              nothing to do here). sitemap: '1'/'0' filters on
     *              in_sitemap, null means every row. sort: 'updated' (the
     *              default) | 'title' | 'path'. dir: 'asc' | 'desc'.
     * @return LengthAwarePaginator<int, array<string, mixed>> already-shaped list rows
     */
    public function paginate(array $filters, int $page, int $perPage): LengthAwarePaginator;

    /** @return array<int, array{type: string, count: int}> */
    public function typeCounts(): array;

    /**
     * The full detail row for GET pages/{id} — every key `paginate()`'s
     * rows carry, plus at least `canonical`, `meta_keywords`,
     * `editable_body` (see `App\Services\PagesApiClient::find()` on the
     * ss.systems side for the complete, optional key list).
     *
     * @return array<string, mixed>
     */
    public function find(int|string $id): array;

    /** @return array<string, mixed> Laravel validation rules for the PUT pages/{id} body */
    public function updateRules(int|string $id): array;

    /**
     * @return array<string, mixed> the fresh detail row (same shape as find())
     *
     * @throws PageOverrideRefused on a site with no writable override at all
     *         (ss.systems' own pages: every PUT refuses exactly like its
     *         store()/destroy() — there is no override table to write)
     */
    public function update(int|string $id, array $data): array;

    /** @return array<string, mixed> Laravel validation rules for the POST pages body */
    public function createRules(): array;

    /**
     * @param  array<string, mixed>  $data  already validated against createRules()
     * @return array{data: array<string, mixed>, listed_on_index?: bool} listed_on_index
     *         defaults to true when omitted — see dawn's ArticlePageWriter for
     *         the one case it is false (a new article published at its own
     *         address but not yet on the hand-written /blog index).
     *
     * @throws PageOverrideRefused when this site's pages are code, not rows
     */
    public function create(array $data): array;

    /**
     * @throws PageOverrideRefused when this row (or every row, on a site
     *         with no deletable pages at all) cannot be removed
     */
    public function delete(int|string $id): void;
}
