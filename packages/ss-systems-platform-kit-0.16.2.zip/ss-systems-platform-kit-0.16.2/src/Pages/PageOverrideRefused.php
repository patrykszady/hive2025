<?php

namespace SsSystems\Platform\Pages;

/**
 * Thrown by a `Contracts\PageOverrideStore::create()`/`delete()`
 * implementation when the site's own rule says no — never a validation
 * failure, so it carries no field errors: gs.construction, jpeterson-design
 * and hive.contractors refuse EVERY create and EVERY delete unconditionally
 * (their pages are routes/views baked into the code, not rows), while a
 * real-CMS site (dawnsellshomes.com's `pages` table) only refuses `delete()`
 * for a row that isn't a blog/article ("Only blog/article pages can be
 * deleted."). The message is exactly what ss.systems' PageList shows the
 * owner as a calm `session('notice')` (never a red error) via
 * `Http\Admin\Concerns\ServesPages`, which catches this and formats
 * `{"message": ...}` at 422 with no `errors` key — the same shape every one
 * of the four sites already hand-rolled with `response()->json([...], 422)`
 * before adopting the trait, so this is a behaviour-preserving move, not a
 * new refusal path.
 *
 * Never thrown for "the id does not exist" — that stays each adapter's own
 * 404 (`abort(404, ...)`/`ModelNotFoundException`), because
 * `App\Exceptions\SiteApiNotSupported` on the ss.systems side reads a 404
 * whose message does NOT start with "No query results" as "this site never
 * registered the endpoint at all", not "this one row is gone". Confusing
 * the two would make an ordinary missing-row 404 render as the wrong kind
 * of failure on the admin screen.
 */
final class PageOverrideRefused extends \RuntimeException
{
}
