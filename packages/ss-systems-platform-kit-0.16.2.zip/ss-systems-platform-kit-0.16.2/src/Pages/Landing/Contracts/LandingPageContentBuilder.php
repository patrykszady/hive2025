<?php

namespace SsSystems\Platform\Pages\Landing\Contracts;

/**
 * The one axis of the LandingPageController family that stays a genuine
 * per-site business rule (docs/CONSOLIDATION-PLAN.md, Kit 0.14.0; verified
 * against docs/audit-2026-09-27/admin-api-verify.md, "Answers to the five
 * questions" (b)): how a draft's content gets written.
 *
 *   - gs.construction: SsSystems\Platform\Pages\Landing\Http\Concerns\
 *     ServesLandingPages never sees this — gsc's own adapter wraps its
 *     existing App\Services\Seo\LandingPageContentGenerator (AI-first,
 *     "no thin pages" proof-gated, real project photography required).
 *   - jpeterson-design / hive.contractors / ss-systems: a small static
 *     template, never proof-gated — see each site's own adapter class.
 *
 * Deliberately NOT responsible for: the slug (ServesLandingPages computes
 * the same deterministic base every site already used — `service [+
 * modifier] + city`, slugified — and resolves a collision through the
 * separate onSlugCollision() hook), `service`/`city`/`modifier`/`source`/
 * `status` (uniform across every site), or any extra persisted attribute
 * the content itself doesn't produce (see extraPersistedAttributes() on
 * the controller trait — jpeterson's `indexed` flag, a column hive/
 * ss-systems don't have). The verify note is explicit that folding any of
 * those into this one contract is exactly how the naive "6-method
 * contract" port breaks two of four sites on the very first submission.
 */
interface LandingPageContentBuilder
{
    /**
     * The fixed service/campaign-type vocabulary this site's "Generate
     * draft" form offers, slug => label. Three real mechanisms, not one:
     * gsc's TitleMetaGenerator::SERVICES constant, jpeterson's DB-backed
     * `Service::ordered()->where('is_landing_page', true)`, hive's/
     * ss-systems' `LandingPage::CAMPAIGN_TYPES` model constant.
     *
     * @return array<string, string>
     */
    public function services(): array;

    /**
     * Build the content fields for a new draft from raw, already-trimmed
     * input. Return null to refuse creation outright — gsc's "no matching
     * project proof, can't build a non-thin page" rule; every other site's
     * implementation always returns an array, since none of them gate
     * creation on anything.
     *
     * Must NOT include `slug`/`service`/`city`/`modifier`/`source`/
     * `status` — ServesLandingPages::store() sets those uniformly and its
     * values win on any key collision, so returning them here is at best
     * redundant, never load-bearing.
     *
     * @param  array{service: string, city: string, modifier: ?string}  $input
     * @return array<string, mixed>|null
     */
    public function build(array $input): ?array;

    /**
     * Whether publish() must refuse a page with no project-photography
     * proof. True only for gsc's Autopilot-generated pages — every other
     * site's pages are hand-created and already reviewed by an admin
     * before Publish is clicked, so requiring matched photography first
     * would make the capability unusable for no safety benefit (see each
     * site's own LandingPageController docblock, e.g. ss-systems': "this
     * app has no home-improvement Projects/proof domain at all").
     */
    public function requiresProofToPublish(): bool;
}
