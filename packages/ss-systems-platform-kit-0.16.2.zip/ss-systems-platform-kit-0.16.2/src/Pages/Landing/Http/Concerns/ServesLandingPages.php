<?php

namespace SsSystems\Platform\Pages\Landing\Http\Concerns;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Str;
use SsSystems\Platform\Http\Admin\Concerns\BuildsApiResponses;
use SsSystems\Platform\Pages\Landing\Contracts\LandingPageContentBuilder;

/**
 * The shared body of every tenant's `Api\Admin\V1\LandingPageController` —
 * the same index/services/store/publish/unpublish/destroy contract and the
 * same `toApiArray()`-shaped response every site already produced (see
 * docs/CONSOLIDATION-PLAN.md, Kit 0.14.0, and
 * docs/audit-2026-09-27/admin-api-skeleton.md #13). Ported from
 * gs.construction's, jpeterson-design's, hive.contractors' and ss-systems'
 * four independently-hand-copied controllers AFTER
 * docs/audit-2026-09-27/admin-api-verify.md found the naive "6-method
 * contract" framing undercounts real, currently-shipped divergence on four
 * separate axes. Every one of those axes is now an explicit hook or
 * contract method — never a silent default that happens to work today:
 *
 *   - Content generation (proof-gated AI vs. static template, and jpeterson's
 *     third "cosmetic proof-match, never gating" variant): the injected
 *     {@see LandingPageContentBuilder}, resolved through contentBuilder().
 *   - Model class / tenant scope: landingPageModel() returns the site's own
 *     `App\Models\LandingPage` FQCN, so every query in this trait runs
 *     through Eloquent AS THAT MODEL — gsc's `BelongsToSite` global scope
 *     fires exactly as it always did, ambiently, with no tenancy-aware code
 *     anywhere in this file. A raw query bypassing the model class would
 *     leak one tenant's pages into another's admin list; there is
 *     deliberately no such shortcut here.
 *   - Slug-collision policy: gsc's store() 422s on a duplicate deterministic
 *     slug ("A page already exists at …"); jpeterson/hive/ss-systems instead
 *     silently auto-suffix (`-2`, `-3`, …) and never error. Patryk's decision
 *     (2026-09-27): every site keeps EXACTLY its current policy — this is a
 *     real UX behavior, not a detail to standardize away — so
 *     onSlugCollision() is abstract, not defaulted, and every site's own
 *     test pins its own answer.
 *   - Extra persisted attributes: jpeterson's store() sets `indexed => true`
 *     in the outer merge, a column hive's and ss-systems' `landing_pages`
 *     migrations don't have at all (confirmed by reading both CREATE TABLE
 *     migrations) — unconditionally writing it here would 500 on those two
 *     sites' very first "Generate draft" submission. extraPersistedAttributes()
 *     defaults to empty (gsc/hive/ss-systems never override it) so this can
 *     never happen; only jpeterson's own controller adds the one key.
 *
 * The deterministic slug BASE — `trim((modifier ? "$modifier " : '') .
 * $service . ' ' . $city)`, slugified — was already byte-identical across
 * all four sites' store() methods before this port; only what happens once
 * that slug already exists differed (see onSlugCollision() above). Computing
 * it once here, instead of once per site, is a pure de-duplication with no
 * behavior change.
 */
trait ServesLandingPages
{
    use BuildsApiResponses;

    /** @return class-string<\Illuminate\Database\Eloquent\Model> this site's own LandingPage model. */
    abstract protected function landingPageModel(): string;

    /** The per-site content-generation rule — a constructor-injected adapter, never resolved from the container here. */
    abstract protected function contentBuilder(): LandingPageContentBuilder;

    /**
     * 'refuse' — 422 the request with a field error on `city` (gsc).
     * 'suffix' — never error; append `-2`, `-3`, … until unique (jpeterson,
     * hive2025, ss-systems). Abstract on purpose: this is a real, named
     * product decision every site keeps making explicitly, not a default a
     * new site could silently inherit wrong.
     *
     * @return 'refuse'|'suffix'
     */
    abstract protected function onSlugCollision(): string;

    /**
     * Attributes to merge in beyond the uniform slug/service/city/modifier/
     * source/status/content set — e.g. jpeterson's `['indexed' => true]`.
     * Empty by default: most sites have nothing to add here.
     *
     * @param  array{service: string, city: string, modifier: ?string}  $input
     * @return array<string, mixed>
     */
    protected function extraPersistedAttributes(array $input): array
    {
        return [];
    }

    /**
     * Runs after publish()/unpublish() flips the status. No-op by default
     * (jpeterson/hive2025/ss-systems all do nothing here); gsc overrides it
     * to regenerate its sitemap the same way its original controller did —
     * see that class's own override for why the exception is swallowed.
     */
    protected function afterPublishToggle(): void
    {
        //
    }

    public function index(Request $request): JsonResponse
    {
        $model = $this->landingPageModel();

        $paginator = $model::query()->orderByDesc('created_at')->paginate($this->perPage($request));

        return $this->paginatedResponse($paginator, fn ($page) => $page->toApiArray());
    }

    /** The fixed service/campaign-type catalogue the generate form offers. */
    public function services(): JsonResponse
    {
        return $this->itemResponse($this->contentBuilder()->services());
    }

    public function store(Request $request): JsonResponse
    {
        $errors = $this->validateStoreInput($request);
        if ($errors !== []) {
            return new JsonResponse(['message' => 'The given data was invalid.', 'errors' => $errors], 422);
        }

        $service = $request->input('service');
        $city = trim($request->input('city'));
        $modifier = filled($request->input('modifier')) ? $request->input('modifier') : null;

        $input = ['service' => $service, 'city' => $city, 'modifier' => $modifier];

        $content = $this->contentBuilder()->build($input);

        if ($content === null) {
            return new JsonResponse([
                'errors' => [
                    'service' => ["No matching project proof for {$service} — can't build a non-thin page. Add a relevant project first."],
                ],
            ], 422);
        }

        $model = $this->landingPageModel();

        $base = trim(($modifier ? "{$modifier} " : '').$service.' '.$city);
        $slug = Str::slug($base);

        if ($model::query()->where('slug', $slug)->exists()) {
            if ($this->onSlugCollision() === 'refuse') {
                $preview = (new $model)->forceFill(['slug' => $slug]);

                return new JsonResponse([
                    // The path, not the absolute URL — the message every site showed before this moved.
                    'errors' => ['city' => ['A page already exists at '.(parse_url($preview->url(), PHP_URL_PATH) ?: $preview->url()).'.']],
                ], 422);
            }

            $original = $slug;
            $suffix = 1;
            do {
                $slug = $original.'-'.(++$suffix);
            } while ($model::query()->where('slug', $slug)->exists());
        }

        $page = $model::create(array_merge(
            $content,
            $this->extraPersistedAttributes($input),
            [
                'slug' => $slug,
                'service' => $service,
                'city' => $city,
                'modifier' => $modifier,
                'source' => 'manual',
                'status' => $model::STATUS_DRAFT,
            ]
        ));

        return $this->itemResponse($page->toApiArray(), 201);
    }

    public function publish(int $landingPage): JsonResponse
    {
        $model = $this->landingPageModel();
        $page = $model::findOrFail($landingPage);

        if ($this->contentBuilder()->requiresProofToPublish() && ! $page->hasProof()) {
            return new JsonResponse([
                'errors' => ['page' => ['Cannot publish a page with no project proof.']],
            ], 422);
        }

        $page->update(['status' => $model::STATUS_PUBLISHED, 'published_at' => now()]);
        $this->afterPublishToggle();

        return $this->itemResponse($page->fresh()->toApiArray());
    }

    public function unpublish(int $landingPage): JsonResponse
    {
        $model = $this->landingPageModel();
        $page = $model::findOrFail($landingPage);

        $page->update(['status' => $model::STATUS_DRAFT, 'published_at' => null]);
        $this->afterPublishToggle();

        return $this->itemResponse($page->fresh()->toApiArray());
    }

    public function destroy(int $landingPage): Response
    {
        $model = $this->landingPageModel();
        $model::findOrFail($landingPage)->delete();

        // `new Response(...)` directly, not the response() helper — see
        // BuildsApiResponses' own docblock: this package requires
        // illuminate/http, never illuminate/foundation, so the global
        // helper doesn't exist here.
        return new Response('', 204);
    }

    /**
     * Hand-rolled equivalent of `$request->validate([...])` for exactly the
     * three fields every site's original controller declared (service:
     * required|string|max:100, city: required|string|max:255, modifier:
     * nullable|string|max:100) — this package requires illuminate/http and
     * illuminate/database, never illuminate/validation/illuminate/foundation
     * (the `$request->validate()` macro only exists once
     * Foundation\Providers\FormRequestServiceProvider has run), so a real
     * Validator can't be resolved here. The three rules are simple and
     * fixed enough to reproduce exactly; only the message TEXT is
     * hand-written rather than translated — every site's own test asserts
     * the field key is present under `errors`, never the exact wording.
     *
     * @return array<string, array<int, string>>
     */
    private function validateStoreInput(Request $request): array
    {
        $errors = [];

        $service = $request->input('service');
        if (! is_string($service) || trim($service) === '' || mb_strlen($service) > 100) {
            $errors['service'] = ['The service field is required.'];
        }

        $city = $request->input('city');
        if (! is_string($city) || trim($city) === '' || mb_strlen($city) > 255) {
            $errors['city'] = ['The city field is required.'];
        }

        $modifier = $request->input('modifier');
        if ($modifier !== null && (! is_string($modifier) || mb_strlen($modifier) > 100)) {
            $errors['modifier'] = ['The modifier field must be a string with no more than 100 characters.'];
        }

        return $errors;
    }
}
