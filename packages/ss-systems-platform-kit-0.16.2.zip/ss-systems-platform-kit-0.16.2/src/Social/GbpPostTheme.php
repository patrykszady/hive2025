<?php

namespace SsSystems\Platform\Social;

use Illuminate\Support\Carbon;
use SsSystems\Platform\Social\Contracts\RankedTowns;
use SsSystems\Platform\Social\Contracts\TrendsIntel;

/**
 * The theme a week's Google Business Profile post follows: a season note,
 * a service that is rising in Google Trends (else a rotation), and one of
 * the core towns rotated week by week. The picker prefers a matching
 * project photo and the caption writer weaves the theme in, so the posts
 * read like a plan instead of a random gallery.
 *
 * Moved to the kit in 0.13.0 from gs.construction's and jpeterson-design's
 * byte-identical copies (jpeterson's was confirmed dead code — it depended
 * on an `AreaServed` model and an `IntelStore` neither of which exist
 * there — and was deleted rather than ported). $serviceRotation is a
 * constructor argument rather than a hardcoded constant (the audit's own
 * recommendation): the default is the two trades sites' existing rotation,
 * but a future non-trades site is never stuck with kitchen/bathroom
 * wording. `season()`'s table stays hardcoded — it is currently read by
 * only those same two trades sites, so there is nothing yet to generalize.
 */
class GbpPostTheme
{
    /** The two trades sites' rotation, unchanged from before the port. */
    public const DEFAULT_SERVICE_ROTATION = ['kitchen', 'bathroom', 'basement', 'home-remodel', 'addition'];

    /** @param  list<string>  $serviceRotation  project types, as the fallback rotation when nothing is rising */
    public function __construct(
        protected RankedTowns $towns,
        protected TrendsIntel $trends,
        protected array $serviceRotation = self::DEFAULT_SERVICE_ROTATION,
    ) {}

    /** @return array{service_type: ?string, town: ?string, season: string, rising_phrase: ?string, note: string, week: int} */
    public function forWeek(?Carbon $when = null): array
    {
        $when = $when ?? Carbon::now();
        $week = (int) $when->isoWeek;
        $season = self::season($when);
        $towns = array_values($this->towns->coreTowns(6));
        $town = $towns !== [] ? $towns[$week % count($towns)] : null;

        $rising = $this->trends->risingPhrase();
        $service = $rising['service'] ?? null;
        $phrase = $rising['phrase'] ?? null;

        if ($service === null) {
            $service = $this->serviceRotation !== [] ? $this->serviceRotation[$week % count($this->serviceRotation)] : null;
        }

        $note = $season['note'] . ($phrase ? " Searches for \"{$phrase}\" are rising locally right now." : '');

        return ['service_type' => $service, 'town' => $town, 'season' => $season['name'], 'rising_phrase' => $phrase, 'note' => $note, 'week' => $week];
    }

    /** Season name and the angle a remodeler leans on in it. */
    public static function season(Carbon $when): array
    {
        return match (true) {
            in_array($when->month, [12, 1, 2], true) => ['name' => 'winter', 'note' => 'Winter is indoor-project season: basements, bathrooms and kitchens finish before spring.'],
            in_array($when->month, [3, 4, 5], true) => ['name' => 'spring', 'note' => 'Spring is planning season: kitchens and additions designed now are built by summer.'],
            in_array($when->month, [6, 7, 8], true) => ['name' => 'summer', 'note' => 'Summer is building season for additions and whole-home work while the weather helps.'],
            default => ['name' => 'fall', 'note' => 'Fall projects finish before the holidays: kitchens and bathrooms ready for guests.'],
        };
    }
}
