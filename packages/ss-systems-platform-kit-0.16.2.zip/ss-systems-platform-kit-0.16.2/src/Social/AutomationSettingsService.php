<?php

namespace SsSystems\Platform\Social;

use SsSystems\Platform\Social\Contracts\PlatformAvailability;
use SsSystems\Platform\Social\Contracts\PublishedPostStats;
use SsSystems\Platform\Social\Contracts\SettingsStore;

/**
 * Builds the GET/PUT /api/admin/v1/social-media automation contract — one
 * item per `SettingsStore::platforms()`, in that fixed order. Moved here
 * (kit 0.13.0) from gs.construction's and jpeterson-design's byte-identical
 * copies (the only divergence was the planner's seed: gsc's live
 * `Site::current()->slug` vs jpeterson's hardcoded `PLAN_SEED` constant, and
 * the platform roster a site's own `SettingsStore` reports — dawn has no
 * `google_business` at all).
 *
 * `$seed` is a plain constructor argument, not resolved in here: a
 * multi-tenant site's thin subclass re-derives `Site::current()->slug` in
 * ITS OWN constructor and calls `parent::__construct()` with the fresh
 * value — exactly the pattern `Social\AutomationPlanner`'s site wrappers
 * already prove — so the seed can never be cached stale by a container
 * binding that outlives one tenant. A single-tenant site's subclass passes
 * a fixed string instead. Getting this wrong reshuffles every site's live
 * posting days, so nothing in here memoizes `$seed` beyond the object's own
 * (per-resolution) lifetime.
 */
class AutomationSettingsService
{
    public function __construct(
        protected AutomationPlanner $planner,
        protected string $seed,
        protected SettingsStore $store,
        protected PlatformAvailability $availability,
        protected PublishedPostStats $stats,
    ) {}

    public function timezone(): string
    {
        return $this->planner->timezone();
    }

    /** @return array<int, array<string, mixed>> */
    public function items(): array
    {
        return collect($this->store->platforms())
            ->map(fn (string $platform) => $this->item($platform))
            ->values()
            ->all();
    }

    /** @return array<string, mixed> */
    public function item(string $platform): array
    {
        $setting = $this->store->find($platform);
        $defaults = $this->store->defaultsFor($platform);

        $cadence = $setting['cadence'] ?? $defaults['cadence'];
        $options = $setting['options'] ?? $defaults['options'];

        return [
            'platform' => $platform,
            'label' => $this->store->label($platform),
            'configured' => $this->isConfigured($platform),
            'publishing_off' => $this->publishingOff($platform),
            'enabled' => (bool) ($setting['enabled'] ?? false),
            'cadence' => $cadence,
            'options' => $options,
            'plan' => $this->planner->plan($this->seed, $platform, $cadence, null, $this->metaSiblingCadence($platform)),
            'last' => $this->lastStats($platform),
            'updated_at' => optional($setting['updated_at'] ?? null)->toIso8601String(),
        ];
    }

    /**
     * Instagram and Facebook must never land on the same day (see
     * AutomationPlanner's class docblock) — this hands the planner the
     * OTHER meta platform's cadence so it can offset its day draw from
     * their shared weekly shuffle. Null for any other platform.
     */
    protected function metaSiblingCadence(string $platform): ?array
    {
        $sibling = match ($platform) {
            'instagram' => 'facebook',
            'facebook' => 'instagram',
            default => null,
        };

        if ($sibling === null) {
            return null;
        }

        $setting = $this->store->find($sibling);

        return $setting['cadence'] ?? $this->store->defaultsFor($sibling)['cadence'];
    }

    /** Persist a validated {enabled, cadence, options} payload and return the refreshed item. */
    public function save(string $platform, bool $enabled, array $cadence, array $options): array
    {
        $this->store->save($platform, ['enabled' => $enabled, 'cadence' => $cadence, 'options' => $options]);

        return $this->item($platform);
    }

    /**
     * Connected, but that platform's publishing switch on the Platforms page
     * is off. The admin says exactly that — "connected, publishing is
     * switched off" — instead of "not connected", which sent people to a
     * Platforms page that said Connected (2026-09-23).
     */
    public function publishingOff(string $platform): bool
    {
        return $this->availability->isPublishingOff($platform);
    }

    protected function isConfigured(string $platform): bool
    {
        return $this->availability->isConfigured($platform);
    }

    /** @return array{at: ?string, status: ?string, count_30d: int} */
    protected function lastStats(string $platform): array
    {
        $latest = $this->stats->latestFor($platform);

        return [
            'at' => optional($latest?->at)->toIso8601String(),
            'status' => $latest?->status,
            'count_30d' => $this->stats->countPublished30d($platform),
        ];
    }
}
