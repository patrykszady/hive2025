<?php

namespace SsSystems\Platform\Social;

use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use SsSystems\Platform\Social\Contracts\MetaCredentialStore;

/**
 * Meta Graph API client: the admin OAuth connect/disconnect dance every
 * site shares, plus — where a site actually posts — the single-image
 * Instagram/Facebook publish flow. Moved here from gs.construction's/
 * jpeterson-design's near-identical `App\Services\MetaSocialService`
 * classes (2026-09-27; hive.contractors' copy carried only the connect
 * half — it has no posting pipeline). See
 * ss-platform-kit/docs/audit-2026-09-27/social-posting-and-automation.md,
 * unit 9, for the full diff this class is built from.
 *
 * Every site keeps its own thin `App\Services\MetaSocialService extends
 * MetaGraphClient`, adding only what is genuinely its own:
 *   - a public `OAUTH_SCOPES` constant, passed by the site's own call
 *     sites into getOAuthUrl()/exchangeCodeAndStore() below (never
 *     re-declared as a narrower override of either method — see
 *     getOAuthUrl()'s docblock for why) — THREE distinct production scope
 *     sets (gsc/jpeterson's 4, hive's own different 4, dawnsellshomes' 6
 *     once it adopts this class), not two, and not a drift to unify;
 *   - gsc's carousel / Instagram-location-tagging / Facebook-check-in /
 *     hourly-metric / debug-token extras (confirmed gsc-only; jpeterson's
 *     own docblock on its trimmed copy says explicitly which of these it
 *     chose not to carry);
 *   - the `publishToInstagramForImage()` domain wrapper (needs each site's
 *     own `ProjectImage`-shaped model — a kit class never references
 *     `App\Models\*`).
 *
 * Credential storage is a real, live fork, not something this class
 * resolves — see `Contracts\MetaCredentialStore`'s docblock. This class
 * only ever talks to that contract.
 *
 * THIS TOUCHES LIVE GRAPH API TOKENS. Never call exchangeCodeAndStore()/
 * publishToInstagram()/publishToFacebook() against the real Graph API
 * outside Http::fake().
 */
class MetaGraphClient
{
    protected const GRAPH_BASE = 'https://graph.facebook.com/v25.0';

    protected ?array $lastError = null;

    public function __construct(
        protected readonly MetaCredentialStore $credentials,
        protected readonly ?string $appId,
        protected readonly ?string $appSecret,
        protected readonly bool $publishingEnabled = false,
    ) {
    }

    /* ------------------------------------------------------------------ */
    /*  Credential resolution                                              */
    /* ------------------------------------------------------------------ */

    /**
     * Resolved Meta credentials for posting.
     *
     * @return array{token: ?string, page_id: ?string, ig_id: ?string, page_name: ?string, ig_username: ?string, source: 'oauth'|'env'|null}
     */
    public function getCredentials(): array
    {
        return $this->credentials->get();
    }

    public function isConnected(): bool
    {
        return $this->getCredentials()['token'] !== null;
    }

    /* ------------------------------------------------------------------ */
    /*  Configuration helpers                                              */
    /* ------------------------------------------------------------------ */

    /** The Platforms card's Meta posting switch (services.meta.enabled). */
    public function isPublishingEnabled(): bool
    {
        return $this->publishingEnabled;
    }

    public function isInstagramConfigured(): bool
    {
        return $this->isPublishingEnabled() && $this->isInstagramConnected();
    }

    /** Credentials for Instagram present — whether or not publishing is switched on. */
    public function isInstagramConnected(): bool
    {
        $c = $this->getCredentials();

        return $c['token'] !== null && ! empty($c['ig_id']);
    }

    public function isFacebookConfigured(): bool
    {
        return $this->isPublishingEnabled() && $this->isFacebookConnected();
    }

    /** Credentials for Facebook present — whether or not publishing is switched on. */
    public function isFacebookConnected(): bool
    {
        $c = $this->getCredentials();

        return $c['token'] !== null && ! empty($c['page_id']);
    }

    public function getLastError(): ?array
    {
        return $this->lastError;
    }

    /* ------------------------------------------------------------------ */
    /*  Instagram Publishing                                               */
    /* ------------------------------------------------------------------ */

    /**
     * Publish a photo to Instagram.
     *
     * @return array{id: string, permalink: string|null}|null
     */
    public function publishToInstagram(string $imageUrl, string $caption, ?string $locationId = null): ?array
    {
        if (! $this->isInstagramConfigured()) {
            $this->lastError = ['message' => 'Instagram not configured'];

            return null;
        }

        $container = $this->createInstagramContainer($imageUrl, $caption, $locationId);
        if (! $container) {
            return null;
        }

        $containerId = $container['id'];
        $creds = $this->getCredentials();
        $token = $creds['token'];
        $igUserId = $creds['ig_id'];

        // Wait for container to be ready (Instagram processes asynchronously)
        if (! $this->waitForContainer($containerId, $token)) {
            return null;
        }

        // Step 2: Publish the container
        $publishResponse = Http::timeout(60)->post(self::GRAPH_BASE."/{$igUserId}/media_publish", [
            'creation_id' => $containerId,
            'access_token' => $token,
        ]);

        if (! $publishResponse->successful()) {
            $this->lastError = [
                'message' => 'Instagram publish failed',
                'status' => $publishResponse->status(),
                'body' => $publishResponse->json(),
            ];
            Log::channel('social')->error('Meta Social: IG publish failed', $this->lastError);

            return null;
        }

        $mediaId = $publishResponse->json('id');
        $permalink = $this->getInstagramPermalink($mediaId, $token);

        Log::channel('social')->info('Meta Social: Published to Instagram', [
            'media_id' => $mediaId,
            'permalink' => $permalink,
        ]);

        return [
            'id' => $mediaId,
            'permalink' => $permalink,
        ];
    }

    /**
     * Create an Instagram media container without publishing it.
     *
     * This lets us validate credentials/image URL/caption end-to-end while
     * avoiding a public post. Container expires automatically if not published.
     *
     * @return array{id: string}|null
     */
    public function createInstagramContainer(string $imageUrl, string $caption, ?string $locationId = null): ?array
    {
        if (! $this->isInstagramConfigured()) {
            $this->lastError = ['message' => 'Instagram not configured'];

            return null;
        }

        $creds = $this->getCredentials();
        $igUserId = $creds['ig_id'];
        $token = $creds['token'];

        $payload = [
            'image_url' => $imageUrl,
            'caption' => $caption,
            'access_token' => $token,
        ];

        if ($locationId) {
            $payload['location_id'] = $locationId;
        }

        $containerResponse = Http::timeout(60)->post(self::GRAPH_BASE."/{$igUserId}/media", $payload);

        if (! $containerResponse->successful()) {
            $this->lastError = [
                'message' => 'Instagram container creation failed',
                'status' => $containerResponse->status(),
                'body' => $containerResponse->json(),
            ];
            Log::channel('social')->error('Meta Social: IG container failed', $this->lastError);

            return null;
        }

        $containerId = $containerResponse->json('id');
        if (! $containerId) {
            $this->lastError = ['message' => 'No container ID returned'];

            return null;
        }

        return ['id' => $containerId];
    }

    /* ------------------------------------------------------------------ */
    /*  Facebook Publishing                                                */
    /* ------------------------------------------------------------------ */

    /**
     * Publish a photo to a Facebook Page.
     *
     * @return array{id: string, permalink: string|null}|null
     */
    public function publishToFacebook(string $imageUrl, string $message, ?string $facebookPlaceId = null): ?array
    {
        if (! $this->isFacebookConfigured()) {
            $this->lastError = ['message' => 'Facebook not configured'];

            return null;
        }

        $creds = $this->getCredentials();
        $pageId = $creds['page_id'];
        $token = $creds['token'];

        $payload = [
            'url' => $imageUrl,
            'message' => $message,
            'access_token' => $token,
        ];

        if (is_string($facebookPlaceId) && trim($facebookPlaceId) !== '') {
            $payload['place'] = trim($facebookPlaceId);
        }

        $response = Http::timeout(60)->asForm()->post(self::GRAPH_BASE."/{$pageId}/photos", $payload);

        if (! $response->successful()) {
            $this->lastError = [
                'message' => 'Facebook photo upload failed',
                'status' => $response->status(),
                'body' => $response->json(),
            ];
            Log::channel('social')->error('Meta Social: FB upload failed', $this->lastError);

            return null;
        }

        $postId = $response->json('post_id') ?? $response->json('id');
        $permalink = $this->getFacebookPermalink((string) $postId, $token)
            ?? "https://www.facebook.com/{$postId}";

        Log::channel('social')->info('Meta Social: Published to Facebook', [
            'post_id' => $postId,
            'permalink' => $permalink,
        ]);

        return [
            'id' => $postId,
            'permalink' => $permalink,
        ];
    }

    protected function getFacebookPermalink(string $postId, string $token): ?string
    {
        if ($postId === '') {
            return null;
        }

        $resp = Http::timeout(20)->get(self::GRAPH_BASE."/{$postId}", [
            'fields' => 'permalink_url',
            'access_token' => $token,
        ]);

        if (! $resp->successful()) {
            return null;
        }

        $url = (string) ($resp->json('permalink_url') ?? '');

        return $url !== '' ? $url : null;
    }

    /* ------------------------------------------------------------------ */
    /*  Token Management                                                   */
    /* ------------------------------------------------------------------ */

    /**
     * Get the access token. Prefers the stored grant's token, falls back
     * to whatever env/config fallback the site's adapter resolves.
     */
    protected function getAccessToken(): string
    {
        return (string) ($this->getCredentials()['token'] ?? '');
    }

    /* ------------------------------------------------------------------ */
    /*  Internals                                                          */
    /* ------------------------------------------------------------------ */

    /**
     * Wait for an Instagram media container to finish processing.
     */
    protected function waitForContainer(string $containerId, string $token, int $maxAttempts = 10): bool
    {
        for ($i = 0; $i < $maxAttempts; $i++) {
            sleep(3);

            $status = Http::get(self::GRAPH_BASE."/{$containerId}", [
                'fields' => 'status_code',
                'access_token' => $token,
            ]);

            $statusCode = $status->json('status_code');

            if ($statusCode === 'FINISHED') {
                return true;
            }

            if ($statusCode === 'ERROR') {
                $this->lastError = [
                    'message' => 'Container processing failed',
                    'body' => $status->json(),
                ];
                Log::channel('social')->error('Meta Social: Container error', $this->lastError);

                return false;
            }

            // IN_PROGRESS — keep waiting
        }

        $this->lastError = ['message' => 'Container processing timed out'];
        Log::channel('social')->warning('Meta Social: Container timed out', ['container_id' => $containerId]);

        return false;
    }

    protected function getInstagramPermalink(string $mediaId, string $token): ?string
    {
        $response = Http::get(self::GRAPH_BASE."/{$mediaId}", [
            'fields' => 'permalink',
            'access_token' => $token,
        ]);

        return $response->json('permalink');
    }

    /* ------------------------------------------------------------------ */
    /*  Admin OAuth (Facebook Login flow)                                  */
    /* ------------------------------------------------------------------ */

    /**
     * Build the Facebook Login dialog URL for the admin to authorise the
     * app against their Facebook user / page / linked Instagram account.
     *
     * $scopes is a required call-time argument, not a class constant on
     * this kit class, because the production scope list genuinely differs
     * per site — gsc/jpeterson request 4 (no Facebook Page posting scopes:
     * App Review isn't needed since only Instagram is published to), hive
     * requests its OWN different 4 (drops instagram_content_publish — it
     * never publishes; adds pages_read_engagement), dawnsellshomes will
     * request 6 (adds pages_manage_posts — it posts to the Page too). A
     * kit-wide default would silently change what a site's "Connect"
     * button requests at the next reconnect.
     *
     * A site's own `App\Services\MetaSocialService` does NOT re-declare
     * `getOAuthUrl()`/`exchangeCodeAndStore()` at a narrower arity — PHP's
     * method-override rules refuse a child signature with fewer or
     * differently-typed parameters than the parent's, however many of
     * them carry defaults (confirmed: even dropping a single *optional*
     * trailing parameter fatals at class-load time, "Declaration ... must
     * be compatible with ..."). Each site's own public `OAUTH_SCOPES`
     * constant is instead passed explicitly, at the SAME handful of call
     * sites that already exist per site (the Platforms Livewire connect
     * action, the stateless oauth-url/callback controller or route, and
     * the CLI auth command where one exists) — e.g.
     * `MetaSocialService::OAUTH_SCOPES` — rather than the subclass
     * silently supplying it. This keeps `MetaGraphClient`'s own tested
     * public API (this method, exactly as declared below) the single
     * source of truth, with no shadow copy of it at a different arity.
     *
     * @param string[] $scopes
     */
    public function getOAuthUrl(string $redirectUri, array $scopes, ?string $state = null): string
    {
        $params = http_build_query([
            'client_id' => $this->appId,
            'redirect_uri' => $redirectUri,
            'response_type' => 'code',
            'scope' => implode(',', $scopes),
            'state' => $state ?: bin2hex(random_bytes(8)),
            'auth_type' => 'rerequest',
        ]);

        return 'https://www.facebook.com/v25.0/dialog/oauth?'.$params;
    }

    /**
     * Exchange the OAuth code for a long-lived Page Access Token,
     * auto-discover the FB Page + linked Instagram Business account, and
     * persist everything through the site's `MetaCredentialStore`. $scopes
     * is recorded into the stored grant where the adapter has somewhere to
     * put it (gsc/jpeterson's `oauth_tokens.scopes` column) — an adapter
     * with no such column (hive/dawn's `platform_settings` design) simply
     * ignores it, matching that site's pre-existing behaviour; it plays no
     * other part in the exchange.
     *
     * @param string[] $scopes
     * @return array{success: bool, error?: string, page_name?: string, ig_username?: ?string}
     */
    public function exchangeCodeAndStore(string $code, string $redirectUri, array $scopes): array
    {
        if (! $this->appId || ! $this->appSecret) {
            return ['success' => false, 'error' => 'META_APP_ID / META_APP_SECRET not configured in .env'];
        }

        // 1. Code -> short-lived user access token
        $tokenResp = Http::timeout(20)->get(self::GRAPH_BASE.'/oauth/access_token', [
            'client_id' => $this->appId,
            'client_secret' => $this->appSecret,
            'redirect_uri' => $redirectUri,
            'code' => $code,
        ]);
        if (! $tokenResp->successful()) {
            return ['success' => false, 'error' => 'Code exchange failed: '.($tokenResp->json('error.message') ?? $tokenResp->body())];
        }
        $shortLivedUserToken = $tokenResp->json('access_token');

        // 2. Short-lived -> long-lived user token (~60d)
        $longResp = Http::timeout(20)->get(self::GRAPH_BASE.'/oauth/access_token', [
            'grant_type' => 'fb_exchange_token',
            'client_id' => $this->appId,
            'client_secret' => $this->appSecret,
            'fb_exchange_token' => $shortLivedUserToken,
        ]);
        if (! $longResp->successful()) {
            return ['success' => false, 'error' => 'Long-lived token exchange failed: '.($longResp->json('error.message') ?? $longResp->body())];
        }
        $longLivedUserToken = $longResp->json('access_token');

        // 3. Fetch user's pages -> page access tokens (these don't expire
        //    while the user keeps the app authorised).
        $pagesResp = Http::timeout(20)->get(self::GRAPH_BASE.'/me/accounts', [
            'fields' => 'id,name,access_token,instagram_business_account{id,username}',
            'access_token' => $longLivedUserToken,
        ]);
        if (! $pagesResp->successful()) {
            return ['success' => false, 'error' => 'Failed to list pages: '.($pagesResp->json('error.message') ?? $pagesResp->body())];
        }

        $pages = $pagesResp->json('data', []);
        if (empty($pages)) {
            return ['success' => false, 'error' => 'This account does not manage any Facebook Pages. Make sure the page admin authorises the app.'];
        }

        // Prefer the page with a linked Instagram Business account; fall back to the first.
        $page = null;
        foreach ($pages as $p) {
            if (! empty($p['instagram_business_account']['id'] ?? null)) {
                $page = $p;
                break;
            }
        }
        $page = $page ?? $pages[0];

        // 4. Identify the authorising user (for the granted_by_email column)
        $meResp = Http::timeout(10)->get(self::GRAPH_BASE.'/me', [
            'fields' => 'id,name,email',
            'access_token' => $longLivedUserToken,
        ]);
        $email = $meResp->successful() ? ($meResp->json('email') ?? $meResp->json('name')) : null;

        // 5. Persist
        $this->credentials->store([
            'access_token' => $page['access_token'],
            'refresh_token' => $longLivedUserToken, // kept for re-issuing page tokens later
            'page_id' => $page['id'],
            'page_name' => $page['name'] ?? null,
            'ig_id' => $page['instagram_business_account']['id'] ?? null,
            'ig_username' => $page['instagram_business_account']['username'] ?? null,
            'granted_by_email' => $email,
            'scopes' => $scopes,
        ]);

        return [
            'success' => true,
            'page_name' => $page['name'] ?? '',
            'ig_username' => $page['instagram_business_account']['username'] ?? null,
        ];
    }

    /**
     * Forget the stored Meta credentials.
     */
    public function disconnect(): void
    {
        $this->credentials->clear();
    }

    /** Who last completed the Meta OAuth connect, for the Platforms card. */
    public function grantedByEmail(): ?string
    {
        return $this->credentials->grantedByEmail();
    }

    /** When the current grant was first stored. */
    public function grantedAt(): ?Carbon
    {
        return $this->credentials->grantedAt();
    }

    /** When the current grant was last written (a re-connect refreshes this without changing grantedAt()). */
    public function credentialsUpdatedAt(): ?Carbon
    {
        return $this->credentials->credentialsUpdatedAt();
    }
}
