<?php

namespace SsSystems\Platform\Social\Adapters;

use Illuminate\Support\Carbon;
use SsSystems\Platform\Social\Contracts\MetaCredentialStore;

/**
 * gsc's / jpeterson-design's Meta credential backend: a shared,
 * multi-provider `oauth_tokens` table (see `Auth\OAuthToken`), one row per
 * provider, the grant's Page/Instagram ids and names inside its `metadata`
 * JSON column.
 *
 * Wraps EACH SITE'S OWN `OAuthToken` model by class-string rather than a
 * kit-owned one, so gsc's `use BelongsToSite;` tenant scope on that model
 * keeps applying to every read/write here exactly as it does today — this
 * class never knows tenancy exists; it only ever calls the class-string's
 * own static methods, which is where that scope actually lives.
 */
final class OAuthTokenCredentialStore implements MetaCredentialStore
{
    /**
     * @param class-string<\Illuminate\Database\Eloquent\Model> $tokenModel
     *        The site's own `OAuthToken` model (`::forProvider()`, `::updateOrCreate()`, `::where()`).
     * @param string $provider The `oauth_tokens.provider` value this Meta grant is stored under.
     * @param array{token: ?string, page_id: ?string, ig_id: ?string, page_name: ?string, ig_username: ?string} $envFallback
     *        Already-resolved `services.meta.*` values (this class never reads config()/env() itself) —
     *        used only when no row is stored.
     */
    public function __construct(
        private readonly string $tokenModel,
        private readonly string $provider = 'meta',
        private readonly array $envFallback = [
            'token' => null, 'page_id' => null, 'ig_id' => null, 'page_name' => null, 'ig_username' => null,
        ],
    ) {
    }

    public function get(): array
    {
        $token = ($this->tokenModel)::forProvider($this->provider);

        if ($token && $token->access_token) {
            $meta = $token->metadata ?? [];

            return [
                'token' => $token->access_token,
                'page_id' => $meta['page_id'] ?? null,
                'ig_id' => $meta['ig_id'] ?? null,
                'page_name' => $meta['page_name'] ?? null,
                'ig_username' => $meta['ig_username'] ?? null,
                'source' => 'oauth',
            ];
        }

        $envToken = trim((string) ($this->envFallback['token'] ?? ''));
        if ($envToken === '') {
            return ['token' => null, 'page_id' => null, 'ig_id' => null, 'page_name' => null, 'ig_username' => null, 'source' => null];
        }

        return [
            'token' => $envToken,
            'page_id' => trim((string) ($this->envFallback['page_id'] ?? '')) ?: null,
            'ig_id' => trim((string) ($this->envFallback['ig_id'] ?? '')) ?: null,
            'page_name' => $this->envFallback['page_name'] ?? null,
            'ig_username' => $this->envFallback['ig_username'] ?? null,
            'source' => 'env',
        ];
    }

    public function store(array $grant): void
    {
        ($this->tokenModel)::updateOrCreate(
            ['provider' => $this->provider],
            [
                'access_token' => $grant['access_token'],
                'refresh_token' => $grant['refresh_token'] ?? null,
                'access_token_expires_at' => null, // page tokens issued from long-lived user tokens don't expire
                'scopes' => $grant['scopes'] ?? [],
                'granted_by_email' => $grant['granted_by_email'] ?? null,
                'metadata' => [
                    'page_id' => $grant['page_id'] ?? null,
                    'page_name' => $grant['page_name'] ?? null,
                    'ig_id' => $grant['ig_id'] ?? null,
                    'ig_username' => $grant['ig_username'] ?? null,
                ],
            ],
        );
    }

    public function clear(): void
    {
        ($this->tokenModel)::where('provider', $this->provider)->delete();
    }

    public function grantedByEmail(): ?string
    {
        return ($this->tokenModel)::forProvider($this->provider)?->granted_by_email;
    }

    public function grantedAt(): ?Carbon
    {
        return ($this->tokenModel)::forProvider($this->provider)?->created_at;
    }

    public function credentialsUpdatedAt(): ?Carbon
    {
        return ($this->tokenModel)::forProvider($this->provider)?->updated_at;
    }
}
