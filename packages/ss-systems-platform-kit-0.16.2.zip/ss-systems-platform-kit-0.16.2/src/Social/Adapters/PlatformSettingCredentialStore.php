<?php

namespace SsSystems\Platform\Social\Adapters;

use Illuminate\Support\Carbon;
use SsSystems\Platform\Social\Contracts\MetaCredentialStore;

/**
 * hive.contractors' (and, later, dawnsellshomes' — see the kit's
 * CONSOLIDATION-PLAN.md, "dawn: later") Meta credential backend:
 * individual encrypted `platform_settings` rows, one per field, rather
 * than a dedicated `oauth_tokens` row — neither site has a multi-provider
 * OAuth table to share, and introducing one just for Meta would duplicate
 * what each already has (see hive's own pre-port `App\Services\
 * MetaSocialService` docblock, which explains this explicitly).
 *
 * Wraps the site's own `PlatformSetting` model by class-string (its
 * `::get()`/`::put()`/`::where()`), never a kit-owned model.
 */
final class PlatformSettingCredentialStore implements MetaCredentialStore
{
    private const FIELD_KEYS = ['access_token', 'refresh_token', 'page_id', 'page_name', 'ig_id', 'ig_username', 'granted_by_email'];

    /**
     * @param class-string $settingModel The site's own `PlatformSetting` model (`::get()`/`::put()`/`::where()`).
     * @param string $prefix The setting-key prefix each field hangs off — hive/dawn both use `meta`
     *        (`meta.access_token`, `meta.page_id`, ...).
     * @param array{token: ?string, page_id: ?string, ig_id: ?string, page_name: ?string, ig_username: ?string} $envFallback
     *        Already-resolved `services.meta.*` values (this class never reads config()/env() itself) —
     *        used only when no row is stored.
     */
    public function __construct(
        private readonly string $settingModel,
        private readonly string $prefix = 'meta',
        private readonly array $envFallback = [
            'token' => null, 'page_id' => null, 'ig_id' => null, 'page_name' => null, 'ig_username' => null,
        ],
    ) {
    }

    private function key(string $field): string
    {
        return "{$this->prefix}.{$field}";
    }

    public function get(): array
    {
        $token = ($this->settingModel)::get($this->key('access_token'));

        if ($token !== null) {
            return [
                'token' => $token,
                'page_id' => ($this->settingModel)::get($this->key('page_id')),
                'ig_id' => ($this->settingModel)::get($this->key('ig_id')),
                'page_name' => ($this->settingModel)::get($this->key('page_name')),
                'ig_username' => ($this->settingModel)::get($this->key('ig_username')),
                'source' => 'oauth',
            ];
        }

        $envToken = trim((string) ($this->envFallback['token'] ?? ''));
        if ($envToken === '') {
            return ['token' => null, 'page_id' => null, 'ig_id' => null, 'page_name' => null, 'ig_username' => null, 'source' => null];
        }

        return [
            'token' => $envToken,
            'page_id' => trim((string) ($this->envFallback['page_id'] ?? '')) ?: null,
            'ig_id' => trim((string) ($this->envFallback['ig_id'] ?? '')) ?: null,
            'page_name' => $this->envFallback['page_name'] ?? null,
            'ig_username' => $this->envFallback['ig_username'] ?? null,
            'source' => 'env',
        ];
    }

    public function store(array $grant): void
    {
        ($this->settingModel)::put($this->key('access_token'), $grant['access_token']);
        ($this->settingModel)::put($this->key('refresh_token'), $grant['refresh_token'] ?? null);
        ($this->settingModel)::put($this->key('page_id'), $grant['page_id'] ?? null);
        ($this->settingModel)::put($this->key('page_name'), $grant['page_name'] ?? null);
        ($this->settingModel)::put($this->key('ig_id'), $grant['ig_id'] ?? null);
        ($this->settingModel)::put($this->key('ig_username'), $grant['ig_username'] ?? null);
        ($this->settingModel)::put($this->key('granted_by_email'), $grant['granted_by_email'] ?? null);
        // 'scopes' has no row on this backend (see class docblock) — silently
        // not stored here, matching this site's pre-existing behaviour.
    }

    public function clear(): void
    {
        foreach (self::FIELD_KEYS as $field) {
            ($this->settingModel)::put($this->key($field), null);
        }
    }

    public function grantedByEmail(): ?string
    {
        return ($this->settingModel)::get($this->key('granted_by_email'));
    }

    public function grantedAt(): ?Carbon
    {
        return ($this->settingModel)::where('key', $this->key('access_token'))->first()?->created_at;
    }

    public function credentialsUpdatedAt(): ?Carbon
    {
        return ($this->settingModel)::where('key', $this->key('access_token'))->first()?->updated_at;
    }
}
