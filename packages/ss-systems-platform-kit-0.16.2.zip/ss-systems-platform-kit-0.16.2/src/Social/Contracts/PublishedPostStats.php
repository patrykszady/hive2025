<?php

namespace SsSystems\Platform\Social\Contracts;

use SsSystems\Platform\Social\PostStatsRow;

/**
 * The automation card's "last post" line for one platform — a site adapter
 * wraps whatever model actually records a publish attempt (gsc/jpeterson:
 * `ImageSocialPost`; a listings site: its own post model), so the kit never
 * references a site's Eloquent model directly.
 */
interface PublishedPostStats
{
    /** The most recent post row for this platform (any status), or null if none exists yet. */
    public function latestFor(string $platform): ?PostStatsRow;

    /** How many posts on this platform were actually published in the last 30 days. */
    public function countPublished30d(string $platform): int;
}
