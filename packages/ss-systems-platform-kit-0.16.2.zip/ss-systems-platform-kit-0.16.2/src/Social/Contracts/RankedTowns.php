<?php

namespace SsSystems\Platform\Social\Contracts;

/**
 * The towns worth naming in this week's Google Business Profile post,
 * ranked by how active the business actually is there — not a page-content
 * completeness list. Deliberately a NEW, separate contract from
 * `Reports\Contracts\AreaCatalog`: that one describes a site's landing
 * PAGES for the on-page SEO audit (id/slug/content_complete); this one is
 * just ranked city names for a caption picker, and the two must never be
 * merged into one shape serving two different callers (kit 0.13.0 audit).
 *
 * Capability key: `ranked_towns`.
 */
interface RankedTowns
{
    /**
     * The $n towns the business is most active in right now, most active
     * first (ties broken alphabetically by the implementation). A town with
     * no activity at all is never included, so a short list is possible.
     *
     * @return list<string> city names
     */
    public function coreTowns(int $n = 6): array;
}
