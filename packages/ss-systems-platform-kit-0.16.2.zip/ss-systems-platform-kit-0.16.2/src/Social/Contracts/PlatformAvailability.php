<?php

namespace SsSystems\Platform\Social\Contracts;

/**
 * Whether a platform can actually post right now, and whether the owner has
 * switched posting off on a platform that otherwise could. A site adapter
 * wraps its own connection services (gsc/jpeterson: `MetaSocialService` for
 * instagram/facebook, `GoogleBusinessProfileService` for google_business);
 * a site with a smaller platform roster (no `google_business` arm) simply
 * never matches that platform and both methods fall through to false.
 */
interface PlatformAvailability
{
    /** Is this platform connected/set up at all? */
    public function isConfigured(string $platform): bool;

    /**
     * Connected, but the owner's publishing switch on the Platforms page is
     * off — reported as exactly that ("connected, publishing is switched
     * off"), never as "not connected" (2026-09-23). A platform with no such
     * switch (google_business: connected is ready) is always false here.
     */
    public function isPublishingOff(string $platform): bool;
}
