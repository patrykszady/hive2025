<?php

namespace SsSystems\Platform\Social\Contracts;

use Illuminate\Support\Carbon;

/**
 * Wraps a site's own `App\Models\SocialAutomationSetting` Eloquent model so
 * `Social\AutomationTickRunner` can read and advance one row per platform
 * without the kit ever referencing `App\Models\*` (gsc's row also carries
 * `BelongsToSite`; jpeterson/dawn's does not — both are invisible past this
 * interface).
 */
interface AutomationSettingsRepository
{
    /**
     * One row per platform THE SITE DECLARES, in that site's own fixed
     * display order (its `PLATFORMS` constant) — including a platform that
     * has never been saved. The adapter resolves `cadence`/`options`
     * against its own `defaultsFor()` and reports `enabled: false` for a
     * missing row, exactly like each site's existing
     * `AutomationSettingsService::item()` already does, so:
     *   - the runner never has to know a platform's own defaults, and
     *   - a sibling-cadence lookup (instagram/facebook must never land on
     *     the same day — see AutomationTickRunner's class docblock) always
     *     gets a real cadence, even for a platform nobody has touched yet,
     *     matching both sites' original `$setting->cadence ?? defaultsFor()`
     *     fallback.
     *
     * @return array<string, array{
     *     enabled: bool,
     *     cadence: array{per_week:int, days:?array<int,int>, window:array{start:string,end:string}},
     *     options: array<string, mixed>,
     *     last_dispatched_slot: ?string,
     *     last_dispatched_at: ?Carbon,
     * }>
     */
    public function all(): array;

    /**
     * Mark $platform's slot spent BEFORE the post is attempted — a
     * `forceFill(...)->save()`, not a queued write — so a crash between
     * this call and the actual publish can only cost this one slot; it can
     * never replay it later, because `last_dispatched_slot` already
     * matches. $at is the real wall-clock moment of dispatch, computed by
     * the runner with its own `Carbon::now()` (not the tick's own `$now`
     * argument) exactly like both sites' original `dispatchSlot()`/
     * `publish()` did.
     */
    public function markDispatched(string $platform, string $slot, Carbon $at): void;
}
