<?php

namespace SsSystems\Platform\Social\Contracts;

/**
 * A site's own trending-services signal for this week's Google Business
 * Profile post: is any of its services searched for noticeably more than
 * usual right now, and if so, which one and what phrase is rising.
 *
 * Nothing like this exists in the kit before 0.13.0 — it is new. The kit
 * never learns the site's service vocabulary (kitchen/bathroom/basement…
 * is remodeling-trade wording that would mean nothing to, say, a listings
 * site): the implementation resolves its OWN raw trend data down to one of
 * its OWN service identifiers before returning it, so `GbpPostTheme` only
 * ever sees the answer, never the phrase→service mapping or the "how far
 * above average counts as rising" threshold that produced it.
 *
 * Capability key: `trends_intel`.
 */
interface TrendsIntel
{
    /**
     * The single most-rising service right now, or null when the site has
     * no trend data at all, or nothing is rising enough to be worth a
     * mention this week.
     *
     * @return ?array{service: string, phrase: string}
     */
    public function risingPhrase(): ?array;
}
