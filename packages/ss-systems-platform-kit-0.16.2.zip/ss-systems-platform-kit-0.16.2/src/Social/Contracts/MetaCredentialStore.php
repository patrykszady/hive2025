<?php

namespace SsSystems\Platform\Social\Contracts;

use Illuminate\Support\Carbon;

/**
 * The Meta (Facebook Page + linked Instagram Business account) OAuth grant,
 * storage-agnostic. `Social\MetaGraphClient` never touches a model or a
 * `platform_settings` row directly — every site's own storage backend
 * implements this instead:
 *
 *   - gsc / jpeterson-design: a shared, multi-provider `oauth_tokens` table
 *     (`Social\Adapters\OAuthTokenCredentialStore`), the grant's Page/
 *     Instagram ids inside its `metadata` JSON column.
 *   - hive.contractors (and, later, dawnsellshomes — see the kit's
 *     CONSOLIDATION-PLAN.md, "dawn: later"): individual encrypted
 *     `platform_settings` rows, one per field
 *     (`Social\Adapters\PlatformSettingCredentialStore`).
 *
 * Both backends are real and live in production today — this contract does
 * not pick a winner, it lets each site keep the one it already has (see
 * ss-platform-kit/docs/audit-2026-09-27/social-posting-and-automation.md,
 * unit 9, "two credential-storage designs already exist").
 */
interface MetaCredentialStore
{
    /**
     * The resolved credentials to post/read with — the stored grant when
     * one exists, an env/config fallback otherwise. Each adapter resolves
     * its own fallback values at construction; this contract (and
     * `MetaGraphClient`) never reads config()/env() directly.
     *
     * @return array{token: ?string, page_id: ?string, ig_id: ?string, page_name: ?string, ig_username: ?string, source: 'oauth'|'env'|null}
     */
    public function get(): array;

    /**
     * Persist a freshly exchanged grant. An adapter with nowhere to keep a
     * given field (e.g. the platform_settings backend has no `scopes` row)
     * simply ignores it — that omission is the site's own, pre-existing
     * behaviour, not a bug introduced here.
     *
     * @param array{
     *     access_token: string,
     *     refresh_token: ?string,
     *     page_id: ?string,
     *     page_name: ?string,
     *     ig_id: ?string,
     *     ig_username: ?string,
     *     granted_by_email: ?string,
     *     scopes: string[],
     * } $grant
     */
    public function store(array $grant): void;

    /** Forget the stored grant entirely (the Platforms card's Disconnect action). */
    public function clear(): void;

    /** Who last completed the OAuth connect, for the Platforms card — null before any grant or once cleared. */
    public function grantedByEmail(): ?string;

    /** When the current grant was first stored. */
    public function grantedAt(): ?Carbon;

    /** When the current grant was last written (a re-connect refreshes this without changing grantedAt()). */
    public function credentialsUpdatedAt(): ?Carbon;
}
