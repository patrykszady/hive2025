<?php

namespace SsSystems\Platform\Social\Contracts;

/**
 * A site's per-platform automatic-posting settings row (instagram, facebook,
 * google_business, or whatever roster the site declares), and the catalog
 * data around it — the fixed platform order, each one's display label and
 * its realistic disabled-default cadence/options. Replaces every direct
 * `App\Models\SocialAutomationSetting::` static/query call the two sites'
 * `AutomationSettingsService` copies made before this port (`PLATFORMS`,
 * `LABELS`, `defaultsFor()`, `where('platform', ...)->first()`,
 * `updateOrCreate()`) — the kit never references that model directly (it
 * stays a per-site Eloquent model, see the kit's Social docs), so a site
 * binds this to a small adapter wrapping its own model instead.
 *
 * `find()`/`save()` are NOT tenant-scoped by this contract: a gsc adapter
 * wraps a model that already carries `Concerns\BelongsToSite`'s global
 * scope, so the tenant boundary is enforced by the model, not by anything
 * here — this contract only ever sees "the current tenant's row", exactly
 * as the site code it replaces did.
 */
interface SettingsStore
{
    /**
     * Every platform this site automates, in the fixed order the API
     * always reports them in.
     *
     * @return list<string>
     */
    public function platforms(): array;

    /** The owner-facing label for one platform (falls back to ucfirst()). */
    public function label(string $platform): string;

    /**
     * A realistic DISABLED cadence/options for a platform that has never
     * been saved, so a fresh site (or a fresh tenant) still reports a
     * plausible plan instead of an arbitrary one.
     *
     * @return array{cadence: array{per_week: int, days: ?array<int, int>, window: array{start: string, end: string}}, options: array<string, mixed>}
     */
    public function defaultsFor(string $platform): array;

    /**
     * The saved row for one platform, or null when nobody has ever saved
     * this platform's card (callers must treat that as enabled=false, never
     * insert a row on read — see the site model's own docblock).
     *
     * @return array{enabled: bool, cadence: array, options: array, updated_at: ?\Illuminate\Support\Carbon}|null
     */
    public function find(string $platform): ?array;

    /**
     * Persist a validated {enabled, cadence, options} payload for one
     * platform (an upsert keyed on platform — a site with no row yet gets
     * one created).
     *
     * @param  array{enabled: bool, cadence: array, options: array}  $data
     */
    public function save(string $platform, array $data): void;
}
