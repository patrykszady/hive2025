<?php

namespace SsSystems\Platform\Social;

use Illuminate\Support\Carbon;
use SsSystems\Platform\Social\Contracts\AutomationSettingsRepository;
use SsSystems\Platform\Social\Contracts\PlatformAvailability;
use SsSystems\Platform\Social\Contracts\SocialPublisher;

/**
 * One 5-minute tick's worth of work for ONE site: for every platform that is
 * both enabled and configured, dispatch the slot `AutomationPlanner` says is
 * due (never twice — see `Contracts\AutomationSettingsRepository`'s own
 * docblock), hold it back instead when it lands the same or the previous
 * calendar day as the last post (`AutomationPlanner::tooSoonAfter()`, a plan
 * that moved under the week), and — for whichever platforms the caller marks
 * as having a catch-up safety net — post anyway once nothing has ACTUALLY
 * published in longer than the plan ever leaves between posts.
 *
 * Ported from gs.construction's and jpeterson-design's near-identical
 * `SocialAutomationTick` console commands (2026-09-27): gsc's own
 * `Tenancy::each` loop and its per-tenant, per-tick resolution of
 * `AutomationPlanner` (so a site's own timezone governs its clock) STAY in
 * gsc's thin command, which calls `run()` once per site inside the loop —
 * this class never learns that tenancy exists. jpeterson has no loop; its
 * thin command calls `run()` once with a fixed seed.
 *
 * APPROVED BEHAVIOUR CHANGE (Patryk, 2026-09-27): before this port,
 * jpeterson's catch-up net checked the settings row's own
 * `last_dispatched_at` — a timestamp both sites set the moment a slot is
 * marked spent, BEFORE the post is even attempted, "so a failure cannot
 * make the tick republish it". That meant jpeterson's net could never
 * actually fire from a silently-failing publish: from its point of view,
 * posting never went stale, because the timestamp kept advancing on every
 * attempt regardless of success. Only gsc's version — which reads
 * `SocialPublisher::lastPublishedAt()`, a REAL published-row lookup — ever
 * noticed a real gap. This class carries gsc's design for every caller, so
 * jpeterson's net starts firing on real missed posts too (it may post once
 * to catch up right after this ships, if its net had in fact gone stale).
 *
 * gsc's original `maybeCatchUp()` ALSO refused to fire on top of any post
 * created the same day — a regular slot that fired earlier and had not
 * published yet, or a manual "Post Now" from the admin, which never
 * touches the settings row. That guard survives the port as
 * `SocialPublisher::attemptedToday()` (each site answers it from its own
 * post rows), beside the settings-row check below; nothing about it
 * changed for gsc, and jpeterson gains the same protection.
 */
final class AutomationTickRunner
{
    /** The one clock minute both sites' original catch-up check ran at. */
    private const CATCH_UP_CHECK_TIME = '10:20';

    public function __construct(
        private readonly AutomationPlanner $planner,
        private readonly AutomationSettingsRepository $settings,
        private readonly PlatformAvailability $availability,
        private readonly SocialPublisher $publisher,
    ) {}

    /**
     * @param  list<string>  $catchUpPlatforms  platforms that also get the once-daily safety net (google_business on
     *         gsc/jpeterson today) — gated exactly like a regular slot: a platform whose row is disabled or not
     *         configured gets neither, even if it is in this list (matches both sites' original `continue` ordering).
     * @param  ?callable(string $platform, string $slot, ?Carbon $lastDispatchedAt, Carbon $now): void  $onHeld  called
     *         when a due slot is held back instead of dispatched, so the site can log/echo it exactly as before — this
     *         class never touches `Log::` itself (kept testable outside a booted Laravel app; see its own test).
     */
    public function run(string $siteSlug, Carbon $now, array $catchUpPlatforms = [], ?callable $onHeld = null): void
    {
        $rows = $this->settings->all();

        foreach ($rows as $platform => $row) {
            if (! $row['enabled'] || ! $this->availability->isConfigured($platform)) {
                continue;
            }

            $cadence = $row['cadence'];
            $slot = $this->planner->due($siteSlug, $platform, $cadence, $now, $this->siblingCadence($platform, $rows));

            if ($slot !== null && $row['last_dispatched_slot'] !== $slot) {
                if ($this->planner->tooSoonAfter($cadence, $row['last_dispatched_at'], $now)) {
                    // Held, not moved: see AutomationPlanner::tooSoonAfter()'s own docblock for why.
                    if ($onHeld !== null) {
                        $onHeld($platform, $slot, $row['last_dispatched_at'], $now);
                    }
                } else {
                    $row = $this->dispatch($platform, $slot, $row['options'], $row);
                }
            }

            if (in_array($platform, $catchUpPlatforms, true)) {
                $this->maybeCatchUp($platform, $row, $this->planner->catchUpAfterDays($cadence), $now);
            }
        }
    }

    /**
     * Mark the slot spent, THEN dispatch — never the other order (see
     * `Contracts\AutomationSettingsRepository::markDispatched()`'s docblock).
     * Returns the row with its two fields updated in place, so a catch-up
     * check running later in the SAME tick sees the fresh
     * `last_dispatched_at` (mirrors both sites mutating the same Eloquent
     * `$setting` instance across the method).
     *
     * @param  array<string, mixed>  $options
     * @param  array{enabled: bool, cadence: array, options: array, last_dispatched_slot: ?string, last_dispatched_at: ?Carbon}  $row
     * @return array{enabled: bool, cadence: array, options: array, last_dispatched_slot: ?string, last_dispatched_at: ?Carbon}
     */
    private function dispatch(string $platform, string $slot, array $options, array $row): array
    {
        $dispatchedAt = Carbon::now();
        $this->settings->markDispatched($platform, $slot, $dispatchedAt);
        $this->publisher->publish($platform, $slot, $options);

        $row['last_dispatched_slot'] = $slot;
        $row['last_dispatched_at'] = $dispatchedAt;

        return $row;
    }

    /**
     * Checked once a day at 10:20 local — the same clock minute both sites'
     * original safety net used, so it runs after the morning's regular slot
     * (if any) has already had its chance to fire.
     *
     * @param  array{enabled: bool, cadence: array, options: array, last_dispatched_slot: ?string, last_dispatched_at: ?Carbon}  $row
     */
    private function maybeCatchUp(string $platform, array $row, int $afterDays, Carbon $now): void
    {
        if ($now->format('H:i') !== self::CATCH_UP_CHECK_TIME) {
            return;
        }

        $catchUpId = $now->toDateString().' catch-up';
        if ($row['last_dispatched_slot'] === $catchUpId) {
            return;
        }

        $lastPublishedAt = $this->publisher->lastPublishedAt($platform);

        // A real publish record governs staleness whenever one exists. Only
        // when there has NEVER been one AND the settings row itself has no
        // dispatch history at all does this read as "just switched on: the
        // plan's first slot is coming, a catch-up now would jump it" — a row
        // with real dispatch history (last_dispatched_at set) but no real
        // publish EVER (every attempt has been silently failing since day
        // one) is exactly the gap this catch-up exists to close, so it reads
        // stale too (see this class's own "APPROVED BEHAVIOUR CHANGE" docblock).
        $isStale = $lastPublishedAt !== null
            ? $lastPublishedAt->lessThan($now->copy()->subDays($afterDays))
            : $row['last_dispatched_at'] !== null;
        if (! $isStale) {
            return;
        }

        // A regular slot already fired earlier today and may still be
        // processing (queued) — or someone posted by hand today: either
        // way a catch-up now would be a second post on the same day.
        if ($row['last_dispatched_at'] !== null && $row['last_dispatched_at']->isSameDay($now)) {
            return;
        }
        if ($this->publisher->attemptedToday($platform, $now)) {
            return;
        }

        $this->dispatch($platform, $catchUpId, [], $row);
    }

    /**
     * Instagram and Facebook must never land on the same day
     * (`AutomationPlanner`'s own class docblock) — hands the planner the
     * OTHER meta platform's cadence so it can offset its day draw from
     * their shared weekly shuffle. Null for any other platform, or when the
     * site does not even declare the sibling (its own `all()` has no entry
     * for it) — `AutomationPlanner::days()` already treats a null sibling
     * as "assume it posts as often as this platform".
     *
     * @param  array<string, array{cadence: array, enabled: bool, options: array, last_dispatched_slot: ?string, last_dispatched_at: ?Carbon}>  $rows
     */
    private function siblingCadence(string $platform, array $rows): ?array
    {
        if (! in_array($platform, AutomationPlanner::META_PLATFORMS, true)) {
            return null;
        }

        foreach (AutomationPlanner::META_PLATFORMS as $sibling) {
            if ($sibling !== $platform) {
                return $rows[$sibling]['cadence'] ?? null;
            }
        }

        return null;
    }
}
