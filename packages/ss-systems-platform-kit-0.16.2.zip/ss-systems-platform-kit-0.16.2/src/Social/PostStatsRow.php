<?php

namespace SsSystems\Platform\Social;

use Illuminate\Support\Carbon;

/**
 * One platform's most recent social post, exactly the two things the
 * automation card's "last post" line shows: when (the site's own adapter
 * resolves published_at, falling back to created_at for a post that never
 * got that far — see gsc/jpeterson's identical `?? ` chain this replaces)
 * and what state it ended up in.
 */
final class PostStatsRow
{
    public function __construct(
        public readonly ?Carbon $at,
        public readonly ?string $status,
    ) {}
}
