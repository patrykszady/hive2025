<?php

namespace SsSystems\Platform\Social\Contracts;

use Illuminate\Support\Carbon;

/**
 * A platform split into lanes that each post on their own schedule — one per
 * Google Business listing on a studio with a listing per city (2026-11-03,
 * jpeterson-design: Chicago, Atlanta and Southwest Michigan each get their
 * own posts a week, only from their own city's photos, instead of sharing
 * one schedule that the city with the most photos mostly won).
 *
 * Optional: a site that binds none, or reports no lanes for a platform,
 * posts that platform exactly as before through `SocialPublisher` and the
 * platform's own settings row. With lanes, `AutomationTickRunner` plans each
 * lane separately (`AutomationPlanner::laneDue()`), keeps each lane's own
 * dispatch record through this contract, and runs the catch-up safety net
 * per lane. The platform's cadence (posts a week, window, days) applies to
 * every lane: "2 a week" means two per lane.
 */
interface PostingLanes
{
    /**
     * The platform's lanes in a fixed order, or [] when it posts as one.
     * The order matters: it decides which lane's slot moves when two lanes
     * land within 30 minutes of each other on the same day.
     *
     * @return list<array{key: string, label: string}>
     */
    public function lanesFor(string $platform): array;

    /**
     * Publish (or queue) one post in this lane only — for a listing lane, a
     * photo of that lane's own city to that city's listing. A lane with
     * nothing left to post simply posts nothing.
     *
     * @param  array<string, mixed>  $options  the platform's saved options (empty for a catch-up)
     */
    public function publish(string $platform, string $lane, string $slot, array $options = []): void;

    /** The lane's last post that actually published — never a dispatch time (see SocialPublisher::lastPublishedAt()). */
    public function lastPublishedAt(string $platform, string $lane): ?Carbon;

    /** Any post row of this lane created today, whatever its status (see SocialPublisher::attemptedToday()). */
    public function attemptedToday(string $platform, string $lane, Carbon $now): bool;

    /** Posts this lane published in the last 30 days, for the admin card. */
    public function publishedCount30d(string $platform, string $lane): int;

    /**
     * The lane's own dispatch record — what the platform's settings row holds
     * for a platform without lanes.
     *
     * @return array{slot: ?string, at: ?Carbon}
     */
    public function lastDispatched(string $platform, string $lane): array;

    /** Mark the lane's slot spent BEFORE publishing (see AutomationSettingsRepository::markDispatched()). */
    public function markDispatched(string $platform, string $lane, string $slot, Carbon $at): void;
}
