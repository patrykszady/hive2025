<?php

namespace SsSystems\Platform\Seo\Visibility;

use SsSystems\Platform\Seo\Contracts\SeoSiteProfile;

/**
 * Builds the `dataforseo` block of the admin SEO snapshot — ported from
 * gs.construction's SeoReportController::dataForSeoSnapshot(), minus the
 * Cache::remember() wrapper (the site's own snapshot-building concern, not
 * this module's — see this class's own call sites for where to cache it)
 * and minus the `balance` key (written by a separate daily balance-check
 * command this port does not include; the site merges that in itself when
 * it has one).
 *
 * The three widgets the "Search Visibility vs. Competitors" card reads:
 *
 *  - share_of_voice: the latest weekly DomainOverviewCommand run, one row
 *    per domain that is either us or still passes CompetitorMatch::isCompetitor()
 *    (a domain dropped from the tracked set keeps its stale rows in the
 *    table forever otherwise — this is why the run's own domain list, not
 *    "every domain ever stored", decides who appears), sorted us-first then
 *    by top10 descending, each with its keyword churn (is_new/is_lost)
 *    against the previous run for the same domain.
 *  - link_gap (+ link_gap_total, link_gap_hidden): domains linking to 2-5
 *    of the tracked competitors, not to us, not spam-flagged, not a
 *    free-host spam network or a directory — link_gap_total and link_gap's
 *    first 20 come from the top 80 by (competitor_count, rank) BEFORE the
 *    free-host/directory reject (ported exactly as gs.construction computed
 *    it — the top-80 cap in link_gap_total is a lower bound once there are
 *    more than 80 qualifying prospects, same as upstream); link_gap_hidden's
 *    own "visible" tally is computed separately, over every qualifying
 *    prospect with no 80 cap, exactly mirroring the two independent queries
 *    gs.construction's controller ran.
 *  - ai_mentions: the latest asked_on day's questions, named-or-not,
 *    against the day before, by platform and by town, plus who the engines
 *    name instead, and (2026-11-11) the pages and sites the engines cited
 *    for those answers: cited_pages / cited_sites, each counted once per
 *    answer, ours marked; cited_recorded says whether that day stored any.
 */
final class VisibilitySnapshot
{
    private const FREE_HOST_PATTERN = '/\.(web\.app|blogspot\.com|wordpress\.com|weebly\.com|wixsite\.com|github\.io|netlify\.app|vercel\.app|pages\.dev|firebaseapp\.com)$/';

    public function __construct(
        private readonly DomainOverviewStore $domainOverviews,
        private readonly BacklinkProspectStore $backlinkProspects,
        private readonly AiMentionStore $aiMentions,
        private readonly SeoSiteProfile $profile,
    ) {}

    /**
     * @return array{
     *     share_of_voice: list<array<string, mixed>>,
     *     link_gap: list<array{domain: string, rank: int, competitors: list<string>, platform: ?string}>,
     *     link_gap_total?: int,
     *     link_gap_hidden?: array{competitor_count_out_of_range: int, spam_score: int, free_host: int, directory: int, visible: int},
     *     ai_mentions: ?array<string, mixed>,
     * }
     */
    public function build(): array
    {
        return array_merge([
            'share_of_voice' => $this->shareOfVoice(),
            'link_gap' => [],
            'ai_mentions' => $this->aiMentionsSnapshot(),
        ], $this->linkGap());
    }

    /** @return list<array<string, mixed>> */
    private function shareOfVoice(): array
    {
        $rows = $this->domainOverviews->rows();
        if ($rows === []) {
            return [];
        }

        $latestRun = $rows[0]['date'];
        $currentDomains = [];
        foreach ($rows as $row) {
            if ($row['date'] === $latestRun) {
                $currentDomains[$row['domain']] = true;
            }
        }

        $byDomain = [];
        foreach ($rows as $row) {
            if (isset($currentDomains[$row['domain']])) {
                $byDomain[$row['domain']][] = $row;
            }
        }

        $top10 = fn (array $r): int => (int) $r['pos_1'] + (int) $r['pos_2_3'] + (int) $r['pos_4_10'];

        $out = [];
        foreach ($byDomain as $domain => $group) {
            $latest = $group[0];
            $prev = $group[1] ?? null;
            $isUs = (bool) $latest['is_us'];
            if (! $isUs && ! CompetitorMatch::isCompetitor((string) $domain, $this->profile)) {
                continue; // a directory/aggregator that slipped into a run is still not a competitor
            }
            $out[] = [
                'domain' => $domain,
                'is_us' => $isUs,
                'date' => $latest['date'],
                'top10' => $top10($latest),
                'top10_prev' => $prev ? $top10($prev) : null,
                'top20' => $top10($latest) + (int) $latest['pos_11_20'],
                'keywords_total' => (int) $latest['keywords_total'],
                'etv' => round((float) $latest['etv']),
                'referring_domains' => $latest['referring_domains'] !== null ? (int) $latest['referring_domains'] : null,
                'domain_rank' => $latest['domain_rank'] !== null ? (int) $latest['domain_rank'] : null,
                'is_new' => (int) $latest['is_new'],
                'is_new_prev' => $prev ? (int) $prev['is_new'] : null,
                'is_lost' => (int) $latest['is_lost'],
                'is_lost_prev' => $prev ? (int) $prev['is_lost'] : null,
            ];
        }

        usort($out, fn (array $a, array $b) => [$b['is_us'], $b['top10']] <=> [$a['is_us'], $a['top10']]);

        return $out;
    }

    /**
     * @return array{link_gap: list<array<string, mixed>>, link_gap_total?: int, link_gap_hidden?: array<string, int>}
     */
    private function linkGap(): array
    {
        if (! $this->backlinkProspects->exists()) {
            return ['link_gap' => []];
        }

        $rows = $this->backlinkProspects->rows();
        $notUs = array_values(array_filter($rows, fn (array $r) => ! (bool) $r['links_to_us']));
        $inRange = array_values(array_filter($notUs, fn (array $r) => (int) $r['competitor_count'] >= 2 && (int) $r['competitor_count'] <= 5));
        $clean = array_values(array_filter($inRange, fn (array $r) => $r['spam_score'] === null || (int) $r['spam_score'] < 30));

        $ordered = $clean;
        usort($ordered, fn (array $a, array $b) => [(int) $b['competitor_count'], (int) $b['rank']] <=> [(int) $a['competitor_count'], (int) $a['rank']]);
        $top80 = array_slice($ordered, 0, 80);
        $visibleTop80 = array_values(array_filter($top80, fn (array $r) => ! self::isFreeHost((string) $r['domain']) && ! CompetitorMatch::isAggregator((string) $r['domain'], $this->profile)));

        $linkGap = array_map(fn (array $r) => [
            'domain' => $r['domain'],
            'rank' => (int) $r['rank'],
            'competitors' => array_keys((array) json_decode((string) $r['links_to'], true)),
            'platform' => $r['platform_type'],
        ], array_slice($visibleTop80, 0, 20));

        $freeHostExcluded = count(array_filter($clean, fn (array $r) => self::isFreeHost((string) $r['domain'])));
        $notFreeHost = array_filter($clean, fn (array $r) => ! self::isFreeHost((string) $r['domain']));
        $directoryExcluded = count(array_filter($notFreeHost, fn (array $r) => CompetitorMatch::isAggregator((string) $r['domain'], $this->profile)));

        return [
            'link_gap' => $linkGap,
            'link_gap_total' => count($visibleTop80),
            'link_gap_hidden' => [
                'competitor_count_out_of_range' => count($notUs) - count($inRange),
                'spam_score' => count($inRange) - count($clean),
                'free_host' => $freeHostExcluded,
                'directory' => $directoryExcluded,
                'visible' => count($clean) - $freeHostExcluded - $directoryExcluded,
            ],
        ];
    }

    /** @return ?array<string, mixed> */
    private function aiMentionsSnapshot(): ?array
    {
        $latestDay = $this->aiMentions->latestAskedOn();
        if ($latestDay === null) {
            return null;
        }

        $rows = $this->aiMentions->rowsForDay($latestDay);
        $prevDay = $this->aiMentions->priorAskedOnBefore($latestDay);
        $prevRows = $prevDay !== null ? $this->aiMentions->rowsForDay($prevDay) : [];

        $named = [];
        foreach ($rows as $r) {
            foreach ((array) json_decode((string) $r['businesses_named'], true) as $n) {
                $named[$n] = ($named[$n] ?? 0) + 1;
            }
        }
        arsort($named);

        $byPlatform = [];
        $byTown = [];
        $byTownDetail = [];
        foreach ($rows as $r) {
            $mentioned = (bool) $r['mentioned'];

            $platform = (string) $r['platform'];
            $byPlatform[$platform]['asked'] = ($byPlatform[$platform]['asked'] ?? 0) + 1;
            $byPlatform[$platform]['mentioned'] = ($byPlatform[$platform]['mentioned'] ?? 0) + ($mentioned ? 1 : 0);

            $town = (string) $r['town'];
            $byTown[$town]['asked'] = ($byTown[$town]['asked'] ?? 0) + 1;
            $byTown[$town]['mentioned'] = ($byTown[$town]['mentioned'] ?? 0) + ($mentioned ? 1 : 0);
            $byTownDetail[$town][] = [
                'platform' => $r['platform'],
                'prompt' => $r['prompt'],
                'mentioned' => $mentioned,
                'answer_excerpt' => $r['answer_excerpt'] !== null ? mb_substr((string) $r['answer_excerpt'], 0, 300) : null,
                'businesses_named' => (array) json_decode((string) $r['businesses_named'], true),
                'cited_sources' => array_slice(self::citedSources($r), 0, 8),
            ];
        }

        [$citedPages, $citedSites, $citedRecorded] = $this->citations($rows);

        $mentionedCount = count(array_filter($rows, fn (array $r) => (bool) $r['mentioned']));
        $prevMentionedCount = count(array_filter($prevRows, fn (array $r) => (bool) $r['mentioned']));

        return [
            'asked_on' => $latestDay,
            'asked' => count($rows),
            'mentioned' => $mentionedCount,
            'prev_rate' => $prevRows !== [] ? round(100 * $prevMentionedCount / count($prevRows)) : null,
            'by_platform' => $byPlatform,
            'by_town' => $byTown,
            'most_named' => array_slice($named, 0, 8, true),
            'by_town_detail' => $byTownDetail,
            'cited_recorded' => $citedRecorded,
            'cited_pages' => $citedPages,
            'cited_sites' => $citedSites,
        ];
    }

    /**
     * The pages and sites the day's answers cited, each counted once per
     * answer, most cited first; ours marked.
     *
     * @param  list<array<string, mixed>>  $rows
     * @return array{0: list<array{url: string, domain: string, title: ?string, answers: int, platforms: list<string>, is_us: bool}>, 1: list<array{domain: string, answers: int, pages: int, is_us: bool}>, 2: bool}
     */
    private function citations(array $rows): array
    {
        $ourDomain = (string) preg_replace('/^www\./', '', mb_strtolower($this->profile->domain()));
        $pages = [];
        $sites = [];
        $recorded = false;

        foreach ($rows as $r) {
            if (($r['cited_sources'] ?? null) !== null) {
                $recorded = true;
            }
            $seenSites = [];
            foreach (self::citedSources($r) as $source) {
                $url = $source['url'];
                $domain = $source['domain'];
                $pages[$url] ??= ['url' => $url, 'domain' => $domain, 'title' => $source['title'], 'answers' => 0, 'platforms' => [], 'is_us' => self::isOurs($domain, $ourDomain)];
                $pages[$url]['answers']++;
                $pages[$url]['platforms'] = array_values(array_unique([...$pages[$url]['platforms'], (string) $r['platform']]));

                $sites[$domain] ??= ['domain' => $domain, 'answers' => 0, 'pages' => 0, 'is_us' => self::isOurs($domain, $ourDomain), 'urls' => []];
                if (! isset($seenSites[$domain])) {
                    $sites[$domain]['answers']++;
                    $seenSites[$domain] = true;
                }
                $sites[$domain]['urls'][$url] = true;
            }
        }

        $byCount = fn (array $a, array $b): int => [$b['answers'], $a['domain']] <=> [$a['answers'], $b['domain']];
        $pages = array_values($pages);
        usort($pages, $byCount);
        $sites = array_map(function (array $site): array {
            $site['pages'] = count($site['urls']);
            unset($site['urls']);

            return $site;
        }, array_values($sites));
        usort($sites, $byCount);

        return [array_slice($pages, 0, 12), array_slice($sites, 0, 10), $recorded];
    }

    /**
     * @param  array<string, mixed>  $row
     * @return list<array{url: string, domain: string, title: ?string}>
     */
    private static function citedSources(array $row): array
    {
        $decoded = json_decode((string) ($row['cited_sources'] ?? ''), true);

        return array_values(array_filter(
            is_array($decoded) ? $decoded : [],
            fn ($source): bool => is_array($source) && is_string($source['url'] ?? null) && is_string($source['domain'] ?? null) && $source['domain'] !== '',
        ));
    }

    private static function isOurs(string $domain, string $ourDomain): bool
    {
        return $ourDomain !== '' && ($domain === $ourDomain || str_ends_with($domain, '.'.$ourDomain));
    }

    private static function isFreeHost(string $domain): bool
    {
        return preg_match(self::FREE_HOST_PATTERN, $domain) === 1;
    }
}
