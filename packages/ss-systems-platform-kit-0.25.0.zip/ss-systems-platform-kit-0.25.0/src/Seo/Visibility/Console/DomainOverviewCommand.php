<?php

namespace SsSystems\Platform\Seo\Visibility\Console;

use Illuminate\Console\Command;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Carbon;
use SsSystems\Platform\Seo\Contracts\SeoSiteProfile;
use SsSystems\Platform\Seo\DataForSeo\Contracts\DataForSeoApi;
use SsSystems\Platform\Seo\Visibility\CompetitorDomains;
use SsSystems\Platform\Seo\Visibility\DataForSeoBudget;
use SsSystems\Platform\Seo\Visibility\DomainOverviewStore;

/**
 * `seo:domain-overview` — weekly organic share of voice: how many Google
 * keywords we and each tracked competitor rank for, by position band, plus
 * estimated traffic and the backlink profile (domain rank, referring
 * domains). One row per domain per week into seo_domain_overviews — the
 * trend VisibilitySnapshot charts. Ported from gs.construction's
 * App\Console\Commands\SeoDomainOverview; ~$0.036 per domain (overview +
 * backlink summary).
 *
 * The competitor list itself is CompetitorDomains::candidates() — see that
 * class's own docblock for how this generalises gs.construction's
 * three-source (owner-curated /compare list + competitor-discovery.json +
 * map_pack_competitors) sourcing down to two (profile->competitorPatterns()
 * + seo_rank_snapshots), none of which are gs.construction-only
 * infrastructure.
 */
final class DomainOverviewCommand extends Command
{
    protected $signature = 'seo:domain-overview {--competitors=30 : Competitor domains to include} {--budget=2}';

    protected $description = 'Weekly organic footprint + backlink profile for us and the competitors (DataForSEO) into seo_domain_overviews';

    public function __construct(
        private readonly DataForSeoApi $api,
        private readonly SeoSiteProfile $profile,
        private readonly DomainOverviewStore $store,
        private readonly ConnectionInterface $connection,
    ) {
        parent::__construct();
    }

    public function handle(): int
    {
        if (! $this->api->isConfigured() || ! $this->store->exists()) {
            $this->comment('DataForSEO not configured or table missing — skipping.');

            return self::SUCCESS;
        }

        $ours = $this->profile->domain();
        $competitors = CompetitorDomains::candidates($this->connection, $this->profile, (int) $this->option('competitors'));
        $domains = array_values(array_unique(array_merge([$ours], $competitors)));

        $estimate = count($domains) * 0.04;
        $guard = new DataForSeoBudget;
        if ($msg = $guard->precheck($estimate, (float) $this->option('budget'), $this->api->balance(), $this->api->getLastError())) {
            $this->error($msg);

            return self::FAILURE;
        }

        $today = Carbon::now()->toDateString();
        foreach ($domains as $domain) {
            if ($this->api->spent() >= (float) $this->option('budget')) {
                $this->warn('Budget reached.');
                break;
            }
            $overview = $this->api->domainRankOverview($domain);
            $backlink = $this->api->backlinkSummary($domain);
            if ($overview === null && $backlink === null) {
                $this->line("  {$domain}: no data (".($this->api->getLastError() ?? '?').')');
                $guard->record(false);

                continue;
            }
            $guard->record(true);
            $this->store->write($domain, $today, $domain === $ours, $overview ?? [], $backlink ?? []);
            $this->line(sprintf(
                '  %-34s top10=%3d  total=%4d  etv=%6.0f  refdomains=%s',
                $domain,
                ($overview['pos_1'] ?? 0) + ($overview['pos_2_3'] ?? 0) + ($overview['pos_4_10'] ?? 0),
                $overview['count'] ?? 0,
                $overview['etv'] ?? 0,
                $backlink['referring_domains'] ?? '-',
            ));
        }

        if ($guard->allFailed()) {
            $this->error('Every domain failed — DataForSEO may be down or misconfigured.');

            return self::FAILURE;
        }
        $this->info(sprintf('Done. Spent $%.3f.', $this->api->spent()));

        return self::SUCCESS;
    }
}
