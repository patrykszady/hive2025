<?php

namespace SsSystems\Platform\Seo\Visibility\Console;

use Illuminate\Console\Command;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Str;
use SsSystems\Platform\Seo\Contracts\SeoSiteProfile;
use SsSystems\Platform\Seo\Visibility\Contracts\ReportSink;

/**
 * `seo:competitor-brand-track` — surfaces Search Console queries that
 * signal competitor/comparison intent: competitor brand names
 * (profile->competitorPatterns(), matched as a case-insensitive regex
 * fragment against the query text — consistent with how this module
 * treats competitorPatterns() everywhere else, see CompetitorMatch's own
 * docblock) and generic comparison modifiers ("alternative", "vs", "best",
 * "near me", "reviews"). Ported from gs.construction's
 * App\Console\Commands\SeoCompetitorBrandTrack, grouped by GSC query
 * metrics (gsc_query_metrics — the same table
 * SsSystems\Platform\Seo\SearchConsoleSync fills) rather than its own
 * App\Models\GscQueryMetric Eloquent model, per the kit's
 * ConnectionInterface convention.
 *
 * gs.construction wrote its optional markdown report straight to
 * `Storage::disk('local')->put('reports/competitor-brand.md', ...)`; the
 * kit never touches a filesystem disk itself, so --markdown instead writes
 * through an injected Contracts\ReportSink (null when the site hasn't
 * bound one, in which case --markdown is a no-op with a warning rather
 * than a crash).
 */
final class CompetitorBrandTrackCommand extends Command
{
    protected $signature = 'seo:competitor-brand-track
        {--days=28 : Look-back window in days}
        {--country=usa : Country filter (blank = all)}
        {--min-impressions=1 : Minimum impressions threshold}
        {--limit=50 : Max rows per bucket}
        {--markdown : Save a markdown report through the bound ReportSink}';

    protected $description = 'Track GSC queries with competitor-brand or comparison intent (alternative/vs/best/reviews).';

    public function __construct(
        private readonly ConnectionInterface $connection,
        private readonly SeoSiteProfile $profile,
        private readonly string $table = 'gsc_query_metrics',
        private readonly ?ReportSink $reportSink = null,
        private readonly ?string $tenantColumn = null,
        private readonly ?\Closure $tenantId = null,
    ) {
        parent::__construct();
    }

    public function handle(): int
    {
        $days = max(1, (int) $this->option('days'));
        $country = trim((string) $this->option('country'));
        $minImpressions = max(1, (int) $this->option('min-impressions'));
        $limit = max(1, (int) $this->option('limit'));

        if (! $this->connection->getSchemaBuilder()->hasTable($this->table)) {
            $this->warn("No {$this->table} table — run the Search Console sync first.");

            return self::SUCCESS;
        }

        $from = Carbon::now()->subDays($days)->toDateString();

        $rows = $this->connection->table($this->table)
            ->where('date', '>=', $from)
            ->when($country !== '', fn ($q) => $q->where('country', $country))
            ->when($this->tenantColumn !== null, fn ($q) => $q->where($this->tenantColumn, ($this->tenantId)()))
            ->selectRaw('query, SUM(impressions) as imp, SUM(clicks) as clk, AVG(position) as pos, MAX(page) as sample_page')
            ->groupBy('query')
            ->having('imp', '>=', $minImpressions)
            ->orderByDesc('imp')
            ->get();

        if ($rows->isEmpty()) {
            $this->warn('No GSC data in window. Run the Search Console sync first.');

            return self::SUCCESS;
        }

        $buckets = $this->bucketize($rows, $limit);

        $totalMatched = array_sum(array_map('count', $buckets));
        $this->info("Scanned {$rows->count()} queries — {$totalMatched} matched competitor/comparison intent in last {$days} days.");

        foreach ($buckets as $name => $bucketRows) {
            if ($bucketRows === []) {
                continue;
            }

            $this->newLine();
            $this->line("<fg=cyan>--- {$name} (".count($bucketRows).') ---</>');
            $this->table(
                ['Query', 'Imp', 'Clk', 'Pos', 'Sample page'],
                array_map(fn ($r) => [
                    $r['query'],
                    $r['imp'],
                    $r['clk'],
                    number_format($r['pos'], 1),
                    $this->shortPath((string) $r['sample_page']),
                ], $bucketRows),
            );
        }

        if ($this->option('markdown')) {
            $this->saveMarkdown($buckets, $days);
        }

        return self::SUCCESS;
    }

    /**
     * @param  Collection<int, object>  $rows
     * @return array<string, array<int, array<string, mixed>>>
     */
    protected function bucketize(Collection $rows, int $limit): array
    {
        $brandTerms = $this->brandTerms();
        $vsPattern = '/\b(vs\.?|versus)\b/i';
        $altPattern = '/\b(alternative|alternatives|other than|better than|instead of)\b/i';
        $reviewPattern = '/\b(reviews?|complaints?|rating|ratings)\b/i';
        $bestPattern = '/\b(best|top|top[- ]rated|highest[- ]rated)\b.*\b(remodel|renovat|contractor|kitchen|bath)/i';
        $nearMePattern = '/\bnear me\b/i';

        $buckets = [
            'Competitor brand mentions' => [],
            '"vs" / versus queries' => [],
            '"alternative" queries' => [],
            '"best / top" queries' => [],
            'Review-intent queries' => [],
            'Near-me queries' => [],
        ];

        foreach ($rows as $r) {
            $q = mb_strtolower((string) $r->query);
            $entry = [
                'query' => (string) $r->query,
                'imp' => (int) $r->imp,
                'clk' => (int) $r->clk,
                'pos' => (float) $r->pos,
                'sample_page' => (string) $r->sample_page,
            ];

            foreach ($brandTerms as $term) {
                if ($term !== '' && @preg_match('/'.$term.'/i', $q) === 1) {
                    $buckets['Competitor brand mentions'][] = $entry + ['matched' => $term];
                    break;
                }
            }

            if (preg_match($vsPattern, $q)) {
                $buckets['"vs" / versus queries'][] = $entry;
            }
            if (preg_match($altPattern, $q)) {
                $buckets['"alternative" queries'][] = $entry;
            }
            if (preg_match($bestPattern, $q)) {
                $buckets['"best / top" queries'][] = $entry;
            }
            if (preg_match($reviewPattern, $q)) {
                $buckets['Review-intent queries'][] = $entry;
            }
            if (preg_match($nearMePattern, $q)) {
                $buckets['Near-me queries'][] = $entry;
            }
        }

        foreach ($buckets as $name => $list) {
            usort($list, fn ($a, $b) => $b['imp'] <=> $a['imp']);
            $buckets[$name] = array_slice($list, 0, $limit);
        }

        return $buckets;
    }

    /** @return list<string> */
    protected function brandTerms(): array
    {
        return array_values(array_unique(array_filter($this->profile->competitorPatterns())));
    }

    protected function shortPath(string $page): string
    {
        $path = parse_url($page, PHP_URL_PATH) ?: $page;

        return Str::limit($path, 60);
    }

    /** @param  array<string, array<int, array<string, mixed>>>  $buckets */
    protected function saveMarkdown(array $buckets, int $days): void
    {
        if ($this->reportSink === null) {
            $this->warn('No ReportSink bound — markdown not saved.');

            return;
        }

        $md = "# Competitor & comparison query tracker\n\n";
        $md .= '_Window: last '.$days." days_\n\n";

        foreach ($buckets as $name => $rows) {
            if ($rows === []) {
                continue;
            }
            $md .= "## {$name}\n\n";
            $md .= "| Query | Imp | Clk | Pos | Sample page |\n";
            $md .= "|---|---:|---:|---:|---|\n";
            foreach ($rows as $r) {
                $md .= sprintf(
                    "| %s | %d | %d | %.1f | %s |\n",
                    str_replace('|', '\\|', (string) $r['query']),
                    (int) $r['imp'],
                    (int) $r['clk'],
                    (float) $r['pos'],
                    $this->shortPath((string) $r['sample_page']),
                );
            }
            $md .= "\n";
        }

        $this->reportSink->write('reports/competitor-brand.md', $md);
        $this->info('Saved: reports/competitor-brand.md');
    }
}
