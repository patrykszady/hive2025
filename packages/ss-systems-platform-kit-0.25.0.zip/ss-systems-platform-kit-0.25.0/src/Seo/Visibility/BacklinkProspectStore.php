<?php

namespace SsSystems\Platform\Seo\Visibility;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Carbon;

/**
 * seo_backlink_prospects — one row per domain seen linking to a tracked
 * competitor, written by BacklinkGapCommand and read back by
 * VisibilitySnapshot. Tenant-scoped the same way
 * SsSystems\Platform\Traffic\Collectors\TrackedEventsCollector is.
 */
final class BacklinkProspectStore
{
    public function __construct(
        private readonly ConnectionInterface $connection,
        private readonly string $table = 'seo_backlink_prospects',
        private readonly ?string $tenantColumn = null,
        private readonly ?\Closure $tenantId = null,
    ) {}

    public function exists(): bool
    {
        return $this->connection->getSchemaBuilder()->hasTable($this->table);
    }

    /**
     * @param  array{rank?: ?int, links_to: array<string, int>, links_to_us: bool, platform_type?: ?string, spam_score?: ?int}  $row
     */
    public function write(string $domain, array $row): void
    {
        $keys = ['domain' => mb_substr($domain, 0, 191)];
        if ($this->tenantColumn !== null) {
            $keys[$this->tenantColumn] = ($this->tenantId)();
        }

        $this->connection->table($this->table)->updateOrInsert($keys, [
            'rank' => $row['rank'] ?? null,
            'links_to' => json_encode($row['links_to']),
            'competitor_count' => count($row['links_to']),
            'links_to_us' => $row['links_to_us'],
            'platform_type' => isset($row['platform_type']) ? mb_substr((string) $row['platform_type'], 0, 60) : null,
            'spam_score' => $row['spam_score'] ?? null,
            'seen_at' => Carbon::now(),
            'updated_at' => Carbon::now(),
            'created_at' => Carbon::now(),
        ]);
    }

    /** @return list<array<string, mixed>> */
    public function rows(): array
    {
        if (! $this->exists()) {
            return [];
        }

        return $this->connection->table($this->table)
            ->when($this->tenantColumn !== null, fn ($q) => $q->where($this->tenantColumn, ($this->tenantId)()))
            ->get()
            ->map(fn ($row) => (array) $row)
            ->all();
    }
}
