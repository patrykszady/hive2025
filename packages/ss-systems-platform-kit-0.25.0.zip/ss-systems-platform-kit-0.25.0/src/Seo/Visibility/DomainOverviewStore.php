<?php

namespace SsSystems\Platform\Seo\Visibility;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Carbon;

/**
 * seo_domain_overviews — one row per domain per week, written by
 * DomainOverviewCommand and read back by VisibilitySnapshot. Tenant-scoped
 * the same way SsSystems\Platform\Traffic\Collectors\TrackedEventsCollector
 * is: an injected ConnectionInterface plus an optional tenant column/id
 * pair, never a hardcoded App\Models\* reference.
 *
 * write() replaces created_at on every call, not only on first insert —
 * ported as-is from gs.construction's own updateOrInsert() call (its
 * $guard->record()/Cache::forget() bookkeeping happens in the command, not
 * here).
 */
final class DomainOverviewStore
{
    public function __construct(
        private readonly ConnectionInterface $connection,
        private readonly string $table = 'seo_domain_overviews',
        private readonly ?string $tenantColumn = null,
        private readonly ?\Closure $tenantId = null,
    ) {}

    public function exists(): bool
    {
        return $this->connection->getSchemaBuilder()->hasTable($this->table);
    }

    /**
     * @param  array{pos_1?: int, pos_2_3?: int, pos_4_10?: int, pos_11_20?: int, count?: int, etv?: float, is_new?: int, is_lost?: int}  $overview
     * @param  array{backlinks?: int, referring_domains?: int, rank?: int}  $backlink
     */
    public function write(string $domain, string $date, bool $isUs, array $overview, array $backlink): void
    {
        $keys = ['domain' => mb_substr($domain, 0, 191), 'date' => $date];
        if ($this->tenantColumn !== null) {
            $keys[$this->tenantColumn] = ($this->tenantId)();
        }

        $this->connection->table($this->table)->updateOrInsert($keys, [
            'is_us' => $isUs,
            'pos_1' => $overview['pos_1'] ?? 0,
            'pos_2_3' => $overview['pos_2_3'] ?? 0,
            'pos_4_10' => $overview['pos_4_10'] ?? 0,
            'pos_11_20' => $overview['pos_11_20'] ?? 0,
            'keywords_total' => $overview['count'] ?? 0,
            'etv' => $overview['etv'] ?? 0,
            'is_new' => $overview['is_new'] ?? 0,
            'is_lost' => $overview['is_lost'] ?? 0,
            'backlinks' => $backlink['backlinks'] ?? null,
            'referring_domains' => $backlink['referring_domains'] ?? null,
            'domain_rank' => $backlink['rank'] ?? null,
            'updated_at' => Carbon::now(),
            'created_at' => Carbon::now(),
        ]);
    }

    /**
     * Every row, newest date first — VisibilitySnapshot groups these by
     * domain itself (latest + previous run per domain).
     *
     * @return list<array<string, mixed>>
     */
    public function rows(): array
    {
        if (! $this->exists()) {
            return [];
        }

        return $this->connection->table($this->table)
            ->when($this->tenantColumn !== null, fn ($q) => $q->where($this->tenantColumn, ($this->tenantId)()))
            ->orderByDesc('date')
            ->orderByDesc('id')
            ->get()
            ->map(fn ($row) => (array) $row)
            ->all();
    }
}
