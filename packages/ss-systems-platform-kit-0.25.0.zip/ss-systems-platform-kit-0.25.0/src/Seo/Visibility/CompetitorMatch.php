<?php

namespace SsSystems\Platform\Seo\Visibility;

use SsSystems\Platform\Seo\Contracts\SeoSiteProfile;

/**
 * "Is this a real local competitor" — ported from gs.construction's
 * App\Support\Seo\CompetitorFilter, with its three config()-backed lists
 * replaced by the site's own SeoSiteProfile (the kit never reads config()
 * for site facts): isKnownLocal() reads profile->competitorPatterns()
 * instead of config('competitors.competitors'), isAggregator() reads
 * profile->competitorExclusions() instead of config('seo.competitor_exclusions'),
 * and the giant thresholds (organic footprint so large it cannot be a local
 * business) are class constants instead of config('seo.competitor_giant_thresholds')
 * — gs.construction's own values, read from live prod data on 2026-09-16:
 * the largest real local competitor it observed sits at organic_count=1,537
 * / etv=$7,896; the smallest observed non-local subject sits at
 * organic_count=173,349 / etv=$225,996 — >13x headroom above every real
 * local company, >3.5x below every observed aggregator.
 *
 * Unlike competitorExclusions() (an exact-host-or-subdomain suffix match,
 * same as gs.construction's own), competitorPatterns() is matched as a
 * case-insensitive regex fragment against the host — consistent with how
 * the sibling brandPatterns() is documented and used, and because
 * SeoSiteProfile documents competitorPatterns() as "host or name
 * fragments": a bare name fragment ('airoom') is a valid regex but never a
 * valid suffix match against a host ('airoom.com').
 *
 * Three checks, in order:
 *  1. isKnownLocal() — the owner-curated competitors (profile->competitorPatterns()).
 *     Human-verified ground truth; nothing below ever overrides it.
 *  2. isAggregator() — a suffix match against profile->competitorExclusions().
 *  3. isGiant() — an organic footprint so large it cannot be a local
 *     competitor. Only applied when metrics are actually available.
 */
final class CompetitorMatch
{
    public const GIANT_ORGANIC_COUNT = 20000;

    public const GIANT_ORGANIC_ETV = 50000.0;

    /** Lowercase, strip a leading 'www.' — the shared normal form every check compares against. */
    public static function normalize(string $host): string
    {
        $host = mb_strtolower(trim($host));

        return preg_replace('/^www\./', '', $host) ?? $host;
    }

    public static function isKnownLocal(string $host, SeoSiteProfile $profile): bool
    {
        $host = self::normalize($host);
        if ($host === '') {
            return false;
        }
        foreach ($profile->competitorPatterns() as $pattern) {
            if ($pattern !== '' && @preg_match('/'.$pattern.'/i', $host) === 1) {
                return true;
            }
        }

        return false;
    }

    /**
     * Exact-host-or-subdomain suffix match against
     * profile->competitorExclusions() — directories, marketplaces, review
     * sites, social platforms, big-box retailers, media and B2B SaaS: never
     * a competing business, however it shows up in a SERP or a domain list.
     * Suffix-safe, not a naive substring match.
     */
    public static function isAggregator(string $host, SeoSiteProfile $profile): bool
    {
        $host = self::normalize($host);
        if ($host === '') {
            return false;
        }
        foreach ($profile->competitorExclusions() as $exclusion) {
            $exclusion = self::normalize($exclusion);
            if ($exclusion !== '' && ($host === $exclusion || str_ends_with($host, '.'.$exclusion))) {
                return true;
            }
        }

        return false;
    }

    /**
     * TRUE when the organic footprint is so large it cannot be a local
     * competitor. Null metrics (not available at this call site) never
     * count toward "giant": we can't judge what we don't have.
     */
    public static function isGiant(?float $organicCount, ?float $organicEtv): bool
    {
        return ($organicCount !== null && $organicCount > self::GIANT_ORGANIC_COUNT)
            || ($organicEtv !== null && $organicEtv > self::GIANT_ORGANIC_ETV);
    }

    /**
     * The one method call sites use: known-local always wins; otherwise an
     * aggregator is never a competitor, and — when metrics are available —
     * neither is a giant.
     */
    public static function isCompetitor(string $host, SeoSiteProfile $profile, ?float $organicCount = null, ?float $organicEtv = null): bool
    {
        $host = self::normalize($host);

        return self::isKnownLocal($host, $profile) || (! self::isAggregator($host, $profile) && ! self::isGiant($organicCount, $organicEtv));
    }

    /**
     * Normalize + dedupe + filter a plain host list (no metrics) through
     * isCompetitor() — for sourcing sites that only ever have bare
     * hostnames (see CompetitorDomains).
     *
     * @param  iterable<string>  $hosts
     * @return list<string>
     */
    public static function keep(iterable $hosts, SeoSiteProfile $profile): array
    {
        $out = [];
        foreach ($hosts as $host) {
            $host = self::normalize((string) $host);
            if ($host === '' || isset($out[$host])) {
                continue;
            }
            if (self::isCompetitor($host, $profile)) {
                $out[$host] = true;
            }
        }

        return array_keys($out);
    }
}
