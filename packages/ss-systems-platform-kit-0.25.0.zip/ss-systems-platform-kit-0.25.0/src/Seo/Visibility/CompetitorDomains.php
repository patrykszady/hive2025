<?php

namespace SsSystems\Platform\Seo\Visibility;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Collection;
use SsSystems\Platform\Seo\Contracts\SeoSiteProfile;

/**
 * The "vs. competitors" domain list for DomainOverviewCommand and
 * BacklinkGapCommand — generalised from gs.construction's
 * SeoDomainOverview::shareOfVoiceDomains()/competitorDomains(), which built
 * this list from three gs.construction-only sources: the owner-curated
 * /compare companies (config/competitors.php), a competitor-discovery JSON
 * file on the local disk, and a `map_pack_competitors` table from its
 * separate map-pack-grid feature. None of those three exist generically in
 * the kit, so this reads two sources instead:
 *
 *  1. profile->competitorPatterns() entries that are themselves a literal
 *     domain (no regex metacharacters, shaped like "airoom.com") — the
 *     site's own curated competitor list, the same role gs.construction's
 *     config/competitors.php[*]['website'] played. A bare name fragment
 *     ('airoom', 'j\.?\s*peterson') is a CompetitorMatch::isKnownLocal()
 *     filter, not a dialable domain, and is skipped here.
 *  2. the site's own `seo_rank_snapshots` table (SeoSiteProfile-agnostic,
 *     shared with SsSystems\Platform\Seo\Http\Concerns\BuildsSeoSnapshot's
 *     rankingSnapshot()), read through the injected connection with a
 *     graceful empty result when the table is missing — each row's
 *     `top_results` JSON column holds the live SERP's {position, url,
 *     domain, title} entries (DataForSeoApi::googleOrganicPosition()'s
 *     SerpResult shape); the domains seen there most often across the
 *     site's tracked queries are gs.construction's "organic page-one
 *     domains" discovery feed, generalised.
 *
 * Both lists are deduped and filtered through CompetitorMatch::keep()
 * (known-local always kept, aggregators and giants dropped) and capped at
 * $limit. gs.construction gave the two call sites a different source order
 * (share-of-voice put the curated list first so the card showed named
 * competitors; link-gap put map-pack/discovery first) — this port uses one
 * order for both (curated patterns first, then discovered), a deliberate
 * simplification now that the three-source gs.construction split collapses
 * to two.
 */
final class CompetitorDomains
{
    /** @return list<string> */
    public static function candidates(
        ConnectionInterface $connection,
        SeoSiteProfile $profile,
        int $limit = 30,
        string $rankSnapshotsTable = 'seo_rank_snapshots',
    ): array {
        $curated = collect($profile->competitorPatterns())
            ->filter(fn (string $pattern) => self::looksLikeDomain($pattern))
            ->map(fn (string $pattern) => CompetitorMatch::normalize($pattern));

        $discovered = self::discoveredHosts($connection, $rankSnapshotsTable);

        return collect(CompetitorMatch::keep($curated->concat($discovered), $profile))
            ->take($limit)
            ->values()
            ->all();
    }

    private static function looksLikeDomain(string $value): bool
    {
        return preg_match('/^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$/i', $value) === 1;
    }

    /**
     * Domains seen in `seo_rank_snapshots.top_results`, most-seen first —
     * the live organic SERP's own page-one domains, across every tracked
     * query, standing in for gs.construction's discovery feed.
     *
     * @return Collection<int, string>
     */
    private static function discoveredHosts(ConnectionInterface $connection, string $table): Collection
    {
        if (! $connection->getSchemaBuilder()->hasTable($table)) {
            return collect();
        }

        $counts = [];
        $rows = $connection->table($table)->whereNotNull('top_results')->orderByDesc('id')->limit(500)->pluck('top_results');
        foreach ($rows as $raw) {
            $results = json_decode((string) $raw, true) ?: [];
            foreach ((array) $results as $result) {
                $domain = (string) ($result['domain'] ?? parse_url((string) ($result['url'] ?? ''), PHP_URL_HOST) ?? '');
                if ($domain === '') {
                    continue;
                }
                $domain = CompetitorMatch::normalize($domain);
                $counts[$domain] = ($counts[$domain] ?? 0) + 1;
            }
        }
        arsort($counts);

        return collect(array_keys($counts));
    }
}
