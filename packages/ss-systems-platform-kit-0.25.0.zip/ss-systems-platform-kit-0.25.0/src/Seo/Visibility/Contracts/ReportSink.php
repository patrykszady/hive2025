<?php

namespace SsSystems\Platform\Seo\Visibility\Contracts;

/**
 * Where CompetitorBrandTrackCommand's optional markdown report lands.
 * gs.construction's own SeoCompetitorBrandTrack wrote straight to
 * `Storage::disk('local')->put('reports/competitor-brand.md', $md)`; the
 * kit never touches a filesystem disk directly (no two sites necessarily
 * share a disk name or a reports path), so the site binds this instead —
 * trivially, `fn (string $path, string $md) => Storage::disk('local')->put($path, $md)`,
 * or through the site's own `Reports\Contracts\ReportStorage::path()` when
 * it wants the same tenant-prefixing every other generated report gets.
 *
 * $relativePath is handed exactly what gs.construction hardcoded
 * ('reports/competitor-brand.md') — the implementation decides what that
 * is relative to.
 */
interface ReportSink
{
    public function write(string $relativePath, string $markdown): void;
}
