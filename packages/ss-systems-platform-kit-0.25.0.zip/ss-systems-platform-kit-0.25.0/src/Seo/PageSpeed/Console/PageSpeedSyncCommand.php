<?php

namespace SsSystems\Platform\Seo\PageSpeed\Console;

use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use SsSystems\Platform\Seo\PageSpeed\Contracts\PageSpeedCredentials;
use SsSystems\Platform\Seo\PageSpeed\Contracts\PageSpeedUrlSource;
use SsSystems\Platform\Seo\PageSpeed\PageSpeedClient;
use SsSystems\Platform\Seo\PageSpeed\PsiSnapshotStore;

/**
 * `seo:psi-sync` — ported from gs.construction's own
 * App\Console\Commands\SyncPageSpeedInsights, kept to the same per-row
 * semantics so gsc's 16,985 existing psi_snapshots rows stay comparable to
 * whatever this command writes from here on: one row per (date, url,
 * strategy), overwritten in place on a same-day rerun
 * (PsiSnapshotStore::record()), both strategies measured per URL unless
 * --strategy narrows it, and a PSI failure for one url×strategy writes
 * nothing for that pair rather than a row full of nulls.
 *
 * Three deliberate differences from gsc's original command, all scoped to
 * this port rather than something gsc itself needs to change (2026-11-01):
 *
 *   - gates on PageSpeedCredentials::isConfigured() and stops cleanly with
 *     no key at all, instead of running keyless — see
 *     Contracts\PageSpeedCredentials's own docblock for why.
 *   - --only filters PageSpeedUrlSource::urls() by the `template` label
 *     each entry already carries (see SitemapUrlSource), rather than gsc's
 *     --urls=* (an explicit override list) or its top-Search-Console-pages
 *     expansion — neither of those has a capability contract here.
 *   - no dead-URL probe, circuit breaker, or failed-url retry cache: those
 *     lean on gsc's own Cache facade and an HTTP probe of its own live
 *     site, neither of which this module takes a contract for. A site
 *     that wants them keeps them in its own thin wrapper around this
 *     command.
 */
final class PageSpeedSyncCommand extends Command
{
    private const DEFAULT_MAX_URLS = 60;

    /** @var string */
    protected $signature = 'seo:psi-sync
        {--max= : Cap URL count (default 60)}
        {--strategy=both : mobile, desktop, or both}
        {--only= : Only measure URLs whose template label matches this value}
        {--dry-run : Compute but do not persist}';

    /** @var string */
    protected $description = "Snapshot PageSpeed Insights (Lighthouse + CrUX) for this site's key pages.";

    public function handle(): int
    {
        /** @var PageSpeedCredentials $credentials */
        $credentials = $this->laravel->make(PageSpeedCredentials::class);

        if (! $credentials->isConfigured()) {
            $this->comment('PageSpeed Insights has no API key configured — seo:psi-sync skipped.');

            return self::SUCCESS;
        }

        /** @var PageSpeedUrlSource $urlSource */
        $urlSource = $this->laravel->make(PageSpeedUrlSource::class);
        /** @var PageSpeedClient $client */
        $client = $this->laravel->make(PageSpeedClient::class);
        /** @var PsiSnapshotStore $store */
        $store = $this->laravel->make(PsiSnapshotStore::class);

        $strategies = match ($this->option('strategy')) {
            'mobile' => ['mobile'],
            'desktop' => ['desktop'],
            default => ['mobile', 'desktop'],
        };

        $urls = $urlSource->urls();

        $only = trim((string) ($this->option('only') ?? ''));
        if ($only !== '') {
            $urls = array_values(array_filter(
                $urls,
                static fn (array $row): bool => strcasecmp((string) $row['template'], $only) === 0,
            ));
        }

        $max = max(1, (int) ($this->option('max') ?: self::DEFAULT_MAX_URLS));
        if (count($urls) > $max) {
            $urls = array_slice($urls, 0, $max);
        }

        $dryRun = (bool) $this->option('dry-run');
        $this->info('PSI URL pool: '.count($urls).' URL(s)');

        $today = Carbon::today()->toDateString();
        $ok = 0;
        $fail = 0;

        foreach ($urls as $row) {
            $url = (string) $row['url'];

            foreach ($strategies as $strategy) {
                $this->line("PSI: {$strategy} {$url}");
                $result = $client->run($url, $strategy);

                if ($result === null) {
                    $fail++;
                    $error = $client->getLastError();
                    $this->warn(' ↳ failed'.($error ? ": {$error}" : ''));

                    continue;
                }

                $this->line(sprintf(
                    ' ↳ perf=%s lab_lcp=%sms cls=%s field=%s',
                    $result['performance'] ?? '?',
                    $result['lab_lcp_ms'] ?? '?',
                    $result['lab_cls'] ?? '?',
                    $result['field_overall'] ?? 'n/a',
                ));

                if ($dryRun) {
                    continue;
                }

                $store->record([
                    'date' => $today,
                    'url' => $url,
                    'strategy' => $strategy,
                    ...$result,
                ]);
                $ok++;
            }
        }

        $this->info("Done. ok={$ok} failed={$fail}".($dryRun ? ' (dry-run)' : ''));

        return self::SUCCESS;
    }
}
