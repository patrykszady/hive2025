<?php

namespace SsSystems\Platform\Seo\PageSpeed;

use Illuminate\Http\Client\ConnectionException;
use Illuminate\Http\Client\Factory;
use Illuminate\Http\Client\RequestException;
use SsSystems\Platform\Seo\PageSpeed\Contracts\PageSpeedCredentials;

/**
 * PageSpeed Insights API v5 client — ported from gs.construction's
 * App\Services\PageSpeedInsightsService, kept byte-identical on the one
 * thing that matters for comparing rows across sites: the exact fields
 * extracted from the Lighthouse/CrUX payload (performance/accessibility/
 * best-practices/seo scores, LCP/FCP/TBT/CLS/speed-index lab metrics, and
 * field (CrUX) LCP/INP (falling back to the older FID metric when a
 * low-traffic page's CrUX record still only has that)/CLS/overall-category
 * when Google has enough real-user traffic on the URL to report them).
 *
 * The query string is built by hand — never Http's `query` option with an
 * array value, which Guzzle encodes as `category[0]=x&category[1]=y` — the
 * PSI API only accepts its own repeated `category=x&category=y` form.
 *
 * Unlike gsc's service, this never reads the Log facade: a failure comes
 * back as null with getLastError() set, the same contract as
 * SsSystems\Platform\Seo\Bing\BingWebmasterApi and
 * SsSystems\Platform\Seo\DataForSeo\DataForSeoClient.
 */
final class PageSpeedClient
{
    public const API = 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed';

    private const CONNECT_TIMEOUT_SECONDS = 15;

    private const TIMEOUT_SECONDS = 75;

    private ?string $lastError = null;

    public function __construct(
        private readonly PageSpeedCredentials $credentials,
        private readonly Factory $http,
    ) {
    }

    public function getLastError(): ?string
    {
        return $this->lastError;
    }

    /**
     * Run PSI for one URL/strategy. Returns null on failure (getLastError()
     * says what); with no key configured this still runs keyless, on
     * Google's shared, lower-quota limit — PageSpeedSyncCommand is what
     * gates on isConfigured(), not this client.
     *
     * @return array{
     *     performance: ?int, accessibility: ?int, best_practices: ?int, seo: ?int,
     *     lab_lcp_ms: ?int, lab_fcp_ms: ?int, lab_tbt_ms: ?int, lab_cls: ?float, lab_si_ms: ?int,
     *     field_lcp_ms: ?int, field_inp_ms: ?int, field_cls: ?float, field_overall: ?string,
     * }|null
     */
    public function run(string $url, string $strategy = 'mobile'): ?array
    {
        $this->lastError = null;
        $key = $this->credentials->apiKey();

        $query = 'url='.urlencode($url)
            .'&strategy='.urlencode($strategy)
            .'&category=performance&category=accessibility&category=best-practices&category=seo'
            .($key !== null && $key !== '' ? '&key='.urlencode($key) : '');

        try {
            $response = $this->http
                ->connectTimeout(self::CONNECT_TIMEOUT_SECONDS)
                ->timeout(self::TIMEOUT_SECONDS)
                ->retry(3, 2500, function (\Exception $exception) {
                    if ($exception instanceof ConnectionException) {
                        return true;
                    }

                    return $exception instanceof RequestException && $exception->response->serverError();
                })
                ->get(self::API.'?'.$query);
        } catch (RequestException $e) {
            // retry()'s own $throw defaults to true regardless of whether the
            // $when predicate above allowed a retry, so a non-5xx failure
            // (e.g. 400/403) also arrives here, not through the generic
            // catch below — report the real status/body rather than
            // Guzzle's own generic "HTTP request returned status code …"
            // exception text.
            $this->lastError = 'HTTP '.$e->response->status().': '.mb_substr($e->response->body(), 0, 300);

            return null;
        } catch (\Throwable $e) {
            $this->lastError = mb_substr($e->getMessage(), 0, 300);

            return null;
        }

        if (! $response->successful()) {
            $this->lastError = 'HTTP '.$response->status().': '.mb_substr($response->body(), 0, 300);

            return null;
        }

        $body = (array) $response->json();
        $cats = (array) data_get($body, 'lighthouseResult.categories', []);
        $audits = (array) data_get($body, 'lighthouseResult.audits', []);
        $field = (array) data_get($body, 'loadingExperience.metrics', []);

        return [
            'performance' => $this->pct($cats, 'performance'),
            'accessibility' => $this->pct($cats, 'accessibility'),
            'best_practices' => $this->pct($cats, 'best-practices'),
            'seo' => $this->pct($cats, 'seo'),
            'lab_lcp_ms' => $this->ms($audits, 'largest-contentful-paint'),
            'lab_fcp_ms' => $this->ms($audits, 'first-contentful-paint'),
            'lab_tbt_ms' => $this->ms($audits, 'total-blocking-time'),
            'lab_cls' => $this->num($audits, 'cumulative-layout-shift'),
            'lab_si_ms' => $this->ms($audits, 'speed-index'),
            'field_lcp_ms' => $this->fieldInt($field, 'LARGEST_CONTENTFUL_PAINT_MS'),
            'field_inp_ms' => $this->fieldInt($field, 'INTERACTION_TO_NEXT_PAINT') ?? $this->fieldInt($field, 'FIRST_INPUT_DELAY_MS'),
            'field_cls' => $this->fieldCls($field),
            'field_overall' => data_get($body, 'loadingExperience.overall_category'),
        ];
    }

    /** @param  array<string, mixed>  $cats */
    private function pct(array $cats, string $key): ?int
    {
        $score = data_get($cats, "{$key}.score");

        return $score === null ? null : (int) round(((float) $score) * 100);
    }

    /** @param  array<string, mixed>  $audits */
    private function ms(array $audits, string $key): ?int
    {
        $v = data_get($audits, "{$key}.numericValue");

        return $v === null ? null : (int) round((float) $v);
    }

    /** @param  array<string, mixed>  $audits */
    private function num(array $audits, string $key): ?float
    {
        $v = data_get($audits, "{$key}.numericValue");

        return $v === null ? null : round((float) $v, 3);
    }

    /** @param  array<string, mixed>  $field */
    private function fieldInt(array $field, string $key): ?int
    {
        $v = data_get($field, "{$key}.percentile");

        return $v === null ? null : (int) $v;
    }

    /** @param  array<string, mixed>  $field */
    private function fieldCls(array $field): ?float
    {
        $v = data_get($field, 'CUMULATIVE_LAYOUT_SHIFT_SCORE.percentile');

        return $v === null ? null : round(((float) $v) / 100, 3);
    }
}
