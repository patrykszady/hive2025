<?php

namespace SsSystems\Platform\Seo\PageSpeed\Contracts;

/**
 * Where a site keeps its PageSpeed Insights API key — on every tenant that
 * is the platform-setting `seo.pagespeed.api_key` (see each site's own
 * App\Support\Seo\PsiSettings), with a services/env value as the fallback.
 * The kit never reads config() for this itself; the site binds this
 * contract.
 *
 * Unlike gs.construction's own PsiSettings (which deliberately never
 * hard-gates PageSpeedInsightsService — PSI runs keyless on Google's
 * shared, lower-quota limit, fine for one site), PageSpeedSyncCommand DOES
 * gate on isConfigured() and stops cleanly with no key at all: a kit
 * command rolled out to every tenant at once is exactly the crowd that
 * shared keyless quota isn't sized for, so every adopter needs its own key
 * before a scheduled run starts spending it. (2026-11-01)
 */
interface PageSpeedCredentials
{
    public function apiKey(): ?string;

    public function isConfigured(): bool;
}
