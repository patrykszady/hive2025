<?php

namespace SsSystems\Platform\Seo\PageSpeed\Contracts;

/**
 * The pages `seo:psi-sync` measures, each labelled with a template the
 * command's own `--only` filter (and, loosely, the CWV report) groups by.
 * A site binds this to its own pinned list (gs.construction's
 * config('seo.psi_urls'), ported as a site's own small adapter — no kit
 * class is needed for a short fixed list) or to SitemapUrlSource, the
 * kit's crawl-your-own-sitemap default, when it has no pinned list at all.
 */
interface PageSpeedUrlSource
{
    /** @return list<array{url: string, template: string}> */
    public function urls(): array;
}
