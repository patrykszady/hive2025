<?php

namespace SsSystems\Platform\Seo\PageSpeed;

use Illuminate\Http\Client\Factory;
use SsSystems\Platform\Seo\PageSpeed\Contracts\PageSpeedUrlSource;

/**
 * The kit's one ready-made PageSpeedUrlSource: fetches a sitemap.xml and
 * returns every <loc> it contains, labelled by a template classifier — the
 * default for a site that has no pinned URL list at all. Mirrors
 * App\Support\Seo\Reports\HttpSiteCatalog::sitemapUrls()'s own
 * fetch-and-regex approach: an unfiltered, trimmed, deduplicated <loc>
 * list, [] on any fetch failure. Capping the result to a run's `--max` is
 * PageSpeedSyncCommand's job, not this class's.
 *
 * gs.construction's own pinned config('seo.psi_urls') list plus its
 * top-Search-Console-pages expansion has no kit equivalent here — a site
 * that wants that keeps writing its own small PageSpeedUrlSource, the same
 * way SiteCatalog implementations stay per-site.
 *
 * The template classifier defaults to the URL's first path segment
 * ('/services/kitchen-remodeling' -> 'services', '/' -> 'home') — simpler
 * than CwvTemplateReport's own classify() (which also recognises specific
 * prefixes like /areas-served/ and /reviews/), because this label only
 * drives PageSpeedSyncCommand's `--only` filter and console output, never
 * what CwvTemplateReport buckets by — that report re-derives its own
 * template straight from each snapshot's stored `url`, independently, the
 * same way it always has. (2026-11-01)
 */
final class SitemapUrlSource implements PageSpeedUrlSource
{
    private const TIMEOUT_SECONDS = 15;

    public function __construct(
        private readonly string $sitemapUrl,
        private readonly Factory $http,
        private readonly ?\Closure $classifier = null,
    ) {
    }

    /** @return list<array{url: string, template: string}> */
    public function urls(): array
    {
        try {
            $response = $this->http->timeout(self::TIMEOUT_SECONDS)->get($this->sitemapUrl);
        } catch (\Throwable) {
            return [];
        }

        if (! $response->successful()) {
            return [];
        }

        if (! preg_match_all('#<loc>(.*?)</loc>#i', $response->body(), $matches)) {
            return [];
        }

        $classify = $this->classifier ?? self::defaultClassifier(...);

        $out = [];
        $seen = [];
        foreach ($matches[1] as $raw) {
            $url = trim($raw);
            if ($url === '' || isset($seen[$url])) {
                continue;
            }
            $seen[$url] = true;
            $out[] = ['url' => $url, 'template' => (string) $classify($url)];
        }

        return $out;
    }

    /** First non-empty path segment; the bare root path classifies as 'home'. */
    public static function defaultClassifier(string $url): string
    {
        $path = trim((string) parse_url($url, PHP_URL_PATH), '/');

        if ($path === '') {
            return 'home';
        }

        $segments = explode('/', $path);

        return $segments[0];
    }
}
