<?php

namespace SsSystems\Platform\Seo\PageSpeed;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Database\Query\Builder;
use Illuminate\Database\QueryException;
use Illuminate\Support\Arr;
use Illuminate\Support\Carbon;
use SsSystems\Platform\Reports\Contracts\PsiSnapshotReader;

/**
 * psi_snapshots over a plain query builder (no Eloquent) — ported from
 * gs.construction's App\Models\PsiSnapshot (a bare Eloquent model with
 * BelongsToSite) and the `PsiSnapshot::updateOrCreate(['date','url',
 * 'strategy'], $result)` call in its App\Console\Commands\
 * SyncPageSpeedInsights, whose exact meaning record() keeps: one row per
 * (date, url, strategy) [+ site], re-measuring the same page on the same
 * day overwrites rather than duplicates.
 *
 * Tenant-scoped exactly like RankSnapshotStore/AiTrafficStore: a
 * single-tenant site (jpeterson-design, dawnsellshomes) passes neither
 * `$tenantColumn` nor `$tenantId`; gs.construction passes `'site_id'` and a
 * closure reading the current tenant at call time (never captured once at
 * construction, since the bound singleton outlives any one request's
 * tenant in a queue worker).
 *
 * Implements the kit's own PsiSnapshotReader contract directly — a site
 * binds THIS class for the `psi_snapshots` capability instead of writing
 * its own Eloquent reader (gsc's App\Support\Seo\Reports\
 * EloquentPsiSnapshotReader did exactly that before this module existed; a
 * new adopter needs nothing of its own). (2026-11-01)
 */
final class PsiSnapshotStore implements PsiSnapshotReader
{
    public function __construct(
        private readonly ConnectionInterface $connection,
        private readonly string $table = 'psi_snapshots',
        private readonly ?string $tenantColumn = null,
        private readonly ?\Closure $tenantId = null,
    ) {
    }

    /**
     * Insert-or-overwrite one (date, url, strategy) row — gsc's
     * updateOrCreate() semantics without Eloquent: try the UPDATE first; no
     * rows affected means the row doesn't exist yet, so INSERT it, with the
     * same duplicate-insert race AiTrafficStore::record() absorbs (a
     * concurrent sync for the same page/day/strategy is vanishingly
     * unlikely but handled the same way regardless).
     *
     * @param  array{
     *     date: string, url: string, strategy: string,
     *     performance?: ?int, accessibility?: ?int, best_practices?: ?int, seo?: ?int,
     *     lab_lcp_ms?: ?int, lab_fcp_ms?: ?int, lab_tbt_ms?: ?int, lab_cls?: ?float, lab_si_ms?: ?int,
     *     field_lcp_ms?: ?int, field_inp_ms?: ?int, field_cls?: ?float, field_overall?: ?string,
     * }  $attributes
     */
    public function record(array $attributes): void
    {
        $conditions = [
            'date' => (string) $attributes['date'],
            'url' => (string) $attributes['url'],
            'strategy' => (string) $attributes['strategy'],
        ];

        $values = Arr::except($attributes, ['date', 'url', 'strategy']);
        $values['updated_at'] = Carbon::now();

        $updated = $this->scoped($this->connection->table($this->table)->where($conditions))->update($values);

        if ($updated > 0) {
            return;
        }

        $row = $conditions + $values;
        if ($this->tenantColumn !== null) {
            $row[$this->tenantColumn] = ($this->tenantId)();
        }
        $row['created_at'] = Carbon::now();

        try {
            $this->connection->table($this->table)->insert($row);
        } catch (QueryException) {
            $this->scoped($this->connection->table($this->table)->where($conditions))->update($values);
        }
    }

    public function hasTable(): bool
    {
        try {
            return $this->connection->getSchemaBuilder()->hasTable($this->table);
        } catch (\Throwable) {
            return false;
        }
    }

    /**
     * Raw rows for CwvTemplateReport's `psi_snapshots` capability — see
     * SsSystems\Platform\Reports\Contracts\PsiSnapshotReader. Unaggregated,
     * tenant-scoped, date-inclusive on both ends.
     *
     * @return list<array{
     *     url: string, strategy: string,
     *     field_lcp_ms: ?int, field_inp_ms: ?int, field_cls: ?float,
     *     lab_lcp_ms: ?int, performance: ?int,
     * }>
     */
    public function snapshots(string $from, string $to): array
    {
        if (! $this->hasTable()) {
            return [];
        }

        $rows = $this->scoped(
            $this->connection->table($this->table)->whereBetween('date', [$from, $to])
        )->get(['url', 'strategy', 'field_lcp_ms', 'field_inp_ms', 'field_cls', 'lab_lcp_ms', 'performance']);

        return $rows->map(static fn ($row): array => [
            'url' => (string) $row->url,
            'strategy' => (string) $row->strategy,
            'field_lcp_ms' => $row->field_lcp_ms !== null ? (int) $row->field_lcp_ms : null,
            'field_inp_ms' => $row->field_inp_ms !== null ? (int) $row->field_inp_ms : null,
            'field_cls' => $row->field_cls !== null ? (float) $row->field_cls : null,
            'lab_lcp_ms' => $row->lab_lcp_ms !== null ? (int) $row->lab_lcp_ms : null,
            'performance' => $row->performance !== null ? (int) $row->performance : null,
        ])->all();
    }

    private function scoped(Builder $query): Builder
    {
        if ($this->tenantColumn !== null) {
            $query->where($this->tenantColumn, ($this->tenantId)());
        }

        return $query;
    }
}
