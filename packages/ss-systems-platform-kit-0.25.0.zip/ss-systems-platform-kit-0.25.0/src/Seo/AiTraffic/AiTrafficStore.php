<?php

namespace SsSystems\Platform\Seo\AiTraffic;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Database\Query\Builder;
use Illuminate\Database\QueryException;
use Illuminate\Support\Carbon;

/**
 * The one read/write path to `ai_traffic_daily` — ported from gs.construction's
 * `TrackAiTraffic::terminate()` (the write half) and its
 * `SeoReportController::aiTrafficSnapshot()` (the read half), merged into one
 * class so every adopter's table shape and tenant scoping live in a single
 * place, the same reasoning as `Pulse\Storage\DatabaseTableStorage`.
 *
 * Tenant-scoped exactly like `Traffic\Collectors\TrackedEventsCollector`: a
 * single-tenant site (jpeterson-design, dawnsellshomes) passes neither
 * `$tenantColumn` nor `$tenantId`; gs.construction passes `'site_id'` and a
 * closure reading the current tenant at call time (never captured once at
 * construction, since the bound singleton outlives any one request's tenant
 * in a queue worker).
 */
final class AiTrafficStore
{
    public function __construct(
        private readonly ConnectionInterface $connection,
        private readonly string $table = 'ai_traffic_daily',
        private readonly ?string $tenantColumn = null,
        private readonly ?\Closure $tenantId = null,
    ) {
    }

    /**
     * Increment-or-insert without a read-modify-write race, exactly like the
     * original middleware: the tiny duplicate-insert race between the two
     * statements is absorbed by the table's unique key — the insert fails,
     * the count is off by at most one request, and nothing surfaces to the
     * visitor. Any other database failure (a missing table, for instance) is
     * left to propagate — the caller (`TrackAiTraffic`) is the one place that
     * decides analytics must never break a page.
     */
    public function record(string $kind, string $source, string $path, ?\DateTimeInterface $on = null): void
    {
        $date = Carbon::parse($on ?? Carbon::now())->toDateString();
        $path = mb_substr($path, 0, 191);

        $conditions = ['date' => $date, 'kind' => $kind, 'source' => $source, 'path' => $path];

        $updated = $this->scoped($this->connection->table($this->table)->where($conditions))->increment('count');

        if ($updated > 0) {
            return;
        }

        $row = $this->tenantColumn !== null ? [...$conditions, $this->tenantColumn => ($this->tenantId)()] : $conditions;
        $row['count'] = 1;
        $row['created_at'] = Carbon::now();
        $row['updated_at'] = Carbon::now();

        try {
            $this->connection->table($this->table)->insert($row);
        } catch (QueryException) {
            $this->scoped($this->connection->table($this->table)->where($conditions))->increment('count');
        }
    }

    public function hasTable(): bool
    {
        try {
            return $this->connection->getSchemaBuilder()->hasTable($this->table);
        } catch (\Throwable) {
            return false;
        }
    }

    /**
     * Summed counts for the last $days days (today inclusive), one row per
     * (kind, source) — the exact grouping gsc's `aiTrafficSnapshot()` reads.
     *
     * @return list<array{kind: string, source: string, total: int}>
     */
    public function totals(int $days): array
    {
        if (! $this->hasTable()) {
            return [];
        }

        $since = Carbon::now()->subDays($days)->toDateString();

        $query = $this->scoped(
            $this->connection->table($this->table)->where('date', '>=', $since)
        )
            ->selectRaw('kind, source, SUM(count) as total')
            ->groupBy('kind', 'source')
            ->orderByDesc('total');

        return array_map(
            static fn ($row): array => ['kind' => (string) $row->kind, 'source' => (string) $row->source, 'total' => (int) $row->total],
            $query->get()->all(),
        );
    }

    private function scoped(Builder $query): Builder
    {
        if ($this->tenantColumn !== null) {
            $query->where($this->tenantColumn, ($this->tenantId)());
        }

        return $query;
    }
}
