<?php

namespace SsSystems\Platform\Seo\AiTraffic;

/**
 * Names a request as an AI crawler fetch, a human referral from an AI
 * assistant, or neither — ported verbatim from gs.construction's
 * `App\Http\Middleware\TrackAiTraffic::classify()` (its `CRAWLERS`/
 * `REFERRERS` fragment lists and first-match-wins order), the one place
 * that decides what counts for the GEO traffic card.
 *
 *   - "crawler": an AI bot fetched a page (user-agent match). The GEO
 *     supply metric — whether assistants are reading the site at all.
 *   - "referral": a human clicked through from an AI assistant (Referer
 *     header from chatgpt.com, perplexity.ai, …). The GEO conversion
 *     metric — the assistant answered with us and someone cared enough to
 *     visit.
 *
 * Pure: no request, no database, no container — just the two strings a
 * caller already has off the request. Kept as an injectable instance
 * (rather than static methods) so `TrackAiTraffic` takes it through its
 * constructor like `AiTrafficStore`, and a site can swap in its own
 * fragment lists by subclassing without touching the middleware.
 *
 * gsc's lists are kept intact; additions beyond gsc (2026-11-01): the
 * `anthropic-ai` training crawler, Common Crawl's `CCBot`, DuckDuckGo's
 * `DuckAssistBot`, Diffbot's crawler, Mistral's user-triggered
 * `MistralAI-User` fetcher (checked before the existing bare `MistralAI`
 * fragment so the more specific label wins), and the `bing.com/chat`
 * referrer path. DuckDuckGo's own `?q=...&ia=chat` query-string shape was
 * deliberately left out — a query parameter on an ordinary `duckduckgo.com`
 * referrer is not a reliable enough signal to count as an AI referral.
 */
final class AiTrafficClassifier
{
    /** User-agent fragment => bot label. Order matters: first match wins. */
    private const CRAWLERS = [
        'OAI-SearchBot' => 'OAI-SearchBot',
        'ChatGPT-User' => 'ChatGPT-User',
        'GPTBot' => 'GPTBot',
        'Perplexity-User' => 'Perplexity-User',
        'PerplexityBot' => 'PerplexityBot',
        'Claude-User' => 'Claude-User',
        'Claude-SearchBot' => 'Claude-SearchBot',
        'ClaudeBot' => 'ClaudeBot',
        'claude-web' => 'Claude-Web',
        'anthropic-ai' => 'anthropic-ai',
        'Google-Extended' => 'Google-Extended',
        'GoogleOther' => 'GoogleOther',
        'Applebot-Extended' => 'Applebot-Extended',
        'Applebot' => 'Applebot',
        'meta-externalagent' => 'Meta-External',
        'FacebookBot' => 'FacebookBot',
        'Amazonbot' => 'Amazonbot',
        'Bytespider' => 'Bytespider',
        'CCBot' => 'CCBot',
        'cohere-ai' => 'Cohere',
        'YouBot' => 'YouBot',
        'DuckAssistBot' => 'DuckAssistBot',
        'Diffbot' => 'Diffbot',
        'MistralAI-User' => 'MistralAI-User',
        'MistralAI' => 'MistralAI',
    ];

    /** Referer host (+ path, where needed) fragment => source label. */
    private const REFERRERS = [
        'chatgpt.com' => 'chatgpt',
        'chat.openai.com' => 'chatgpt',
        'perplexity.ai' => 'perplexity',
        'copilot.microsoft.com' => 'copilot',
        'bing.com/chat' => 'bing-chat',
        'gemini.google.com' => 'gemini',
        'claude.ai' => 'claude',
        'you.com' => 'you.com',
        'phind.com' => 'phind',
        'poe.com' => 'poe',
        'duckduckgo.com/aichat' => 'duckduckgo-ai',
    ];

    /**
     * @return array{kind: 'crawler'|'referral', source: string}|null
     */
    public function classify(?string $userAgent, ?string $referer): ?array
    {
        $userAgent = (string) $userAgent;
        if ($userAgent !== '') {
            foreach (self::CRAWLERS as $fragment => $label) {
                if (stripos($userAgent, $fragment) !== false) {
                    return ['kind' => 'crawler', 'source' => $label];
                }
            }
        }

        $referer = strtolower((string) $referer);
        if ($referer !== '') {
            foreach (self::REFERRERS as $fragment => $label) {
                if (str_contains($referer, $fragment)) {
                    return ['kind' => 'referral', 'source' => $label];
                }
            }
        }

        return null;
    }
}
