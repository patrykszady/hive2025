<?php

namespace SsSystems\Platform\Seo\AiTraffic;

/**
 * Shapes `AiTrafficStore`'s rows into the exact shape gs.construction's (and
 * jpeterson-design's — J. Peterson reads this but has never shipped the
 * table) `seo-reports.blade.php` reads as `$snapshot['ai_traffic']`: two
 * source => visits maps and their two totals. Ported verbatim from
 * `SeoReportController::aiTrafficSnapshot()`, keys unchanged, so the
 * ss.systems hub's "AI Assistant Visibility" card renders identically for
 * every adopter.
 *
 * Caching is deliberately NOT this class's job (same reasoning as
 * `Pulse\SnapshotBuilder`): `build()` always computes fresh, and a site wraps
 * the call in its own `Cache::remember(..., now()->addMinutes(15), ...)`,
 * matching how gsc/jpeterson-design already cache every other seo/snapshot
 * section (`seo_reports_ai_traffic_v1`, 900 seconds, in the original).
 */
final class AiTrafficSnapshot
{
    /** @var array{referrals: array<string, int>, crawlers: array<string, int>, total_referrals: int, total_crawls: int} */
    private const EMPTY = ['referrals' => [], 'crawlers' => [], 'total_referrals' => 0, 'total_crawls' => 0];

    public function __construct(private readonly AiTrafficStore $store)
    {
    }

    /**
     * @return array{referrals: array<string, int>, crawlers: array<string, int>, total_referrals: int, total_crawls: int}
     */
    public function build(int $days = 28): array
    {
        if (! $this->store->hasTable()) {
            return self::EMPTY;
        }

        $referrals = [];
        $crawlers = [];

        foreach ($this->store->totals($days) as $row) {
            if ($row['kind'] === 'referral') {
                $referrals[$row['source']] = $row['total'];
            } else {
                $crawlers[$row['source']] = $row['total'];
            }
        }

        return [
            'referrals' => $referrals,
            'crawlers' => $crawlers,
            'total_referrals' => array_sum($referrals),
            'total_crawls' => array_sum($crawlers),
        ];
    }
}
