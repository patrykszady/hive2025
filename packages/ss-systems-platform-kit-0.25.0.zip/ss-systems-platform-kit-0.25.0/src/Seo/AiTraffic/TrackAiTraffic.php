<?php

namespace SsSystems\Platform\Seo\AiTraffic;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Terminating middleware that turns AI-assistant referrals and AI-crawler
 * fetches into `ai_traffic_daily` counters — the feedback signal behind the
 * SEO Reports "AI Assistant Visibility" card. Ported from gs.construction's
 * `App\Http\Middleware\TrackAiTraffic`: same terminating-middleware shape
 * (work happens in `terminate()` after the response is sent, one cheap
 * upsert per matching request), same skip rules, same never-throws guarantee
 * — analytics must never break a page.
 *
 * A site appends this to its `web` middleware group in `bootstrap/app.php`
 * (Laravel only calls `terminate()` on middleware that was actually run, so
 * it must be in the stack, not just bound):
 *
 *     use SsSystems\Platform\Seo\AiTraffic\TrackAiTraffic;
 *
 *     ->withMiddleware(function (Middleware $middleware): void {
 *         $middleware->append(TrackAiTraffic::class);
 *     })
 *
 * and binds the store once, scoped however that site scopes its own tables
 * (see `AiTrafficStore`'s docblock):
 *
 *     $this->app->singleton(AiTrafficStore::class, fn () => new AiTrafficStore(DB::connection()));
 *
 * Behaviour change from gsc (2026-11-01): `/api` is skipped alongside
 * `/admin`, `/livewire`, `/horizon`, `/storage`, `/build` — gsc's own API
 * lives under its tenant-admin path and was already covered by the `/admin`
 * prefix, but a site with a plain public `/api` (JSON endpoints a browser
 * never "visits" in the GEO sense) needs the same exclusion, and every site
 * sharing this one middleware class must get it rather than re-deriving its
 * own skip list.
 */
final class TrackAiTraffic
{
    /** @var list<string> path prefixes never counted. */
    private const SKIP_PREFIXES = ['/admin', '/api', '/livewire', '/horizon', '/storage', '/build'];

    public function __construct(
        private readonly AiTrafficStore $store,
        private readonly AiTrafficClassifier $classifier,
    ) {
    }

    public function handle(Request $request, Closure $next): Response
    {
        return $next($request);
    }

    public function terminate(Request $request, Response $response): void
    {
        try {
            if (! $request->isMethod('GET') || $response->getStatusCode() >= 400) {
                return;
            }

            $path = '/'.ltrim($request->path(), '/');
            foreach (self::SKIP_PREFIXES as $prefix) {
                if (str_starts_with($path, $prefix)) {
                    return;
                }
            }

            $match = $this->classifier->classify($request->userAgent(), $request->headers->get('referer'));
            if ($match === null) {
                return;
            }

            $this->store->record($match['kind'], $match['source'], $path);
        } catch (\Throwable) {
            // Analytics must never break a page.
        }
    }
}
