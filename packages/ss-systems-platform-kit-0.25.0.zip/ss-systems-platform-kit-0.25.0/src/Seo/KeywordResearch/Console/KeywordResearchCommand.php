<?php

namespace SsSystems\Platform\Seo\KeywordResearch\Console;

use Illuminate\Console\Command;
use Illuminate\Database\ConnectionInterface;
use SsSystems\Platform\Seo\Contracts\SeoSiteProfile;
use SsSystems\Platform\Seo\DataForSeo\Contracts\DataForSeoApi;
use SsSystems\Platform\Seo\KeywordResearch\CompetitorDomainSource;
use SsSystems\Platform\Seo\KeywordResearch\KeywordClassifier;
use SsSystems\Platform\Seo\KeywordResearch\KeywordOpportunityScorer;
use SsSystems\Platform\Seo\KeywordResearch\KeywordSeedBuilder;
use SsSystems\Platform\Seo\KeywordResearch\KeywordStore;
use SsSystems\Platform\Seo\KeywordResearch\OwnQueryMetrics;

/**
 * `seo:keyword-research` — weekly keyword + competitor research into
 * `seo_keywords` via DataForSEO, ported from gs.construction's
 * App\Console\Commands\SeoKeywordResearch (same signature, same four-step
 * shape: universe -> competitor/idea keywords -> volumes -> write, then a
 * fifth pass fills intent/difficulty for the highest-volume keywords). See
 * each collaborator's own docblock for what changed in the port:
 *
 *  - Universe seeds: KeywordSeedBuilder (`$profile->services()` x
 *    `$profile->towns()`) replaces gs.construction's hardcoded remodeling
 *    service list x `AreaServed`; OwnQueryMetrics::topQueries() is the
 *    fallback when a site configures no services.
 *  - Competitor domains: CompetitorDomainSource (`seo_rank_snapshots`)
 *    replaces `SeoDomainOverview::competitorDomains()` (a `map_pack_competitors`
 *    table plus a stored discovery JSON file, neither of which exist here).
 *  - Classification: KeywordClassifier reads `$profile->services()`/
 *    `towns()` instead of a hardcoded SERVICE_KEYWORDS/knownCities() lexicon;
 *    it never assigns a `modifier` (gs.construction's luxury/affordable/...
 *    lexicon was not generalised — the column stays, always null, see the
 *    migration stub).
 *  - Opportunity scoring: KeywordOpportunityScorer's "local"/"our trade"
 *    gates read `$profile->services()`/towns() instead of a remodeling
 *    regex.
 *  - DataForSEO calls pass `$profile->locationName()` instead of
 *    gs.construction's hardcoded 'United States'.
 *  - No `--dry-run`/balance-guard class is ported (gs.construction's
 *    App\Support\Seo\DataForSeoBudget) — the same precheck logic is inlined
 *    here; behaviour is identical (refuse before spending when the estimate
 *    exceeds `--budget` or the balance can't cover it, fail the run if every
 *    competitor domain failed).
 *
 * A site registers this the same way it registers any other kit console
 * command: a thin `App\Console\Commands\SeoKeywordResearch extends
 * KeywordResearchCommand {}` under `app/Console/Commands/`, auto-discovered
 * by Laravel, or bound directly. gs.construction schedules it
 * `weeklyOn(0, '04:30')` with `--budget=4 --ideas`.
 */
class KeywordResearchCommand extends Command
{
    protected $signature = 'seo:keyword-research
        {--budget=3 : Max USD to spend this run}
        {--competitors=15 : Competitor domains to pull ranked keywords for}
        {--ideas : Also pull keyword ideas around each service (adds ~$0.10)}
        {--dry-run : Build the universe and report what would be fetched, spend nothing}
        {--rescore : Recompute opportunity for stored keywords only; no API calls}';

    protected $description = 'Keyword + competitor research via DataForSEO into seo_keywords (volume, our position, competitor coverage, opportunity)';

    public function __construct(
        private readonly DataForSeoApi $api,
        private readonly SeoSiteProfile $profile,
        private readonly ConnectionInterface $connection,
        private readonly string $keywordsTable = 'seo_keywords',
        private readonly string $queryMetricsTable = 'gsc_query_metrics',
        private readonly string $rankSnapshotsTable = 'seo_rank_snapshots',
        private readonly ?string $tenantColumn = null,
        private readonly ?\Closure $tenantId = null,
    ) {
        parent::__construct();
    }

    public function handle(): int
    {
        if (! $this->api->isConfigured()) {
            $this->comment('DataForSEO not configured — skipping.');

            return self::SUCCESS;
        }

        $store = new KeywordStore($this->connection, $this->keywordsTable, $this->tenantColumn, $this->tenantId);

        if ($this->option('rescore')) {
            return $this->rescore($store);
        }

        $budget = (float) $this->option('budget');
        $dry = (bool) $this->option('dry-run');

        $ownQueries = new OwnQueryMetrics($this->connection, $this->queryMetricsTable, $this->tenantColumn, $this->tenantId);
        $ours = $ownQueries->ownPositions();

        $universe = [];
        $add = function (string $kw, string $source) use (&$universe): void {
            $kw = trim(preg_replace('/\s+/', ' ', mb_strtolower($kw)) ?? '');
            if ($kw === '' || mb_strlen($kw) > 120) {
                return;
            }
            $universe[$kw][$source] = true;
        };

        foreach (array_keys($ours) as $query) {
            $add($query, 'gsc');
        }

        $seeds = (new KeywordSeedBuilder($this->profile))->seeds();
        $seedSource = 'town_service';
        if ($seeds === []) {
            $seeds = $ownQueries->topQueries(50);
            $seedSource = 'own_query';
        }
        foreach ($seeds as $seed) {
            $add($seed, $seedSource);
        }

        $competitorDomainSource = new CompetitorDomainSource(
            $this->connection, $this->profile, $this->rankSnapshotsTable, 'top_results', $this->tenantColumn, $this->tenantId,
        );
        $domains = $competitorDomainSource->domains((int) $this->option('competitors'));

        $this->info(sprintf('Universe: %d keywords (%d from Search Console); %d competitor domains.', count($universe), count($ours), count($domains)));

        $estimate = $this->estimateCost(count($universe), count($domains), (bool) $this->option('ideas'));
        $balance = $this->api->balance();
        $this->line(sprintf('Estimated cost: $%.2f · budget: $%.2f · balance: %s', $estimate, $budget, $balance === null ? 'unknown' : '$'.number_format($balance, 2)));

        if ($dry) {
            $this->line('Dry run — nothing fetched. Domains: '.implode(', ', $domains));

            return self::SUCCESS;
        }

        if ($estimate > $budget) {
            $this->error(sprintf('Estimated cost $%.2f exceeds --budget $%.2f; narrow the run or raise --budget.', $estimate, $budget));

            return self::FAILURE;
        }
        if ($balance === null) {
            $this->error(sprintf('DataForSEO balance unknown (%s) — refusing to spend blind.', $this->api->getLastError() ?? 'balance check failed'));

            return self::FAILURE;
        }
        if ($balance < $estimate) {
            $this->error(sprintf('DataForSEO balance $%.2f cannot cover this run ($%.2f).', $balance, $estimate));

            return self::FAILURE;
        }

        $competitorHits = [];
        $attempted = 0;
        $failed = 0;
        foreach ($domains as $domain) {
            if ($this->api->spent() >= $budget) {
                $this->warn('Budget reached before all competitors were pulled.');
                break;
            }

            $rows = $this->api->rankedKeywords($domain, 300, $this->profile->locationName());
            $attempted++;
            $failed += ($rows === [] && $this->api->getLastError() !== null) ? 1 : 0;

            $n = 0;
            foreach ($rows as $r) {
                $keyword = (string) $r['keyword'];
                $add($keyword, 'competitor');
                $competitorHits[$keyword][$domain] = $r['position'];
                $universe[$keyword]['__vol'] = max($universe[$keyword]['__vol'] ?? 0, (int) ($r['volume'] ?? 0));
                $universe[$keyword]['__diff'] = $r['difficulty'] ?? ($universe[$keyword]['__diff'] ?? null);
                $n++;
            }
            $this->line("  {$domain}: {$n} keywords".($this->api->getLastError() ? " ({$this->api->getLastError()})" : ''));
        }

        if ($this->option('ideas') && $this->profile->services() !== [] && $this->api->spent() < $budget) {
            foreach ($this->api->keywordIdeas($this->profile->services(), 300, $this->profile->locationName()) as $r) {
                $keyword = (string) $r['keyword'];
                $add($keyword, 'ideas');
                $universe[$keyword]['__vol'] = max($universe[$keyword]['__vol'] ?? 0, (int) ($r['volume'] ?? 0));
            }
        }

        $need = array_keys($universe);
        $volumes = [];
        foreach (array_chunk($need, 1000) as $chunk) {
            if ($this->api->spent() >= $budget) {
                $this->warn('Budget reached before all volumes were fetched.');
                break;
            }
            $chunkVolumes = $this->api->searchVolume($chunk, $this->profile->locationName());

            if ($chunkVolumes === [] && $this->api->getLastError() !== null) {
                // jpeterson-design, 2026-11-08: one failed lookup came back as
                // an empty list, the run went on, and every keyword was written
                // with no volume over the volumes it had the week before.
                $this->error(sprintf('Search volumes could not be read (%s) — nothing written; the next run retries.', $this->api->getLastError()));

                return self::FAILURE;
            }

            $volumes += $chunkVolumes;
        }

        $classifier = new KeywordClassifier($this->profile);
        $scorer = new KeywordOpportunityScorer($this->profile);
        $written = 0;

        foreach ($universe as $kw => $meta) {
            $vol = $volumes[$kw]['volume'] ?? ($meta['__vol'] ?? null);
            if ($vol === null && ! isset($ours[$kw])) {
                continue; // nothing known about it
            }

            $mine = $ours[$kw] ?? null;
            $hits = $competitorHits[$kw] ?? [];
            $sources = array_keys(array_filter($meta, fn ($v, $k) => ! str_starts_with((string) $k, '__'), ARRAY_FILTER_USE_BOTH));
            $city = $classifier->town($kw);

            $opp = $scorer->score((int) ($vol ?? 0), $mine['position'] ?? null, $hits !== [], $kw, $city, $sources);
            if ($opp > 0 && isset($meta['__diff']) && $meta['__diff'] !== null) {
                $opp = round($opp * (1 - min(100, (int) $meta['__diff']) / 200), 2);
            }

            $store->upsert($kw, [
                'volume' => $vol,
                'cpc' => $volumes[$kw]['cpc'] ?? null,
                'competition' => $volumes[$kw]['competition'] ?? null,
                'difficulty' => $meta['__diff'] ?? null,
                'service' => $classifier->service($kw),
                'city' => $city,
                'modifier' => null,
                'sources' => json_encode($sources),
                'competitor_domains' => $hits !== [] ? json_encode($hits) : null,
                'competitor_best_position' => $hits !== [] ? min($hits) : null,
                'our_position' => $mine['position'] ?? null,
                'our_impressions' => $mine['impressions'] ?? null,
                'our_clicks' => $mine['clicks'] ?? null,
                'opportunity' => $opp,
            ]);
            $written++;
        }

        if ($this->api->spent() < $budget) {
            $withVolume = $store->keywordsWithVolume(10, 2000);
            $difficulty = $this->api->keywordDifficulty($withVolume);
            $intent = $this->api->searchIntent($withVolume);

            foreach ($withVolume as $kw) {
                $upd = [];
                if (isset($difficulty[$kw])) {
                    $upd['difficulty'] = $difficulty[$kw];
                    $row = $store->find($kw);
                    if ($row !== null && (float) $row->opportunity > 0) {
                        $upd['opportunity'] = round((float) $row->opportunity * (1 - min(100, (int) $difficulty[$kw]) / 200), 2);
                    }
                }
                if (isset($intent[$kw])) {
                    $upd['intent'] = mb_substr($intent[$kw], 0, 20);
                    if ($intent[$kw] === 'navigational') {
                        $upd['opportunity'] = 0; // someone's brand, not a market
                    }
                }
                if ($upd !== []) {
                    $store->updateFields($kw, $upd);
                }
            }
            $this->line(sprintf('  intent/difficulty for %d keywords', count($withVolume)));
        }

        if ($attempted > 0 && $failed === $attempted) {
            $this->error('Every competitor domain failed — DataForSEO may be down or misconfigured.');

            return self::FAILURE;
        }

        $this->info(sprintf('Wrote %d keywords. Spent $%.3f.', $written, $this->api->spent()));

        return self::SUCCESS;
    }

    private function rescore(KeywordStore $store): int
    {
        $scorer = new KeywordOpportunityScorer($this->profile);
        $n = 0;

        foreach ($store->all() as $row) {
            $sources = (array) json_decode((string) $row->sources, true);
            $hasCompetitor = $row->competitor_domains !== null;

            $opp = ($row->intent ?? null) === 'navigational'
                ? 0.0
                : $scorer->score((int) $row->volume, $row->our_position !== null ? (float) $row->our_position : null, $hasCompetitor, (string) $row->keyword, $row->city, $sources);

            if ($opp > 0 && $row->difficulty !== null) {
                $opp = round($opp * (1 - min(100, (int) $row->difficulty) / 200), 2);
            }

            $store->updateOpportunity((int) $row->id, $opp);
            $n++;
        }

        $this->info("Rescored {$n} keywords.");

        return self::SUCCESS;
    }

    /**
     * Ported from gs.construction's own estimate: ~$0.08 per 1,000-keyword
     * volume batch (a +3,000 headroom fudge for the competitor/ideas
     * keywords not yet known when the universe is first sized), $0.03 per
     * competitor domain, $0.02 per service when `--ideas` is set (gs.
     * construction's hardcoded 8-service list -> `$profile->services()`
     * count), plus a flat cost for the intent/difficulty pass (2 calls each,
     * <= 2,000 keywords, $0.013/call).
     */
    private function estimateCost(int $universeSize, int $domainsCount, bool $pullIdeas): float
    {
        $volumeCost = ceil(($universeSize + 3000) / 1000) * 0.08;
        $competitorCost = $domainsCount * 0.03;
        $ideasCost = $pullIdeas ? count($this->profile->services()) * 0.02 : 0.0;
        $intentDifficultyCost = 2 * 2 * 0.013;

        return $volumeCost + $competitorCost + $ideasCost + $intentDifficultyCost;
    }
}
