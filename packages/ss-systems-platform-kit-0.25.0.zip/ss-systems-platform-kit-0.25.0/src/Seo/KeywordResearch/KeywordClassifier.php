<?php

namespace SsSystems\Platform\Seo\KeywordResearch;

use SsSystems\Platform\Seo\Contracts\SeoSiteProfile;

/**
 * Labels a keyword with the service and town it names, for the "Keyword
 * Opportunities" report card's per-row `city` / `service` columns — ported
 * from gs.construction's SeoAutopilotService::classify(), whose
 * SERVICE_KEYWORDS/knownCities() were a hardcoded remodeling lexicon
 * (kitchen/bathroom/basement -> slug, a curated Chicago-suburbs town list).
 * Generalised here to read both from the site's own
 * `$profile->services()`/`$profile->towns()`, so a non-remodeling site's
 * trade vocabulary classifies exactly as well as gs.construction's does.
 *
 * Unlike the ported original, this never returns null for "no match at all"
 * — `service()`/`town()` each answer independently, since a competitor- or
 * ideas-sourced keyword may legitimately name a town with no recognised
 * service (or vice versa); gs.construction's single parseQuery() required
 * both or rejected the keyword entirely, which this port does not need to
 * reproduce (nothing downstream depends on an all-or-nothing match).
 */
final class KeywordClassifier
{
    public function __construct(private readonly SeoSiteProfile $profile)
    {
    }

    /** The first configured service whose phrase appears in the keyword, or null. */
    public function service(string $keyword): ?string
    {
        $q = mb_strtolower($keyword);

        foreach ($this->profile->services() as $service) {
            if (str_contains($q, mb_strtolower($service))) {
                return $service;
            }
        }

        return null;
    }

    /** The first configured town named in the keyword (longest names checked first), or null. */
    public function town(string $keyword): ?string
    {
        $q = ' '.trim(preg_replace('/\s+/', ' ', mb_strtolower($keyword)) ?? '').' ';

        foreach ($this->townsLongestFirst() as $town) {
            if (str_contains($q, ' '.mb_strtolower($town).' ')) {
                return $town;
            }
        }

        return null;
    }

    /** @return list<string> */
    private function townsLongestFirst(): array
    {
        $towns = $this->profile->towns();
        usort($towns, fn (string $a, string $b): int => mb_strlen($b) <=> mb_strlen($a));

        return $towns;
    }
}
