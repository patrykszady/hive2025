<?php

namespace SsSystems\Platform\Seo\KeywordResearch;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Database\Query\Builder;
use Illuminate\Database\QueryException;

/**
 * The "Keyword Opportunities" report card's data block — ported byte-for-byte
 * in shape from gs.construction's
 * App\Http\Controllers\Api\Admin\V1\SeoReportController::keywordResearchSnapshot(),
 * ss.systems' `resources/views/livewire/admin/seo-reports.blade.php` (lines
 * 1356-1424) reads every key this returns by the same name and meaning:
 * `available`, `total`, `volume_total`, `researched_at`, `opportunities`,
 * `competitor_gap`, `already_winning`, and each row's `keyword`/`volume`/
 * `difficulty`/`intent`/`our_position`/`competitor_best`/`competitors`/
 * `service`/`city`/`modifier`/`opportunity`.
 *
 * Deliberately does NOT wrap itself in `Cache::remember()` the way
 * gs.construction's controller method does — the using site's own snapshot
 * assembly decides caching (see
 * SsSystems\Platform\Seo\Http\Concerns\BuildsSeoSnapshot for the pattern),
 * same as every other Seo\* builder in this kit.
 *
 * Also deliberately drops gs.construction's `total_prev`/`volume_total_prev`/
 * `opportunities_count_prev` week-over-week chevron fields: those were read
 * from a small ad-hoc ledger gs.construction kept in `Cache` across runs
 * (`keywordResearchPriorTotals()`), which only exists alongside the
 * `Cache::remember()` wrapper this class intentionally does not have. The
 * report card's required keys (see ss.systems' blade, line 1373) never read
 * them.
 */
final class KeywordResearchSnapshot
{
    public function __construct(
        private readonly ConnectionInterface $connection,
        private readonly string $table = 'seo_keywords',
        private readonly ?string $tenantColumn = null,
        private readonly ?\Closure $tenantId = null,
    ) {
    }

    /** @return array<string, mixed> */
    public function build(): array
    {
        try {
            $total = (int) $this->base()->count();
        } catch (QueryException) {
            return ['available' => false];
        }

        if ($total === 0) {
            return ['available' => false, 'total' => 0];
        }

        $row = function (object $k): array {
            return [
                'keyword' => $k->keyword,
                'volume' => (int) $k->volume,
                'difficulty' => $k->difficulty !== null ? (int) $k->difficulty : null,
                'intent' => $k->intent ?? null,
                'cpc' => $k->cpc !== null ? round((float) $k->cpc, 2) : null,
                'our_position' => $k->our_position !== null ? round((float) $k->our_position, 1) : null,
                'our_impressions' => $k->our_impressions !== null ? (int) $k->our_impressions : null,
                'competitor_best' => $k->competitor_best_position !== null ? (int) $k->competitor_best_position : null,
                'competitors' => $k->competitor_domains ? array_keys((array) json_decode((string) $k->competitor_domains, true)) : [],
                'service' => $k->service,
                'city' => $k->city,
                'modifier' => $k->modifier,
                'opportunity' => (float) $k->opportunity,
            ];
        };

        $volumeTotal = (int) $this->base()->sum('volume');
        $withVolume = (int) $this->base()->where('volume', '>', 0)->count();
        $opportunitiesCount = (int) $this->base()->where('opportunity', '>', 0)->count();
        $researchedAt = $this->base()->max('researched_at');

        return [
            'available' => true,
            'total' => $total,
            'with_volume' => $withVolume,
            'researched_at' => $researchedAt !== null ? substr((string) $researchedAt, 0, 10) : null,
            'volume_total' => $volumeTotal,
            'opportunities_count' => $opportunitiesCount,
            'opportunities' => $this->base()->where('opportunity', '>', 0)->orderByDesc('opportunity')->limit(15)->get()->map($row)->all(),
            'competitor_gap' => $this->base()->whereNotNull('competitor_domains')->whereNull('our_position')->where('opportunity', '>', 0)->orderByDesc('volume')->limit(15)->get()->map($row)->all(),
            'already_winning' => $this->base()->where('our_position', '<=', 3)->where('volume', '>', 0)->orderByDesc('volume')->limit(8)->get()->map($row)->all(),
        ];
    }

    private function base(): Builder
    {
        return $this->connection->table($this->table)
            ->when($this->tenantColumn !== null, fn ($q) => $q->where($this->tenantColumn, ($this->tenantId)()));
    }
}
