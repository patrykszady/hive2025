<?php

namespace SsSystems\Platform\Seo\KeywordResearch;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Database\QueryException;
use SsSystems\Platform\Seo\Contracts\SeoSiteProfile;

/**
 * Candidate competitor domains for KeywordResearchCommand's step 2 (pull each
 * one's ranked keywords via DataForSeoApi::rankedKeywords()) — ported from
 * gs.construction's SeoDomainOverview::competitorDomains(), which read a
 * `map_pack_competitors` table plus a stored competitor-discovery JSON file
 * neither of which exist in the kit. Generalised here to read the page-one
 * results the kit's own rank-checking already stores — `seo_rank_snapshots`'s
 * `top_results` column (the `SerpResult` list {@see
 * \SsSystems\Platform\Seo\DataForSeo\Contracts\DataForSeoApi}) — so this
 * reads "whoever actually shows up on page one for our tracked searches"
 * instead of a map-pack-specific table.
 *
 * A domain counts once per snapshot row it appears in at position <= 10
 * (page one); the ones seen most often across recent rows are the ones most
 * worth spending DataForSEO credit investigating. Excludes the site's own
 * domain (`$profile->domain()`, matched loosely by host suffix, plus
 * `$profile->brandPatterns()` against the bare domain — gs.construction's
 * own CompetitorFilter used a similar "is this us" identity check before
 * ever reaching its exclusion list) and `$profile->competitorExclusions()`
 * (directories, aggregators, social platforms).
 *
 * Returns an empty list rather than throwing when `seo_rank_snapshots` does
 * not exist — a site that has not adopted live rank checking yet gets zero
 * competitor domains, not a fatal error; KeywordResearchCommand still runs
 * with the Search-Console-sourced and town x service universe alone.
 */
final class CompetitorDomainSource
{
    public function __construct(
        private readonly ConnectionInterface $connection,
        private readonly SeoSiteProfile $profile,
        private readonly string $table = 'seo_rank_snapshots',
        private readonly string $column = 'top_results',
        private readonly ?string $tenantColumn = null,
        private readonly ?\Closure $tenantId = null,
    ) {
    }

    /** @return list<string> */
    public function domains(int $limit): array
    {
        try {
            $payloads = $this->connection->table($this->table)
                ->when($this->tenantColumn !== null, fn ($q) => $q->where($this->tenantColumn, ($this->tenantId)()))
                ->whereNotNull($this->column)
                ->orderByDesc('id')
                ->limit(2000)
                ->pluck($this->column);
        } catch (QueryException) {
            return [];
        }

        $isExcluded = $this->exclusionMatcher();
        $weights = [];

        foreach ($payloads as $payload) {
            foreach ((array) json_decode((string) $payload, true) as $index => $result) {
                // Two shapes live in top_results: the kit's SerpResult list of
                // {domain, position} objects, and jpeterson-design's older
                // rank checker's plain list of domains in rank order (found
                // 2026-11-10: 186 rows, 0 competitor domains). A bare string
                // is the domain at position index + 1.
                if (is_string($result)) {
                    $result = ['domain' => $result, 'position' => (int) $index + 1];
                }

                $domain = $this->normalizeDomain($result['domain'] ?? $result['url'] ?? null);
                $position = $result['position'] ?? null;

                if ($domain === null || ! is_int($position) || $position > 10) {
                    continue;
                }
                if ($isExcluded($domain)) {
                    continue;
                }

                $weights[$domain] = ($weights[$domain] ?? 0) + 1;
            }
        }

        arsort($weights);

        return array_slice(array_keys($weights), 0, $limit);
    }

    private function normalizeDomain(mixed $domain): ?string
    {
        if (! is_string($domain) || $domain === '') {
            return null;
        }

        $domain = mb_strtolower(trim($domain));

        if (str_contains($domain, '://')) {
            $domain = (string) (parse_url($domain, PHP_URL_HOST) ?? '');
        }

        return str_starts_with($domain, 'www.') ? substr($domain, 4) : $domain;
    }

    /** @return \Closure(string): bool */
    private function exclusionMatcher(): \Closure
    {
        $ownDomain = mb_strtolower($this->profile->domain());
        $brandPatterns = $this->profile->brandPatterns();
        $exclusions = array_map(mb_strtolower(...), $this->profile->competitorExclusions());

        $hostMatches = static fn (string $domain, string $suffix): bool => $domain === $suffix || str_ends_with($domain, '.'.$suffix);

        return function (string $domain) use ($ownDomain, $brandPatterns, $exclusions, $hostMatches): bool {
            if ($hostMatches($domain, $ownDomain)) {
                return true;
            }
            foreach ($brandPatterns as $pattern) {
                if (preg_match('/'.$pattern.'/i', $domain) === 1) {
                    return true;
                }
            }
            foreach ($exclusions as $excluded) {
                if ($hostMatches($domain, $excluded)) {
                    return true;
                }
            }

            return false;
        };
    }
}
