<?php

namespace SsSystems\Platform\Seo\KeywordResearch;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Database\QueryException;

/**
 * The site's own standing (position, impressions, clicks) per Search Console
 * query, read from `gsc_query_metrics` (columns per
 * resources/stubs/seo/create_gsc_query_metrics_table.php.stub) — ported from
 * gs.construction's SeoKeywordResearch::handle(), which built the same `$ours`
 * map unconditionally (every keyword in the universe gets matched against
 * it, not only ones it seeded) and, separately, used the identical table as
 * a keyword-universe SOURCE when a site has no configured services (see
 * `topQueries()`, read by KeywordResearchCommand only when
 * KeywordSeedBuilder::seeds() comes back empty).
 *
 * Returns an empty result rather than throwing when the table does not
 * exist yet (a site that has not adopted Search Console sync at all) —
 * matches the graceful-absence convention the DataForSeoApi-reading
 * CompetitorDomainSource also follows.
 */
final class OwnQueryMetrics
{
    public function __construct(
        private readonly ConnectionInterface $connection,
        private readonly string $table = 'gsc_query_metrics',
        private readonly ?string $tenantColumn = null,
        private readonly ?\Closure $tenantId = null,
    ) {
    }

    /**
     * @return array<string, array{impressions: int, clicks: int, position: ?float}> keyed by lowercase query
     */
    public function ownPositions(int $sinceDays = 28): array
    {
        try {
            $rows = $this->query($sinceDays)->get();
        } catch (QueryException) {
            return [];
        }

        $out = [];
        foreach ($rows as $row) {
            $out[mb_strtolower((string) $row->query)] = [
                'impressions' => (int) $row->imp,
                'clicks' => (int) $row->clicks,
                'position' => $row->pos !== null ? round((float) $row->pos, 1) : null,
            ];
        }

        return $out;
    }

    /** @return list<string> the site's own top queries by impressions — the universe fallback for a site with no configured services. */
    public function topQueries(int $limit, int $sinceDays = 28): array
    {
        try {
            return $this->query($sinceDays)->orderByDesc('imp')->limit($limit)->pluck('query')->all();
        } catch (QueryException) {
            return [];
        }
    }

    private function query(int $sinceDays): \Illuminate\Database\Query\Builder
    {
        $since = (new \DateTimeImmutable())->modify("-{$sinceDays} days")->format('Y-m-d');

        return $this->connection->table($this->table)
            ->where('date', '>=', $since)
            ->when($this->tenantColumn !== null, fn ($q) => $q->where($this->tenantColumn, ($this->tenantId)()))
            ->groupBy('query')
            ->selectRaw('query, SUM(impressions) imp, SUM(clicks) clicks, SUM(position*impressions)/NULLIF(SUM(impressions),0) pos');
    }
}
