<?php

namespace SsSystems\Platform\Seo\KeywordResearch;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Database\Query\Builder;
use Illuminate\Support\Collection;

/**
 * Reads and writes `seo_keywords` (columns per
 * resources/stubs/seo/create_seo_keywords_table.php.stub) for
 * KeywordResearchCommand — one row per (site, keyword), replaced whole on
 * every `seo:keyword-research` run, same as gs.construction's own
 * `Tenancy::table('seo_keywords')->updateOrInsert(...)` calls. Tenant-scoped
 * exactly like SsSystems\Platform\Traffic\Collectors\TrackedEventsCollector:
 * a single-tenant adopter passes neither `$tenantColumn` nor `$tenantId` and
 * every row's `site_id` stays null; a multi-tenant one (gs.construction)
 * passes both and every query is scoped to the current site.
 */
final class KeywordStore
{
    public function __construct(
        private readonly ConnectionInterface $connection,
        private readonly string $table = 'seo_keywords',
        private readonly ?string $tenantColumn = null,
        private readonly ?\Closure $tenantId = null,
    ) {
    }

    /**
     * Replaces the whole row for `$keyword` (matched within the current
     * tenant scope) — `researched_at`/`updated_at`/`created_at` are always
     * stamped to now, same as gs.construction's own upsert (a keyword's
     * `created_at` is "the last time this run touched it", not when it was
     * first discovered — there is no history table to preserve otherwise).
     *
     * @param  array<string, mixed>  $attributes
     */
    public function upsert(string $keyword, array $attributes): void
    {
        $now = date('Y-m-d H:i:s');
        $match = $this->matchKey($keyword);

        $this->query()->updateOrInsert($match, $attributes + [
            'researched_at' => $now,
            'updated_at' => $now,
            'created_at' => $now,
        ]);
    }

    /** @param  array<string, mixed>  $fields */
    public function updateFields(string $keyword, array $fields): void
    {
        $this->query()->where($this->matchKey($keyword))->update($fields);
    }

    public function updateOpportunity(int $id, float $opportunity): void
    {
        $this->query()->where('id', $id)->update(['opportunity' => $opportunity]);
    }

    public function find(string $keyword): ?object
    {
        return $this->query()->where($this->matchKey($keyword))->first();
    }

    /** @return list<string> keywords with at least `$min` monthly volume, highest volume first. */
    public function keywordsWithVolume(int $min = 10, int $limit = 2000): array
    {
        return $this->query()->where('volume', '>=', $min)->orderByDesc('volume')->limit($limit)->pluck('keyword')->all();
    }

    /** Every stored keyword in the current tenant scope — read by KeywordResearchCommand's `--rescore`. */
    public function all(): Collection
    {
        return $this->query()->get();
    }

    /** @return array<string, mixed> */
    private function matchKey(string $keyword): array
    {
        $match = ['keyword' => mb_substr($keyword, 0, 191)];
        if ($this->tenantColumn !== null) {
            $match[$this->tenantColumn] = ($this->tenantId)();
        }

        return $match;
    }

    private function query(): Builder
    {
        return $this->connection->table($this->table)
            ->when($this->tenantColumn !== null, fn ($q) => $q->where($this->tenantColumn, ($this->tenantId)()));
    }
}
