<?php

namespace SsSystems\Platform\Seo\KeywordResearch;

use SsSystems\Platform\Seo\Contracts\SeoSiteProfile;

/**
 * volume x distance-from-page-1 x proof, gated to real, local, on-trade
 * demand — ported from gs.construction's
 * App\Console\Commands\SeoKeywordResearch::opportunity(). That method's
 * "local" and "our trade" gates were a hardcoded remodeling lexicon
 * (`kitchen|bath|basement|addition|...`); here both gates read the site's
 * own `$profile->services()` instead, so a non-remodeling site (interior
 * design, home inspection, ...) gets gates that mean the same thing for its
 * own trade rather than gs.construction's. A site with no services
 * configured gets no trade gate at all (every keyword passes it) — it has
 * already opted out of trade-scoped research by leaving `services()` empty
 * (see KeywordSeedBuilder).
 *
 * A term we already rank 1-3 for is no opportunity; one a competitor ranks
 * for that we are absent from is the strongest signal there is real,
 * winnable intent.
 */
final class KeywordOpportunityScorer
{
    /**
     * A national head term is not an opportunity for a locally-scoped
     * business, however big the number — without a recognised town in the
     * phrase, a Search-Console-sourced keyword only counts up to this
     * volume (gs.construction's own cap).
     */
    private const VOLUME_CAP = 20000;

    public function __construct(private readonly SeoSiteProfile $profile)
    {
    }

    /**
     * @param  list<string>  $sources  e.g. ['gsc'], ['town_service'], ['competitor'] — however
     *                                 the keyword entered the universe (see KeywordResearchCommand)
     */
    public function score(int $volume, ?float $ourPosition, bool $competitorRanks, string $keyword, ?string $city, array $sources): float
    {
        if ($volume <= 0) {
            return 0.0;
        }

        $local = $city !== null || (in_array('gsc', $sources, true) && $volume <= self::VOLUME_CAP);
        $ourTrade = $this->profile->services() === [] || $this->matchesOurServices($keyword);

        if (! $local || ! $ourTrade) {
            return 0.0;
        }

        $distance = $ourPosition === null ? 1.0 : ($ourPosition <= 3 ? 0.0 : min(1.0, ($ourPosition - 3) / 17));
        $proof = $competitorRanks ? 1.3 : 1.0;

        return round($volume * $distance * $proof, 2);
    }

    private function matchesOurServices(string $keyword): bool
    {
        $q = mb_strtolower($keyword);

        foreach ($this->profile->services() as $service) {
            if (str_contains($q, mb_strtolower($service))) {
                return true;
            }
        }

        return false;
    }
}
