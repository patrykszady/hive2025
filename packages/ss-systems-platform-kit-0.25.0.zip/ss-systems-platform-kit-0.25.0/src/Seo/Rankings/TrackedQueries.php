<?php

namespace SsSystems\Platform\Seo\Rankings;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Carbon;
use SsSystems\Platform\Seo\Contracts\SeoSiteProfile;

/**
 * Everything TrackRankingsCommand needs from gsc_query_metrics for the rank
 * tracker: which queries to track, and — the same table, the same
 * tenant scope, so one class owns both reads instead of duplicating the
 * scoping logic — each one's impression-weighted Search Console position.
 *
 * resolve() prefers the site's own SeoSiteProfile::trackedQueries() (gs.
 * construction's config/seo.php `web_queries` list, carried over verbatim);
 * a site that configures none gets them derived instead: the top queries by
 * impressions over the last 28 days, plus the brand name, each stamped with
 * the profile's one locationName() since gsc_query_metrics carries no
 * per-town signal of its own to pick a better one from.
 */
final class TrackedQueries
{
    public function __construct(
        private readonly ConnectionInterface $connection,
        private readonly string $table = 'gsc_query_metrics',
        private readonly int $deriveLimit = 30,
        private readonly int $deriveWindowDays = 28,
        private readonly ?string $tenantColumn = null,
        private readonly ?\Closure $tenantId = null,
    ) {
    }

    /** @return list<array{q: string, location?: string, city_slug?: string}> */
    public function resolve(SeoSiteProfile $profile): array
    {
        $configured = $profile->trackedQueries();

        return $configured !== [] ? $configured : $this->deriveFromSearchConsole($profile);
    }

    /**
     * The impression-weighted average position gsc_query_metrics reports
     * for $query over the last $windowDays days: SUM(position *
     * impressions) / SUM(impressions), ported from gs.construction's own
     * TrackRankings. Tracked queries often carry a trailing town/state
     * token real searchers rarely type ("kitchen remodeling Palatine IL");
     * matching both the query as configured and the same string with a
     * trailing two-letter token stripped, then letting the impression-
     * weighted union decide, is the generic form of gsc's " IL"-specific
     * handling — it works the same for any state abbreviation without
     * hardcoding one.
     *
     * @return array{position: ?int, impressions: int, clicks: int}
     */
    public function weightedPosition(string $query, int $windowDays = 7): array
    {
        $lower = mb_strtolower($query);
        $stripped = preg_replace('/\s+[a-z]{2}$/', '', $lower) ?? $lower;
        $variants = array_values(array_unique([$lower, $stripped]));
        $since = Carbon::now()->subDays($windowDays - 1)->toDateString();

        $row = $this->connection->table($this->table)
            ->when($this->tenantColumn !== null, fn ($q) => $q->where($this->tenantColumn, ($this->tenantId)()))
            ->where('date', '>=', $since)
            ->whereIn('query', $variants)
            ->selectRaw('SUM(position * impressions) as weighted, SUM(impressions) as impressions, SUM(clicks) as clicks')
            ->first();

        $impressions = (int) ($row->impressions ?? 0);
        $position = $impressions > 0 ? (int) round(((float) $row->weighted) / $impressions) : null;

        return ['position' => $position, 'impressions' => $impressions, 'clicks' => (int) ($row->clicks ?? 0)];
    }

    /** @return list<array{q: string, location: string}> */
    private function deriveFromSearchConsole(SeoSiteProfile $profile): array
    {
        $since = Carbon::now()->subDays($this->deriveWindowDays)->toDateString();

        try {
            $rows = $this->connection->table($this->table)
                ->when($this->tenantColumn !== null, fn ($q) => $q->where($this->tenantColumn, ($this->tenantId)()))
                ->where('date', '>=', $since)
                ->groupBy('query')
                ->selectRaw('query, SUM(impressions) as impressions_sum')
                ->orderByDesc('impressions_sum')
                ->limit($this->deriveLimit)
                ->get();
        } catch (\Throwable) {
            $rows = collect();
        }

        $location = $profile->locationName();
        $queries = $rows->map(fn ($r) => ['q' => (string) $r->query, 'location' => $location])->all();

        $brand = trim($profile->brandName());
        $alreadyTracked = collect($queries)->contains(fn (array $q) => strcasecmp($q['q'], $brand) === 0);

        if ($brand !== '' && ! $alreadyTracked) {
            $queries[] = ['q' => $brand, 'location' => $location];
        }

        return $queries;
    }
}
