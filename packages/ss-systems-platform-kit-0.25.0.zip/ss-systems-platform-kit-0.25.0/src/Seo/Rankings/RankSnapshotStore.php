<?php

namespace SsSystems\Platform\Seo\Rankings;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Carbon;

/**
 * seo_rank_snapshots over a plain query builder (no Eloquent) — ported from
 * gs.construction's App\Models\SeoRankSnapshot, whose scopeForQuery() and
 * latestForEach() this class's forQuery()/latestRows() keep the same
 * meaning for. Single-tenant sites (jpeterson-design, dawnsellshomes) bind
 * this with no tenant column at all; gs.construction — every table scoped
 * to the current Site — passes $tenantColumn ('site_id') and $tenantId (a
 * closure read at call time, never captured once at construction), the
 * same convention as Pulse\Storage\DatabaseTableStorage and
 * Traffic\Collectors\TrackedEventsCollector.
 *
 * `top_results` and `meta` are stored as JSON text (query-builder writes
 * never get Eloquent's 'array' cast) — record()/update() encode on the way
 * in, every read method decodes on the way out, so callers always see plain
 * PHP arrays.
 */
final class RankSnapshotStore
{
    public function __construct(
        private readonly ConnectionInterface $connection,
        private readonly string $table = 'seo_rank_snapshots',
        private readonly ?string $tenantColumn = null,
        private readonly ?\Closure $tenantId = null,
    ) {
    }

    /**
     * Insert one snapshot row. `fetched_at` defaults to now when omitted;
     * `top_results`/`meta` default to an empty array.
     *
     * @param  array<string, mixed>  $attributes
     */
    public function record(array $attributes): int
    {
        $now = Carbon::now();
        $row = $attributes;

        if ($this->tenantColumn !== null) {
            $row[$this->tenantColumn] = ($this->tenantId)();
        }

        $row['top_results'] = json_encode($attributes['top_results'] ?? [], JSON_THROW_ON_ERROR);
        $row['meta'] = json_encode($attributes['meta'] ?? [], JSON_THROW_ON_ERROR);
        $row['fetched_at'] = isset($attributes['fetched_at'])
            ? Carbon::parse($attributes['fetched_at'])->toDateTimeString()
            : $now->toDateTimeString();
        $row['created_at'] = $now->toDateTimeString();
        $row['updated_at'] = $now->toDateTimeString();

        return (int) $this->connection->table($this->table)->insertGetId($row);
    }

    /**
     * Update an existing row by id (gsc_position/top_results/meta after a
     * late DataForSEO result arrives, or just meta when a queued task is
     * given up on) — tenant-scoped the same as every read, so one site can
     * never overwrite another's row even by a guessed id.
     *
     * @param  array<string, mixed>  $attributes
     */
    public function update(int $id, array $attributes): void
    {
        $row = $attributes;

        if (array_key_exists('top_results', $row)) {
            $row['top_results'] = json_encode($row['top_results'], JSON_THROW_ON_ERROR);
        }
        if (array_key_exists('meta', $row)) {
            $row['meta'] = json_encode($row['meta'], JSON_THROW_ON_ERROR);
        }
        $row['updated_at'] = Carbon::now()->toDateTimeString();

        $this->connection->table($this->table)
            ->where('id', $id)
            ->when($this->tenantColumn !== null, fn ($q) => $q->where($this->tenantColumn, ($this->tenantId)()))
            ->update($row);
    }

    /**
     * The latest row for one (engine, query, location) — gsc's
     * `scopeForQuery(...)->latest('id')->first()`. $location filters only
     * when given (a query tracked with no location at all matches on engine
     * + query alone, same as the Eloquent scope's `when($location, ...)`).
     * $beforeId restricts to rows older than a given id — the "previous
     * run" lookup `seo:show-rankings` needs for its Δ column.
     *
     * @return array<string, mixed>|null
     */
    public function forQuery(string $engine, string $query, ?string $location = null, ?int $beforeId = null): ?array
    {
        $row = $this->connection->table($this->table)
            ->where('engine', $engine)
            ->where('query', $query)
            ->when($location !== null && $location !== '', fn ($q) => $q->where('location', $location))
            ->when($this->tenantColumn !== null, fn ($q) => $q->where($this->tenantColumn, ($this->tenantId)()))
            ->when($beforeId !== null, fn ($q) => $q->where('id', '<', $beforeId))
            ->orderByDesc('id')
            ->first();

        return $row ? $this->hydrate($row) : null;
    }

    /**
     * The latest row per (engine, query, location) as of an optional
     * cutoff — gs.construction's SeoReportController `$latestRows` closure,
     * ported statement-for-statement: a correlated MAX(id) subquery grouped
     * by query/engine/location (COALESCE'd so a null location groups with
     * other null locations rather than being excluded by the equality
     * check), tenant-scoped on both the outer and the correlated row.
     * `$before` (a 'Y-m-d H:i:s' string) is `created_at <=`, matching the
     * prior-window cutoff RankingsSnapshot computes from maxCreatedAt().
     *
     * @return list<array<string, mixed>>
     */
    public function latestRows(?string $before = null): array
    {
        $query = $this->connection->table("{$this->table} as r1")
            ->selectRaw(
                'r1.id as id, r1.engine as engine, r1.query as query, r1.location as location, '
                .'r1.gsc_position as position, r1.gsc_match_title as gsc_match_title, '
                .'r1.top_results as top_results, r1.meta as meta, r1.fetched_at as fetched_at'
            );

        $tenantSql = '';
        $bindings = [];
        if ($this->tenantColumn !== null) {
            $tenantSql = " AND (r2.{$this->tenantColumn} = ? OR r2.{$this->tenantColumn} IS NULL)";
            $bindings[] = ($this->tenantId)();
        }

        $beforeSql = '';
        if ($before !== null) {
            $beforeSql = ' AND r2.created_at <= ?';
            $bindings[] = $before;
        }

        $query->whereRaw(
            'r1.id = (SELECT MAX(r2.id) FROM '.$this->table.' r2 WHERE r2.query = r1.query AND r2.engine = r1.engine'
            .' AND COALESCE(r2.location, \'\') = COALESCE(r1.location, \'\')'
            .$tenantSql.$beforeSql.')',
            $bindings,
        );

        if ($this->tenantColumn !== null) {
            $query->where(function ($q) {
                $q->where("r1.{$this->tenantColumn}", ($this->tenantId)())->orWhereNull("r1.{$this->tenantColumn}");
            });
        }

        if ($before !== null) {
            $query->where('r1.created_at', '<=', $before);
        }

        return $query->get()->map(fn ($row) => $this->hydrate($row))->all();
    }

    /** The newest created_at across every stored snapshot (tenant-scoped), or null when the table is empty. */
    public function maxCreatedAt(): ?string
    {
        return $this->connection->table($this->table)
            ->when($this->tenantColumn !== null, fn ($q) => $q->where($this->tenantColumn, ($this->tenantId)()))
            ->max('created_at');
    }

    /**
     * Rows a standard-queue check failed to answer inside its run, recent
     * enough to still be worth asking DataForSEO about again —
     * `engine = 'google'` and `meta.fetch_failed === true`, fetched within
     * `$withinDays`. meta is filtered in PHP after fetching (the same
     * approach gsc's own collectLateResults() used): a JSON predicate
     * has no portable SQL across the SQLite this suite tests against and
     * the MySQL a site runs in production.
     *
     * @return list<array<string, mixed>>
     */
    public function openFailedRows(int $withinDays = 30): array
    {
        $cutoff = Carbon::now()->subDays($withinDays)->toDateTimeString();

        $rows = $this->connection->table($this->table)
            ->where('engine', 'google')
            ->where('fetched_at', '>=', $cutoff)
            ->when($this->tenantColumn !== null, fn ($q) => $q->where($this->tenantColumn, ($this->tenantId)()))
            ->orderBy('fetched_at')
            ->get();

        return $rows->map(fn ($row) => $this->hydrate($row))
            ->filter(fn (array $row) => ($row['meta']['fetch_failed'] ?? false) === true)
            ->values()
            ->all();
    }

    /** @return array<string, mixed> */
    private function hydrate(object $row): array
    {
        $array = (array) $row;

        if (array_key_exists('top_results', $array)) {
            $array['top_results'] = json_decode((string) $array['top_results'], true) ?: [];
        }
        if (array_key_exists('meta', $array)) {
            $array['meta'] = json_decode((string) $array['meta'], true) ?: [];
        }
        if (array_key_exists('position', $array) && $array['position'] !== null) {
            $array['position'] = (int) $array['position'];
        }
        if (array_key_exists('gsc_position', $array) && $array['gsc_position'] !== null) {
            $array['gsc_position'] = (int) $array['gsc_position'];
        }

        return $array;
    }
}
