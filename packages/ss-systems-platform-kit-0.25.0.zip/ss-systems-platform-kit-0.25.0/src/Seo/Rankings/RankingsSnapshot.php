<?php

namespace SsSystems\Platform\Seo\Rankings;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Arr;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;

/**
 * The "Where You Rank in Google and Bing" report-card data, ported
 * statement-for-statement from gs.construction's
 * App\Http\Controllers\Api\Admin\V1\SeoReportController::rankingSnapshot()
 * (plus its bingRankingBuckets()/rankingQueryRows() helpers) — build()'s
 * return shape is exactly what resources/views/livewire/admin/
 * seo-reports.blade.php (ss.systems hub, lines ~860-1000) reads off `$rk`:
 * available, as_of, days, current/prior (the backward-compatible merged
 * panel), search_console, live_serp, local_pack, bing, queries. No Cache
 * here — gsc wrapped the original in `Cache::remember(...)`; the site
 * controller that calls build() does that itself, the same way every other
 * ported kit snapshot builder leaves caching to its caller.
 *
 * Two engines, by design, never agree: 'gsc' rows are Search Console's own
 * impression-weighted position (free, a little behind); 'google' rows are a
 * real DataForSEO SERP check (paid, current, the only one that ever sets
 * meta.local_pack_present). The merged current/prior panel exists only for
 * a caller still reading the older single-panel shape — it prefers the
 * 'google' row over 'gsc' when a query has both, so a dual-tracked query is
 * never double-counted.
 */
final class RankingsSnapshot
{
    public function __construct(
        private readonly RankSnapshotStore $store,
        private readonly ConnectionInterface $connection,
        private readonly string $bingTable = 'bing_traffic_stats',
        private readonly ?string $tenantColumn = null,
        private readonly ?\Closure $tenantId = null,
    ) {
    }

    /** @return array<string, mixed> */
    public function build(int $daysBack = 7): array
    {
        $asOfRaw = $this->store->maxCreatedAt();
        $priorCutoff = $asOfRaw !== null ? Carbon::parse($asOfRaw)->subDays($daysBack)->toDateTimeString() : null;

        $currentRows = collect($this->store->latestRows(null));
        $priorRows = collect($this->store->latestRows($priorCutoff));

        $currentByEngine = $currentRows->groupBy('engine');
        $priorByEngine = $priorRows->groupBy('engine');

        $searchConsoleCurrent = $this->bucket($currentByEngine->get('gsc', collect()));
        $searchConsolePrior = $this->bucket($priorByEngine->get('gsc', collect()));
        $liveSerpCurrent = $this->bucket($currentByEngine->get('google', collect()));
        $liveSerpPrior = $this->bucket($priorByEngine->get('google', collect()));

        $dedupeByQuery = fn (Collection $rows): Collection => $rows->groupBy('query')
            ->map(fn (Collection $g) => $g->firstWhere('engine', 'google') ?? $g->first())
            ->values();

        $mergedCurrent = $this->bucket($dedupeByQuery($currentRows));
        $mergedPrior = $this->bucket($dedupeByQuery($priorRows));

        $strip = fn (array $d): array => Arr::except($d, 'local_pack_pct');

        return [
            'available' => $mergedCurrent['tracked'] > 0,
            'as_of' => $asOfRaw !== null ? Carbon::parse($asOfRaw)->toDateString() : null,
            'days' => $daysBack,
            'current' => $strip($mergedCurrent),
            'prior' => $strip($mergedPrior),
            'search_console' => [
                'label' => 'Google Search Console',
                'current' => $strip($searchConsoleCurrent),
                'prior' => $strip($searchConsolePrior),
            ],
            'live_serp' => [
                'label' => 'Live Google SERP',
                'current' => $strip($liveSerpCurrent),
                'prior' => $strip($liveSerpPrior),
            ],
            'local_pack' => [
                'current' => $liveSerpCurrent['local_pack_pct'],
                'prior' => $liveSerpPrior['local_pack_pct'],
            ],
            'bing' => $this->bingBuckets($daysBack),
            'queries' => $this->queryRows($currentRows, $priorRows),
        ];
    }

    /**
     * @param  Collection<int, array<string, mixed>>  $rows
     * @return array{tracked: int, top3: int, top10: int, top20: int, below20: int, local_pack_pct: float}
     */
    private function bucket(Collection $rows): array
    {
        $within = fn (int $max): int => $rows->filter(fn (array $r) => $r['position'] !== null && $r['position'] <= $max)->count();
        $total = $rows->count();
        $top20 = $within(20);
        $withLocalPack = $rows->filter(fn (array $r) => ($r['meta']['local_pack_present'] ?? false) === true)->count();

        return [
            'tracked' => $total,
            'top3' => $within(3),
            'top10' => $within(10),
            'top20' => $top20,
            'below20' => max(0, $total - $top20),
            'local_pack_pct' => $total > 0 ? round(100 * $withLocalPack / $total, 1) : 0.0,
        ];
    }

    /**
     * @param  Collection<int, array<string, mixed>>  $current
     * @param  Collection<int, array<string, mixed>>  $prior
     * @return list<array<string, mixed>>
     */
    private function queryRows(Collection $current, Collection $prior): array
    {
        $priorByKey = $prior->keyBy(fn (array $r) => $r['engine'].'|'.$r['query']);

        return $current->map(function (array $r) use ($priorByKey) {
            $priorRow = $priorByKey->get($r['engine'].'|'.$r['query']);

            return [
                'query' => $r['query'],
                'engine' => $r['engine'],
                'position' => $r['position'],
                'position_prev' => $priorRow['position'] ?? null,
                'top_results' => array_slice(array_values($r['top_results'] ?? []), 0, 5),
                'matched_url' => $r['meta']['matched_url'] ?? null,
                'local_pack_present' => ($r['meta']['local_pack_present'] ?? false) === true,
            ];
        })->sortBy([['engine', 'asc'], ['query', 'asc']])->values()->all();
    }

    /**
     * Where we rank on Bing: each query's average position over the last
     * $daysBack days Bing has reported, bucketed like the Google panels,
     * against the $daysBack days before. Bing is not in seo_rank_snapshots
     * (no live check, no tracker) — bing_traffic_stats' own daily query
     * report is the source, so a query counts once per window whatever days
     * it appeared on. Null on a site with no Bing data at all.
     *
     * @return array{label: string, as_of: string, current: array<string, int>, prior: array<string, int>}|null
     */
    private function bingBuckets(int $daysBack): ?array
    {
        try {
            if (! $this->connection->getSchemaBuilder()->hasTable($this->bingTable)) {
                return null;
            }
        } catch (\Throwable) {
            return null;
        }

        $base = fn () => $this->connection->table($this->bingTable)
            ->when($this->tenantColumn !== null, fn ($q) => $q->where($this->tenantColumn, ($this->tenantId)()))
            ->where('position', '>', 0);

        $latest = $base()->max('date');
        if ($latest === null) {
            return null;
        }

        $end = Carbon::parse($latest);
        $positions = fn (Carbon $from, Carbon $to): Collection => $base()
            ->whereBetween('date', [$from->toDateString(), $to->toDateString()])
            ->groupBy('query')
            ->selectRaw('query, AVG(position) as position')
            ->get();

        $bucket = function (Collection $rows): array {
            $within = fn (int $max): int => $rows->filter(fn ($r) => (float) $r->position <= $max)->count();
            $total = $rows->count();
            $top20 = $within(20);

            return [
                'tracked' => $total,
                'top3' => $within(3),
                'top10' => $within(10),
                'top20' => $top20,
                'below20' => max(0, $total - $top20),
            ];
        };

        return [
            'label' => 'Bing',
            'as_of' => $end->toDateString(),
            'current' => $bucket($positions($end->copy()->subDays($daysBack - 1), $end)),
            'prior' => $bucket($positions($end->copy()->subDays(2 * $daysBack - 1), $end->copy()->subDays($daysBack))),
        ];
    }
}
