<?php

namespace SsSystems\Platform\Seo\Rankings\Console;

use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Str;
use SsSystems\Platform\Seo\Rankings\RankSnapshotStore;

/**
 * `seo:show-rankings` — ported from gs.construction's own
 * App\Console\Commands\ShowRankings: the latest stored snapshot per
 * (engine, query, location), each with its delta against the run before it.
 *
 * gsc's `--competitors` flag rendered one column per name in its own
 * keyed `config('seo.rank_tracker.competitor_patterns')` ('airoom' =>
 * [...patterns]); SeoSiteProfile::competitorPatterns() is a flat list of
 * patterns with no per-competitor label to hang a column on, so here
 * `--competitors` instead prints which of those patterns matched inside
 * each row's own meta['competitors'] (written by whatever populates that —
 * out of this port's scope, same as gsc's own SeoMapPackGrid), one
 * comma-joined column rather than one column per name.
 */
class ShowRankingsCommand extends Command
{
    /** @var string */
    protected $signature = 'seo:show-rankings
        {--engine= : gsc | google}
        {--competitors : Show which competitor patterns matched per query}';

    /** @var string */
    protected $description = 'Print the latest stored ranking snapshots, including delta vs the previous run.';

    public function handle(): int
    {
        /** @var RankSnapshotStore $store */
        $store = $this->laravel->make(RankSnapshotStore::class);

        $engine = $this->option('engine');
        $showCompetitors = (bool) $this->option('competitors');

        $latest = collect($store->latestRows(null))
            ->when($engine, fn ($c) => $c->where('engine', $engine))
            ->sortBy([['engine', 'asc'], ['query', 'asc']])
            ->values();

        if ($latest->isEmpty()) {
            $this->warn('No rank snapshots yet. Run: php artisan seo:track-rankings');

            return self::SUCCESS;
        }

        if ($showCompetitors) {
            return $this->renderCompetitors($latest);
        }

        $rows = $latest->map(function (array $s) use ($store) {
            $prev = $store->forQuery($s['engine'], $s['query'], $s['location'], beforeId: $s['id']);

            $delta = '—';
            if ($prev && $prev['gsc_position'] !== null && $s['position'] !== null) {
                $d = $prev['gsc_position'] - $s['position'];
                $delta = $d === 0 ? '=' : ($d > 0 ? "▲{$d}" : '▼'.abs($d));
            } elseif ($s['position'] !== null && $prev && $prev['gsc_position'] === null) {
                $delta = 'NEW';
            } elseif ($s['position'] === null && $prev && $prev['gsc_position'] !== null) {
                $delta = 'DROPPED';
            }

            return [
                $s['engine'],
                $s['query'],
                $s['location'] ?? '',
                $s['position'] === null ? '—' : '#'.$s['position'],
                $delta,
                $s['gsc_match_title'] ?? '',
                $s['fetched_at'] ? Carbon::parse($s['fetched_at'])->diffForHumans() : '',
            ];
        })->all();

        $this->table(['Engine', 'Query', 'Location', 'Pos', 'Δ', 'Matched as', 'When'], $rows);

        return self::SUCCESS;
    }

    /** @param  Collection<int, array<string, mixed>>  $latest */
    private function renderCompetitors(Collection $latest): int
    {
        $rows = $latest->map(fn (array $s) => [
            $s['engine'],
            Str::limit($s['query'], 38, ''),
            $s['position'] === null ? '—' : '#'.$s['position'],
            implode(', ', array_keys((array) ($s['meta']['competitors'] ?? []))) ?: '—',
        ])->all();

        $this->table(['Engine', 'Query', 'Us', 'Competitors matched'], $rows);

        return self::SUCCESS;
    }
}
