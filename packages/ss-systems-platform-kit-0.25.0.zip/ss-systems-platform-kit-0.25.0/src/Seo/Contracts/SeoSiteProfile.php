<?php

namespace SsSystems\Platform\Seo\Contracts;

/**
 * What the SEO tools need to know about the business they work for, bound
 * by each site (gs.construction from its config/seo.php, J. Peterson from
 * config + its service list). Everything here has a sensible empty: a site
 * that lists no tracked queries gets them from its own Search Console top
 * queries; no coordinates means no map-pack grid; no services means
 * keyword ideas are seeded from the top queries alone.
 */
interface SeoSiteProfile
{
    /** The live host without "www." — 'jpeterson-design.com'. */
    public function domain(): string;

    /** The business name as people search for it — 'J. Peterson Design'. */
    public function brandName(): string;

    /**
     * Case-insensitive regex fragments that identify THIS business in a
     * search or maps result title/host ('j\.?\s*peterson', 'jpeterson-design').
     *
     * @return list<string>
     */
    public function brandPatterns(): array;

    /**
     * Known competitors (host or name fragments) worth watching.
     *
     * @return list<string>
     */
    public function competitorPatterns(): array;

    /**
     * Hosts that are never a competitor: directories, aggregators, social
     * networks (yelp.com, houzz.com, angi.com, facebook.com …).
     *
     * @return list<string>
     */
    public function competitorExclusions(): array;

    /** DataForSEO location_name for live searches — 'Palatine,Illinois,United States'. */
    public function locationName(): string;

    public function latitude(): ?float;

    public function longitude(): ?float;

    /**
     * Searches to track every week. Empty = the tools derive them from the
     * site's own Search Console data (top queries by impressions).
     *
     * @return list<array{q: string, location?: string, city_slug?: string}>
     */
    public function trackedQueries(): array;

    /**
     * Searches to scan on the map-pack grid ('kitchen remodeling').
     *
     * @return list<string>
     */
    public function mapsQueries(): array;

    /**
     * The services the business sells, as search phrases — keyword-idea
     * seeds and AI-mention prompts ('kitchen remodeling', 'interior design').
     *
     * @return list<string>
     */
    public function services(): array;

    /**
     * Towns the business serves, for location-flavoured prompts and queries.
     *
     * @return list<string>
     */
    public function towns(): array;
}
