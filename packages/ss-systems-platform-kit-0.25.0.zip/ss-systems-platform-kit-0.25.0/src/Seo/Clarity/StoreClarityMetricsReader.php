<?php

namespace SsSystems\Platform\Seo\Clarity;

use SsSystems\Platform\Reports\Contracts\ClarityMetricsReader;
use SsSystems\Platform\Seo\Clarity\Contracts\ClarityCredentials;

/**
 * The `clarity_metrics` capability (ClarityHealthReport) over the kit's own
 * client and store: a site binds ClarityMetricsReader to this class and
 * writes no reader of its own. The JS-error beacon count is the one thing
 * that lives in a site's own tables (gs.construction's client_errors); a
 * site with a beacon passes a closure, the others report 0.
 */
final class StoreClarityMetricsReader implements ClarityMetricsReader
{
    /**
     * @param  \Closure(\DateTimeInterface): int|null  $beaconErrorCount
     */
    public function __construct(
        private readonly ClarityClient $client,
        private readonly ClarityMetricsStore $store,
        private readonly ClarityCredentials $credentials,
        private readonly ?\Closure $beaconErrorCount = null,
    ) {
    }

    public function isConfigured(): bool
    {
        return $this->credentials->isConfigured();
    }

    public function projectId(): ?string
    {
        return $this->credentials->projectId();
    }

    public function fetchLiveSnapshot(): ?array
    {
        return $this->client->dailySnapshot(ClarityClient::MAX_DAYS);
    }

    public function lastError(): ?string
    {
        return $this->client->lastError();
    }

    public function latestStoredMetric(): ?array
    {
        return $this->store->latestDay((string) $this->credentials->projectId());
    }

    public function storedRowCount(): int
    {
        return $this->store->dayCount((string) $this->credentials->projectId());
    }

    public function baselineMetrics(string $beforeDate, int $limit): array
    {
        return $this->store->daysBefore((string) $this->credentials->projectId(), $beforeDate, $limit);
    }

    public function beaconErrorCount(\DateTimeInterface $since): int
    {
        return $this->beaconErrorCount !== null ? (int) ($this->beaconErrorCount)($since) : 0;
    }
}
