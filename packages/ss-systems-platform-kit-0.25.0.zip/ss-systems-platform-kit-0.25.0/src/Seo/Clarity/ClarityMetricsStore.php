<?php

namespace SsSystems\Platform\Seo\Clarity;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Database\Query\Builder;
use Illuminate\Database\QueryException;
use Illuminate\Support\Carbon;

/**
 * clarity_daily_metrics (one site-wide row per project per day) and the
 * optional clarity_page_metrics (one row per path per day), over a plain
 * query builder. Keeps gs.construction's upsert meaning — a same-day
 * re-sync overwrites the day's row — and matches days with whereDate(),
 * because rows an Eloquent `date` cast wrote read 'Y-m-d 00:00:00' on
 * SQLite while MySQL's DATE column stores 'Y-m-d'.
 *
 * Tenant-scoped like PsiSnapshotStore: single-tenant sites pass no tenant
 * column; gs.construction passes 'site_id' and a closure that reads the
 * current tenant at call time.
 */
final class ClarityMetricsStore
{
    private const DAY_COLUMNS = ['sessions', 'users', 'pageviews', 'scroll_depth', 'active_time_seconds', 'bounce_rate', 'dead_clicks', 'rage_clicks', 'quickbacks', 'script_errors', 'error_clicks'];

    private const PAGE_COLUMNS = ['path', 'sessions', 'rage_clicks', 'dead_clicks', 'quickbacks', 'script_errors', 'scroll_depth'];

    public function __construct(
        private readonly ConnectionInterface $connection,
        private readonly string $dailyTable = 'clarity_daily_metrics',
        private readonly string $pageTable = 'clarity_page_metrics',
        private readonly ?string $tenantColumn = null,
        private readonly ?\Closure $tenantId = null,
    ) {
    }

    public function hasDailyTable(): bool
    {
        return $this->hasTable($this->dailyTable);
    }

    /** Only gs.construction keeps the per-page breakdown so far; the sync skips it where the table is missing. */
    public function hasPageTable(): bool
    {
        return $this->hasTable($this->pageTable);
    }

    /** @param  array<string, mixed>  $row  one ClarityClient::dailySnapshot() row */
    public function recordDay(string $projectId, array $row): void
    {
        $values = array_intersect_key($row, array_flip(self::DAY_COLUMNS));
        $this->upsert($this->dailyTable, ['project_id' => $projectId], (string) $row['date'], $values);
    }

    /** @param  array<string, mixed>  $row  one ClarityClient::pageMetrics() row */
    public function recordPage(string $projectId, array $row): void
    {
        $values = array_intersect_key($row, array_flip(self::PAGE_COLUMNS));
        $this->upsert($this->pageTable, ['project_id' => $projectId, 'path_hash' => self::hashPath((string) $row['path'])], (string) $row['date'], $values);
    }

    public static function hashPath(string $path): string
    {
        return sha1($path);
    }

    /**
     * @return array{date: string, sessions: int, users: int, pageviews: int, scroll_depth: float, active_time_seconds: int, bounce_rate: float, dead_clicks: int, rage_clicks: int, quickbacks: int, script_errors: int, error_clicks: int}|null
     */
    public function latestDay(string $projectId): ?array
    {
        if (! $this->hasDailyTable()) {
            return null;
        }

        $row = $this->days($projectId)->orderByDesc('date')->first();

        return $row ? self::dayArray($row) : null;
    }

    public function dayCount(string $projectId): int
    {
        return $this->hasDailyTable() ? $this->days($projectId)->count() : 0;
    }

    /**
     * Up to $limit days strictly before $beforeDate, most recent first.
     *
     * @return list<array{sessions: int, script_errors: int}>
     */
    public function daysBefore(string $projectId, string $beforeDate, int $limit): array
    {
        if (! $this->hasDailyTable()) {
            return [];
        }

        return $this->days($projectId)
            ->whereDate('date', '<', $beforeDate)
            ->orderByDesc('date')
            ->limit($limit)
            ->get(['sessions', 'script_errors'])
            ->map(static fn ($row): array => ['sessions' => (int) $row->sessions, 'script_errors' => (int) $row->script_errors])
            ->values()
            ->all();
    }

    /**
     * @param  array<string, string>  $keys
     * @param  array<string, mixed>  $values
     */
    private function upsert(string $table, array $keys, string $date, array $values): void
    {
        $date = substr($date, 0, 10);
        $values['updated_at'] = Carbon::now();

        $existing = fn (): Builder => $this->scoped($this->connection->table($table)->where($keys)->whereDate('date', $date));

        if ($existing()->exists()) {
            $existing()->update($values);

            return;
        }

        $row = $keys + ['date' => $date] + $values + ['created_at' => Carbon::now()];
        if ($this->tenantColumn !== null) {
            $row[$this->tenantColumn] = ($this->tenantId)();
        }

        try {
            $this->connection->table($table)->insert($row);
        } catch (QueryException) {
            $existing()->update($values);
        }
    }

    private function days(string $projectId): Builder
    {
        return $this->scoped($this->connection->table($this->dailyTable)->where('project_id', $projectId));
    }

    private function scoped(Builder $query): Builder
    {
        if ($this->tenantColumn !== null) {
            $query->where($this->tenantColumn, ($this->tenantId)());
        }

        return $query;
    }

    private function hasTable(string $table): bool
    {
        try {
            return $this->connection->getSchemaBuilder()->hasTable($table);
        } catch (\Throwable) {
            return false;
        }
    }

    /**
     * @return array{date: string, sessions: int, users: int, pageviews: int, scroll_depth: float, active_time_seconds: int, bounce_rate: float, dead_clicks: int, rage_clicks: int, quickbacks: int, script_errors: int, error_clicks: int}
     */
    private static function dayArray(object $row): array
    {
        return [
            'date' => substr((string) $row->date, 0, 10),
            'sessions' => (int) $row->sessions,
            'users' => (int) $row->users,
            'pageviews' => (int) $row->pageviews,
            'scroll_depth' => (float) $row->scroll_depth,
            'active_time_seconds' => (int) $row->active_time_seconds,
            'bounce_rate' => (float) $row->bounce_rate,
            'dead_clicks' => (int) $row->dead_clicks,
            'rage_clicks' => (int) $row->rage_clicks,
            'quickbacks' => (int) $row->quickbacks,
            'script_errors' => (int) ($row->script_errors ?? 0),
            'error_clicks' => (int) ($row->error_clicks ?? 0),
        ];
    }
}
