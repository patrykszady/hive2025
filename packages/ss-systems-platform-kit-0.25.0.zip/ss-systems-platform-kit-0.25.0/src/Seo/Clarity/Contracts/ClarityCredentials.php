<?php

namespace SsSystems\Platform\Seo\Clarity\Contracts;

/**
 * A site's Microsoft Clarity project id and Data Export API token. Every
 * site already has a ClaritySettings class with exactly these three
 * methods (admin-stored value first, config() as the fallback); it
 * implements this contract and is bound to it, and the kit's Clarity
 * module reads nothing else.
 */
interface ClarityCredentials
{
    public function projectId(): ?string;

    public function apiToken(): ?string;

    /** Both the project id and the API token are present. */
    public function isConfigured(): bool;
}
