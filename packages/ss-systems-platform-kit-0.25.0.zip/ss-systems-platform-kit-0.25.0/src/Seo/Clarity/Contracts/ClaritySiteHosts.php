<?php

namespace SsSystems\Platform\Seo\Clarity\Contracts;

/**
 * The hosts that count as this site in Clarity's per-page export. The
 * project's tag also fires on local dev and preview tunnels, so the URL
 * breakdown carries rows for hosts that are not the site; only these are
 * kept. Optional: without a binding the sync falls back to the bound
 * SeoSiteProfile's domain().
 */
interface ClaritySiteHosts
{
    /** @return list<string> lowercased, with or without a leading www */
    public function hosts(): array;
}
