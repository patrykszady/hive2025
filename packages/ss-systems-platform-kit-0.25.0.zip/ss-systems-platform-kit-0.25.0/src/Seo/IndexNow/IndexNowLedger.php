<?php

namespace SsSystems\Platform\Seo\IndexNow;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Database\Query\Builder;
use Illuminate\Database\QueryException;
use Illuminate\Support\Carbon;

/**
 * The one read/write path to `indexnow_submissions` — "what have we already
 * told Bing (IndexNow) about", the same role `AiTrafficStore` and
 * `MapPackStore` play for their own tables, and built to the same
 * conventions throughout (the race-safe upsert, `scoped()`, tenant args).
 *
 * Exists so `Console\IndexNowCommand`'s hourly tick resubmits only pages
 * that are new or changed since the last run, instead of dawnsellshomes'
 * `SubmitSitemap --recent` (its own cache-based "what changed" heuristic)
 * or ss-systems' `IndexNowSubmit` (`App\Support\PublicPages::recordChanges()`)
 * — both reinvented this per site. `--all` (the deploy line) bypasses the
 * ledger entirely and treats every URL as due, so a deploy always resyncs
 * the whole site regardless of what this table remembers.
 *
 * Tenant-scoped exactly like `AiTrafficStore`/`MapPackStore`: a
 * single-tenant site passes neither `$tenantColumn` nor `$tenantId`; a
 * multi-tenant site passes `'site_id'` and a closure reading the current
 * tenant at call time (never captured once at construction, since the
 * bound singleton outlives any one request's tenant in a queue worker).
 *
 * Missing table reads as "nothing recorded" the same way `AiTrafficStore::totals()`
 * and `MapPackStore`'s read methods do: `due()` returns `[]` rather than
 * guessing, and `recordSubmitted()` is a silent no-op — a site that hasn't
 * copied the stub into its own migrations yet gets "no ledger" rather than
 * a crash, it just also never dedupes until it does.
 */
final class IndexNowLedger
{
    public function __construct(
        private readonly ConnectionInterface $connection,
        private readonly string $table = 'indexnow_submissions',
        private readonly ?string $tenantColumn = null,
        private readonly ?\Closure $tenantId = null,
    ) {}

    public function hasTable(): bool
    {
        try {
            return $this->connection->getSchemaBuilder()->hasTable($this->table);
        } catch (\Throwable) {
            return false;
        }
    }

    /**
     * Every URL due for submission: all of them when `$all` is true
     * (`--all`, the deploy line, ignores this ledger completely); otherwise
     * a URL this ledger has never recorded, or one whose `lastmod` is
     * strictly newer than the `lastmod` recorded for it last time. A page
     * with no `<lastmod>` (or one recorded with none) can never be judged
     * "newer" — it is due only the first time, exactly like gsc's
     * `ReindexApplier` prefers an honest unknown over a confident guess.
     *
     * @param  list<array{url: string, lastmod: ?string}>  $pages
     * @return list<string>
     */
    public function due(array $pages, bool $all = false): array
    {
        if ($pages === []) {
            return [];
        }

        if ($all) {
            return array_values(array_unique(array_column($pages, 'url')));
        }

        if (! $this->hasTable()) {
            return [];
        }

        $urls = array_values(array_unique(array_column($pages, 'url')));

        /** @var array<string, ?string> $recordedLastmodByUrl */
        $recordedLastmodByUrl = $this->scoped(
            $this->connection->table($this->table)->whereIn('url', $urls)
        )
            ->get(['url', 'lastmod'])
            ->mapWithKeys(static fn (object $row): array => [(string) $row->url => $row->lastmod !== null ? (string) $row->lastmod : null])
            ->all();

        $due = [];
        $seen = [];

        foreach ($pages as $page) {
            $url = $page['url'];
            if (isset($seen[$url])) {
                continue;
            }
            $seen[$url] = true;

            if (! array_key_exists($url, $recordedLastmodByUrl)) {
                $due[] = $url;

                continue;
            }

            if (self::isNewer($page['lastmod'], $recordedLastmodByUrl[$url])) {
                $due[] = $url;
            }
        }

        return $due;
    }

    /**
     * Records that `$urls` were just submitted, with the `lastmod` each one
     * carried at submission time — the next `due()` call compares against
     * these values. A no-op when the table is missing.
     *
     * @param  list<string>  $urls
     * @param  array<string, ?string>  $lastmodByUrl
     */
    public function recordSubmitted(array $urls, array $lastmodByUrl, string $status): void
    {
        if ($urls === [] || ! $this->hasTable()) {
            return;
        }

        $now = Carbon::now();

        foreach (array_unique($urls) as $url) {
            $url = mb_substr($url, 0, 500);
            $lastmod = $lastmodByUrl[$url] ?? null;
            $match = ['url' => $url];

            $updated = $this->scoped($this->connection->table($this->table)->where($match))->update([
                'lastmod' => $lastmod,
                'submitted_at' => $now,
                'last_status' => $status,
                'updated_at' => $now,
            ]);

            if ($updated > 0) {
                continue;
            }

            $row = $this->tenantColumn !== null ? [...$match, $this->tenantColumn => ($this->tenantId)()] : $match;
            $row = [...$row, 'lastmod' => $lastmod, 'submitted_at' => $now, 'last_status' => $status, 'created_at' => $now, 'updated_at' => $now];

            try {
                $this->connection->table($this->table)->insert($row);
            } catch (QueryException) {
                // Race with another process inserting the same (site_id, url)
                // between our failed update and this insert — same pattern as
                // AiTrafficStore::record()/MapPackStore::upsert().
                $this->scoped($this->connection->table($this->table)->where($match))->update([
                    'lastmod' => $lastmod,
                    'submitted_at' => $now,
                    'last_status' => $status,
                    'updated_at' => $now,
                ]);
            }
        }
    }

    private static function isNewer(?string $current, ?string $recorded): bool
    {
        if ($current === null || $recorded === null) {
            return false;
        }

        $currentTime = strtotime($current);
        $recordedTime = strtotime($recorded);

        if ($currentTime === false || $recordedTime === false) {
            return false;
        }

        return $currentTime > $recordedTime;
    }

    private function scoped(Builder $query): Builder
    {
        if ($this->tenantColumn !== null) {
            $query->where($this->tenantColumn, ($this->tenantId)());
        }

        return $query;
    }
}
