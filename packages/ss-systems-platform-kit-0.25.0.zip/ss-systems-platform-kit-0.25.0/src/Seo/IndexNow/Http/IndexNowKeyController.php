<?php

namespace SsSystems\Platform\Seo\IndexNow\Http;

use Illuminate\Http\Response;
use SsSystems\Platform\Seo\IndexNow\Contracts\IndexNowKey;

/**
 * `GET /{key}.txt` — IndexNow/Bing fetch this before accepting any
 * submission signed with `$key`, to prove the site that claims the key
 * actually controls the host. Ported from jpeterson-design's identical
 * closure route (`routes/web.php`, originally copied from gsc's own) into a
 * reusable controller: a site adds one route —
 *
 *   Route::get('/{key}.txt', IndexNowKeyController::class)->where('key', '[a-z0-9-]{8,128}');
 *
 * — registration order relative to a catch-all route only matters if that
 * route's own slug regex would also match "{key}.txt" (it won't, if that
 * regex excludes the dot the way jpeterson-design's `/{market}` route's
 * `[a-z0-9-]+` does); see that site's route for the full reasoning.
 */
final class IndexNowKeyController
{
    public function __construct(
        private readonly IndexNowKey $key,
    ) {}

    public function __invoke(string $key): Response
    {
        $configured = $this->key->key();

        if ($configured === null || $configured === '' || ! hash_equals($configured, $key)) {
            return new Response('', 404);
        }

        return new Response($configured, 200, ['Content-Type' => 'text/plain; charset=UTF-8']);
    }
}
