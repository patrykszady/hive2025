<?php

namespace SsSystems\Platform\Seo\IndexNow;

use Illuminate\Http\Client\Factory;

/**
 * POSTs {host, key, keyLocation, urlList} to IndexNow
 * (https://www.indexnow.org) — Bing, Yandex, Seznam and Naver all answer
 * behind the one shared endpoint; Google never joined IndexNow (see
 * gsc's `ReindexApplier` docblock for how costly that confusion got there).
 *
 * Replaces jpeterson-design's `App\Jobs\SubmitUrlsToIndexNow` +
 * `App\Support\IndexNowUrls`'s dispatch half, dawnsellshomes'
 * `SubmitSitemap`'s inline `Http::post(...)` block, and ss-systems'
 * `IndexNowService` (`src/Indexing/IndexNowService.php`) — all three built
 * the same request by hand. This class owns only the HTTP call and its
 * batching; a site's own per-model "what changed" logic
 * (`IndexNowUrls`-style hooks) stays site-side and feeds `Console\IndexNowCommand`
 * or this client directly.
 *
 * IndexNow's documented cap is 10,000 URLs per request; the default batch
 * size here is a tenth of that ($batchSize = 1,000) to stay gentle with the
 * shared endpoint — a site that wants the full cap can pass it explicitly,
 * still clamped to 10,000.
 *
 * Never throws: a batch that raises (network error) or answers 4xx/5xx is
 * recorded in the returned `failures` list and `lastError()`, exactly the
 * "never fail a deployment because a search engine was unreachable"
 * discipline dawnsellshomes' `SubmitSitemap` already followed inline.
 */
final class IndexNowClient
{
    public const ENDPOINT = 'https://api.indexnow.org/indexnow';

    private const DEFAULT_BATCH_SIZE = 1_000;

    private const MAX_BATCH_SIZE = 10_000;

    private ?string $lastError = null;

    public function __construct(
        private readonly Factory $http,
        private readonly int $timeoutSeconds = 30,
        private readonly int $batchSize = self::DEFAULT_BATCH_SIZE,
    ) {}

    /**
     * @param  list<string>  $urls
     * @return array{accepted: int, batches: int, failures: list<string>}
     */
    public function submit(string $host, array $urls, string $key, string $keyLocation): array
    {
        $urls = array_values(array_unique(array_filter(
            array_map('trim', $urls),
            static fn (string $url): bool => $url !== '',
        )));

        $this->lastError = null;

        if ($urls === [] || trim($host) === '' || trim($key) === '') {
            return ['accepted' => 0, 'batches' => 0, 'failures' => []];
        }

        $batchSize = max(1, min(self::MAX_BATCH_SIZE, $this->batchSize));
        $chunks = array_chunk($urls, $batchSize);

        $accepted = 0;
        $failures = [];

        foreach ($chunks as $chunk) {
            try {
                $response = $this->http->timeout($this->timeoutSeconds)->post(self::ENDPOINT, [
                    'host' => $host,
                    'key' => $key,
                    'keyLocation' => $keyLocation,
                    'urlList' => array_values($chunk),
                ]);
            } catch (\Throwable $e) {
                $failures[] = $e->getMessage();
                $this->lastError = $e->getMessage();

                continue;
            }

            // IndexNow answers 200 OK or 202 Accepted on success; Response::successful()
            // already covers both (2xx), spelled out here since 202 is the
            // documented, expected case rather than an edge one.
            if ($response->successful() || $response->status() === 202) {
                $accepted += count($chunk);

                continue;
            }

            $error = 'HTTP '.$response->status().': '.mb_substr(trim($response->body()), 0, 300);
            $failures[] = $error;
            $this->lastError = $error;
        }

        return ['accepted' => $accepted, 'batches' => count($chunks), 'failures' => $failures];
    }

    public function lastError(): ?string
    {
        return $this->lastError;
    }
}
