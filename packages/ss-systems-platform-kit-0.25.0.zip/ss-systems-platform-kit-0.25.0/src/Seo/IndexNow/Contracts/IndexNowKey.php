<?php

namespace SsSystems\Platform\Seo\IndexNow\Contracts;

/**
 * Where a site's IndexNow key and key file live — bound per site, the same
 * shape every other kit contract uses (`PageSpeedCredentials`,
 * `BingWebmasterClient`…): the kit never reads config() for a site fact
 * itself. A single-tenant site binds this straight from config/env
 * (jpeterson-design's `config('indexnow.key')`); a multi-tenant admin binds
 * it from a platform setting per tenant, the same way `AiTrafficStore`'s
 * tenant column is a closure rather than a captured value.
 *
 * `key()` returns null when IndexNow isn't configured yet —
 * `Console\IndexNowCommand` treats that as "exit 1, clear message" rather
 * than silently doing nothing, since a deploy step that silently no-ops on
 * a missing key is exactly the kind of failure that goes unnoticed for
 * months. (2026-11-02)
 */
interface IndexNowKey
{
    /** 8–128 characters of [a-z0-9-], or null when no key is configured yet. */
    public function key(): ?string;

    /**
     * Absolute URL of the key file IndexNow/Bing fetch to verify ownership
     * before accepting a submission signed with this key —
     * 'https://example.com/<key>.txt'. `Console\IndexNowCommand` also reads
     * this URL's host as the default `--host` when none is given.
     */
    public function keyLocation(): string;
}
