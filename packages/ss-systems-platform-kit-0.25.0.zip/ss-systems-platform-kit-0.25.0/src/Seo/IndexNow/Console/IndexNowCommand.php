<?php

namespace SsSystems\Platform\Seo\IndexNow\Console;

use Illuminate\Console\Command;
use Illuminate\Http\Client\Factory;
use SsSystems\Platform\Seo\IndexNow\Contracts\IndexNowKey;
use SsSystems\Platform\Seo\IndexNow\IndexNowClient;
use SsSystems\Platform\Seo\IndexNow\IndexNowLedger;
use SsSystems\Platform\Seo\IndexNow\SitemapCrawler;

/**
 * `seo:indexnow` — tells Bing/Yandex/Seznam/Naver (IndexNow) which of the
 * site's pages are new or changed, so the next crawl finds them without
 * waiting on the engine's own schedule. Two ways to run it:
 *
 *   - hourly, with no flags: only URLs `IndexNowLedger::due()` says are new
 *     or changed since the last tick.
 *   - `--all` on every deploy: resubmit the whole sitemap regardless of
 *     what the ledger remembers — a deploy can change a page's content
 *     without touching its `<lastmod>` (a template change, for instance),
 *     so the deploy line cannot rely on the incremental check at all.
 *
 * Replaces jpeterson-design's `config/indexnow.php` + its key-file route +
 * `App\Jobs\SubmitUrlsToIndexNow` + `App\Support\IndexNowUrls`,
 * dawnsellshomes' `sitemap:submit` (the IndexNow half — its Google Search
 * Console sitemap-ping half has no equivalent here and stays site-side),
 * and ss-systems' `seo:indexnow-submit` — three separate "build the sitemap
 * URL list, diff against what changed, POST it" implementations collapsed
 * into one command plus `SitemapCrawler` + `IndexNowLedger` + `IndexNowClient`.
 *
 * `IndexNowKey`, `IndexNowClient`, `IndexNowLedger` and `Illuminate\Http\Client\Factory`
 * are resolved from the container — a site binds `IndexNowKey` to its own
 * config/platform-setting source and (optionally) `IndexNowClient`/`IndexNowLedger`
 * as singletons if it wants non-default batch sizes or tenant scoping;
 * `SitemapCrawler` is resolved the same way but needs no site-specific
 * binding at all (autowires from the bound `Factory`).
 *
 * Sitemap discovery: `--sitemap` (repeatable) pins the list explicitly;
 * otherwise this fetches `https://<host>/robots.txt` and reads every
 * `Sitemap:` line itself — no site has to also bind a sitemap-location
 * contract just for this command. `--host` names the host for both that
 * fetch and the IndexNow submission itself; left unset, it is read from
 * `IndexNowKey::keyLocation()`'s own host, which is already the site's real
 * production host (the key file must be fetchable there).
 *
 * Exits 1 only when no key is configured at all — every other outcome
 * (nothing due, a sitemap fetch failure, IndexNow itself refusing a batch)
 * exits 0 and is reported in the summary line instead, the same
 * "never fail a deployment because a search engine was unreachable"
 * discipline dawnsellshomes' `SubmitSitemap` already followed.
 *
 * Ledger bookkeeping is all-or-nothing per run: `IndexNowClient::submit()`
 * reports only aggregate counts, not which URLs landed in which batch, so
 * when ANY batch fails this command records nothing in the ledger and
 * every URL in this run stays due for the next one — a URL that silently
 * drops out of future retries because it happened to share a batch with a
 * failure would be a worse outcome than resubmitting a few already-accepted
 * URLs next time. (2026-11-02)
 */
final class IndexNowCommand extends Command
{
    /** @var string */
    protected $signature = 'seo:indexnow
        {--all : Submit every URL in the sitemap(s), ignoring what was already submitted — the deploy line}
        {--sitemap=* : Sitemap URL(s) to crawl (default: the ones robots.txt lists, fetched from the site itself)}
        {--host= : The host to submit for (default: the key file\'s own host)}
        {--dry-run : Compute what is due but submit nothing}';

    /** @var string */
    protected $description = 'Submit new or changed pages to IndexNow (Bing, Yandex, Seznam, Naver)';

    public function handle(): int
    {
        /** @var IndexNowKey $key */
        $key = $this->laravel->make(IndexNowKey::class);
        $keyValue = $key->key();

        if ($keyValue === null || trim($keyValue) === '') {
            $this->error('No IndexNow key is configured — bind SsSystems\Platform\Seo\IndexNow\Contracts\IndexNowKey to supply one.');

            return self::FAILURE;
        }

        $host = trim((string) $this->option('host')) ?: (string) parse_url($key->keyLocation(), PHP_URL_HOST);

        if ($host === '') {
            $this->error("Could not determine a host to submit for — pass --host, or make IndexNowKey::keyLocation() return an absolute URL.");

            return self::FAILURE;
        }

        /** @var Factory $http */
        $http = $this->laravel->make(Factory::class);

        $sitemapUrls = array_values(array_filter(array_map('trim', (array) $this->option('sitemap'))));
        if ($sitemapUrls === []) {
            $sitemapUrls = $this->sitemapsFromRobots($host, $http);
        }

        if ($sitemapUrls === []) {
            $this->comment("No sitemap URLs found for {$host} (checked robots.txt, nothing was passed via --sitemap).");
            $this->info('0 URLs due, 0 accepted, 0 failed');

            return self::SUCCESS;
        }

        /** @var SitemapCrawler $crawler */
        $crawler = $this->laravel->make(SitemapCrawler::class);
        $pages = $crawler->crawl($sitemapUrls);

        /** @var IndexNowLedger $ledger */
        $ledger = $this->laravel->make(IndexNowLedger::class);
        $due = $ledger->due($pages, (bool) $this->option('all'));

        if ($due === []) {
            $this->info('0 URLs due, 0 accepted, 0 failed');

            return self::SUCCESS;
        }

        if ($this->option('dry-run')) {
            $this->info(sprintf('%d URLs due, 0 accepted, 0 failed (dry run — nothing sent)', count($due)));

            return self::SUCCESS;
        }

        /** @var IndexNowClient $client */
        $client = $this->laravel->make(IndexNowClient::class);
        $result = $client->submit($host, $due, $keyValue, $key->keyLocation());

        if ($result['failures'] === []) {
            $lastmodByUrl = array_column($pages, 'lastmod', 'url');
            $ledger->recordSubmitted($due, $lastmodByUrl, 'accepted');
        } else {
            foreach ($result['failures'] as $failure) {
                $this->warn(' ↳ '.$failure);
            }
        }

        $failed = count($due) - $result['accepted'];
        $this->info(sprintf('%d URLs due, %d accepted, %d failed', count($due), $result['accepted'], $failed));

        return self::SUCCESS;
    }

    /** @return list<string> */
    private function sitemapsFromRobots(string $host, Factory $http): array
    {
        try {
            $response = $http->timeout(15)->get("https://{$host}/robots.txt");
        } catch (\Throwable) {
            return [];
        }

        if (! $response->successful()) {
            return [];
        }

        $sitemaps = [];
        foreach (preg_split('/\r\n|\r|\n/', $response->body()) ?: [] as $line) {
            if (preg_match('/^\s*Sitemap:\s*(\S+)/i', $line, $matches) === 1) {
                $sitemaps[] = trim($matches[1]);
            }
        }

        return array_values(array_unique(array_filter($sitemaps, static fn (string $url): bool => $url !== '')));
    }
}
