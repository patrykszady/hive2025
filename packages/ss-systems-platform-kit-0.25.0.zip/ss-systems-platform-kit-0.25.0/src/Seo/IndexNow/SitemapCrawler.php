<?php

namespace SsSystems\Platform\Seo\IndexNow;

use Illuminate\Http\Client\Factory;

/**
 * Fetches a site's sitemap URL(s) and returns every page they list, with
 * `<lastmod>` when the sitemap carries one — `IndexNowLedger::due()`'s input.
 *
 * Deliberately NOT `SitemapUrlSource` (see that class's own docblock): that
 * one is PageSpeedSyncCommand's URL pool, parses only `<loc>`, and never
 * follows a `<sitemapindex>`. IndexNow needs `<lastmod>` to tell a changed
 * page from an unchanged one, and several sites in this fleet
 * (dawnsellshomes' listings, gsc's areas-served) publish a sitemap INDEX of
 * several child files rather than one flat `sitemap.xml` — a gap this class
 * exists to close rather than growing `SitemapUrlSource` into two
 * incompatible shapes.
 *
 * Follows a `<sitemapindex>` exactly one level deep (a child sitemap that is
 * itself an index is not re-followed) — deep enough for every sitemap this
 * fleet actually publishes, shallow enough that a misconfigured site can
 * never cause unbounded recursion. Tolerates a plain, uncompressed XML body
 * (no `.gz` handling — none of this fleet's sitemaps are gzipped); a fetch
 * failure on any one sitemap (this one or a child) contributes no pages
 * from it and does not fail the others. Deduplicates by URL across every
 * source sitemap and stops once `$maxUrls` is reached (default 50,000 —
 * IndexNow's own per-request cap is smaller, but `Console\IndexNowCommand`
 * batches via `IndexNowClient`, so this cap only needs to guard against an
 * unbounded sitemap, not IndexNow's limit).
 */
final class SitemapCrawler
{
    private const TIMEOUT_SECONDS = 15;

    private const MAX_URLS = 50_000;

    public function __construct(
        private readonly Factory $http,
        private readonly int $timeoutSeconds = self::TIMEOUT_SECONDS,
        private readonly int $maxUrls = self::MAX_URLS,
    ) {}

    /**
     * @param  list<string>  $sitemapUrls
     * @return list<array{url: string, lastmod: ?string}>
     */
    public function crawl(array $sitemapUrls): array
    {
        $seen = [];
        $out = [];

        foreach ($sitemapUrls as $sitemapUrl) {
            foreach ($this->fetchOne($sitemapUrl, depth: 0) as $page) {
                if (isset($seen[$page['url']])) {
                    continue;
                }
                $seen[$page['url']] = true;
                $out[] = $page;

                if (count($out) >= $this->maxUrls) {
                    return $out;
                }
            }
        }

        return $out;
    }

    /** @return list<array{url: string, lastmod: ?string}> */
    private function fetchOne(string $url, int $depth): array
    {
        $body = $this->fetchBody($url);
        if ($body === null) {
            return [];
        }

        if (preg_match('#<sitemapindex[\s>]#i', $body) === 1) {
            if ($depth >= 1) {
                return [];
            }

            $out = [];
            foreach ($this->extractLocs($body) as $child) {
                $out = [...$out, ...$this->fetchOne($child, $depth + 1)];

                if (count($out) >= $this->maxUrls) {
                    break;
                }
            }

            return $out;
        }

        return $this->extractUrlEntries($body);
    }

    private function fetchBody(string $url): ?string
    {
        try {
            $response = $this->http->timeout($this->timeoutSeconds)->get($url);
        } catch (\Throwable) {
            return null;
        }

        return $response->successful() ? $response->body() : null;
    }

    /** @return list<string> */
    private function extractLocs(string $body): array
    {
        if (preg_match_all('#<loc>(.*?)</loc>#is', $body, $matches) === false) {
            return [];
        }

        return array_values(array_filter(
            array_map('trim', $matches[1]),
            static fn (string $url): bool => $url !== '',
        ));
    }

    /** @return list<array{url: string, lastmod: ?string}> */
    private function extractUrlEntries(string $body): array
    {
        if (preg_match_all('#<url>(.*?)</url>#is', $body, $matches) === false || $matches[1] === []) {
            // Tolerate a flat sitemap with no <url> wrappers at all — read the
            // bare <loc> tags directly, with no per-entry <lastmod>.
            return array_map(
                static fn (string $url): array => ['url' => $url, 'lastmod' => null],
                $this->extractLocs($body),
            );
        }

        $out = [];
        foreach ($matches[1] as $block) {
            if (preg_match('#<loc>(.*?)</loc>#is', $block, $locMatch) !== 1) {
                continue;
            }
            $url = trim($locMatch[1]);
            if ($url === '') {
                continue;
            }

            $lastmod = null;
            if (preg_match('#<lastmod>(.*?)</lastmod>#is', $block, $lastmodMatch) === 1) {
                $lastmod = trim($lastmodMatch[1]);
                $lastmod = $lastmod !== '' ? $lastmod : null;
            }

            $out[] = ['url' => $url, 'lastmod' => $lastmod];
        }

        return $out;
    }
}
