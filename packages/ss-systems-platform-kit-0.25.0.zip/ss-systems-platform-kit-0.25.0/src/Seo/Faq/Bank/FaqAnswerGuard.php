<?php

namespace SsSystems\Platform\Seo\Faq\Bank;

/**
 * The "derived" rule, enforced: a generated question-and-answer pair gets
 * into the bank only when it restates the page — every number in the
 * answer is on the page, nobody else's name is in it, no link, no talk
 * about "this page", a real question of a sensible length (2026-11-10).
 * The prompt asks the model for all of this; the guard is what makes it
 * true when the model does not listen.
 *
 * Rules, in the order they are checked — the first one failed is the
 * reason returned, and the builder counts pairs by reason:
 *
 *   not_a_question       the question does not end with "?"
 *   question_length      shorter than QUESTION_MIN or longer than QUESTION_MAX characters
 *   answer_length        shorter than ANSWER_MIN or longer than ANSWER_MAX characters
 *   url                  http://, https:// or www. anywhere in the pair
 *   banned_term          one of the site's banned terms, whole-word, any case, in the question or the answer
 *   number_not_on_page   a numeric token of the answer that the page's text does not carry (see below)
 *   meta_language        one of META_PHRASES in the question or the answer
 *   unsupported_wording  the answer leans on words the page never uses (see below)
 *
 * The last rule catches what the others cannot: a claim with no number in
 * it that the page simply does not make. jpeterson-design's first real run
 * (2026-11-10) answered "Does this service include appliance selection?"
 * with "Yes, our material selections include guidance for kitchen
 * appliances" from a page that names cabinetry, countertops and fixtures —
 * no number, no link, nothing the rules above see. So the answer's content
 * words (four letters and up, minus STOPWORDS, crudely stemmed) are checked
 * against the page's: when at least UNSUPPORTED_MIN_WORDS of them, and more
 * than UNSUPPORTED_MAX_RATIO of the answer's distinct content words, are not
 * on the page, the answer is saying something the page does not. A faithful
 * paraphrase stays under the line; a new claim does not.
 *
 * Numbers are compared after both texts go through {@see normaliseNumbers()}:
 * lower case, dashes of every kind to "-", "8 to 12" and "8 - 12" to
 * "8-12", "$" and thousands commas stripped ($35,000 → 35000), K/k
 * thousands expanded ($35K → 35000, 1.5k → 1500). Then every run of digits
 * (with an optional decimal part) in the answer must appear as a run of
 * digits in the page — so "$35K" restates "$35,000", "8 to 12 weeks"
 * restates "8–12 weeks", and "about 40 projects" on a page that says
 * nothing about 40 is an invention. A range is checked by its ends, which
 * also lets "12 weeks" restate "8–12 weeks".
 */
final class FaqAnswerGuard
{
    public const QUESTION_MIN = 12;

    public const QUESTION_MAX = 160;

    public const ANSWER_MIN = 30;

    public const ANSWER_MAX = 700;

    /** Talk about the page or the model instead of the business, any case. */
    /** At least this many of the answer's content words must be missing from the page before the ratio counts. */
    public const UNSUPPORTED_MIN_WORDS = 3;

    /** More than this share of the answer's distinct content words missing from the page = unsupported. */
    public const UNSUPPORTED_MAX_RATIO = 0.2;

    /** Function words and the business voice — never evidence either way. */
    public const STOPWORDS = [
        'about', 'above', 'after', 'again', 'also', 'always', 'another', 'any', 'anything', 'around', 'available', 'away', 'back',
        'been', 'before', 'being', 'below', 'best', 'between', 'both', 'bring', 'came', 'cannot', 'come', 'comes', 'could', 'does',
        'doing', 'done', 'down', 'during', 'each', 'either', 'else', 'enough', 'even', 'ever', 'every', 'everything', 'first', 'from',
        'full', 'gets', 'getting', 'give', 'gives', 'good', 'great', 'have', 'having', 'help', 'helps', 'here', 'into', 'just', 'keep',
        'keeps', 'know', 'last', 'like', 'made', 'make', 'makes', 'making', 'many', 'more', 'most', 'much', 'must', 'need', 'needs',
        'never', 'next', 'once', 'only', 'onto', 'other', 'others', 'over', 'part', 'right', 'same', 'should', 'since', 'some',
        'something', 'such', 'sure', 'take', 'takes', 'than', 'that', 'their', 'them', 'then', 'there', 'these', 'they', 'thing',
        'things', 'this', 'those', 'through', 'time', 'together', 'toward', 'towards', 'under', 'until', 'upon', 'used', 'uses',
        'using', 'very', 'want', 'wants', 'well', 'were', 'what', 'when', 'where', 'whether', 'which', 'while', 'will', 'with',
        'within', 'without', 'would', 'your', 'yours', 'ours', 'include', 'includes', 'included', 'including', 'provide',
        'provides', 'provided', 'offer', 'offers', 'offered', 'work', 'works', 'worked', 'working', 'like', 'able', 'yes',
    ];

    public const META_PHRASES = [
        'this page', 'on the page', 'the page says', 'the page states', 'the page mentions', 'the page does not', "the page doesn't",
        'the text', 'this text', 'the provided text', 'the provided content', 'the provided information', 'the given text',
        'according to the website', 'according to the site', 'according to the page', 'the website says', 'the website states', 'this website',
        'as an ai', 'as a language model', 'i cannot', "i can't", 'i am unable', "i'm unable", 'i do not have', "i don't have",
        'not mentioned', 'does not mention', "doesn't mention",
    ];

    /**
     * @param  array{q: string, a: string}  $pair
     * @param  list<string>  $bannedTerms
     * @return string|null  null when the pair passes, else the reason key
     */
    public static function rejectReason(array $pair, string $sourceText, array $bannedTerms): ?string
    {
        $q = trim((string) ($pair['q'] ?? ''));
        $a = trim((string) ($pair['a'] ?? ''));

        if (! str_ends_with($q, '?')) {
            return 'not_a_question';
        }

        $questionLength = mb_strlen($q);

        if ($questionLength < self::QUESTION_MIN || $questionLength > self::QUESTION_MAX) {
            return 'question_length';
        }

        $answerLength = mb_strlen($a);

        if ($answerLength < self::ANSWER_MIN || $answerLength > self::ANSWER_MAX) {
            return 'answer_length';
        }

        if (preg_match('~https?://|www\.~i', $q.' '.$a) === 1) {
            return 'url';
        }

        if (self::bannedTerm($q.' '.$a, $bannedTerms) !== null) {
            return 'banned_term';
        }

        if (self::numberNotOnPage($a, $sourceText) !== null) {
            return 'number_not_on_page';
        }

        if (self::metaPhrase($q.' '.$a) !== null) {
            return 'meta_language';
        }

        if (self::unsupportedWords($a, $sourceText) !== []) {
            return 'unsupported_wording';
        }

        return null;
    }

    /**
     * The answer's distinct content-word stems the page does not use, when
     * there are enough of them to call the answer unsupported; [] otherwise.
     *
     * @return list<string>
     */
    public static function unsupportedWords(string $answer, string $sourceText): array
    {
        $answerStems = array_values(array_unique(self::contentStems($answer)));

        if ($answerStems === []) {
            return [];
        }

        $pageStems = array_flip(self::contentStems($sourceText));
        $novel = array_values(array_filter($answerStems, static fn (string $stem): bool => ! isset($pageStems[$stem])));

        if (count($novel) >= self::UNSUPPORTED_MIN_WORDS && count($novel) / count($answerStems) > self::UNSUPPORTED_MAX_RATIO) {
            return $novel;
        }

        return [];
    }

    /** @return list<string> lower-cased content words of four letters and up, stop words dropped, crudely stemmed */
    private static function contentStems(string $text): array
    {
        preg_match_all("/\\p{L}[\\p{L}'’]{3,}/u", mb_strtolower($text), $matches);
        $stems = [];

        foreach ($matches[0] as $word) {
            $word = (string) preg_replace("/['’]s$/u", '', $word);

            if (isset(self::stopwordSet()[$word])) {
                continue;
            }

            $stems[] = self::stem($word);
        }

        return $stems;
    }

    /** Enough stemming to match "selections" to "selection" and "designed" to "design", nothing cleverer. */
    private static function stem(string $word): string
    {
        foreach (['ational' => 'ate', 'ization' => 'ize', 'iness' => 'y', 'ies' => 'y', 'ing' => '', 'ed' => '', 'es' => '', 's' => '', 'ly' => ''] as $suffix => $replacement) {
            if (str_ends_with($word, $suffix) && mb_strlen($word) - mb_strlen($suffix) >= 3) {
                return mb_substr($word, 0, mb_strlen($word) - mb_strlen($suffix)).$replacement;
            }
        }

        return $word;
    }

    /** @return array<string, true> */
    private static function stopwordSet(): array
    {
        static $set = null;

        return $set ??= array_fill_keys(self::STOPWORDS, true);
    }

    /** The first banned term found whole-word (any case) in `$text`, or null. @param  list<string>  $bannedTerms */
    public static function bannedTerm(string $text, array $bannedTerms): ?string
    {
        foreach ($bannedTerms as $term) {
            $term = trim((string) $term);

            if ($term === '') {
                continue;
            }

            $pattern = '/(?<![\p{L}\p{N}])'.preg_replace('/\s+/', '\s+', preg_quote($term, '/')).'(?![\p{L}\p{N}])/iu';

            if (preg_match($pattern, $text) === 1) {
                return $term;
            }
        }

        return null;
    }

    /** The first numeric token of `$answer` that `$sourceText` does not carry (both normalised), or null when every one is on the page. */
    public static function numberNotOnPage(string $answer, string $sourceText): ?string
    {
        $onPage = array_fill_keys(self::numericTokens($sourceText), true);

        foreach (self::numericTokens($answer) as $token) {
            if (! isset($onPage[$token])) {
                return $token;
            }
        }

        return null;
    }

    /** The first META_PHRASES entry found in `$text` (any case), or null. */
    public static function metaPhrase(string $text): ?string
    {
        $haystack = mb_strtolower($text);

        foreach (self::META_PHRASES as $phrase) {
            if (str_contains($haystack, $phrase)) {
                return $phrase;
            }
        }

        return null;
    }

    /** See the class docblock for each step. */
    public static function normaliseNumbers(string $text): string
    {
        $text = mb_strtolower($text);
        $text = str_replace(['–', '—', '‒', '―', '−'], '-', $text);
        $text = (string) preg_replace('/(?<=\d),(?=\d{3}(?!\d))/u', '', $text);
        $text = str_replace('$', '', $text);
        $text = (string) preg_replace('/(\d)\s*(?:-|to)\s*(?=\d)/u', '$1-', $text);

        return (string) preg_replace_callback('/(\d+(?:\.\d+)?)k(?![\p{L}\p{N}])/u', static fn (array $m): string => self::thousands($m[1]), $text);
    }

    /**
     * Every run of digits (with an optional decimal part) in the normalised
     * text, decimals trimmed of trailing zeros so "1.50" and "1.5" are one
     * token.
     *
     * @return list<string>
     */
    public static function numericTokens(string $text): array
    {
        preg_match_all('/\d+(?:\.\d+)?/', self::normaliseNumbers($text), $matches);

        return array_values(array_unique(array_map(
            static fn (string $token): string => str_contains($token, '.') ? rtrim(rtrim($token, '0'), '.') : $token,
            $matches[0],
        )));
    }

    private static function thousands(string $number): string
    {
        $value = round((float) $number * 1000, 3);

        return $value == floor($value) ? (string) (int) $value : rtrim(rtrim(number_format($value, 3, '.', ''), '0'), '.');
    }
}
