<?php

namespace SsSystems\Platform\Seo\Faq\Bank\Generators;

use SsSystems\Platform\Seo\Faq\Bank\Contracts\TextGenerator;

/**
 * The generators a site holds keys for, tried in order — so one binding in
 * `AppServiceProvider` covers "Gemini if we have a key, else OpenAI, else
 * Anthropic", and a provider outage falls through to the next key instead
 * of failing the night's run (2026-11-10).
 *
 * Configured when any of them is. A generate() asks each configured one in
 * turn and returns the first text; when every one fails, lastError() joins
 * their reasons so the page's `last_error` says what each provider said.
 * label() names the generator that answered last, or, before any answer,
 * the first configured one — the summary line's "via {provider}" is read
 * after the run, so it names what actually wrote the bank.
 */
final class FirstConfiguredTextGenerator implements TextGenerator
{
    /** @var list<TextGenerator> */
    private readonly array $generators;

    private ?string $lastError = null;

    private ?TextGenerator $answered = null;

    /** @param  list<TextGenerator>  $generators  in the order to try them */
    public function __construct(array $generators)
    {
        $this->generators = array_values($generators);
    }

    public function isConfigured(): bool
    {
        foreach ($this->generators as $generator) {
            if ($generator->isConfigured()) {
                return true;
            }
        }

        return false;
    }

    public function generate(string $prompt, int $maxOutputTokens = 2000): ?string
    {
        $failures = [];

        foreach ($this->generators as $generator) {
            if (! $generator->isConfigured()) {
                continue;
            }

            $text = $generator->generate($prompt, $maxOutputTokens);

            if ($text !== null) {
                $this->answered = $generator;
                $this->lastError = null;

                return $text;
            }

            $failures[] = $generator->lastError() ?? $generator->label().' answered nothing.';
        }

        $this->lastError = $failures === [] ? 'No text generator is configured.' : implode('; ', $failures);

        return null;
    }

    public function lastError(): ?string
    {
        return $this->lastError;
    }

    public function label(): string
    {
        if ($this->answered !== null) {
            return $this->answered->label();
        }

        foreach ($this->generators as $generator) {
            if ($generator->isConfigured()) {
                return $generator->label();
            }
        }

        return 'no provider';
    }
}
