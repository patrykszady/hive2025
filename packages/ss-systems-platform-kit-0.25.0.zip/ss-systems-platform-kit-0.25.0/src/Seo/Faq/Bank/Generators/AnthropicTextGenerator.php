<?php

namespace SsSystems\Platform\Seo\Faq\Bank\Generators;

use Illuminate\Http\Client\Factory;
use SsSystems\Platform\Seo\Faq\Bank\Contracts\TextGenerator;

/**
 * Anthropic's Messages API as a {@see TextGenerator} — the third provider
 * behind the FAQ bank (2026-11-10), for a site that holds an Anthropic key.
 *
 *   https://docs.anthropic.com/en/api/messages
 *
 * One POST per prompt, the key in `x-api-key`, `anthropic-version`
 * 2023-06-01 (the one stable version string the API takes), temperature
 * 0.3, `max_tokens` as the output cap. There is no JSON response mode to
 * switch on: the prompt itself asks for JSON only, and the builder's parser
 * strips a ```json fence should the model add one. The text is every text
 * block of the answer joined.
 *
 * The default model is Haiku 4.5 — the cheapest current model, and a
 * restating job needs no more. The HTTP client is Laravel's, handed in for
 * the same two reasons as in {@see GeminiTextGenerator}.
 */
final class AnthropicTextGenerator implements TextGenerator
{
    public const ENDPOINT = 'https://api.anthropic.com/v1/messages';

    public const API_VERSION = '2023-06-01';

    public const DEFAULT_MODEL = 'claude-haiku-4-5';

    public const TIMEOUT_SECONDS = 60;

    public const TEMPERATURE = 0.3;

    private ?string $lastError = null;

    public function __construct(
        private readonly ?string $apiKey,
        private readonly string $model = self::DEFAULT_MODEL,
        private readonly ?Factory $http = null,
    ) {}

    public function isConfigured(): bool
    {
        return trim((string) $this->apiKey) !== '';
    }

    public function label(): string
    {
        return 'Anthropic '.$this->model;
    }

    public function lastError(): ?string
    {
        return $this->lastError;
    }

    public function generate(string $prompt, int $maxOutputTokens = 2000): ?string
    {
        $http = $this->http ?? new Factory();

        try {
            $response = $http->timeout(self::TIMEOUT_SECONDS)
                ->withHeaders(['x-api-key' => (string) $this->apiKey, 'anthropic-version' => self::API_VERSION])
                ->asJson()
                ->post(self::ENDPOINT, [
                    'model' => $this->model,
                    'max_tokens' => max(1, $maxOutputTokens),
                    'temperature' => self::TEMPERATURE,
                    'messages' => [['role' => 'user', 'content' => $prompt]],
                ]);
        } catch (\Throwable $e) {
            $this->lastError = $this->label().': '.$e->getMessage();

            return null;
        }

        if (! $response->successful()) {
            $this->lastError = $this->label().' answered '.$response->status().': '.mb_substr(trim($response->body()), 0, 300);

            return null;
        }

        $blocks = $response->json('content');
        $text = '';

        foreach (is_array($blocks) ? $blocks : [] as $block) {
            $text .= is_array($block) && ($block['type'] ?? 'text') === 'text' && is_string($block['text'] ?? null) ? $block['text'] : '';
        }

        if (trim($text) === '') {
            $reason = $response->json('stop_reason');
            $this->lastError = $this->label().' answered with no text'.(is_string($reason) ? ' ('.$reason.')' : '').'.';

            return null;
        }

        $this->lastError = null;

        return $text;
    }
}
