<?php

namespace SsSystems\Platform\Seo\Faq\Bank\Generators;

use Illuminate\Http\Client\Factory;
use SsSystems\Platform\Seo\Faq\Bank\Contracts\TextGenerator;

/**
 * OpenAI's Chat Completions API as a {@see TextGenerator} — the second
 * provider behind the FAQ bank (2026-11-10), for a site that holds an
 * OpenAI key rather than a Gemini one (hive's estimate and invoice readers
 * already run on gpt-4.1).
 *
 *   https://platform.openai.com/docs/api-reference/chat/create
 *
 * One POST per prompt, bearer-token auth, `response_format` json_object so
 * the model answers with the JSON the builder's prompt asks for,
 * temperature 0.3, `max_completion_tokens` as the output cap (the current
 * name of the parameter; `max_tokens` is the deprecated one). The text is
 * the first choice's message content.
 *
 * The HTTP client is Laravel's, handed in for the same two reasons as in
 * {@see GeminiTextGenerator}.
 */
final class OpenAiTextGenerator implements TextGenerator
{
    public const ENDPOINT = 'https://api.openai.com/v1/chat/completions';

    public const DEFAULT_MODEL = 'gpt-4.1-mini';

    public const TIMEOUT_SECONDS = 60;

    public const TEMPERATURE = 0.3;

    private ?string $lastError = null;

    public function __construct(
        private readonly ?string $apiKey,
        private readonly string $model = self::DEFAULT_MODEL,
        private readonly ?Factory $http = null,
    ) {}

    public function isConfigured(): bool
    {
        return trim((string) $this->apiKey) !== '';
    }

    public function label(): string
    {
        return 'OpenAI '.$this->model;
    }

    public function lastError(): ?string
    {
        return $this->lastError;
    }

    public function generate(string $prompt, int $maxOutputTokens = 2000): ?string
    {
        $http = $this->http ?? new Factory();

        try {
            $response = $http->timeout(self::TIMEOUT_SECONDS)->withToken((string) $this->apiKey)->asJson()->post(self::ENDPOINT, [
                'model' => $this->model,
                'messages' => [['role' => 'user', 'content' => $prompt]],
                'response_format' => ['type' => 'json_object'],
                'temperature' => self::TEMPERATURE,
                'max_completion_tokens' => max(1, $maxOutputTokens),
            ]);
        } catch (\Throwable $e) {
            $this->lastError = $this->label().': '.$e->getMessage();

            return null;
        }

        if (! $response->successful()) {
            $this->lastError = $this->label().' answered '.$response->status().': '.mb_substr(trim($response->body()), 0, 300);

            return null;
        }

        $text = $response->json('choices.0.message.content');

        if (! is_string($text) || trim($text) === '') {
            $reason = $response->json('choices.0.finish_reason');
            $this->lastError = $this->label().' answered with no text'.(is_string($reason) ? ' ('.$reason.')' : '').'.';

            return null;
        }

        $this->lastError = null;

        return $text;
    }
}
