<?php

namespace SsSystems\Platform\Seo\Faq\Bank\Generators;

use Illuminate\Http\Client\Factory;
use SsSystems\Platform\Seo\Faq\Bank\Contracts\TextGenerator;

/**
 * Google's Gemini API (generateContent) as a {@see TextGenerator} — the
 * first provider the FAQ bank was built against (2026-11-10): the sites
 * already hold a Gemini key for their area descriptions, so a bank costs
 * them nothing new to switch on.
 *
 *   https://ai.google.dev/api/generate-content
 *
 * One POST per prompt, the key on the query string as Google documents it,
 * temperature 0.3, `responseMimeType` application/json so the model
 * answers with the JSON the builder's prompt asks for. The text is every
 * part of the first candidate joined. A 2.5 model thinks before it answers
 * and its thinking counts against `maxOutputTokens`, so the builder asks
 * for generous room; a candidate cut short carries its `finishReason` in
 * lastError() so a truncated answer is not mistaken for a model that said
 * nothing.
 *
 * The HTTP client is Laravel's, handed in so a site passes the one behind
 * its Http facade (and Http::fake() in its tests applies), and so a kit
 * test can fake it with no container at all.
 */
final class GeminiTextGenerator implements TextGenerator
{
    public const API_BASE = 'https://generativelanguage.googleapis.com/v1beta/models';

    public const DEFAULT_MODEL = 'gemini-2.5-flash';

    public const TIMEOUT_SECONDS = 60;

    public const TEMPERATURE = 0.3;

    private ?string $lastError = null;

    public function __construct(
        private readonly ?string $apiKey,
        private readonly string $model = self::DEFAULT_MODEL,
        private readonly ?Factory $http = null,
    ) {}

    public function isConfigured(): bool
    {
        return trim((string) $this->apiKey) !== '';
    }

    public function label(): string
    {
        return 'Gemini '.$this->model;
    }

    public function lastError(): ?string
    {
        return $this->lastError;
    }

    public function generate(string $prompt, int $maxOutputTokens = 2000): ?string
    {
        $http = $this->http ?? new Factory();

        try {
            $response = $http->timeout(self::TIMEOUT_SECONDS)->asJson()->post(
                self::API_BASE.'/'.rawurlencode($this->model).':generateContent?key='.rawurlencode((string) $this->apiKey),
                [
                    'contents' => [['role' => 'user', 'parts' => [['text' => $prompt]]]],
                    'generationConfig' => [
                        'temperature' => self::TEMPERATURE,
                        'maxOutputTokens' => max(1, $maxOutputTokens),
                        'responseMimeType' => 'application/json',
                    ],
                ],
            );
        } catch (\Throwable $e) {
            $this->lastError = $this->label().': '.$e->getMessage();

            return null;
        }

        if (! $response->successful()) {
            $this->lastError = $this->label().' answered '.$response->status().': '.mb_substr(trim($response->body()), 0, 300);

            return null;
        }

        $parts = $response->json('candidates.0.content.parts');
        $text = '';

        foreach (is_array($parts) ? $parts : [] as $part) {
            $text .= is_array($part) && is_string($part['text'] ?? null) ? $part['text'] : '';
        }

        if (trim($text) === '') {
            $reason = $response->json('candidates.0.finishReason') ?? $response->json('promptFeedback.blockReason');
            $this->lastError = $this->label().' answered with no text'.(is_string($reason) ? ' ('.$reason.')' : '').'.';

            return null;
        }

        $this->lastError = null;

        return $text;
    }
}
