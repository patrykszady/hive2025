<?php

namespace SsSystems\Platform\Seo\Faq\Bank;

/**
 * A rendered page's own words, for the FAQ bank's prompt: the first
 * `<main>` (else the `<body>`) with the chrome dropped — header, nav,
 * footer, aside, forms, buttons, scripts, styles, SVG, iframes, templates,
 * dialogs and anything hidden — block elements and `<br>` as line breaks,
 * headings on lines of their own, whitespace collapsed, cut at `$maxChars`
 * on a word boundary so a long town page does not blow the prompt up
 * (2026-11-10).
 *
 * Except a page's disclosures, which are content, not chrome: an FAQ is
 * the best source of questions there is, and the sites render it three
 * ways — Flux's accordion (a `<ui-disclosure>` whose question is a
 * `<button>` and whose answer panel is `hidden` until opened),
 * gs.construction's FAQ (a button carrying `aria-expanded` and an answer
 * panel `hidden="until-found"`, which browsers and Google treat as page
 * content), and plain `<details>`/`<summary>`. A button that opens one, or
 * reads like one (a question, or four words and more), is kept on a line
 * of its own; a hidden panel inside a disclosure, or `until-found`, is
 * kept. Short call-to-action buttons, menus and modals stay out
 * (ss.systems' FAQ bank found its own /how-it-works accordion unread,
 * 2026-11-10).
 *
 * The "derived" rule (an answer may only restate what the page says) is
 * checked against exactly this text by {@see FaqAnswerGuard}, so what is
 * dropped here is dropped from the truth too: a price that only appears in
 * the footer cannot be restated. That is on purpose — the footer is the
 * same on every page and would otherwise be restated on every page.
 *
 * libxml's warnings about the HTML the sites emit (unknown tags, nested
 * forms) are suppressed, never logged.
 */
final class PageTextExtractor
{
    public const DEFAULT_MAX_CHARS = 12000;

    /** Elements whose whole subtree is chrome or code, never content. */
    public const DROPPED = ['header', 'nav', 'footer', 'aside', 'script', 'style', 'noscript', 'svg', 'form', 'template', 'iframe', 'button', 'dialog'];

    /** Containers whose hidden parts are still the page's content (see the class docblock). */
    public const DISCLOSURES = ['ui-disclosure', 'details'];

    /** A button with at least this many words reads like a question heading, not a call to action. */
    public const QUESTION_BUTTON_MIN_WORDS = 4;

    /** Elements that start and end a line of their own. */
    public const BLOCKS = [
        'address', 'article', 'blockquote', 'dd', 'details', 'div', 'dl', 'dt', 'fieldset', 'figcaption', 'figure',
        'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'hr', 'legend', 'li', 'main', 'ol', 'p', 'pre', 'section', 'summary',
        'table', 'tbody', 'tfoot', 'thead', 'tr', 'ul',
    ];

    /** Table cells: a space apart, on their row's line. */
    public const CELLS = ['td', 'th'];

    public static function extract(string $html, int $maxChars = self::DEFAULT_MAX_CHARS): string
    {
        if (trim($html) === '') {
            return '';
        }

        $document = new \DOMDocument();
        $previous = libxml_use_internal_errors(true);
        $loaded = $document->loadHTML('<?xml encoding="UTF-8">'.$html, LIBXML_NONET | LIBXML_NOWARNING | LIBXML_NOERROR);
        libxml_clear_errors();
        libxml_use_internal_errors($previous);

        if (! $loaded) {
            return '';
        }

        $root = $document->getElementsByTagName('main')->item(0)
            ?? $document->getElementsByTagName('body')->item(0)
            ?? $document->documentElement;

        if ($root === null) {
            return '';
        }

        $out = '';
        self::walk($root, $out);

        return self::truncate(self::tidy($out), $maxChars);
    }

    /** Cuts `$text` to at most `$maxChars`, stepping back to the last space or line break unless that would lose more than half. */
    public static function truncate(string $text, int $maxChars): string
    {
        if ($maxChars <= 0 || mb_strlen($text) <= $maxChars) {
            return $text;
        }

        $cut = mb_substr($text, 0, $maxChars);

        if (preg_match('/\s/u', mb_substr($text, $maxChars, 1)) === 1) {
            return rtrim($cut);
        }

        $boundary = max((int) mb_strrpos($cut, ' '), (int) mb_strrpos($cut, "\n"));

        if ($boundary > $maxChars / 2) {
            $cut = mb_substr($cut, 0, $boundary);
        }

        return rtrim($cut);
    }

    private static function walk(\DOMNode $node, string &$out): void
    {
        if ($node instanceof \DOMText) {
            $out .= $node->nodeValue ?? '';

            return;
        }

        if (! $node instanceof \DOMElement) {
            return;
        }

        $name = strtolower($node->tagName);

        $dropped = in_array($name, self::DROPPED, true) && ! ($name === 'button' && self::opensDisclosure($node));
        $hidden = $node->hasAttribute('hidden') && ! self::isDisclosureContent($node);
        $modal = strtolower($node->getAttribute('role')) === 'dialog' || strtolower($node->getAttribute('aria-modal')) === 'true';

        if ($dropped || $hidden || $modal || strtolower($node->getAttribute('aria-hidden')) === 'true') {
            return;
        }

        if ($name === 'br') {
            $out .= "\n";

            return;
        }

        $separator = in_array($name, self::BLOCKS, true) || $name === 'button' || $name === 'summary' ? "\n" : (in_array($name, self::CELLS, true) ? ' ' : '');
        $out .= $separator;

        foreach ($node->childNodes as $child) {
            self::walk($child, $out);
        }

        $out .= $separator;
    }

    /** A button that opens a disclosure, or whose text reads like a question heading. */
    private static function opensDisclosure(\DOMElement $button): bool
    {
        foreach ($button->attributes as $attribute) {
            if (str_contains(strtolower($attribute->nodeName), 'aria-expanded') || strtolower($attribute->nodeName) === 'aria-controls') {
                return true;
            }
        }

        if (self::insideDisclosure($button)) {
            return true;
        }

        $text = trim((string) preg_replace('/\s+/u', ' ', $button->textContent));

        return $text !== '' && (str_ends_with($text, '?') || count(explode(' ', $text)) >= self::QUESTION_BUTTON_MIN_WORDS);
    }

    /** A hidden element that is still the page's content: `until-found`, or a panel inside a disclosure. */
    private static function isDisclosureContent(\DOMElement $node): bool
    {
        return strtolower(trim($node->getAttribute('hidden'))) === 'until-found' || self::insideDisclosure($node);
    }

    private static function insideDisclosure(\DOMElement $node): bool
    {
        for ($parent = $node->parentNode; $parent instanceof \DOMElement; $parent = $parent->parentNode) {
            if (in_array(strtolower($parent->tagName), self::DISCLOSURES, true)) {
                return true;
            }

            foreach ($parent->attributes as $attribute) {
                if (str_starts_with(strtolower($attribute->nodeName), 'data-flux-accordion')) {
                    return true;
                }
            }
        }

        return false;
    }

    /** Non-breaking spaces to spaces, runs of spaces to one, lines trimmed, empty lines dropped. */
    private static function tidy(string $text): string
    {
        $text = str_replace("\r", '', $text);
        $lines = [];

        foreach (explode("\n", $text) as $line) {
            $line = trim((string) preg_replace('/[\p{Zs}\t\f\v]+/u', ' ', $line));

            if ($line !== '') {
                $lines[] = $line;
            }
        }

        return implode("\n", $lines);
    }
}
