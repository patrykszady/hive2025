<?php

namespace SsSystems\Platform\Seo\Faq\Bank;

/**
 * The bank behind a site's {@see \SsSystems\Platform\Seo\Faq\Contracts\FaqCatalog}:
 * its `items()` hands its hand-written list here and gets back that list,
 * unchanged and first, followed by every bank answer as `{q, a, url,
 * topics: [kind]}` — `url` is the page the answer was derived from, which
 * `BuildsFaqPageFeed` publishes on the Question node so an answer engine
 * can cite the page (2026-11-10). A bank answer whose question, normalised
 * the way {@see FaqKeys} normalises one (towns kept — "in Palatine" and
 * "in Barrington" are different questions here), equals a hand-written
 * question is skipped: the hand-written answer is the one Patryk chose. A
 * bank question repeated by a second page is skipped too — one answer per
 * question in the feed, the first page's. The whole list is capped at
 * `$cap`; the hand-written items are never the ones cut.
 */
final class FaqBankCatalog
{
    public const DEFAULT_CAP = 3000;

    /**
     * @param  list<array{q: string, a: string, topics?: list<string>}>  $handWritten
     * @return list<array{q: string, a: string, url?: string, topics?: list<string>}>
     */
    public static function merge(array $handWritten, FaqBankStore $store, int $cap = self::DEFAULT_CAP): array
    {
        $items = array_values($handWritten);
        $seen = [];

        foreach ($items as $item) {
            $seen[FaqKeys::question((string) ($item['q'] ?? ''), [])] = true;
        }

        if (count($items) >= $cap) {
            return $items;
        }

        foreach ($store->all($cap) as $row) {
            $key = FaqKeys::question($row['q'], []);

            if (isset($seen[$key])) {
                continue;
            }

            $seen[$key] = true;
            $items[] = ['q' => $row['q'], 'a' => $row['a'], 'url' => $row['url'], 'topics' => [$row['kind']]];

            if (count($items) >= $cap) {
                break;
            }
        }

        return $items;
    }
}
