<?php

namespace SsSystems\Platform\Seo\Faq\Bank\Contracts;

/**
 * One prompt in, one text out — the whole of what the FAQ bank asks of an
 * AI provider. The kit ships three HTTP implementations under
 * `Seo\Faq\Bank\Generators` (Gemini, OpenAI, Anthropic) and
 * `FirstConfiguredTextGenerator`, which tries them in order; a site binds
 * whichever it has a key for in `AppServiceProvider`. Nothing here throws:
 * a failure comes back as null with {@see lastError()} set, the way
 * `Seo\Bing\BingWebmasterApi` reports one, and the builder decides what to
 * do (record it on the page, stop the run after too many in a row).
 */
interface TextGenerator
{
    /** Whether a key is present — a run with none is skipped, not failed. */
    public function isConfigured(): bool;

    /** The generated text (the builder asks for JSON), or null on failure with {@see lastError()} set. */
    public function generate(string $prompt, int $maxOutputTokens = 2000): ?string;

    /** Why the last call returned null: the HTTP status and a short body excerpt, or the transport error. Null after a success. */
    public function lastError(): ?string;

    /** Provider and model for log lines, e.g. 'Gemini gemini-2.5-flash'. */
    public function label(): string;
}
