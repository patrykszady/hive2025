<?php

namespace SsSystems\Platform\Seo\Faq\Bank\Contracts;

/**
 * What one site hands the FAQ bank builder (`seo:faq-bank`, see
 * {@see \SsSystems\Platform\Seo\Faq\Bank\FaqBankBuilder}): the pages worth
 * mining, their words when the site wants to supply them itself, and the
 * few facts the builder needs to keep every answer honest. Bound once per
 * site in `AppServiceProvider`, the way `Seo\Faq\Contracts\FaqCatalog` is.
 *
 * Why (Patryk, 2026-11-10): `/geo/answers.json` carried a few hand-written
 * answers per site (gs.construction 23, hive 15, ss.systems 15;
 * jpeterson-design 397, mostly one question repeated per town) and he
 * wants many, many answers for the AI answer engines, DERIVED from each
 * site's own pages — an answer may only restate what a page says. The
 * bank feeds `/geo/answers.json` and llms-full.txt, never the HTML pages.
 *
 * What stays the site's own: which pages (a kit class never references
 * `App\Models`, so the sitemap, the service and town models, the blog are
 * read behind this interface), and what the page's own words are —
 * Dawn Sells Homes must exclude the MLS listing data injected into its
 * rendered pages, so {@see textFor()} lets a site supply the text instead
 * of letting the builder render the page in-process.
 */
interface FaqBankSource
{
    /**
     * The absolute public URLs the site wants mined, in priority order
     * (the builder visits pages it has never seen in this order, then the
     * longest-ago checked). `kind` is a short label the bank keeps on every
     * answer and the feed publishes as the Question's topic: service, town,
     * cost, permit, project, guide, blog, page.
     *
     * @return list<array{url: string, kind: string}>
     */
    public function pages(): array;

    /**
     * The page's own words, when the site wants to supply them itself —
     * null means "render it": the builder dispatches a GET for the URL
     * through the HTTP kernel in-process and extracts the main text.
     */
    public function textFor(string $url): ?string;

    /** The name the prompt and the log lines call the business. */
    public function businessName(): string;

    /** The language the answers are written in, e.g. 'US English'. */
    public function language(): string;

    /**
     * Place names the site serves, so the same answer said about Palatine
     * and about Barrington is recognised as one answer and kept once —
     * see {@see \SsSystems\Platform\Seo\Faq\Bank\FaqKeys}.
     *
     * @return list<string>
     */
    public function towns(): array;

    /**
     * Competitor names and anything else an answer must never contain —
     * a pair naming one is dropped, see
     * {@see \SsSystems\Platform\Seo\Faq\Bank\FaqAnswerGuard}.
     *
     * @return list<string>
     */
    public function bannedTerms(): array;
}
