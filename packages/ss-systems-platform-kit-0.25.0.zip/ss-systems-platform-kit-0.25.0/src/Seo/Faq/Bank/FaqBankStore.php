<?php

namespace SsSystems\Platform\Seo\Faq\Bank;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Database\Query\Builder;
use Illuminate\Support\Carbon;

/**
 * Reads and writes the two FAQ bank tables (columns per
 * resources/stubs/seo/create_geo_faq_bank_tables.php.stub): one row per
 * mined page in `geo_faq_bank_pages` — the hash of the text it was built
 * from, when it was built, when it was last looked at, how many answers it
 * holds, why it failed — and one row per answer in `geo_faq_bank`, keyed
 * back to its page by `url_hash` (2026-11-10). {@see FaqBankBuilder}
 * writes, {@see FaqBankCatalog} reads for `/geo/answers.json`.
 *
 * Tenant-scoped exactly like `Seo\KeywordResearch\KeywordStore`: a
 * single-tenant adopter passes neither `$tenantColumn` nor `$tenantId` and
 * every row's `site_id` stays null; a multi-tenant one (gs.construction)
 * passes both and every query is scoped to the current site.
 *
 * A page's answers are replaced whole, in one transaction, every time the
 * page is rebuilt; a page that left the source's list loses its row and
 * its answers ({@see forgetPagesNotIn()}) — unlike Bing's URL rows there
 * is no history worth keeping, the next run rebuilds it from the page.
 */
final class FaqBankStore
{
    public function __construct(
        private readonly ConnectionInterface $connection,
        private readonly string $pagesTable = 'geo_faq_bank_pages',
        private readonly string $answersTable = 'geo_faq_bank',
        private readonly ?string $tenantColumn = null,
        private readonly ?\Closure $tenantId = null,
    ) {}

    /** Whether both tables exist — a site that has not copied the stub yet gets a failed run, not an exception. */
    public function exists(): bool
    {
        $schema = $this->connection->getSchemaBuilder();

        return $schema->hasTable($this->pagesTable) && $schema->hasTable($this->answersTable);
    }

    /** @return array{source_hash: ?string, generated_at: ?string, checked_at: ?string, answers: int}|null  null for a page never visited */
    public function pageState(string $url): ?array
    {
        $row = $this->pages()->where('url_hash', self::hash($url))->first();

        if ($row === null) {
            return null;
        }

        return [
            'source_hash' => $row->source_hash !== null ? (string) $row->source_hash : null,
            'generated_at' => $row->generated_at !== null ? (string) $row->generated_at : null,
            'checked_at' => $row->checked_at !== null ? (string) $row->checked_at : null,
            'answers' => (int) $row->answers,
        ];
    }

    /**
     * The page was built: its row says so (generated_at and checked_at now,
     * the hash of the text it was built from, the answer count, no error)
     * and its answers are the given rows, in order, nothing else — one
     * transaction, so a reader never sees the page half-replaced.
     *
     * @param  list<array{q: string, a: string, q_key: string, a_key: string}>  $rows
     */
    public function replacePage(string $url, string $kind, string $sourceHash, array $rows): void
    {
        $now = self::now();
        $hash = self::hash($url);

        $this->connection->transaction(function () use ($url, $kind, $sourceHash, $rows, $now, $hash): void {
            $this->writePage($hash, $url, [
                'kind' => mb_substr($kind, 0, 40),
                'source_hash' => $sourceHash,
                'answers' => count($rows),
                'last_error' => null,
                'generated_at' => $now,
                'checked_at' => $now,
                'updated_at' => $now,
            ], $now);

            $this->answers()->where('url_hash', $hash)->delete();

            $inserts = [];

            foreach (array_values($rows) as $position => $row) {
                $inserts[] = $this->tenantFields() + [
                    'url_hash' => $hash,
                    'source_url' => mb_substr($url, 0, 500),
                    'kind' => mb_substr($kind, 0, 40),
                    'question' => $row['q'],
                    'answer' => $row['a'],
                    'q_key' => mb_substr($row['q_key'], 0, 191),
                    'a_key' => mb_substr($row['a_key'], 0, 191),
                    'position' => $position,
                    'created_at' => $now,
                    'updated_at' => $now,
                ];
            }

            foreach (array_chunk($inserts, 200) as $chunk) {
                $this->connection->table($this->answersTable)->insert($chunk);
            }
        });
    }

    /**
     * The page was looked at but not rebuilt — unchanged, too thin, or the
     * generation failed: checked_at now, the error (or none), the kind, and
     * the source hash only when one is given (a failed page keeps the hash
     * it was last built from, so the next run sees the change and tries
     * again; a thin page passes the hash of its thin text so a page that
     * fills back up is rebuilt). The answers are untouched; a thin page's
     * are cleared by the builder through {@see clearPage()}.
     */
    public function markChecked(string $url, string $kind, ?string $sourceHash, ?string $error = null): void
    {
        $now = self::now();
        $values = [
            'kind' => mb_substr($kind, 0, 40),
            'last_error' => $error !== null ? mb_substr($error, 0, 255) : null,
            'checked_at' => $now,
            'updated_at' => $now,
        ];

        if ($sourceHash !== null) {
            $values['source_hash'] = $sourceHash;
        }

        $this->writePage(self::hash($url), $url, $values, $now);
    }

    /** Deletes the page's answers and zeroes its count; the page row itself stays. */
    public function clearPage(string $url): void
    {
        $hash = self::hash($url);

        $this->connection->transaction(function () use ($hash): void {
            $this->answers()->where('url_hash', $hash)->delete();
            $this->pages()->where('url_hash', $hash)->update(['answers' => 0, 'updated_at' => self::now()]);
        });
    }

    /**
     * Deletes every page (and its answers) whose URL is not in the list —
     * the source stopped listing it. Returns how many pages went.
     *
     * @param  list<string>  $urls
     */
    public function forgetPagesNotIn(array $urls): int
    {
        $keep = array_fill_keys(array_map([self::class, 'hash'], $urls), true);
        $gone = [];

        foreach ($this->pages()->pluck('url_hash') as $hash) {
            if (! isset($keep[(string) $hash])) {
                $gone[] = (string) $hash;
            }
        }

        if ($gone === []) {
            return 0;
        }

        $this->connection->transaction(function () use ($gone): void {
            foreach (array_chunk($gone, 500) as $chunk) {
                $this->answers()->whereIn('url_hash', $chunk)->delete();
                $this->pages()->whereIn('url_hash', $chunk)->delete();
            }
        });

        return count($gone);
    }

    /**
     * Every "q_key|a_key" held by a page other than `$exceptUrl` — what a
     * page being rebuilt must not repeat.
     *
     * @return array<string, true>
     */
    public function takenKeys(string $exceptUrl): array
    {
        $taken = [];

        foreach ($this->answers()->where('url_hash', '!=', self::hash($exceptUrl))->get(['q_key', 'a_key']) as $row) {
            $taken[$row->q_key.'|'.$row->a_key] = true;
        }

        return $taken;
    }

    /**
     * Up to `$limit` of `$pages` to visit this run: the ones with no state
     * row first, in the given order, then the rest by checked_at, oldest
     * first.
     *
     * @param  list<array{url: string, kind: string}>  $pages
     * @return list<array{url: string, kind: string}>
     */
    public function pagesToVisit(array $pages, int $limit): array
    {
        if ($limit <= 0 || $pages === []) {
            return [];
        }

        $checkedAt = [];

        foreach (array_chunk(array_map(static fn (array $page): string => self::hash($page['url']), $pages), 500) as $chunk) {
            foreach ($this->pages()->whereIn('url_hash', $chunk)->get(['url_hash', 'checked_at']) as $row) {
                $checkedAt[(string) $row->url_hash] = $row->checked_at !== null ? (string) $row->checked_at : '';
            }
        }

        $never = [];
        $seen = [];

        foreach ($pages as $page) {
            $hash = self::hash($page['url']);

            if (! isset($checkedAt[$hash])) {
                $never[] = $page;
            } else {
                $seen[] = [$checkedAt[$hash], $page];
            }
        }

        usort($seen, static fn (array $a, array $b): int => strcmp($a[0], $b[0]));

        return array_slice([...$never, ...array_column($seen, 1)], 0, $limit);
    }

    /**
     * Every answer in the bank, by kind, then page URL, then position —
     * what {@see FaqBankCatalog} publishes.
     *
     * @return list<array{q: string, a: string, url: string, kind: string}>
     */
    public function all(int $cap = 5000): array
    {
        $out = [];

        foreach ($this->answers()->orderBy('kind')->orderBy('source_url')->orderBy('position')->limit(max(0, $cap))->get() as $row) {
            $out[] = ['q' => (string) $row->question, 'a' => (string) $row->answer, 'url' => (string) $row->source_url, 'kind' => (string) $row->kind];
        }

        return $out;
    }

    /** @return array{answers: int, pages: int, last_generated_at: ?string} */
    public function summary(): array
    {
        $last = $this->pages()->max('generated_at');

        return [
            'answers' => (int) $this->answers()->count(),
            'pages' => (int) $this->pages()->count(),
            'last_generated_at' => $last !== null ? (string) $last : null,
        ];
    }

    /** The url_hash a page is keyed on — sha1 of the URL as the source spelled it, same as Seo\Bing\BingCoverageSync::hash(). */
    public static function hash(string $url): string
    {
        return sha1(trim($url));
    }

    /** @param  array<string, mixed>  $values */
    private function writePage(string $hash, string $url, array $values, string $now): void
    {
        if ($this->pages()->where('url_hash', $hash)->exists()) {
            $this->pages()->where('url_hash', $hash)->update($values);

            return;
        }

        $this->connection->table($this->pagesTable)->insert($this->tenantFields() + $values + [
            'url_hash' => $hash,
            'url' => mb_substr($url, 0, 500),
            'source_hash' => null,
            'answers' => 0,
            'created_at' => $now,
        ]);
    }

    /** @return array<string, mixed> */
    private function tenantFields(): array
    {
        return $this->tenantColumn !== null ? [$this->tenantColumn => ($this->tenantId)()] : [];
    }

    private function pages(): Builder
    {
        return $this->scoped($this->connection->table($this->pagesTable));
    }

    private function answers(): Builder
    {
        return $this->scoped($this->connection->table($this->answersTable));
    }

    private function scoped(Builder $query): Builder
    {
        return $query->when($this->tenantColumn !== null, fn (Builder $q) => $q->where($this->tenantColumn, ($this->tenantId)()));
    }

    private static function now(): string
    {
        return Carbon::now()->toDateTimeString();
    }
}
