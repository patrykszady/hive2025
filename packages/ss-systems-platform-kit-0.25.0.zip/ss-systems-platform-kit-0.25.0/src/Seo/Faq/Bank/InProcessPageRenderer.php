<?php

namespace SsSystems\Platform\Seo\Faq\Bank;

use Illuminate\Contracts\Container\Container;
use Illuminate\Contracts\Http\Kernel;
use Illuminate\Http\Request;

/**
 * Renders one of the site's own pages without leaving the process: a GET
 * for the absolute URL dispatched through the HTTP kernel, the way a
 * feature test does — no socket, no DNS, no robots rule, no rate limit,
 * and the page the builder reads is the page the site serves (2026-11-10).
 * The request carries a User-Agent of its own so a site's analytics can
 * leave it out, and asks for HTML so a content-negotiating route answers
 * with the page.
 *
 * Only a 200 with an HTML content type counts; anything else — a redirect,
 * a 404, a JSON answer, an exception out of the kernel — is null, and the
 * builder records the page as too thin to mine rather than failing the
 * run. The kernel is resolved on the first render, not in the constructor,
 * so the command can be built in a bare container (its tests, a site whose
 * source supplies every page's text itself) without ever touching one.
 */
final class InProcessPageRenderer
{
    public const USER_AGENT = 'ss-platform faq-bank';

    private ?Kernel $kernel = null;

    public function __construct(private readonly Kernel|Container $app) {}

    public function render(string $url): ?string
    {
        try {
            $kernel = $this->kernel();
            $request = Request::create($url, 'GET', server: ['HTTP_USER_AGENT' => self::USER_AGENT, 'HTTP_ACCEPT' => 'text/html']);
            $response = $kernel->handle($request);
            $kernel->terminate($request, $response);
        } catch (\Throwable) {
            return null;
        }

        if ($response->getStatusCode() !== 200) {
            return null;
        }

        if (! str_contains(strtolower((string) $response->headers->get('Content-Type', '')), 'text/html')) {
            return null;
        }

        $body = $response->getContent();

        return is_string($body) ? $body : null;
    }

    private function kernel(): Kernel
    {
        return $this->kernel ??= $this->app instanceof Kernel ? $this->app : $this->app->make(Kernel::class);
    }
}
