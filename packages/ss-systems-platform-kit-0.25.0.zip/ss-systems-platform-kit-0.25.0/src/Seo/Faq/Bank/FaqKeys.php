<?php

namespace SsSystems\Platform\Seo\Faq\Bank;

/**
 * The key two answers are compared on, so the bank keeps one of them:
 * lower case, every town name the site serves replaced by "{town}" (the
 * longest names first, so "Lake Zurich" is one town before "Zurich" could
 * be), punctuation dropped, spaces collapsed, cut at the column's 191
 * characters. Two pairs whose question key AND answer key match are the
 * same answer said about different towns — jpeterson-design's 397
 * hand-written answers were mostly one question repeated per town, and the
 * bank must not repeat that (2026-11-10). A town-specific answer (a permit
 * rule, a price that differs) keeps a different answer key and survives.
 *
 * A possessive ("Palatine's permit office") collapses with its town, so
 * the key reads "{town} permit office" whichever town it was.
 */
final class FaqKeys
{
    public const TOWN = '{town}';

    public const MAX_LENGTH = 191;

    /** @param  list<string>  $towns */
    public static function question(string $q, array $towns): string
    {
        return self::key($q, $towns);
    }

    /** @param  list<string>  $towns */
    public static function answer(string $a, array $towns): string
    {
        return self::key($a, $towns);
    }

    /** @param  list<string>  $towns */
    public static function key(string $text, array $towns): string
    {
        $key = mb_strtolower(trim($text));

        $towns = array_values(array_unique(array_filter(array_map(static fn ($town): string => trim((string) $town), $towns))));
        usort($towns, static fn (string $a, string $b): int => mb_strlen($b) <=> mb_strlen($a));

        foreach ($towns as $town) {
            $pattern = '/(?<![\p{L}\p{N}])'.preg_replace('/\s+/', '\s+', preg_quote(mb_strtolower($town), '/')).'(?:[\'’]s)?(?![\p{L}\p{N}])/u';
            $key = (string) preg_replace($pattern, ' '.self::TOWN.' ', $key);
        }

        $key = (string) preg_replace('/[\'’]/u', '', $key);
        $key = (string) preg_replace('/[^\p{L}\p{N}\s{}]+/u', ' ', $key);
        $key = trim((string) preg_replace('/\s+/u', ' ', $key));

        return mb_substr($key, 0, self::MAX_LENGTH);
    }
}
