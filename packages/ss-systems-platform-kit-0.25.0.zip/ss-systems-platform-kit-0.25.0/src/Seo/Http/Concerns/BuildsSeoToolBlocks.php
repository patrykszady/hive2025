<?php

namespace SsSystems\Platform\Seo\Http\Concerns;

use Illuminate\Container\Container;
use Illuminate\Database\ConnectionInterface;
use SsSystems\Platform\Seo\AiTraffic\AiTrafficSnapshot;
use SsSystems\Platform\Seo\Intel\IntelRunner;
use SsSystems\Platform\Seo\Intel\IntelSnapshot;
use SsSystems\Platform\Seo\Intel\IntelStore;
use SsSystems\Platform\Seo\KeywordResearch\KeywordResearchSnapshot;
use SsSystems\Platform\Seo\MapPack\Contracts\MapPackContext;
use SsSystems\Platform\Seo\MapPack\MapPackSnapshot;
use SsSystems\Platform\Seo\MapPack\MapPackStore;
use SsSystems\Platform\Seo\MapPack\NullMapPackContext;
use SsSystems\Platform\Seo\Rankings\RankingsSnapshot;
use SsSystems\Platform\Seo\Visibility\VisibilitySnapshot;

/**
 * The SEO-tool blocks of a site's /api/admin/v1/seo/snapshot — rank
 * tracking, keyword research, competitor visibility, AI traffic, the
 * map-pack grid and the change intel — from one call, so every site's snapshot controller
 * spreads `...$this->seoToolBlocks($rankDays, $remember)` into its data
 * and the ss.systems report page reads the same shapes everywhere
 * (Patryk, 2026-10-31: "we should be using the same ... in the kit").
 *
 * A tool whose table a site has not migrated yet answers its own empty
 * shape rather than failing the whole snapshot: the card then says "not
 * set up on this site yet". Caching is the site's: it passes a $remember
 * callable (key, ttl seconds, builder) — usually Cache::remember — and
 * forgets seoToolBlockCacheKeys() when the owner clicks Refresh. The
 * container, not app(), so the trait also runs in the kit's bare-container
 * unit tests.
 */
trait BuildsSeoToolBlocks
{
    /** @var list<int> the rank-card windows the hub offers */
    private static array $rankWindows = [7, 14, 28];

    /**
     * @param  (callable(string, int, callable(): array): array)|null  $remember
     * @return array<string, array<string, mixed>>
     */
    protected function seoToolBlocks(int $rankDays = 7, ?callable $remember = null): array
    {
        $remember ??= fn (string $key, int $ttl, callable $build): array => $build();
        $container = Container::getInstance();
        $schema = $container->make(ConnectionInterface::class)->getSchemaBuilder();

        return [
            'rankings' => $schema->hasTable('seo_rank_snapshots')
                ? $remember('seo_reports_rankings_v1_'.$rankDays, 1800, fn (): array => $container->make(RankingsSnapshot::class)->build($rankDays))
                : ['available' => false],
            'keyword_research' => $schema->hasTable('seo_keywords')
                ? $remember('seo_reports_keyword_research_v1', 1800, fn (): array => $container->make(KeywordResearchSnapshot::class)->build())
                : ['available' => false],
            'dataforseo' => $remember('seo_reports_dataforseo_v1', 1800, fn (): array => $container->make(VisibilitySnapshot::class)->build()),
            'ai_traffic' => $schema->hasTable('ai_traffic_daily')
                ? $remember('seo_reports_ai_traffic_v1', 900, fn (): array => $container->make(AiTrafficSnapshot::class)->build())
                : ['referrals' => [], 'crawlers' => [], 'total_referrals' => 0, 'total_crawls' => 0],
            'map_pack' => $schema->hasTable('map_pack_scans')
                ? $remember('seo_reports_map_pack_v1', 1800, fn (): array => $this->mapPackSnapshot($container)->build())
                : ['available' => false, 'keywords' => []],
            // Intel needs the three seo_intel_* tables AND the site's own
            // IntelRunner binding (which lists the families it runs); without
            // either, the card shows nothing to report rather than failing.
            'intel' => $container->bound(IntelRunner::class) && $container->make(IntelStore::class)->ready()
                ? $remember('seo_reports_intel_v1', 1800, fn (): array => $container->make(IntelSnapshot::class)->build())
                : ['families' => [], 'open_findings' => 0, 'critical' => 0, 'spent_30d' => 0.0, 'top_findings' => []],
        ];
    }

    /**
     * Every key seoToolBlocks() may have cached — a refresh forgets them all.
     *
     * @return list<string>
     */
    public static function seoToolBlockCacheKeys(): array
    {
        $keys = ['seo_reports_keyword_research_v1', 'seo_reports_dataforseo_v1', 'seo_reports_ai_traffic_v1', 'seo_reports_map_pack_v1', 'seo_reports_intel_v1'];
        foreach (self::$rankWindows as $days) {
            $keys[] = 'seo_reports_rankings_v1_'.$days;
        }

        return $keys;
    }

    /** A site that never bound a MapPackContext still gets the grid, without town labels or a review gap. */
    private function mapPackSnapshot(Container $container): MapPackSnapshot
    {
        if ($container->bound(MapPackContext::class)) {
            return $container->make(MapPackSnapshot::class);
        }

        return new MapPackSnapshot($container->make(MapPackStore::class), new NullMapPackContext);
    }
}
