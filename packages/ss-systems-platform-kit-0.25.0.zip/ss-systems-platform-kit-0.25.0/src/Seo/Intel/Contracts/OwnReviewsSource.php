<?php

namespace SsSystems\Platform\Seo\Intel\Contracts;

/**
 * Our own, already-collected reviews/testimonials — what a site would read
 * from its own review model (gs.construction's `App\Models\Testimonial`,
 * its non-hidden rows) to compare against what the Business Data API
 * reports Google shows for the same business. Deliberately thin: a count
 * and an average rating, nothing else — {@see \SsSystems\Platform\Seo\Intel\Sources\BusinessDataSource}'s
 * optional constructor dependency (see its class docblock) uses it purely
 * as a cross-check tile/finding, never to read or summarise review text
 * itself. gs.construction's own `collectReviewThemes()` used to run an AI
 * theme classifier over the raw text of its own testimonials alongside the
 * competitors' — that half has no equivalent here (no kit-owned contract
 * exposes arbitrary review text) and is dropped; see BusinessDataSource's
 * class docblock for where that gap is documented.
 *
 * A null return from either method means "unknown", not zero — a source
 * reading this contract must omit the comparison it backs rather than
 * treat null as 0 (there is no "faked" 0-review site).
 */
interface OwnReviewsSource
{
    /** Reviews/testimonials this site currently shows, or null when unknown. */
    public function count(): ?int;

    /** Their average rating (e.g. 1-5 stars), or null when unknown. */
    public function averageRating(): ?float;
}
