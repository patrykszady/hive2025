<?php

namespace SsSystems\Platform\Seo\Intel;

use Illuminate\Support\Carbon;
use SsSystems\Platform\Seo\DataForSeo\Contracts\DataForSeoApi;

/**
 * Runs intelligence sources: collect → store today's snapshots → compare with
 * the previous run → open/resolve findings → ledger the cost. Ported from
 * gs.construction's App\Services\Seo\Intel\IntelRunner.
 *
 * GENERALISED: gs.construction's `sources()` resolved classes out of
 * `config('seo-intel.sources', [])` through the container on every call
 * (so a not-yet-written class could be listed ahead of its code). The kit
 * has no config dependency and no app container to resolve against, so a
 * site builds its own `IntelSource` instances (each already wired with the
 * DataForSeoApi/IntelStore/SeoSiteProfile/IntelSettings it needs) and hands
 * the finished list to this class's constructor once — "a plain list of
 * source classes passed to the runner" in the porting brief. Cache
 * invalidation (gs.construction's `Cache::forget()` after every recorded
 * run) is also gone: nothing in the kit reads the Cache facade (see
 * {@see IntelSnapshot}'s own docblock) — a site wrapping `IntelSnapshot::build()`
 * in its own `Cache::remember()` forgets that key itself after a run, the
 * same way it already does for every other SEO snapshot section.
 */
final class IntelRunner
{
    /** @param  list<IntelSource>  $sources  every family this site collects, already constructed */
    public function __construct(
        private readonly DataForSeoApi $dfs,
        private readonly IntelStore $store,
        private readonly array $sources = [],
    ) {
    }

    /** USD spent through this runner's transport so far (the command's budget check reads this). */
    public function spent(): float
    {
        return $this->dfs->spent();
    }

    /**
     * Registered sources, keyed by family.
     *
     * @param  list<string>|null  $only  families to keep
     * @return array<string, IntelSource>
     */
    public function sources(?array $only = null): array
    {
        $out = [];
        foreach ($this->sources as $source) {
            if ($only === null || in_array($source->family(), $only, true)) {
                $out[$source->family()] = $source;
            }
        }

        return $out;
    }

    /**
     * @return array{family: string, ok: bool, skipped: bool, cost: float, snapshots: int, findings: array{new: int, open: int, resolved: int}, error: ?string, duration_ms: int}
     */
    public function run(IntelSource $source, bool $dryRun = false, bool $findingsOnly = false): array
    {
        $family = $source->family();
        $runId = Carbon::now()->format('Ymd-His');
        $takenOn = Carbon::now()->toDateString();
        $started = microtime(true);
        $spentBefore = $this->dfs->spent();
        $stats = ['new' => 0, 'open' => 0, 'resolved' => 0];
        $count = 0;
        $error = null;

        try {
            if (! $findingsOnly) {
                $snapshots = $source->collect();
                $count = count($snapshots);
                if ($count === 0 && $this->dfs->getLastError()) {
                    $error = $this->dfs->getLastError();
                }
                if ($source->wasSkipped()) {
                    // Nothing to collect right now (a crawl still queued, a
                    // family not due): no snapshots, no findings churn, no ledger row.
                    return ['family' => $family, 'ok' => true, 'skipped' => true, 'cost' => round($this->dfs->spent() - $spentBefore, 4), 'snapshots' => 0, 'findings' => $stats, 'error' => null, 'duration_ms' => (int) round((microtime(true) - $started) * 1000)];
                }
                if (! $dryRun) {
                    $this->store->save($family, $runId, $takenOn, $snapshots);
                }
            }
            if (! $dryRun) {
                $stats = $this->store->saveFindings($family, $runId, $takenOn, $source->findings());
            }
        } catch (\Throwable $e) {
            $error = mb_substr(get_class($e).': '.$e->getMessage(), 0, 500);
        }

        $cost = round($this->dfs->spent() - $spentBefore, 4);
        $duration = (int) round((microtime(true) - $started) * 1000);
        if (! $dryRun && ! $findingsOnly) {
            $this->store->recordRun($family, $runId, $takenOn, [
                'cost' => $cost, 'snapshots' => $count, 'findings_open' => $stats['open'], 'findings_new' => $stats['new'],
                'findings_resolved' => $stats['resolved'], 'duration_ms' => $duration, 'error' => $error,
            ]);
        }

        return ['family' => $family, 'ok' => $error === null, 'skipped' => false, 'cost' => $cost, 'snapshots' => $count, 'findings' => $stats, 'error' => $error, 'duration_ms' => $duration];
    }
}
