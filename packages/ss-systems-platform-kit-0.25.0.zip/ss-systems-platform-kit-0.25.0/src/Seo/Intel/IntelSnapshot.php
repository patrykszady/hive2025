<?php

namespace SsSystems\Platform\Seo\Intel;

use Illuminate\Support\Carbon;

/**
 * Shapes `IntelStore`'s rows into the exact shape gs.construction's
 * `seo-reports.blade.php` reads as `$snapshot['intel']` ("What Changed
 * Since Last Check" on the ss.systems report page) — ported from
 * `SeoReportController::intelSnapshot()`, keys unchanged, verified against
 * the blade (not memory): `families[*].label/taken_on/prev_taken_on/cost/
 * error/estimate/report/findings/findings_open/findings_by_severity/runs`,
 * plus the top-level `open_findings`/`critical`/`spent_30d`/`top_findings`.
 *
 * Caching is deliberately NOT this class's job (same reasoning as
 * {@see \SsSystems\Platform\Seo\AiTraffic\AiTrafficSnapshot}): `build()`
 * always computes fresh, and a site wraps the call in its own
 * `Cache::remember(..., now()->addMinutes(30), ...)`, matching
 * gs.construction's own `seo_reports_intel_v1` key (1800 seconds).
 */
final class IntelSnapshot
{
    public function __construct(
        private readonly IntelStore $store,
        private readonly IntelRunner $runner,
    ) {
    }

    /**
     * @return array{
     *     families: array<string, array{label: string, taken_on: ?string, prev_taken_on: ?string, cost: ?float, error: ?string, estimate: float, report: array, findings: list<array<string, mixed>>, findings_open: int, findings_by_severity: array<string, int>, runs: list<array<string, mixed>>}>,
     *     open_findings: int,
     *     critical: int,
     *     spent_30d: float,
     *     top_findings: list<array{family: string, source: string, severity: string, title: string, detail: string, key: ?string, action: ?array}>
     * }
     */
    public function build(): array
    {
        if (! $this->store->ready()) {
            return ['families' => [], 'open_findings' => 0, 'critical' => 0, 'spent_30d' => 0.0, 'top_findings' => []];
        }

        $families = [];
        $labels = [];

        foreach ($this->runner->sources() as $family => $source) {
            $labels[$family] = $source->label();
            $runs = $this->store->runs($family, 8);
            $last = $runs->first();

            try {
                $report = $last ? $source->report() : ['tiles' => [], 'tables' => [], 'note' => 'Not collected yet.'];
            } catch (\Throwable $e) {
                $report = ['tiles' => [], 'tables' => [], 'note' => 'Report unavailable: '.mb_substr($e->getMessage(), 0, 120)];
            }

            $open = $this->store->openFindings($family, 200);

            $families[$family] = [
                'label' => $source->label(),
                'taken_on' => $last->taken_on ?? null,
                'prev_taken_on' => $runs->skip(1)->first()->taken_on ?? null,
                'cost' => $last ? round((float) $last->cost, 3) : null,
                'error' => $last->error ?? null,
                'estimate' => round($source->estimateCost(), 3),
                'report' => $report,
                'findings' => $open->take(10)->map(fn ($f) => [
                    'severity' => $f->severity, 'code' => $f->code, 'title' => $f->title, 'detail' => $f->detail, 'key' => $f->key,
                    'first_seen_on' => substr((string) $f->first_seen_on, 0, 10), 'delta' => $f->delta, 'action' => $f->action,
                ])->values()->all(),
                'findings_open' => $open->count(),
                'findings_by_severity' => $open->countBy('severity')->all(),
                'runs' => $runs->map(fn ($r) => ['taken_on' => $r->taken_on, 'cost' => round((float) $r->cost, 3), 'new' => (int) $r->findings_new, 'resolved' => (int) $r->findings_resolved, 'error' => $r->error])->values()->all(),
            ];
        }

        $all = $this->store->openFindings(null, 1000);
        $spent = $this->store->spentSince(Carbon::now()->subDays(30)->toDateString());

        return [
            'families' => $families,
            'open_findings' => $all->count(),
            'critical' => $all->where('severity', 'critical')->count(),
            'spent_30d' => round($spent, 2),
            // 'title' is the plain finding text (never vendor/family-prefixed);
            // 'source' is the family's human label, for a Details accordion —
            // 'family' (the raw slug) stays for backward-compatible filtering.
            'top_findings' => $all->take(12)->map(fn ($f) => ['family' => $f->family, 'source' => $labels[$f->family] ?? $f->family, 'severity' => $f->severity, 'title' => $f->title, 'detail' => $f->detail, 'key' => $f->key, 'action' => $f->action])->values()->all(),
        ];
    }
}
