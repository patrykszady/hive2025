<?php

namespace SsSystems\Platform\Seo\Intel;

/**
 * Replaces gs.construction's `config('seo-intel.families.<family>.<key>',
 * $default)` (read by every `IntelSource::config()` call) with an injected
 * value object: the kit never reads `config()` itself (see composer.json —
 * no illuminate/config dependency at all), so a site's own
 * `config/seo-intel.php` becomes an array handed to `IntelSettings` at
 * bind time instead.
 *
 * Deliberately NOT keyed by anything but `[family][key]` — every knob a
 * ported source reads (`max_cost`, `max_findings`, `depth`, `tracked`,
 * `queries`, `services`, `phrases`, `location_code`, `metro_cities`,
 * `serp_mode`, ...) is a plain scalar or array a site's config file already
 * organised this way.
 */
final class IntelSettings
{
    /** @param  array<string, array<string, mixed>>  $families  per-family knobs, keyed by IntelSource::family() */
    public function __construct(private readonly array $families = [])
    {
    }

    public function get(string $family, string $key, mixed $default = null): mixed
    {
        return $this->families[$family][$key] ?? $default;
    }

    /**
     * A copy of this settings object with one family's knobs replaced/added
     * — handy for tests and for a site assembling settings incrementally.
     *
     * @param  array<string, mixed>  $values
     */
    public function withFamily(string $family, array $values): self
    {
        $families = $this->families;
        $families[$family] = array_merge($families[$family] ?? [], $values);

        return new self($families);
    }
}
