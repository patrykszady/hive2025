<?php

namespace SsSystems\Platform\Seo\MapPack;

use Illuminate\Http\Client\Factory;
use Illuminate\Support\Carbon;
use Illuminate\Support\Str;
use SsSystems\Platform\Seo\Contracts\SeoSiteProfile;

/**
 * Reads a map-pack competitor's homepage for ANALYSIS: title, description,
 * a text excerpt, its headings, and which of the site's own services and
 * towns it names — ported from gs.construction's
 * App\Services\Seo\CompetitorSiteFetcher (82 lines), called by its
 * `seo:map-pack-competitors` command. Nothing read here is ever rendered or
 * reused as the site's own copy, and no images are touched — this is
 * competitive intelligence, not content.
 *
 * CHANGED FROM GSC:
 *  - gsc matched `AreaServed::pluck('city')` and a hardcoded SERVICES lexicon
 *    against every competitor's page. This port matches
 *    `SeoSiteProfile::towns()`/`::services()` instead (a site's own
 *    vocabulary, whole-word, case-insensitive) and falls back to
 *    `self::GENERIC_SERVICES` — gsc's own lexicon, kept verbatim as a
 *    constant — only when a site's profile lists no services at all, same
 *    as `MapPackGridCommand` falling back to nothing when a profile is
 *    thin. `GENERIC_SERVICES` matches by substring, not whole-word, exactly
 *    as gsc's original did (its keys are deliberately partial — "tub"
 *    inside "bathtub" is still a hit).
 *  - gsc fetched the URL once, as given, and returned null (the caller
 *    substituted `['site_fetched_at' => now()]` itself) on any failure.
 *    `read()` never returns null: a failed fetch stamps `site_fetched_at`
 *    with every other field empty right here, so `MapPackStore`'s
 *    "needs a read" query does not retry it again tomorrow. It also tries
 *    `https://` first and falls back to `http://` on failure — gsc's
 *    `map_pack_competitors.url` rows came from DataForSEO's Google Maps
 *    "website" field, which is not guaranteed to carry a working scheme.
 *  - HTTP goes through an injected `Illuminate\Http\Client\Factory` (explicit
 *    timeout, no facade), the same seam `DataForSeoClient` and
 *    `Citations\LinkCheck`'s sibling classes use — gsc called the `Http`
 *    facade directly via a `PartnerSiteFetcher` collaborator this port does
 *    not carry over (that class also fetches up to three follow-up pages;
 *    one page is enough for "what do they offer and which towns" analysis).
 *  - A host matched by `SeoSiteProfile::competitorExclusions()` is skipped
 *    before any HTTP call at all (`read()` returns `[]` — nothing to write)
 *    — gsc's command did this check itself, before ever calling its
 *    fetcher; here it lives with the fetch so any caller gets the same
 *    "don't read a directory's homepage" guarantee for free.
 *  - The downloaded body is capped at `MAX_HTML_BYTES` before parsing — a
 *    competitor's homepage is unknown, un-trusted content, and gsc's
 *    version had no such limit.
 */
final class CompetitorSiteReader
{
    private const TIMEOUT_SECONDS = 10;

    /** A competitor's homepage is untrusted content of unknown size; parsed as plain text past this point is wasted effort, not more signal. */
    private const MAX_HTML_BYTES = 400_000;

    private const USER_AGENT = 'Mozilla/5.0 (compatible; SsSystemsSeoBot/1.0)';

    /** gsc's `CompetitorSiteFetcher::SERVICES`, verbatim — the fallback vocabulary for a site profile that lists no services at all. */
    private const GENERIC_SERVICES = [
        'kitchen' => 'Kitchen', 'bathroom' => 'Bathroom', 'basement' => 'Basement', 'addition' => 'Additions',
        'whole home' => 'Whole-home', 'home remodel' => 'Home remodel', 'roof' => 'Roofing', 'deck' => 'Decks',
        'siding' => 'Siding', 'window' => 'Windows', 'flooring' => 'Flooring', 'tile' => 'Tile', 'cabinet' => 'Cabinetry',
        'countertop' => 'Countertops', 'design' => 'Design', 'shower' => 'Showers', 'tub' => 'Tubs', 'painting' => 'Painting',
    ];

    public function __construct(
        private readonly Factory $http,
        private readonly SeoSiteProfile $profile,
    ) {
    }

    /**
     * Attributes for `MapPackStore::recordSiteRead()`, or `[]` when the host
     * is one of `SeoSiteProfile::competitorExclusions()` (nothing to write —
     * the row stays unread and un-stamped, same as gsc's command never
     * calling its fetcher for one). Never throws and never returns null for
     * any other reason: an unreachable site still comes back with
     * `site_fetched_at` set so it is not retried on every run.
     *
     * @return array{site_title: ?string, site_description: ?string, site_excerpt: ?string, site_headings: list<string>, site_towns: list<string>, site_services: list<string>, site_fetched_at: \DateTimeInterface}|array{}
     */
    public function read(string $url): array
    {
        $url = trim($url);
        if ($url === '') {
            return [];
        }

        $host = self::hostOf($url);
        if ($host === null || $this->isExcluded($host)) {
            return [];
        }

        $bare = (string) preg_replace('#^https?://#i', '', $url);
        $html = $this->fetch('https://'.$bare) ?? $this->fetch('http://'.$bare);

        return $html !== null ? $this->parse($html) : $this->unreadable();
    }

    private function fetch(string $url): ?string
    {
        try {
            $response = $this->http
                ->withHeaders(['User-Agent' => self::USER_AGENT])
                ->timeout(self::TIMEOUT_SECONDS)
                ->get($url);
        } catch (\Throwable) {
            return null;
        }

        if (! $response->successful()) {
            return null;
        }

        return mb_substr((string) $response->body(), 0, self::MAX_HTML_BYTES);
    }

    /** @return array{site_title: null, site_description: null, site_excerpt: null, site_headings: array{}, site_towns: array{}, site_services: array{}, site_fetched_at: \DateTimeInterface} */
    private function unreadable(): array
    {
        return [
            'site_title' => null,
            'site_description' => null,
            'site_excerpt' => null,
            'site_headings' => [],
            'site_towns' => [],
            'site_services' => [],
            'site_fetched_at' => Carbon::now(),
        ];
    }

    /** @return array{site_title: ?string, site_description: ?string, site_excerpt: ?string, site_headings: list<string>, site_towns: list<string>, site_services: list<string>, site_fetched_at: \DateTimeInterface} */
    private function parse(string $html): array
    {
        $title = self::extractTitle($html);
        $description = self::extractDescription($html);
        $headings = self::extractHeadings($html);
        $excerptFull = self::extractExcerpt($html);
        $excerpt = $excerptFull !== null ? Str::limit($excerptFull, 1200, '') : null;

        $text = ' '.mb_strtolower(implode(' ', [...$headings, (string) $title, (string) $description, (string) $excerpt])).' ';

        return [
            'site_title' => $title,
            'site_description' => $description,
            'site_excerpt' => $excerpt,
            'site_headings' => $headings,
            'site_towns' => $this->matchedTowns($text),
            'site_services' => $this->matchedServices($text),
            'site_fetched_at' => Carbon::now(),
        ];
    }

    private static function extractTitle(string $html): ?string
    {
        if (preg_match('#<title[^>]*>(.*?)</title>#is', $html, $m) !== 1) {
            return null;
        }

        $title = self::clean($m[1]);

        return $title !== '' ? $title : null;
    }

    private static function extractDescription(string $html): ?string
    {
        $matched = preg_match('#<meta[^>]+name=["\']description["\'][^>]*content=["\']([^"\']*)["\']#i', $html, $m) === 1
            || preg_match('#<meta[^>]+content=["\']([^"\']*)["\'][^>]*name=["\']description["\']#i', $html, $m) === 1;

        if (! $matched) {
            return null;
        }

        $description = self::clean($m[1]);

        return $description !== '' ? $description : null;
    }

    /**
     * H1-H3 only (gsc's choice — lower headings are usually boilerplate),
     * deduplicated, capped at 120 characters and 30 headings.
     *
     * @return list<string>
     */
    private static function extractHeadings(string $html): array
    {
        preg_match_all('#<h([1-3])[^>]*>(.*?)</h\1>#is', $html, $m);

        $headings = [];
        foreach ($m[2] as $raw) {
            $heading = self::clean(strip_tags($raw));
            if ($heading !== '' && mb_strlen($heading) <= 120 && ! in_array($heading, $headings, true)) {
                $headings[] = $heading;
            }
            if (count($headings) >= 30) {
                break;
            }
        }

        return $headings;
    }

    /**
     * The page's visible text, head/script/style/nav/header/footer/form
     * stripped out along with their content — ported from gs.construction's
     * `App\Services\Blog\PartnerSiteFetcher::parse()`, the same collaborator
     * gsc's `CompetitorSiteFetcher` read its title/description/excerpt
     * through.
     */
    private static function extractExcerpt(string $html): ?string
    {
        $body = (string) preg_replace('#<(head|script|style|noscript|svg|nav|header|footer|form)[^>]*>.*?</\1>#is', ' ', $html);
        $body = (string) preg_replace('#<!--.*?-->#s', ' ', $body);
        // A space at every tag boundary, so "<h1>A</h1><p>B" does not fuse into "AB".
        $text = self::clean(strip_tags(str_replace('>', '> ', $body)));

        return $text !== '' ? $text : null;
    }

    /** @return list<string> */
    private function matchedTowns(string $textLower): array
    {
        $matched = [];
        foreach ($this->profile->towns() as $town) {
            $town = trim($town);
            if ($town !== '' && self::containsWholeWord($textLower, $town)) {
                $matched[] = $town;
            }
        }

        return $matched;
    }

    /** @return list<string> */
    private function matchedServices(string $textLower): array
    {
        $services = $this->profile->services();

        if ($services === []) {
            $matched = [];
            foreach (self::GENERIC_SERVICES as $word => $label) {
                if (str_contains($textLower, $word)) {
                    $matched[] = $label;
                }
            }

            return $matched;
        }

        $matched = [];
        foreach ($services as $service) {
            $service = trim($service);
            if ($service !== '' && self::containsWholeWord($textLower, $service)) {
                $matched[] = $service;
            }
        }

        return $matched;
    }

    private static function containsWholeWord(string $haystackLower, string $needle): bool
    {
        return preg_match('/\b'.preg_quote(mb_strtolower($needle), '/').'\b/u', $haystackLower) === 1;
    }

    /**
     * Exact-host-or-subdomain match against `SeoSiteProfile::competitorExclusions()`
     * — the same `$host === $suffix || str_ends_with($host, '.'.$suffix)` shape
     * `CompetitorDomainSource::exclusionMatcher()` uses, kept local here since
     * this is the only check this class needs (no brand/own-domain check — a
     * row never reaches `map_pack_competitors` for the site's own business in
     * the first place, see `MapPackGridCommand::matchesBrand()`).
     */
    private function isExcluded(string $host): bool
    {
        foreach ($this->profile->competitorExclusions() as $exclusion) {
            $exclusion = self::normalizeHost($exclusion);
            if ($exclusion !== '' && ($host === $exclusion || str_ends_with($host, '.'.$exclusion))) {
                return true;
            }
        }

        return false;
    }

    private static function hostOf(string $url): ?string
    {
        $withScheme = preg_match('#^https?://#i', $url) === 1 ? $url : 'https://'.$url;
        $host = parse_url($withScheme, PHP_URL_HOST);

        return is_string($host) && $host !== '' ? self::normalizeHost($host) : null;
    }

    private static function normalizeHost(string $host): string
    {
        return (string) preg_replace('/^www\./', '', mb_strtolower(trim($host)));
    }

    /**
     * Decode entities and collapse whitespace — ported from
     * `PartnerSiteFetcher::clean()`, including its repeated-phrase squash
     * (a gallery page's "View fullsize View fullsize View fullsize …"
     * collapsed to one copy, so it does not dominate the text a service/town
     * match runs against).
     */
    private static function clean(string $value): string
    {
        $value = html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $value = trim((string) preg_replace('/\s+/u', ' ', $value));

        return (string) preg_replace('/\b((?:\w+ ){0,3}\w+)(?:\s+\1\b){2,}/u', '$1', $value);
    }
}
