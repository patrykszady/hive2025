<?php

namespace SsSystems\Platform\Seo\MapPack\Console;

use Illuminate\Console\Command;
use SsSystems\Platform\Seo\MapPack\CompetitorSiteReader;
use SsSystems\Platform\Seo\MapPack\MapPackStore;

/**
 * `seo:map-pack-competitors` — the map pack's top competitors, aggregated
 * across every keyword and scan `seo:map-pack-grid` has recorded (see
 * `MapPackStore::topCompetitors()`): who shows up most across the whole
 * campaign, by total 3-pack appearances — then, unless `--no-fetch` is
 * given, reads each one's homepage (see `CompetitorSiteReader`) so the SEO
 * page can show what they offer and which of the site's own towns they
 * name, ported from gs.construction's `SeoMapPackCompetitors` (59 lines).
 *
 * CHANGED FROM GSC:
 *  - gsc's command did only the homepage-reading half (`--limit` there
 *    meant "competitor sites to read this run"); the leaderboard print was
 *    this port's own earlier addition. `--limit` now bounds both: the
 *    leaderboard shown, and — since the read step reads sites FOR that same
 *    leaderboard — the number of distinct businesses read this run.
 *  - `--refresh` is gsc's option, same meaning (ignore the 30-day staleness
 *    gate and re-read every pack-positive row with a URL). `--stale-days`
 *    lets a site change the 30 days without reaching for `--refresh`.
 *  - `--no-fetch` is new: print the leaderboard only, make no HTTP calls at
 *    all — the escape hatch for a site with no outbound-HTTP budget, or a
 *    CI run.
 *  - gsc's `CompetitorFilter::isAggregator()` host-exclusion check ran in
 *    the command, before ever calling its fetcher. Here it lives inside
 *    `CompetitorSiteReader::read()` itself (`SeoSiteProfile::competitorExclusions()`),
 *    so this command only has to react to an empty result — see that
 *    class's docblock for why.
 *  - `CompetitorSiteReader` (and the `SeoSiteProfile`/HTTP `Factory` it
 *    needs) is resolved from the container lazily, only once there is at
 *    least one row actually due for a read — a site that records no
 *    competitor URLs (or whose leaderboard rows are all already fresh)
 *    never needs those bound at all, same as a site that passes
 *    `--no-fetch`.
 */
class MapPackCompetitorsCommand extends Command
{
    private const PACING_MICROSECONDS = 700_000;

    protected $signature = 'seo:map-pack-competitors
        {--limit=20 : Competitors to list, and competitor sites to read this run}
        {--stale-days=30 : Re-read a site after this many days}
        {--refresh : Re-read every pack-positive site regardless of staleness}
        {--no-fetch : Print the leaderboard only, skip reading competitor homepages}';

    protected $description = "List the map pack's top competitors, aggregated across every tracked keyword, and read their homepages";

    /** @var callable(int): void */
    private $sleeper;

    /** @param  ?callable(int): void  $sleeper  Called with a pacing gap in microseconds between homepage reads — usleep() by default. Inject a no-op in tests so a run over several competitors is instant. */
    public function __construct(?callable $sleeper = null)
    {
        parent::__construct();

        $this->sleeper = $sleeper ?? static function (int $microseconds): void {
            usleep($microseconds);
        };
    }

    public function handle(MapPackStore $store): int
    {
        if (! $store->hasCompetitorsTable()) {
            $this->comment('map_pack_competitors table is missing — skipping.');

            return self::SUCCESS;
        }

        $limit = max(1, (int) $this->option('limit'));
        $competitors = $store->topCompetitors($limit);

        if ($competitors === []) {
            $this->comment('No pack competitors recorded yet — run seo:map-pack-grid first.');

            return self::SUCCESS;
        }

        foreach ($competitors as $competitor) {
            $this->line(sprintf(
                '  %-32s %3d pts · %3d seen · best #%s · %s reviews',
                $competitor['name'],
                $competitor['pack_points'],
                $competitor['seen_points'],
                $competitor['best_rank'] ?? '—',
                $competitor['reviews'] ?? '—',
            ));
        }

        $this->info(sprintf('%d competitor(s) listed.', count($competitors)));

        if (! $this->option('no-fetch')) {
            $this->readCompetitorSites($store, $limit);
        }

        return self::SUCCESS;
    }

    private function readCompetitorSites(MapPackStore $store, int $limit): void
    {
        $staleDays = max(0, (int) $this->option('stale-days'));
        $forceAll = (bool) $this->option('refresh');

        // A pool a few times the size of $limit to dedupe hosts from — the
        // same shape as gsc's own `limit * 3` candidate pool, since several
        // rows (different keywords, different place_ids) can share one host.
        $candidates = $store->competitorsNeedingSiteRead($staleDays, $limit * 5, $forceAll);

        if ($candidates === []) {
            $this->info('Read 0 competitor site(s).');

            return;
        }

        $reader = $this->laravel->make(CompetitorSiteReader::class);

        $seen = [];
        $read = 0;

        foreach ($candidates as $row) {
            $host = $row['host'];
            if ($host === null || isset($seen[$host])) {
                continue;
            }
            $seen[$host] = true;

            if ($read >= $limit) {
                break;
            }

            $data = $reader->read($row['url']);
            if ($data === []) {
                continue; // excluded host (directory/social/aggregator) — never read, not counted toward the limit
            }

            $store->recordSiteRead($host, $data);
            $read++;

            $this->line(sprintf('  %s — %s', $row['name'], $data['site_title'] !== null ? 'read' : 'unreachable'));

            ($this->sleeper)(self::PACING_MICROSECONDS);
        }

        $this->info(sprintf('Read %d competitor site(s).', $read));
    }
}
