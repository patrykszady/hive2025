<?php

namespace SsSystems\Platform\Seo\MapPack;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Database\Query\Builder;
use Illuminate\Database\QueryException;
use Illuminate\Support\Carbon;

/**
 * The one read/write path to `map_pack_scans` and `map_pack_competitors` —
 * ported from gs.construction's `SeoMapPackGrid::handle()` (the write half)
 * and its `SeoReportController::mapPackSnapshot()` (the read half), merged
 * into one class the same way `AiTrafficStore` merges `TrackAiTraffic` and
 * `aiTrafficSnapshot()` — read that class first, this one follows its
 * conventions throughout (the race-safe upsert, `scoped()`, tenant args).
 *
 * Tenant-scoped exactly like `AiTrafficStore`: a single-tenant site passes
 * neither `$tenantColumn` nor `$tenantId`; gs.construction passes
 * `'site_id'` and a closure reading the current tenant at call time.
 *
 * JSON columns (`raw`, `categories`, `site_headings`, `site_towns`,
 * `site_services`) are decoded here, not left as strings for every caller
 * to decode again — `MapPackSnapshot` and `MapPackCompetitorsCommand` both
 * read them as PHP arrays.
 */
final class MapPackStore
{
    public function __construct(
        private readonly ConnectionInterface $connection,
        private readonly string $scansTable = 'map_pack_scans',
        private readonly string $competitorsTable = 'map_pack_competitors',
        private readonly ?string $tenantColumn = null,
        private readonly ?\Closure $tenantId = null,
    ) {
    }

    public function hasScansTable(): bool
    {
        return $this->hasTable($this->scansTable);
    }

    public function hasCompetitorsTable(): bool
    {
        return $this->hasTable($this->competitorsTable);
    }

    /**
     * One scan row per keyword per run — `$raw` is the free-form detail blob
     * (grid points, pack leaders, partial-run flag…) `MapPackSnapshot` reads
     * back; this class does not interpret it.
     *
     * @param  array<string, mixed>  $raw
     */
    public function recordScan(
        string $scanId,
        string $keyword,
        ?string $platform,
        \DateTimeInterface $scannedAt,
        ?float $arp,
        ?float $atrp,
        ?float $solv,
        ?float $saiv,
        int $gridPoints,
        int $inTop3,
        array $raw,
    ): void {
        if (! $this->hasScansTable()) {
            return;
        }

        $this->upsert($this->scansTable, ['scan_id' => $scanId], [
            'keyword' => $keyword,
            'platform' => $platform,
            'scanned_at' => Carbon::instance(\DateTime::createFromInterface($scannedAt)),
            'arp' => $arp,
            'atrp' => $atrp,
            'solv' => $solv,
            'saiv' => $saiv,
            'grid_points' => $gridPoints,
            'in_top3' => $inTop3,
            'raw' => json_encode($raw),
        ]);
    }

    /**
     * Every competitor business seen on this scan's grid — one row per
     * business per keyword, keyed `(site_id, place_id, keyword)` exactly
     * like `recordScan()`'s race-safe upsert.
     *
     * @param  list<array{place_id: string, name: string, url: ?string, rating: ?float, reviews: ?int, claimed: ?bool, categories: ?list<string>, pack_points: int, seen_points: int, best_rank: ?int}>  $competitors
     */
    public function recordCompetitors(string $scanId, string $keyword, \DateTimeInterface $scannedAt, array $competitors): void
    {
        if (! $this->hasCompetitorsTable()) {
            return;
        }

        $keyword = mb_substr($keyword, 0, 191);

        foreach ($competitors as $competitor) {
            $url = $competitor['url'] !== null ? mb_substr((string) $competitor['url'], 0, 500) : null;

            $this->upsert($this->competitorsTable, [
                'place_id' => $competitor['place_id'],
                'keyword' => $keyword,
            ], [
                'name' => mb_substr((string) $competitor['name'], 0, 191),
                'url' => $url,
                'host' => $url !== null ? self::hostOf($url) : null,
                'rating' => $competitor['rating'],
                'reviews' => $competitor['reviews'],
                'claimed' => $competitor['claimed'],
                'categories' => $competitor['categories'] !== null ? json_encode($competitor['categories']) : null,
                'scan_id' => $scanId,
                'scanned_at' => Carbon::instance(\DateTime::createFromInterface($scannedAt)),
                'pack_points' => $competitor['pack_points'],
                'seen_points' => $competitor['seen_points'],
                'best_rank' => $competitor['best_rank'],
            ]);
        }
    }

    /**
     * Most-recently-scanned rows first, across every keyword and platform —
     * `MapPackSnapshot` groups these by keyword itself (gsc's `->limit(60)`).
     *
     * @return list<array{scan_id: string, keyword: string, platform: ?string, scanned_at: string, arp: ?float, atrp: ?float, solv: ?float, saiv: ?float, grid_points: ?int, in_top3: ?int, raw: array<string, mixed>}>
     */
    public function recentScans(int $limit = 60): array
    {
        if (! $this->hasScansTable()) {
            return [];
        }

        $rows = $this->scoped(
            $this->connection->table($this->scansTable)->whereNotNull('scanned_at')->orderByDesc('scanned_at')
        )->limit($limit)->get();

        return array_map(static fn ($row): array => [
            'scan_id' => (string) $row->scan_id,
            'keyword' => (string) $row->keyword,
            'platform' => $row->platform !== null ? (string) $row->platform : null,
            'scanned_at' => (string) $row->scanned_at,
            'arp' => $row->arp !== null ? (float) $row->arp : null,
            'atrp' => $row->atrp !== null ? (float) $row->atrp : null,
            'solv' => $row->solv !== null ? (float) $row->solv : null,
            'saiv' => $row->saiv !== null ? (float) $row->saiv : null,
            'grid_points' => $row->grid_points !== null ? (int) $row->grid_points : null,
            'in_top3' => $row->in_top3 !== null ? (int) $row->in_top3 : null,
            'raw' => is_string($row->raw) ? (json_decode($row->raw, true) ?: []) : [],
        ], $rows->all());
    }

    /**
     * Every competitor row that landed in the 3-pack at least once —
     * gsc's `$competitorRows` (`where('pack_points', '>', 0)`), the universe
     * `MapPackSnapshot` filters per keyword/scan and `topCompetitors()`
     * aggregates across all of them.
     *
     * @return list<array{place_id: string, keyword: string, name: string, url: ?string, host: ?string, rating: ?float, reviews: ?int, claimed: ?bool, categories: ?array<int, string>, scan_id: ?string, scanned_at: ?string, pack_points: int, seen_points: int, best_rank: ?int, site_title: ?string, site_services: ?array<int, string>, site_towns: ?array<int, string>, site_fetched_at: ?string}>
     */
    public function packCompetitors(): array
    {
        if (! $this->hasCompetitorsTable()) {
            return [];
        }

        $rows = $this->scoped(
            $this->connection->table($this->competitorsTable)->where('pack_points', '>', 0)
        )->get();

        return array_map(self::hydrateCompetitor(...), $rows->all());
    }

    /**
     * Competitors summed across every keyword and scan this store has ever
     * recorded, by place_id — the one piece of gsc's `seo:map-pack-competitors`
     * that is pure data the store already owns (who shows up most across the
     * whole campaign); reading each business's own homepage is a separate
     * concern, see `competitorsNeedingSiteRead()`/`recordSiteRead()` and
     * `CompetitorSiteReader`.
     *
     * @return list<array{place_id: string, name: string, url: ?string, host: ?string, rating: ?float, reviews: ?int, claimed: ?bool, categories: ?array<int, string>, pack_points: int, seen_points: int, best_rank: ?int}>
     */
    public function topCompetitors(int $limit = 20): array
    {
        $aggregated = [];

        foreach ($this->packCompetitors() as $row) {
            $id = $row['place_id'];

            if (! isset($aggregated[$id])) {
                $aggregated[$id] = [
                    'place_id' => $id,
                    'name' => $row['name'],
                    'url' => $row['url'],
                    'host' => $row['host'],
                    'rating' => $row['rating'],
                    'reviews' => $row['reviews'],
                    'claimed' => $row['claimed'],
                    'categories' => $row['categories'],
                    'pack_points' => 0,
                    'seen_points' => 0,
                    'best_rank' => null,
                    'scanned_at' => $row['scanned_at'],
                ];
            }

            $aggregated[$id]['pack_points'] += $row['pack_points'];
            $aggregated[$id]['seen_points'] += $row['seen_points'];

            if ($row['best_rank'] !== null && ($aggregated[$id]['best_rank'] === null || $row['best_rank'] < $aggregated[$id]['best_rank'])) {
                $aggregated[$id]['best_rank'] = $row['best_rank'];
            }

            if (($row['scanned_at'] ?? '') > ($aggregated[$id]['scanned_at'] ?? '')) {
                $aggregated[$id] = [...$aggregated[$id], 'name' => $row['name'], 'url' => $row['url'], 'host' => $row['host'], 'rating' => $row['rating'], 'reviews' => $row['reviews'], 'claimed' => $row['claimed'], 'categories' => $row['categories'], 'scanned_at' => $row['scanned_at']];
            }
        }

        usort($aggregated, static fn (array $a, array $b): int => [$b['pack_points'], $b['seen_points']] <=> [$a['pack_points'], $a['seen_points']]);

        return array_map(
            static fn (array $row): array => array_diff_key($row, ['scanned_at' => null]),
            array_slice(array_values($aggregated), 0, $limit),
        );
    }

    /**
     * Pack-competitor rows due for a homepage read via `CompetitorSiteReader`
     * — a URL on record, at least one 3-pack appearance, and never read (or
     * read more than `$staleDays` ago, gsc's monthly re-read rule — unless
     * `$forceAll` reproduces its `--refresh` flag and ignores staleness
     * entirely), newest-busiest first. Several rows can share one host (the
     * same business under different keywords, or several place_ids pointing
     * at the same site); `Console\MapPackCompetitorsCommand` dedupes by host
     * itself, the same way gsc's command did, so it reads enough distinct
     * businesses rather than enough rows.
     *
     * @return list<array{place_id: string, keyword: string, name: string, url: string, host: ?string, pack_points: int}>
     */
    public function competitorsNeedingSiteRead(int $staleDays = 30, int $limit = 200, bool $forceAll = false): array
    {
        if (! $this->hasCompetitorsTable()) {
            return [];
        }

        $staleBefore = Carbon::now()->subDays($staleDays);

        $query = $this->scoped(
            $this->connection->table($this->competitorsTable)
                ->whereNotNull('url')
                ->where('pack_points', '>', 0)
        );

        if (! $forceAll) {
            $query->where(function (Builder $query) use ($staleBefore): void {
                $query->whereNull('site_fetched_at')->orWhere('site_fetched_at', '<', $staleBefore);
            });
        }

        $rows = $query->orderByDesc('pack_points')->limit($limit)->get();

        return array_map(static fn ($row): array => [
            'place_id' => (string) $row->place_id,
            'keyword' => (string) $row->keyword,
            'name' => (string) $row->name,
            'url' => (string) $row->url,
            'host' => $row->host !== null ? (string) $row->host : null,
            'pack_points' => (int) $row->pack_points,
        ], $rows->all());
    }

    /**
     * Writes `CompetitorSiteReader::read()`'s result onto every competitor
     * row sharing `$host` — not just one `(place_id, keyword)` row, same as
     * gsc's `->where('host', $host)->update($data...)`: the homepage read is
     * a fact about the business, not about any one keyword it was seen
     * under. A no-op when the competitors table is missing, or when no row
     * has this host (the business hasn't been recorded by
     * `recordCompetitors()` yet, or was in a run since purged).
     *
     * @param  array{site_title: ?string, site_description: ?string, site_excerpt: ?string, site_headings: list<string>, site_towns: list<string>, site_services: list<string>, site_fetched_at: \DateTimeInterface}  $attributes
     */
    public function recordSiteRead(string $host, array $attributes): void
    {
        if (! $this->hasCompetitorsTable()) {
            return;
        }

        $this->scoped($this->connection->table($this->competitorsTable)->where('host', $host))->update([
            'site_title' => $attributes['site_title'] !== null ? mb_substr($attributes['site_title'], 0, 191) : null,
            'site_description' => $attributes['site_description'] !== null ? mb_substr($attributes['site_description'], 0, 990) : null,
            'site_excerpt' => $attributes['site_excerpt'],
            'site_headings' => json_encode($attributes['site_headings']),
            'site_towns' => json_encode($attributes['site_towns']),
            'site_services' => json_encode($attributes['site_services']),
            'site_fetched_at' => Carbon::instance(\DateTime::createFromInterface($attributes['site_fetched_at'])),
            'updated_at' => Carbon::now(),
        ]);
    }

    /** @return array{place_id: string, keyword: string, name: string, url: ?string, host: ?string, rating: ?float, reviews: ?int, claimed: ?bool, categories: ?array<int, string>, scan_id: ?string, scanned_at: ?string, pack_points: int, seen_points: int, best_rank: ?int, site_title: ?string, site_services: ?array<int, string>, site_towns: ?array<int, string>, site_fetched_at: ?string} */
    private static function hydrateCompetitor(object $row): array
    {
        return [
            'place_id' => (string) $row->place_id,
            'keyword' => (string) $row->keyword,
            'name' => (string) $row->name,
            'url' => $row->url !== null ? (string) $row->url : null,
            'host' => $row->host !== null ? (string) $row->host : null,
            'rating' => $row->rating !== null ? (float) $row->rating : null,
            'reviews' => $row->reviews !== null ? (int) $row->reviews : null,
            'claimed' => $row->claimed !== null ? (bool) $row->claimed : null,
            'categories' => is_string($row->categories) ? json_decode($row->categories, true) : null,
            'scan_id' => $row->scan_id !== null ? (string) $row->scan_id : null,
            'scanned_at' => $row->scanned_at !== null ? (string) $row->scanned_at : null,
            'pack_points' => (int) $row->pack_points,
            'seen_points' => (int) $row->seen_points,
            'best_rank' => $row->best_rank !== null ? (int) $row->best_rank : null,
            'site_title' => $row->site_title ?? null,
            'site_services' => is_string($row->site_services ?? null) ? json_decode($row->site_services, true) : null,
            'site_towns' => is_string($row->site_towns ?? null) ? json_decode($row->site_towns, true) : null,
            'site_fetched_at' => $row->site_fetched_at !== null ? (string) $row->site_fetched_at : null,
        ];
    }

    private function hasTable(string $table): bool
    {
        try {
            return $this->connection->getSchemaBuilder()->hasTable($table);
        } catch (\Throwable) {
            return false;
        }
    }

    /**
     * Update-first, race-safe insert on conflict — identical shape to
     * `AiTrafficStore::record()`: the duplicate-insert race between the two
     * statements is absorbed by the table's own unique key.
     *
     * @param  array<string, mixed>  $match
     * @param  array<string, mixed>  $values
     */
    private function upsert(string $table, array $match, array $values): void
    {
        $values['updated_at'] = Carbon::now();

        $updated = $this->scoped($this->connection->table($table)->where($match))->update($values);

        if ($updated > 0) {
            return;
        }

        $row = $this->tenantColumn !== null ? [...$match, $this->tenantColumn => ($this->tenantId)()] : $match;
        $row = [...$row, ...$values, 'created_at' => Carbon::now()];

        try {
            $this->connection->table($table)->insert($row);
        } catch (QueryException) {
            $this->scoped($this->connection->table($table)->where($match))->update($values);
        }
    }

    private function scoped(Builder $query): Builder
    {
        if ($this->tenantColumn !== null) {
            $query->where($this->tenantColumn, ($this->tenantId)());
        }

        return $query;
    }

    private static function hostOf(string $url): ?string
    {
        $host = parse_url($url, PHP_URL_HOST);

        if (! is_string($host) || $host === '') {
            return null;
        }

        return mb_substr((string) preg_replace('/^www\./', '', mb_strtolower($host)), 0, 191);
    }
}
