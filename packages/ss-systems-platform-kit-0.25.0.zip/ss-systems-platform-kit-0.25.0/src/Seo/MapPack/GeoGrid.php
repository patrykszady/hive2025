<?php

namespace SsSystems\Platform\Seo\MapPack;

/**
 * Pure geometry for the map-pack scan — no DataForSEO call, no database,
 * no site facts beyond the centre/size/radius a command is given. Ported
 * from gs.construction's `SeoMapPackGrid::grid()` (the point layout) and
 * `SeoReportController::mapPackSnapshot()`'s `$nearestTown` closure (the
 * labelling helper), kept here together since both are the same kind of
 * "where is this point relative to known places" arithmetic.
 */
final class GeoGrid
{
    private const MILES_PER_DEGREE_LATITUDE = 69.0;

    /**
     * An evenly-spaced size×size grid of points, the outermost `radiusMiles`
     * from the centre along each axis — identical layout to gsc's original,
     * row-major (north-west to south-east) so a caller can still reshape the
     * flat result into a heatmap by `size` alone.
     *
     * @return list<array{lat: float, lng: float}>
     */
    public static function points(float $centerLat, float $centerLng, int $size, float $radiusMiles): array
    {
        $size = max(1, $size);
        $milesPerDegreeLongitude = self::MILES_PER_DEGREE_LATITUDE * cos(deg2rad($centerLat));

        $points = [];
        for ($row = 0; $row < $size; $row++) {
            for ($col = 0; $col < $size; $col++) {
                $deltaLat = $size === 1 ? 0.0 : (-$radiusMiles + 2 * $radiusMiles * $row / ($size - 1));
                $deltaLng = $size === 1 ? 0.0 : (-$radiusMiles + 2 * $radiusMiles * $col / ($size - 1));

                $points[] = [
                    'lat' => round($centerLat + $deltaLat / self::MILES_PER_DEGREE_LATITUDE, 6),
                    'lng' => round($centerLng + $deltaLng / $milesPerDegreeLongitude, 6),
                ];
            }
        }

        return $points;
    }

    /**
     * The nearest of a list of known town centres to one grid point, within
     * `$maxMiles` — gsc's `$nearestTown` closure, generalised off the
     * `AreaServed` model to the plain `MapPackContext::areaPoints()` shape.
     * Null when nothing known is close enough (the point stays unlabelled),
     * including when `$areaPoints` is empty (a site with no such context).
     *
     * @param  list<array{city: string, slug: string, latitude: float, longitude: float}>  $areaPoints
     * @return array{city: string, slug: string}|null
     */
    public static function nearestArea(float $lat, float $lng, array $areaPoints, float $maxMiles = 4.0): ?array
    {
        $best = null;
        $bestDistance = $maxMiles;

        foreach ($areaPoints as $area) {
            $distance = self::MILES_PER_DEGREE_LATITUDE * sqrt(
                ($area['latitude'] - $lat) ** 2
                + (($area['longitude'] - $lng) * cos(deg2rad($lat))) ** 2
            );

            if ($distance < $bestDistance) {
                $bestDistance = $distance;
                $best = ['city' => $area['city'], 'slug' => $area['slug']];
            }
        }

        return $best;
    }
}
