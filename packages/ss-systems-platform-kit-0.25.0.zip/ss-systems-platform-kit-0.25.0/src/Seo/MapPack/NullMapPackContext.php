<?php

namespace SsSystems\Platform\Seo\MapPack;

use SsSystems\Platform\Seo\MapPack\Contracts\MapPackContext;

/**
 * The default binding for a site that tracks neither served-town
 * coordinates nor its own Google review count — J. Peterson Design and any
 * new adopter until it wires its own. `MapPackSnapshot::build()` is written
 * to treat an empty `areaPoints()` and a null `ourGoogleReviewCount()` as
 * "nothing to compare against", not as an error.
 */
final class NullMapPackContext implements MapPackContext
{
    public function areaPoints(): array
    {
        return [];
    }

    public function ourGoogleReviewCount(): ?int
    {
        return null;
    }
}
