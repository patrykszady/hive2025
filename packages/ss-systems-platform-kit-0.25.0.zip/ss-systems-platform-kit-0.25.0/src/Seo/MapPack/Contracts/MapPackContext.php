<?php

namespace SsSystems\Platform\Seo\MapPack\Contracts;

/**
 * The two gsc-only facts `MapPackSnapshot` leans on that no other site is
 * guaranteed to have: a list of town centres to label grid points with
 * (gs.construction binds `AreaServed`'s geocoded rows), and how many Google
 * reviews the business itself has (gs.construction binds a count of
 * `Testimonial` rows with a Google `review_urls` entry), so the map-pack
 * card can show a "pack leader has N reviews, we have M" gap.
 *
 * A site with neither concept binds `NullMapPackContext` — the snapshot
 * degrades gracefully: grid points stay unlabelled ("unnamed point") and
 * the review-gap comparison is omitted entirely rather than shown as 0.
 */
interface MapPackContext
{
    /**
     * Town centres to label grid points with, nearest-match — gs.construction's
     * served towns, each with its own lat/lng. Empty when the site tracks no
     * such list.
     *
     * @return list<array{city: string, slug: string, latitude: float, longitude: float}>
     */
    public function areaPoints(): array;

    /**
     * How many Google reviews the business itself has, for the review-gap
     * comparison against the map-pack leader. Null when the site has no way
     * to count this — the snapshot then omits review_gap rather than
     * comparing against zero.
     */
    public function ourGoogleReviewCount(): ?int;
}
