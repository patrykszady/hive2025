<?php

namespace SsSystems\Platform\Seo\MapPack;

use Illuminate\Support\Carbon;
use SsSystems\Platform\Seo\MapPack\Contracts\MapPackContext;

/**
 * Shapes `MapPackStore`'s rows into the exact shape the ss.systems hub's
 * "Map Pack Visibility" card reads as `$snapshot['map_pack']` — ported
 * verbatim from gs.construction's `SeoReportController::mapPackSnapshot()`,
 * keys unchanged (verified against resources/views/livewire/admin/
 * seo-reports.blade.php lines 1725-1900, not memory), with two gsc-only
 * dependencies (nearest served town, our own Google review count)
 * generalised through `MapPackContext` — see that interface's docblock.
 *
 * Caching is deliberately NOT this class's job, same reasoning as
 * `AiTrafficSnapshot`: `build()` always computes fresh, and a site wraps
 * the call in its own `Cache::remember()` (gsc: `seo_reports_map_pack_v1`,
 * 900 seconds).
 *
 * CHANGED FROM GSC: the AI-answer-engine half of the original (`ai`, scans
 * whose `platform` is chatgpt/gemini/aimode/gaio/grok/apple) is reproduced
 * only insofar as `MapPackStore` already has the rows — nothing in this
 * port's commands ever writes one (gsc's SAIV scans come from a different,
 * non-map-pack tool not in scope here); `ai` is simply `[]` until a site
 * writes such rows itself through `MapPackStore::recordScan()`.
 */
final class MapPackSnapshot
{
    private const AI_PLATFORMS = ['chatgpt', 'gemini', 'aimode', 'gaio', 'grok', 'apple'];

    private const RECENT_SCANS_LIMIT = 60;

    private const RETIRED_KEYWORD_GRACE_DAYS = 3;

    public function __construct(
        private readonly MapPackStore $store,
        private readonly MapPackContext $context,
    ) {
    }

    /** @return array<string, mixed> */
    public function build(): array
    {
        $empty = ['available' => false, 'keywords' => []];

        if (! $this->store->hasScansTable()) {
            return $empty;
        }

        $scans = $this->store->recentScans(self::RECENT_SCANS_LIMIT);

        if ($scans === []) {
            return $empty;
        }

        $ai = $this->aiSummary($scans);
        $mapScans = array_values(array_filter(
            $scans,
            static fn (array $scan): bool => ! in_array($scan['platform'], self::AI_PLATFORMS, true),
        ));

        if ($mapScans === []) {
            return [...$empty, 'ai' => $ai];
        }

        $mapScans = $this->dropRetiredKeywords($mapScans);
        $ourReviews = $this->context->ourGoogleReviewCount();
        $packCompetitors = $this->store->packCompetitors();
        $areaPoints = $this->context->areaPoints();

        $groups = [];
        foreach ($mapScans as $scan) {
            $groups[$scan['keyword']][] = $scan;
        }

        $keywords = [];
        foreach ($groups as $keyword => $group) {
            $row = $this->keywordRow((string) $keyword, $group, $areaPoints, $packCompetitors, $ourReviews);
            if ($row !== null) {
                $keywords[] = $row;
            }
        }

        return [
            'available' => true,
            'keywords' => $keywords,
            'ai' => $ai,
            'our_reviews' => $ourReviews,
            'latest' => self::dateOnly($mapScans[0]['scanned_at']),
        ];
    }

    /**
     * @param  list<array{scan_id: string, keyword: string, platform: ?string, scanned_at: string, arp: ?float, atrp: ?float, solv: ?float, saiv: ?float, grid_points: ?int, in_top3: ?int, raw: array<string, mixed>}>  $scans
     * @return list<array{platform: string, keyword: string, scanned_at: string, saiv: ?float, arp: ?float}>
     */
    private function aiSummary(array $scans): array
    {
        $newestPerGroup = [];

        foreach ($scans as $scan) {
            if (! in_array($scan['platform'], self::AI_PLATFORMS, true)) {
                continue;
            }

            // $scans is already newest-first (recentScans() orders by
            // scanned_at desc), so the first row seen per platform|keyword
            // is the newest — same as gsc's groupBy()->first().
            $newestPerGroup[$scan['platform'].'|'.$scan['keyword']] ??= $scan;
        }

        return array_values(array_map(static fn (array $scan): array => [
            'platform' => (string) $scan['platform'],
            'keyword' => $scan['keyword'],
            'scanned_at' => self::dateOnly($scan['scanned_at']),
            'saiv' => $scan['saiv'] !== null ? round($scan['saiv'], 1) : null,
            'arp' => $scan['arp'] !== null ? round($scan['arp'], 1) : null,
        ], $newestPerGroup));
    }

    /**
     * Only keywords scanned within 3 days of the newest scan in this batch
     * stay — a keyword last scanned long before the others is a retired one
     * (gsc: a misspelled keyword from its first manual scans).
     *
     * @param  list<array<string, mixed>>  $mapScans
     * @return list<array<string, mixed>>
     */
    private function dropRetiredKeywords(array $mapScans): array
    {
        $newest = max(array_map(static fn (array $s): int => strtotime($s['scanned_at']), $mapScans));

        $latestPerKeyword = [];
        foreach ($mapScans as $scan) {
            $timestamp = strtotime($scan['scanned_at']);
            $latestPerKeyword[$scan['keyword']] = max($latestPerKeyword[$scan['keyword']] ?? 0, $timestamp);
        }

        return array_values(array_filter(
            $mapScans,
            static fn (array $scan): bool => $latestPerKeyword[$scan['keyword']] >= $newest - self::RETIRED_KEYWORD_GRACE_DAYS * 86400,
        ));
    }

    /**
     * @param  list<array<string, mixed>>  $group  newest-first scans for one keyword
     * @param  list<array{city: string, slug: string, latitude: float, longitude: float}>  $areaPoints
     * @param  list<array<string, mixed>>  $packCompetitors
     */
    private function keywordRow(string $keyword, array $group, array $areaPoints, array $packCompetitors, ?int $ourReviews): ?array
    {
        $latest = $group[0];
        $prev = $group[1] ?? null;
        $detail = $latest['raw'];
        $grid = (array) ($detail['grid'] ?? []);
        $points = count($grid) ?: (int) ($detail['points_total'] ?? 0);

        if ($points === 0) {
            return null; // pre-campaign/placeholder scans with no per-point data
        }

        $found = array_values(array_filter($grid, static fn (array $point): bool => ($point['rank'] ?? null) !== null));
        $towns = $this->townsFor($found, $areaPoints);

        $keywordCompetitors = array_values(array_filter(
            $packCompetitors,
            static fn (array $c): bool => $c['keyword'] === $keyword && $c['scan_id'] === $latest['scan_id'],
        ));
        usort($keywordCompetitors, static fn (array $a, array $b): int => $b['pack_points'] <=> $a['pack_points']);
        $packLeaders = array_slice($keywordCompetitors, 0, 6);

        $topReviews = null;
        foreach ($packLeaders as $leader) {
            if ($leader['reviews'] !== null) {
                $topReviews = $topReviews === null ? $leader['reviews'] : max($topReviews, $leader['reviews']);
            }
        }

        return [
            'keyword' => $keyword,
            'scanned_at' => self::dateOnly($latest['scanned_at']),
            'grid' => $latest['grid_points'] ? $latest['grid_points'].'×'.$latest['grid_points'] : null,
            'radius' => $detail['radius'] ?? null,
            'arp' => $latest['arp'] !== null ? round($latest['arp'], 1) : null,
            'atrp' => $latest['atrp'] !== null ? round($latest['atrp'], 1) : null,
            'solv' => $latest['solv'] !== null ? round($latest['solv'], 1) : null,
            'found' => count($found) ?: (int) ($detail['found'] ?? 0),
            'points' => $points,
            'top3' => count(array_filter($found, static fn (array $point): bool => (int) $point['rank'] <= 3)),
            'prev' => $prev !== null ? [
                'scanned_at' => self::dateOnly($prev['scanned_at']),
                'arp' => $prev['arp'] !== null ? round($prev['arp'], 1) : null,
                'solv' => $prev['solv'] !== null ? round($prev['solv'], 1) : null,
            ] : null,
            'towns' => array_values($towns),
            'pack_leaders' => $packLeaders !== [] ? array_map(static fn (array $c): array => [
                'business' => $c['name'],
                'appearances' => $c['pack_points'],
                'best_rank' => $c['best_rank'],
                'reviews' => $c['reviews'],
                'rating' => $c['rating'],
                'url' => $c['url'],
                'host' => $c['host'],
                'services' => $c['site_services'],
                'towns' => $c['site_towns'],
                'site_read' => $c['site_fetched_at'] !== null && $c['site_title'] !== null,
                'claimed' => $c['claimed'],
                'categories' => $c['categories'],
            ], $packLeaders) : array_slice((array) ($detail['pack_leaders'] ?? []), 0, 5),
            'review_gap' => ($topReviews !== null && $ourReviews !== null) ? [
                'ours' => $ourReviews,
                'leader' => $topReviews,
                'gap' => max(0, $topReviews - $ourReviews),
            ] : null,
            'report_url' => $detail['public_url'] ?? null,
            'heatmap_grid' => self::heatmapGrid($grid, (int) ($latest['grid_points'] ?? 0)),
        ];
    }

    /**
     * @param  list<array{lat?: mixed, lng?: mixed, rank?: mixed}>  $found
     * @param  list<array{city: string, slug: string, latitude: float, longitude: float}>  $areaPoints
     * @return array<string, array{city: string, slug: ?string, best_rank: int, points: int}>
     */
    private function townsFor(array $found, array $areaPoints): array
    {
        $towns = [];

        foreach ($found as $point) {
            if (! is_numeric($point['lat'] ?? null) || ! is_numeric($point['lng'] ?? null)) {
                continue;
            }

            $area = GeoGrid::nearestArea((float) $point['lat'], (float) $point['lng'], $areaPoints);
            $name = $area['city'] ?? 'unnamed point';
            $rank = (int) $point['rank'];

            if (! isset($towns[$name]) || $rank < $towns[$name]['best_rank']) {
                $towns[$name] = ['city' => $name, 'slug' => $area['slug'] ?? null, 'best_rank' => $rank, 'points' => ($towns[$name]['points'] ?? 0) + 1];
            } else {
                $towns[$name]['points']++;
            }
        }

        usort($towns, static fn (array $a, array $b): int => $a['best_rank'] <=> $b['best_rank']);

        return $towns;
    }

    /**
     * Every grid point's rank (or null when not found), row-major north-west
     * to south-east, reshaped into a `gridPoints`×`gridPoints` array — gsc's
     * `heatmapGrid()`. Falls back to a single row when `gridPoints` doesn't
     * evenly describe the point count (an old or partial scan).
     *
     * @param  list<array{rank?: mixed}>  $grid
     * @return list<list<int|null>>
     */
    private static function heatmapGrid(array $grid, int $gridPoints): array
    {
        $ranks = array_map(static fn (array $point): ?int => ($point['rank'] ?? null) === null ? null : (int) $point['rank'], $grid);

        if ($gridPoints < 1 || count($ranks) !== $gridPoints * $gridPoints) {
            return $ranks === [] ? [] : [$ranks];
        }

        return array_chunk($ranks, $gridPoints);
    }

    private static function dateOnly(string $value): string
    {
        return Carbon::parse($value)->toDateString();
    }
}
