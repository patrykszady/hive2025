<?php

namespace SsSystems\Platform\Seo\Bing;

/**
 * Bing's half of "every site's sitemaps are submitted, nothing by hand"
 * (Patryk, 2026-10-29 for Google; 2026-11-02 for Bing, when mozaika.haus
 * turned out to have no sitemap in Bing Webmaster at all). Reads what Bing
 * already holds and submits only what is missing, so a daily run is
 * idempotent and never re-submits a map Bing is already crawling.
 */
final class BingSitemapSubmitter
{
    public function __construct(private readonly BingWebmasterApi $bing) {}

    /**
     * @param  list<string>  $sitemapUrls
     * @return array{submitted: list<string>, already: list<string>, failures: array<string, string>, skipped: ?string}
     */
    public function submitMissing(array $sitemapUrls): array
    {
        $result = ['submitted' => [], 'already' => [], 'failures' => [], 'skipped' => null];

        if (! $this->bing->isConfigured()) {
            $result['skipped'] = 'Bing Webmaster is not configured on this site.';

            return $result;
        }

        $known = $this->bing->feeds();
        if ($known === null) {
            $result['skipped'] = 'Bing did not list the site\'s sitemaps: '.($this->bing->lastError() ?? 'unknown error');

            return $result;
        }

        $knownUrls = array_map(fn (array $feed): string => rtrim($feed['url'], '/'), $known);

        foreach ($sitemapUrls as $sitemapUrl) {
            if (in_array(rtrim($sitemapUrl, '/'), $knownUrls, true)) {
                $result['already'][] = $sitemapUrl;

                continue;
            }

            if ($this->bing->submitFeed($sitemapUrl)) {
                $result['submitted'][] = $sitemapUrl;
            } else {
                $result['failures'][$sitemapUrl] = $this->bing->lastError() ?? 'Unknown error.';
            }
        }

        return $result;
    }
}
