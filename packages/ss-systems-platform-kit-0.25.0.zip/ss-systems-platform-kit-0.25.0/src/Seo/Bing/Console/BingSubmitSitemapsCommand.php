<?php

namespace SsSystems\Platform\Seo\Bing\Console;

use Illuminate\Console\Command;
use Illuminate\Http\Client\Factory;
use SsSystems\Platform\Seo\Bing\BingSitemapSubmitter;
use SsSystems\Platform\Seo\Bing\BingWebmasterApi;

/**
 * `seo:bing-submit-sitemaps` — Bing Webmaster gets every sitemap the site's
 * own robots.txt lists, submitting only the ones Bing does not hold yet.
 * Google has had this from the hub since 2026-10-29; Bing was still a
 * hand job until mozaika.haus showed up with no sitemap there at all
 * (Patryk, 2026-11-02). Daily on every site, it is idempotent.
 */
final class BingSubmitSitemapsCommand extends Command
{
    protected $signature = 'seo:bing-submit-sitemaps
        {--sitemap=* : Sitemap URLs to submit (default: the Sitemap: lines of the site\'s own robots.txt)}';

    protected $description = 'Submit the site\'s sitemaps to Bing Webmaster, skipping the ones Bing already has';

    public function handle(BingWebmasterApi $bing, Factory $http): int
    {
        if (! $bing->isConfigured()) {
            $this->info('Bing Webmaster is not configured on this site — nothing submitted.');

            return self::SUCCESS;
        }

        $sitemaps = array_values(array_filter(array_map('trim', (array) $this->option('sitemap'))));
        if ($sitemaps === []) {
            $sitemaps = self::sitemapsFromRobots($http, $bing->siteUrl());
        }

        if ($sitemaps === []) {
            $this->warn('No sitemaps found: robots.txt lists none and --sitemap was not given.');

            return self::SUCCESS;
        }

        $result = (new BingSitemapSubmitter($bing))->submitMissing($sitemaps);

        if ($result['skipped'] !== null) {
            $this->warn($result['skipped']);

            return self::FAILURE;
        }

        foreach ($result['already'] as $url) {
            $this->line("  already in Bing: {$url}");
        }
        foreach ($result['submitted'] as $url) {
            $this->info("  submitted: {$url}");
        }
        foreach ($result['failures'] as $url => $message) {
            $this->error("  failed: {$url} — {$message}");
        }

        $this->line(sprintf('Done: %d submitted, %d already there, %d failed.', count($result['submitted']), count($result['already']), count($result['failures'])));

        return $result['failures'] === [] ? self::SUCCESS : self::FAILURE;
    }

    /**
     * The `Sitemap:` lines of the site's own robots.txt — the same source
     * ss.systems reads for Google, so both engines get the same list.
     *
     * @return list<string>
     */
    public static function sitemapsFromRobots(Factory $http, string $siteUrl): array
    {
        try {
            $response = $http->timeout(20)->get(rtrim($siteUrl, '/').'/robots.txt');
        } catch (\Throwable) {
            return [];
        }

        if (! $response->successful()) {
            return [];
        }

        preg_match_all('/^\s*sitemap:\s*(\S+)/im', $response->body(), $matches);

        return array_values(array_unique(array_map('trim', $matches[1])));
    }
}
