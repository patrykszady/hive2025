<?php

namespace SsSystems\Platform\Seo\Bing\Http\Concerns;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use SsSystems\Platform\Seo\Bing\BingCoverageSync;
use SsSystems\Platform\Seo\Bing\Contracts\BingCoverageClient;
use SsSystems\Platform\Seo\Bing\Contracts\BingFeedsClient;

/**
 * The admin API behind the hub's Bing card (GET seo/bing-coverage, POST
 * seo/bing-coverage/refresh), reading the two tables BingCoverageSync
 * fills. A site's controller uses this trait and supplies:
 *
 *   protected function bingCrawlStatModel(): string   — the model over the
 *       create_bing_crawl_stats_table stub (tenant-scoped on multi-tenant
 *       sites through the model's own global scope, like every kit table);
 *   protected function bingUrlInfoModel(): string     — the model over the
 *       create_bing_url_info_table stub;
 *   protected function dispatchBingCoverageSync(): void — queue or run
 *       `seo:bing-coverage` for the Refresh button.
 *
 * The quota and the property's verified flag come live from Bing through
 * the bound BingCoverageClient, cached an hour and a day; a site without
 * the binding, or a Bing that does not answer, shows them as unknown.
 *
 * A URL's `status`, the one word the card sorts and filters by:
 *   shown          — Bing showed it in results in the last 28 days (so it has it)
 *   crawled        — Bing has fetched it, shown it or not
 *   never_crawled  — Bing knows nothing of it (asked, no fetch on record)
 *   pending        — not asked yet (the sync covers the sitemap in batches),
 *                    or asked and Bing did not answer (asked again later)
 *   error          — Bing's last fetch got a 4xx/5xx
 * The five are a partition of the sitemap URLs, in that order of precedence,
 * for the counts and the filter alike.
 */
trait ServesBingCoverage
{
    /** @return class-string<Model> */
    abstract protected function bingCrawlStatModel(): string;

    /** @return class-string<Model> */
    abstract protected function bingUrlInfoModel(): string;

    abstract protected function dispatchBingCoverageSync(): void;

    protected function bingCoverageClient(): ?BingCoverageClient
    {
        return app()->bound(BingCoverageClient::class) ? app(BingCoverageClient::class) : null;
    }

    public function index(Request $request): JsonResponse
    {
        $crawl = $this->bingCrawlStatModel();
        $info = $this->bingUrlInfoModel();
        $client = $this->bingCoverageClient();
        $configured = $client?->isConfigured() ?? false;

        $latest = $crawl::query()->orderByDesc('date')->first();
        $series = $crawl::query()->orderByDesc('date')->limit(30)->get()
            ->sortBy(fn (Model $row) => (string) $row->getAttribute('date'))
            ->values()
            ->map(fn (Model $row) => [
                'date' => substr((string) $row->getAttribute('date'), 0, 10),
                'in_index' => (int) $row->getAttribute('in_index'),
                'crawled_pages' => (int) $row->getAttribute('crawled_pages'),
                'crawl_errors' => (int) $row->getAttribute('crawl_errors'),
            ])
            ->all();

        $inSitemap = fn (): Builder => $info::query()->where('in_sitemap', true);

        $perPage = max(1, min(200, (int) $request->integer('per_page', 50)));
        $rows = $this->filteredUrls($request, $inSitemap())->paginate($perPage)->withQueryString();

        return response()->json(['data' => [
            'configured' => $configured,
            'site_url' => $client?->siteUrl(),
            'verified' => $configured ? $this->verified($client) : null,
            'quota' => $configured ? $this->quota($client) : null,
            'feeds' => $configured ? $this->feeds($client) : null,
            'latest' => $latest ? [
                'date' => substr((string) $latest->getAttribute('date'), 0, 10),
                'in_index' => (int) $latest->getAttribute('in_index'),
                'crawled_pages' => (int) $latest->getAttribute('crawled_pages'),
                'crawl_errors' => (int) $latest->getAttribute('crawl_errors'),
                'blocked_by_robots' => (int) $latest->getAttribute('blocked_by_robots'),
                'code_4xx' => (int) $latest->getAttribute('code_4xx'),
                'code_5xx' => (int) $latest->getAttribute('code_5xx'),
            ] : null,
            'series' => $series,
            'shown_window_days' => BingCoverageSync::SHOWN_WINDOW_DAYS,
            // One tile per URL: the same precedence serializeUrl() gives a
            // row (error, shown, crawled, never_crawled, pending), so the
            // five counts add up to the total and a tile's filter shows
            // exactly the rows it counted.
            'urls' => [
                'total' => (clone $inSitemap())->count(),
                'shown' => $this->withStatus(clone $inSitemap(), 'shown')->count(),
                'crawled' => $this->withStatus(clone $inSitemap(), 'crawled')->count(),
                'never_crawled' => $this->withStatus(clone $inSitemap(), 'never_crawled')->count(),
                'pending' => $this->withStatus(clone $inSitemap(), 'pending')->count(),
                'errors' => $this->withStatus(clone $inSitemap(), 'error')->count(),
                'last_inspected_at' => optional($inSitemap()->max('inspected_at'), fn ($v) => (string) $v),
            ],
            'rows' => collect($rows->items())->map(fn (Model $row) => $this->serializeUrl($row))->all(),
            'meta' => [
                'current_page' => $rows->currentPage(),
                'last_page' => $rows->lastPage(),
                'per_page' => $rows->perPage(),
                'total' => $rows->total(),
            ],
        ]]);
    }

    public function refresh(Request $request): JsonResponse
    {
        $this->dispatchBingCoverageSync();

        return response()->json(['data' => ['queued' => true, 'message' => 'Asking Bing — the card updates when the run finishes.']], 202);
    }

    protected function filteredUrls(Request $request, Builder $query): Builder
    {
        $status = (string) $request->query('status', '');
        $term = trim((string) $request->query('q', ''));

        if (in_array($status, ['shown', 'crawled', 'never_crawled', 'pending', 'error'], true)) {
            $this->withStatus($query, $status);
        }

        if ($term !== '') {
            $query->where('url', 'like', '%'.str_replace(['%', '_'], ['\\%', '\\_'], $term).'%');
        }

        return in_array($status, ['never_crawled', 'pending'], true)
            ? $query->orderBy('url')
            : $query->orderByDesc('impressions_28d')->orderByDesc('last_crawled_at')->orderBy('url');
    }

    /**
     * The rows in one status, with the same precedence serializeUrl() uses
     * for a row's own `status`: an error first, then shown, then crawled,
     * then never crawled, else pending — so the statuses partition the set.
     */
    protected function withStatus(Builder $query, string $status): Builder
    {
        $notError = fn (Builder $q) => $q->where(fn (Builder $w) => $w->whereNull('http_status')->orWhere('http_status', '<', 400));
        $notShown = fn (Builder $q) => $q->where('impressions_28d', '<=', 0);
        $notCrawled = fn (Builder $q) => $q->whereNull('last_crawled_at');
        $askedAndAnswered = fn (Builder $q) => $q->whereNotNull('inspected_at')->whereNull('inspect_error');

        return match ($status) {
            'error' => $query->where('http_status', '>=', 400),
            'shown' => $notError($query)->where('impressions_28d', '>', 0),
            'crawled' => $notShown($notError($query))->whereNotNull('last_crawled_at'),
            'never_crawled' => $askedAndAnswered($notCrawled($notShown($notError($query)))),
            'pending' => $notCrawled($notShown($notError($query)))->where(fn (Builder $w) => $w->whereNull('inspected_at')->orWhereNotNull('inspect_error')),
            default => $query,
        };
    }

    /** @return array<string, mixed> */
    protected function serializeUrl(Model $row): array
    {
        $status = (int) $row->getAttribute('http_status');
        $state = match (true) {
            $status >= 400 => 'error',
            (int) $row->getAttribute('impressions_28d') > 0 => 'shown',
            $row->getAttribute('last_crawled_at') !== null => 'crawled',
            $row->getAttribute('inspected_at') !== null && $row->getAttribute('inspect_error') === null => 'never_crawled',
            default => 'pending',
        };

        $url = (string) $row->getAttribute('url');

        return [
            'url' => $url,
            'path' => (parse_url($url, PHP_URL_PATH) ?: '/').((string) parse_url($url, PHP_URL_QUERY) !== '' ? '?'.parse_url($url, PHP_URL_QUERY) : ''),
            'status' => $state,
            'http_status' => $status > 0 ? $status : null,
            'last_crawled_at' => $this->iso($row->getAttribute('last_crawled_at')),
            'discovered_on' => $row->getAttribute('discovered_on') ? substr((string) $row->getAttribute('discovered_on'), 0, 10) : null,
            'impressions_28d' => (int) $row->getAttribute('impressions_28d'),
            'clicks_28d' => (int) $row->getAttribute('clicks_28d'),
            'last_shown_on' => $row->getAttribute('last_shown_on') ? substr((string) $row->getAttribute('last_shown_on'), 0, 10) : null,
            'inspected_at' => $this->iso($row->getAttribute('inspected_at')),
            'inspect_error' => $row->getAttribute('inspect_error'),
        ];
    }

    protected function iso(mixed $value): ?string
    {
        if ($value === null || $value === '') {
            return null;
        }

        try {
            return \Illuminate\Support\Carbon::parse((string) $value)->toIso8601String();
        } catch (\Throwable) {
            return null;
        }
    }

    /** @return array{daily: int, monthly: int}|null */
    protected function quota(BingCoverageClient $client): ?array
    {
        return Cache::remember('bing-coverage:quota:'.sha1($client->siteUrl()), 3600, function () use ($client) {
            try {
                return $client->urlSubmissionQuota();
            } catch (\Throwable) {
                return null;
            }
        });
    }

    /**
     * The sitemaps Bing holds for the property, live from Bing and cached an
     * hour like the quota: whether Bing has read sitemap-listings.xml or
     * sitemap-sold.xml used to be a question only the site owner's Bing
     * Webmaster Tools account could answer (0.23.0).
     *
     * @return list<array{url: string, status: string, url_count: int, type?: ?string, submitted_at?: ?string, last_crawled_at?: ?string}>|null
     */
    protected function feeds(BingCoverageClient $client): ?array
    {
        if (! $client instanceof BingFeedsClient) {
            return null;
        }

        return Cache::remember('bing-coverage:feeds:'.sha1($client->siteUrl()), 3600, function () use ($client) {
            try {
                return $client->feeds();
            } catch (\Throwable) {
                return null;
            }
        });
    }

    protected function verified(BingCoverageClient $client): ?bool
    {
        return Cache::remember('bing-coverage:verified:'.sha1($client->siteUrl()), 86400, function () use ($client) {
            try {
                $sites = $client->userSites();
            } catch (\Throwable) {
                return null;
            }

            if ($sites === null) {
                return null;
            }

            $wanted = BingCoverageSync::urlKey($client->siteUrl());

            foreach ($sites as $site) {
                if (BingCoverageSync::urlKey($site['url']) === $wanted) {
                    return $site['verified'];
                }
            }

            return false;
        });
    }
}
