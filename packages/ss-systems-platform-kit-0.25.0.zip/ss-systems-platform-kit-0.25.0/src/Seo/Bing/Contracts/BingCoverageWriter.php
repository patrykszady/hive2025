<?php

namespace SsSystems\Platform\Seo\Bing\Contracts;

/**
 * Where BingCoverageSync's rows land, and the one question it asks back.
 * The kit computes every row; each site's own implementation is the only
 * place that reads or writes one, over the two tables in the kit's
 * create_bing_crawl_stats_table / create_bing_url_info_table stubs —
 * gs.construction's rows tenant-scoped through BelongsToSite, a
 * single-tenant site's plain models. Bound once in the site's
 * AppServiceProvider, like BingWriter.
 */
interface BingCoverageWriter
{
    /**
     * Insert or update one day's crawl stats, keyed on date + site_url. The
     * lookup must be whereDate() on `date`, not a string match (see
     * BingWriter::upsertDailyTotal() for why).
     *
     * @param  array{date: string, site_url: string, crawled_pages: int, in_index: int, in_links: int, crawl_errors: int, blocked_by_robots: int, code_2xx: int, code_301: int, code_302: int, code_4xx: int, code_5xx: int, other_codes: int, connection_timeouts: int, dns_failures: int}  $row
     */
    public function upsertCrawlStat(array $row): void;

    /**
     * Insert or update one URL's row, keyed on url_hash; only the keys given
     * change, the others keep their value (the shown-in-search figures and
     * the fetch figures arrive in separate steps).
     *
     * @param  array{url: string, url_hash: string, in_sitemap?: bool, http_status?: ?int, is_page?: ?bool, document_size?: ?int, anchor_count?: ?int, child_url_count?: ?int, discovered_on?: ?string, last_crawled_at?: ?string, impressions_28d?: int, clicks_28d?: int, last_shown_on?: ?string, inspected_at?: ?string, inspect_error?: ?string}  $row
     */
    public function upsertUrlInfo(array $row): void;

    /**
     * Up to $limit of $sitemapUrls to ask Bing about next: the ones never
     * asked about first, then the longest ago.
     *
     * @param  list<string>  $sitemapUrls
     * @return list<string>
     */
    public function urlsToInspect(array $sitemapUrls, int $limit): array;

    /**
     * Mark every stored URL that is not in $sitemapUrls as out of the
     * sitemap (in_sitemap = false) — never delete, the fetch history stays.
     * Returns how many rows changed.
     *
     * @param  list<string>  $sitemapUrls
     */
    public function forgetUrlsNotIn(array $sitemapUrls): int;
}
