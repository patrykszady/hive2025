<?php

namespace SsSystems\Platform\Seo\Bing\Contracts;

/**
 * What BingCoverageSync needs from Bing Webmaster Tools: how much of the
 * site Bing holds, which pages it has fetched and which it shows. Bing's
 * index is what ChatGPT search and Copilot answer from, so this is the
 * closest thing to "can the AI assistants find this page" that any API
 * gives (2026-11-10). BingWebmasterApi is the one real implementation; a
 * test hands in a fake with no HTTP behind it. Kept apart from
 * BingWebmasterClient so every fake of that older interface stays valid.
 */
interface BingCoverageClient
{
    /** A key and a property to ask about. */
    public function isConfigured(): bool;

    /** The property, as Bing knows it ("https://example.com/"). */
    public function siteUrl(): string;

    /**
     * GetCrawlStats: one row per day, about six months back — pages Bing
     * crawled that day, pages in its index, crawl errors and the status
     * codes it met. Null when the call failed (see lastError()).
     *
     * @return list<array{date: string, crawled_pages: int, in_index: int, in_links: int, crawl_errors: int, blocked_by_robots: int, code_2xx: int, code_301: int, code_302: int, code_4xx: int, code_5xx: int, other_codes: int, connection_timeouts: int, dns_failures: int}>|null
     */
    public function crawlStats(): ?array;

    /**
     * GetUrlInfo: what Bing knows about one URL — when it found it, when it
     * last fetched it and what it got. last_crawled_at is null for a URL
     * Bing has never fetched. Null when the call failed.
     *
     * @return array{url: string, http_status: ?int, is_page: bool, document_size: ?int, anchor_count: ?int, child_url_count: ?int, discovered_on: ?string, last_crawled_at: ?string}|null
     */
    public function urlInfo(string $url): ?array;

    /**
     * GetPageStats: one row per page per day it was shown in Bing results,
     * about three months back. Null when the call failed.
     *
     * @return list<array{date: string, url: string, impressions: int, clicks: int, position: float}>|null
     */
    public function pageStats(): ?array;

    /**
     * GetUrlSubmissionQuota: how many URLs Bing lets this property submit a
     * day and a month. Null when the call failed.
     *
     * @return array{daily: int, monthly: int}|null
     */
    public function urlSubmissionQuota(): ?array;

    /**
     * GetUserSites: every property the key's account holds, and whether it
     * is verified. Null when the call failed.
     *
     * @return list<array{url: string, verified: bool}>|null
     */
    public function userSites(): ?array;

    /** Why the last call returned null, for the run's summary and the log. */
    public function lastError(): ?string;
}
