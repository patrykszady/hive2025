<?php

namespace SsSystems\Platform\Seo\Bing\Contracts;

/**
 * The URLs a site wants Bing to hold: the same set its Search Console
 * coverage tracks (ServesGscErrors::sitemapUrlSet()), so the two screens
 * count the same pages. Each site binds its own — the list it builds its
 * sitemap from, not a fetch of sitemap.xml, which on some sites is an
 * index of several files.
 */
interface BingCoverageUrls
{
    /** @return list<string> absolute URLs */
    public function urls(): array;
}
