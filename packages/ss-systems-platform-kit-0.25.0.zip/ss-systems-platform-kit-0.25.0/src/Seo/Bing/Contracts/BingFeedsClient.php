<?php

namespace SsSystems\Platform\Seo\Bing\Contracts;

/**
 * The sitemaps Bing holds for the property (GetFeeds). Its own interface,
 * beside BingCoverageClient rather than inside it, so a site's existing
 * coverage client (and every test fake that implements the coverage
 * contract) keeps working as it is: ServesBingCoverage asks for feeds only
 * when the bound client implements this. BingWebmasterApi does (0.23.1).
 */
interface BingFeedsClient
{
    /**
     * URL, Bing's own status word, URL count, feed type, and when the feed
     * was submitted and last read. Null when the call failed (see
     * lastError() on the client).
     *
     * @return list<array{url: string, status: string, url_count: int, type?: ?string, submitted_at?: ?string, last_crawled_at?: ?string}>|null
     */
    public function feeds(): ?array;
}
