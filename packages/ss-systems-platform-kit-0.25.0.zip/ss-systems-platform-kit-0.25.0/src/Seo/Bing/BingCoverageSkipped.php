<?php

namespace SsSystems\Platform\Seo\Bing;

use RuntimeException;

/** Thrown by BingCoverageSync when the site has no Bing key or property to ask about — a skip, not a failure. */
final class BingCoverageSkipped extends RuntimeException {}
