<?php

namespace SsSystems\Platform\Seo\Bing;

use Illuminate\Support\Carbon;
use SsSystems\Platform\Seo\Bing\Contracts\BingCoverageClient;
use SsSystems\Platform\Seo\Bing\Contracts\BingCoverageWriter;

/**
 * What Bing holds of the site — one implementation, run by every site
 * through its own BingCoverageClient and BingCoverageWriter, the way
 * BingSync runs the query stats. Bing's index is what ChatGPT search and
 * Copilot answer from; until this existed (2026-11-10) the hub knew Google's
 * coverage of every page and nothing about Bing's.
 *
 * Three things happen per run:
 *
 *   1. GetCrawlStats, one row per day: pages Bing crawled, pages in its
 *      index, errors — the headline and the trend.
 *   2. GetPageStats, folded into each sitemap URL's clicks and impressions
 *      over the last SHOWN_WINDOW_DAYS: a page Bing shows is a page Bing
 *      has. Every sitemap URL gets a row, zero or not, so a page that
 *      stopped being shown reads zero again; URLs that left the sitemap
 *      are marked, never deleted.
 *   3. GetUrlInfo for up to `url_limit` sitemap URLs the writer picks (never
 *      asked first, then the longest ago), `pause_ms` apart: when Bing found
 *      the page and when it last fetched it. A sitemap of 1,800 pages is
 *      covered in six daily runs at the default limit.
 *
 * Bing rate-limits GetUrlInfo per site and per key: on the first all-pages
 * run (2026-11-10, 250 ms apart) it answered HTTP 400 "ThrottleHost" or
 * "ThrottleUser" after 20 to 30 pages, for 234 of hive's 264. That answer
 * says nothing about the page, so it is never recorded as one. The run
 * waits `throttle_wait_ms` and asks again, doubling the wait each time;
 * after `throttle_retries` refusals in a row it stops, and the page and the
 * rest stay unasked for the next run.
 *
 * A failed GetPageStats or a failed single GetUrlInfo does not fail the run;
 * both are counted and reported. A failed GetCrawlStats does: it is the one
 * call that says whether Bing can be asked at all.
 */
final class BingCoverageSync
{
    public const SHOWN_WINDOW_DAYS = 28;

    public const DEFAULT_URL_LIMIT = 300;

    public const DEFAULT_PAUSE_MS = 1000;

    /** The first wait after Bing says to slow down; each further wait for the same page doubles it. */
    public const THROTTLE_WAIT_MS = 60_000;

    /** Waits in a row for one page before the run stops and leaves the rest for the next run. */
    public const THROTTLE_RETRIES = 3;

    public const SAMPLE_ROWS = 10;

    /**
     * @param  list<string>  $sitemapUrls
     * @param  array{url_limit?: int, pause_ms?: int, throttle_wait_ms?: int, throttle_retries?: int, dry_run?: bool, now?: string, sleep?: callable(int): void}  $options
     * @return array{status: string, site_url: string, crawl_days: int, latest: ?array{date: string, in_index: int, crawled_pages: int, crawl_errors: int, blocked_by_robots: int}, page_stats_error: ?string, sitemap_urls: int, shown_urls: int, inspected: int, crawled: int, never_crawled: int, inspect_errors: int, throttle_waits: int, left_for_next_run: int, forgotten: int, started_at: string, finished_at: ?string, error: ?string, sample: list<string>}
     *
     * @throws BingCoverageSkipped  when the client has no key or property configured.
     */
    public static function run(BingCoverageClient $client, BingCoverageWriter $writer, array $sitemapUrls, array $options = []): array
    {
        $dryRun = (bool) ($options['dry_run'] ?? false);
        $limit = max(0, (int) ($options['url_limit'] ?? self::DEFAULT_URL_LIMIT));
        $pauseMs = max(0, (int) ($options['pause_ms'] ?? self::DEFAULT_PAUSE_MS));
        $throttleWaitMs = max(0, (int) ($options['throttle_wait_ms'] ?? self::THROTTLE_WAIT_MS));
        $throttleRetries = max(0, (int) ($options['throttle_retries'] ?? self::THROTTLE_RETRIES));
        $now = isset($options['now']) ? Carbon::parse((string) $options['now'], 'UTC') : Carbon::now('UTC');
        $sleep = $options['sleep'] ?? static function (int $ms): void {
            usleep($ms * 1000);
        };
        $sitemapUrls = array_values(array_unique(array_filter(array_map('trim', $sitemapUrls))));

        $summary = [
            'status' => 'ok',
            'site_url' => $client->siteUrl(),
            'crawl_days' => 0,
            'latest' => null,
            'page_stats_error' => null,
            'sitemap_urls' => count($sitemapUrls),
            'shown_urls' => 0,
            'inspected' => 0,
            'crawled' => 0,
            'never_crawled' => 0,
            'inspect_errors' => 0,
            'throttle_waits' => 0,
            'left_for_next_run' => 0,
            'forgotten' => 0,
            'started_at' => $now->toIso8601String(),
            'finished_at' => null,
            'error' => null,
            'sample' => [],
        ];

        if (! $client->isConfigured()) {
            throw new BingCoverageSkipped('Bing Webmaster Tools is not configured for '.$client->siteUrl().'.');
        }

        $stats = $client->crawlStats();

        if ($stats === null) {
            $summary['status'] = 'failed';
            $summary['error'] = $client->lastError() ?? 'GetCrawlStats failed.';
            $summary['finished_at'] = Carbon::now('UTC')->toIso8601String();

            return $summary;
        }

        $latest = null;

        foreach ($stats as $day) {
            if (! $dryRun) {
                $writer->upsertCrawlStat($day + ['site_url' => $client->siteUrl()]);
            }

            $summary['crawl_days']++;

            if ($latest === null || $day['date'] > $latest['date']) {
                $latest = $day;
            }
        }

        if ($latest !== null) {
            $summary['latest'] = [
                'date' => $latest['date'],
                'in_index' => $latest['in_index'],
                'crawled_pages' => $latest['crawled_pages'],
                'crawl_errors' => $latest['crawl_errors'],
                'blocked_by_robots' => $latest['blocked_by_robots'],
            ];
        }

        $shown = self::shownByUrl($client, $now, $summary['page_stats_error']);

        foreach ($sitemapUrls as $url) {
            $hit = $shown[self::urlKey($url)] ?? null;

            if ($hit !== null) {
                $summary['shown_urls']++;
            }

            if (! $dryRun) {
                $writer->upsertUrlInfo([
                    'url' => $url,
                    'url_hash' => self::hash($url),
                    'in_sitemap' => true,
                    'impressions_28d' => (int) ($hit['impressions'] ?? 0),
                    'clicks_28d' => (int) ($hit['clicks'] ?? 0),
                    'last_shown_on' => $hit['last_shown_on'] ?? null,
                ]);
            }
        }

        if (! $dryRun) {
            $summary['forgotten'] = $writer->forgetUrlsNotIn($sitemapUrls);
        }

        $toInspect = $limit > 0 ? $writer->urlsToInspect($sitemapUrls, $limit) : [];

        if ($dryRun) {
            $summary['sample'] = array_slice($toInspect, 0, self::SAMPLE_ROWS);
            $summary['status'] = 'dry-run';
            $summary['finished_at'] = Carbon::now('UTC')->toIso8601String();

            return $summary;
        }

        $toInspect = array_values($toInspect);

        foreach ($toInspect as $index => $url) {
            if ($index > 0 && $pauseMs > 0) {
                $sleep($pauseMs);
            }

            $info = $client->urlInfo($url);

            for ($waits = 0; $info === null && self::isThrottled($client->lastError()) && $waits < $throttleRetries; $waits++) {
                $sleep($throttleWaitMs * (2 ** $waits));
                $summary['throttle_waits']++;
                $info = $client->urlInfo($url);
            }

            if ($info === null && self::isThrottled($client->lastError())) {
                $summary['left_for_next_run'] = count($toInspect) - $index;

                break;
            }

            $summary['inspected']++;

            if ($info === null) {
                $summary['inspect_errors']++;
                $writer->upsertUrlInfo([
                    'url' => $url,
                    'url_hash' => self::hash($url),
                    'inspected_at' => Carbon::now('UTC')->toDateTimeString(),
                    'inspect_error' => mb_substr((string) ($client->lastError() ?? 'GetUrlInfo failed.'), 0, 255),
                ]);

                continue;
            }

            $info['last_crawled_at'] !== null ? $summary['crawled']++ : $summary['never_crawled']++;

            $writer->upsertUrlInfo([
                'url' => $url,
                'url_hash' => self::hash($url),
                'http_status' => $info['http_status'],
                'is_page' => $info['is_page'],
                'document_size' => $info['document_size'],
                'anchor_count' => $info['anchor_count'],
                'child_url_count' => $info['child_url_count'],
                'discovered_on' => $info['discovered_on'],
                'last_crawled_at' => $info['last_crawled_at'],
                'inspected_at' => Carbon::now('UTC')->toDateTimeString(),
                'inspect_error' => null,
            ]);
        }

        $summary['finished_at'] = Carbon::now('UTC')->toIso8601String();

        return $summary;
    }

    /** Bing's "slow down" answer (ThrottleHost or ThrottleUser), which says nothing about the page asked about. */
    public static function isThrottled(?string $error): bool
    {
        return $error !== null && str_contains($error, 'Throttle');
    }

    /**
     * The key one page is matched on across Bing's page stats and the
     * sitemap: no scheme, no www., no fragment, no trailing slash, lower
     * case — Bing reports a page the way it showed it, which is not always
     * the sitemap's spelling.
     */
    public static function urlKey(string $url): string
    {
        $url = strtolower(trim($url));
        $url = (string) preg_replace('#^https?://#', '', $url);
        $url = (string) preg_replace('#^www\.#', '', $url);
        $url = explode('#', $url, 2)[0];

        return rtrim($url, '/');
    }

    /** The url_hash a row is keyed on — of the sitemap's own spelling, same as ServesGscErrors' rows. */
    public static function hash(string $url): string
    {
        return sha1(trim($url));
    }

    /**
     * Bing's page stats over the last SHOWN_WINDOW_DAYS, folded per page.
     *
     * @return array<string, array{impressions: int, clicks: int, last_shown_on: string}>
     */
    private static function shownByUrl(BingCoverageClient $client, Carbon $now, ?string &$error): array
    {
        $rows = $client->pageStats();

        if ($rows === null) {
            $error = $client->lastError() ?? 'GetPageStats failed.';

            return [];
        }

        $since = $now->copy()->subDays(self::SHOWN_WINDOW_DAYS)->toDateString();
        $shown = [];

        foreach ($rows as $row) {
            if ($row['date'] < $since) {
                continue;
            }

            $key = self::urlKey($row['url']);
            $shown[$key]['impressions'] = ($shown[$key]['impressions'] ?? 0) + (int) $row['impressions'];
            $shown[$key]['clicks'] = ($shown[$key]['clicks'] ?? 0) + (int) $row['clicks'];
            $shown[$key]['last_shown_on'] = max($shown[$key]['last_shown_on'] ?? '', $row['date']);
        }

        return $shown;
    }
}
