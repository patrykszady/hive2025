<?php

namespace SsSystems\Platform\Seo\DataForSeo;

/**
 * One cap, shared by every `--budget`-bounded DataForSEO command, so each
 * port doesn't re-invent gsc's ad hoc `$dfs->spent() >= $budget` check (and
 * each invent it slightly differently). A command asks canSpend() before
 * an API call it knows the approximate cost of, or checks remaining()
 * against DataForSeoApi::spent() after the fact; charge() is for a
 * command tracking its own running total independently of the client.
 */
final class Budget
{
    private float $spent = 0.0;

    private function __construct(private readonly float $cap)
    {
    }

    public static function usd(float $cap): self
    {
        return new self($cap);
    }

    public function canSpend(float $cost): bool
    {
        return $this->spent + $cost <= $this->cap;
    }

    public function charge(float $cost): void
    {
        $this->spent += $cost;
    }

    public function remaining(): float
    {
        return max(0.0, $this->cap - $this->spent);
    }
}
