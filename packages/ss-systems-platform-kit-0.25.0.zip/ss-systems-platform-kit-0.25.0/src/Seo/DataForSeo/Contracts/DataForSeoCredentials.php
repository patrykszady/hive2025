<?php

namespace SsSystems\Platform\Seo\DataForSeo\Contracts;

/**
 * Where a site keeps its DataForSEO login — on every tenant that is the
 * platform-setting pair ss.systems pushes (seo.dataforseo.login /
 * seo.dataforseo.password, see each site's App\Support\Seo\DataForSeoSettings),
 * with the services.dataforseo env pair as the fallback. The kit never
 * reads config() for these itself; the site binds this contract.
 */
interface DataForSeoCredentials
{
    public function login(): ?string;

    public function password(): ?string;

    public function isConfigured(): bool;
}
