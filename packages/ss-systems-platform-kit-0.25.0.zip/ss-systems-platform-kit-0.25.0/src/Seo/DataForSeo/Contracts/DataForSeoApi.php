<?php

namespace SsSystems\Platform\Seo\DataForSeo\Contracts;

/**
 * The DataForSEO calls the SEO tools make — one client every site shares
 * (ported from gs.construction's App\Services\DataForSeoService, whose
 * method names, argument order and return shapes this contract keeps so
 * the ported tools read the same). Money: every call adds its cost to
 * spent(); a tool stops when a run's --budget is reached.
 *
 * @phpstan-type SerpResult array{position: int, url: string, domain: string, title: string}
 */
interface DataForSeoApi
{
    public function isConfigured(): bool;

    public function getLastError(): ?string;

    /** USD spent through this instance since it was built. */
    public function spent(): float;

    /** The account balance in USD, null when it cannot be read. */
    public function balance(): ?float;

    /** @return array<string, mixed> the decoded response body ([] on failure, see getLastError()) */
    public function request(string $method, string $path, array $body = []): array;

    /** Post one standard-queue task; its id, or null on failure. */
    public function postTask(string $path, array $task): ?string;

    /** Call $probe every $interval seconds until it returns non-null or $maxSeconds pass. */
    public function pollUntil(callable $probe, int $maxSeconds = 600, int $interval = 15): mixed;

    /** @return list<string> ids of standard-queue tasks posted by the last batch */
    public function lastStandardTaskIds(): array;

    /**
     * @param  list<string>  $keywords
     * @return array<string, array{volume: ?int, cpc: ?float, competition: ?float}>  keyed by keyword
     */
    public function searchVolume(array $keywords, string $locationName = 'United States'): array;

    /** @return list<array<string, mixed>> */
    public function rankedKeywords(string $domain, int $limit = 300, string $locationName = 'United States'): array;

    /**
     * @param  list<string>  $seeds
     * @return list<array<string, mixed>>
     */
    public function keywordIdeas(array $seeds, int $limit = 200, string $locationName = 'United States'): array;

    /**
     * @param  list<string>  $keywords
     * @return array<string, ?int>  keyed by keyword
     */
    public function keywordDifficulty(array $keywords): array;

    /**
     * @param  list<string>  $keywords
     * @return array<string, string>  keyed by keyword
     */
    public function searchIntent(array $keywords): array;

    /** @return array<string, mixed>|null */
    public function domainRankOverview(string $domain): ?array;

    /** @return array<string, mixed>|null */
    public function backlinkSummary(string $domain): ?array;

    /** @return list<array<string, mixed>> */
    public function referringDomains(string $domain, int $limit = 100): array;

    public function llmAnswer(string $platform, string $model, string $prompt): ?string;

    /**
     * The same answer with the web pages the engine cited (DataForSEO LLM
     * Responses, web search on): `sources` are the answer's annotations,
     * one entry per page in the order first cited, never more than 20.
     *
     * @return array{text: string, sources: list<array{url: string, domain: string, title: ?string}>}|null
     */
    public function llmResponse(string $platform, string $model, string $prompt): ?array;

    /** @return list<array<string, mixed>> */
    public function mapsResults(string $keyword, float $lat, float $lng, int $depth = 20): array;

    /** @return array{position: ?int, matched: ?string, results: list<SerpResult>, local_pack: bool, result_count: ?int} */
    public function googleOrganicPosition(string $query, string $targetDomain, string $locationName = 'United States'): array;

    /**
     * @param  list<array<string, mixed>>  $tasks
     * @return array<string, array<string, mixed>>|null  results keyed by task id for the tasks that finished inside the wait
     *                                                    (still-queued ids are absent; lastStandardTaskIds() lists them all);
     *                                                    null only when task_post itself failed
     */
    public function googleOrganicStandardBatch(array $tasks, int $maxSeconds = 240, int $interval = 10): ?array;

    /** @return array<string, mixed> */
    public function googleOrganicTaskResult(string $id): array;

    /** @return list<array{id: string, tag: ?string}> */
    public function googleOrganicReadyTasks(): array;
}
