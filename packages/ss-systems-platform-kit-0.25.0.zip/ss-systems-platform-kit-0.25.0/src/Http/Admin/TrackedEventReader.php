<?php

namespace SsSystems\Platform\Http\Admin;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use SsSystems\Platform\Http\Admin\Contracts\AnalyticsEventReader;
use SsSystems\Platform\Traffic\SourceClassifier;

/**
 * AnalyticsEventReader over a site's own TrackedEvent-shaped Eloquent model
 * (gs.construction/jpeterson-design.com today). Resolved fresh on every
 * call — never cached on this object — so gsc's `BelongsToSite` global
 * scope (bound to `Site::current()` at query time) fires exactly the way a
 * bare `TrackedEvent::query()` call site already would. The kit must never
 * reference `App\Models\TrackedEvent` directly (CLAUDE.md/RULES.md): each
 * site supplies either the class-string (the common case — the model's own
 * global scope, if any, is enough) or a closure when a site needs to seed
 * the query with something beyond what the model's own boot method adds.
 *
 * The model only needs to expose `id`, `type`, `label`, `page_path`,
 * `referrer`, `utm_source`, `utm_medium`, `utm_campaign`, `country` and
 * `created_at` — exactly `TrackedEvent`'s own columns on every site that
 * has one. Whichever of `ip_address`, `user_agent` and `session_id` the
 * table has (gsc and jpeterson have all three) are read too and hashed
 * into each row's `duplicate_key`: BuildsAnalyticsScreen folds rows that
 * share it and match in everything else that day, so the same IP, browser
 * and session tapping the same thing again is one row. A row with none of
 * the three never folds, and the hash never reaches the API. The column
 * lookup runs once per reader instance, not per row.
 */
class TrackedEventReader implements AnalyticsEventReader
{
    /** The columns that say who did it, in this order when the table has them. */
    public const IDENTITY_COLUMNS = ['ip_address', 'user_agent', 'session_id'];

    /** @var list<string>|null which IDENTITY_COLUMNS the table has — looked up on the first rowsSince() call, then kept */
    private ?array $identityColumns = null;

    /**
     * @param  class-string<Model>|(\Closure(): Builder)  $model  e.g. `\App\Models\TrackedEvent::class`,
     *                                                             or a closure returning a fresh `Builder` when a site needs to seed the
     *                                                             query beyond the model's own global scope.
     */
    /** @param  list<string>  $ownHosts  the site's hosts; APP_URL's is added */
    public function __construct(protected string|\Closure $model, protected array $ownHosts = [])
    {
    }

    public function rowsSince(Carbon $start): Collection
    {
        $own = SourceClassifier::ownHosts(null, $this->ownHosts);
        $query = $this->query();
        $identityColumns = $this->identityColumns($query);

        $columns = ['id', 'type', 'label', 'page_path', 'referrer', 'utm_source', 'utm_medium', 'utm_campaign', 'country', 'created_at', ...$identityColumns];

        return $query
            ->where('created_at', '>=', $start)
            ->latest()
            ->get($columns)
            ->map(fn (Model $event) => [
                ...SourceClassifier::classify($event->referrer, $event->utm_source, $event->utm_medium, $own, $event->utm_campaign),
                'id' => $event->getKey(),
                'type' => $event->type,
                'label' => $event->label,
                'page_path' => $event->page_path,
                'referrer' => $event->referrer,
                'utm_source' => $event->utm_source,
                'utm_medium' => $event->utm_medium,
                'utm_campaign' => $event->utm_campaign,
                'country' => $event->country,
                'created_at' => $event->created_at instanceof Carbon ? $event->created_at : Carbon::parse($event->created_at),
                'duplicate_key' => $this->duplicateKey($event, $identityColumns),
            ])
            ->values();
    }

    protected function query(): Builder
    {
        return is_string($this->model) ? $this->model::query() : ($this->model)();
    }

    /**
     * The same IP, browser and session (whichever the table records) as one
     * opaque hash; null when the row records none of them.
     *
     * @param  list<string>  $identityColumns
     */
    protected function duplicateKey(Model $event, array $identityColumns): ?string
    {
        $identity = array_map(fn (string $column) => is_string($event->{$column}) ? trim($event->{$column}) : null, $identityColumns);

        if (array_filter($identity, fn (?string $value) => $value !== null && $value !== '') === []) {
            return null;
        }

        return hash('sha256', (string) json_encode(array_combine($identityColumns, $identity)));
    }

    /**
     * Asked of the model's own connection (never the Schema facade, so a
     * closure-supplied builder on another connection is checked where it
     * lives) and remembered for the life of this reader.
     *
     * @return list<string>
     */
    protected function identityColumns(Builder $query): array
    {
        if ($this->identityColumns === null) {
            $model = $query->getModel();
            $present = array_map('strtolower', $model->getConnection()->getSchemaBuilder()->getColumnListing($model->getTable()));
            $this->identityColumns = array_values(array_intersect(self::IDENTITY_COLUMNS, $present));
        }

        return $this->identityColumns;
    }
}
