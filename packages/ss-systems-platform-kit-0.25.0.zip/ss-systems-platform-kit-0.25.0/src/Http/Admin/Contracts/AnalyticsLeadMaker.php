<?php

namespace SsSystems\Platform\Http\Admin\Contracts;

/**
 * "Make lead" on the hub's Analytics screen (2026-11-10): a visitor tapped
 * Call, Text or Email and then reached the team off the site, so the team
 * fills in who it was and the tap becomes a lead in the site's own leads.
 *
 * Each site implements this over its own lead table and delivers the lead
 * exactly the way a lead from its own form is delivered. A controller that
 * uses BuildsAnalyticsScreen opts in by returning one from
 * analyticsLeadMaker(); a site that returns null keeps its table without
 * the lead column and answers 404 to POST analytics/events/{id}/lead.
 */
interface AnalyticsLeadMaker
{
    /**
     * The leads already made from any of these analytics events.
     *
     * @param  list<string>  $eventIds  API row ids, every event of a folded row
     * @return array<string, array{id: int|string, contact: ?string}> event id => the lead, and the phone, email or name the hub searches Leads by to open it
     */
    public function leadsForEvents(array $eventIds): array;

    /**
     * Makes the lead and delivers it like a lead from the site's own form.
     * The lead is dated at the first tap and keeps where the visit came from.
     * AnalyticsLeadMessage::for() words its message the same on every site.
     *
     * @param  array<string, mixed>  $event  the row as the API shows it (type, label, page_path, referrer, utm_*, channel, source, count, created_at, last_at…) plus `event_ids`
     * @param  array{name: ?string, phone: ?string, email: ?string, note: ?string}  $input
     * @return array{id: int|string, contact: ?string}
     */
    public function makeLead(array $event, array $input): array;
}
