<?php

namespace SsSystems\Platform\Http\Admin;

use Illuminate\Support\Carbon;

/**
 * The words every site's lead made from an analytics tap carries, so a lead
 * reads the same in each site's Leads, its email and its CRM:
 *
 *     Tapped Text ((224) 628-4013) on the website (2 taps), Nov 9, 2026
 *     9:22–9:23 AM CT. Came to the site from ChatGPT.
 *     <what the team says they said>
 *
 * dawnsellshomes.com writes the same sentence from its own controller.
 */
final class AnalyticsLeadMessage
{
    /** API row type => what the visitor tapped, and the lead's origin/source value. */
    public const TAPS = [
        'phone_click' => ['Call', 'call'],
        'text_click' => ['Text', 'text'],
        'email_click' => ['Email', 'email'],
    ];

    /** @param  array<string, mixed>  $event  an API row (created_at/last_at ISO strings or Carbon) */
    public static function for(array $event, ?string $note = null, string $timezone = 'America/Chicago'): string
    {
        $tapped = self::TAPS[$event['type'] ?? ''][0] ?? 'Contact';
        $value = self::readableValue(isset($event['label']) ? (string) $event['label'] : null);
        $count = max(1, (int) ($event['count'] ?? 1));

        $first = Carbon::parse($event['created_at'])->timezone($timezone);
        $last = Carbon::parse($event['last_at'] ?? $event['created_at'])->timezone($timezone);
        $zone = $timezone === 'America/Chicago' ? 'CT' : $first->format('T');

        $when = $count > 1 && $last->format('g:i A') !== $first->format('g:i A')
            ? $first->format('M j, Y g:i').($first->format('A') === $last->format('A') ? '' : ' '.$first->format('A')).'–'.$last->format('g:i A')
            : $first->format('M j, Y g:i A');

        $source = isset($event['source']) ? trim((string) $event['source']) : '';
        $from = $source !== '' && ($event['channel'] ?? 'direct') !== 'direct' ? " Came to the site from {$source}." : '';

        $message = "Tapped {$tapped}".($value !== null ? " ({$value})" : '').' on the website'
            .($count > 1 ? " ({$count} taps)" : '').", {$when} {$zone}.{$from}";

        $note = trim((string) $note);

        return $note !== '' ? $message."\n".$note : $message;
    }

    /** The lead's origin/source for a tap type: call, text or email. */
    public static function origin(string $type): ?string
    {
        return self::TAPS[$type][1] ?? null;
    }

    /** A tapped US number reads (224) 628-4013; anything else as it was tapped. */
    public static function readableValue(?string $value): ?string
    {
        if ($value === null || trim($value) === '') {
            return null;
        }

        if (str_contains($value, '@')) {
            return $value;
        }

        $digits = (string) preg_replace('/\D+/', '', $value);
        if (strlen($digits) === 11 && str_starts_with($digits, '1')) {
            $digits = substr($digits, 1);
        }

        return strlen($digits) === 10
            ? sprintf('(%s) %s-%s', substr($digits, 0, 3), substr($digits, 3, 3), substr($digits, 6))
            : $value;
    }
}
