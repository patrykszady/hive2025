<?php

namespace SsSystems\Platform\Http\Admin\Concerns;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;
use SsSystems\Platform\Http\Admin\AnalyticsLeadMessage;
use SsSystems\Platform\Http\Admin\Contracts\AnalyticsEventReader;
use SsSystems\Platform\Http\Admin\Contracts\AnalyticsLeadMaker;
use SsSystems\Platform\Traffic\SourceClassifier;

/**
 * `events()`/`summary()` for `/api/admin/v1/analytics/*` — every kit site's
 * `Livewire\Admin\SiteAnalytics` screen reads exactly this shape (a `days`
 * + `type_filter` scope, a paginated `events()` table and a `summary()`
 * aggregate carrying the four-tile stats/prior-stats, a top-8-pages
 * breakdown and a per-day trend series) regardless of what
 * `AnalyticsEventReader` a site binds — see that contract's own docblock
 * for the two real implementations.
 *
 * Ported from gs.construction/jpeterson-design.com's identical
 * `AnalyticsController` (`TrackedEvent`-backed) and
 * hive.contractors/ss.systems' identical one (Pulse-backed): the whole
 * rest of the class — windowing, the four-tile breakdown, the trend
 * series, top pages, pagination, response shape — was already
 * byte-identical bar the row source. This trait ALSO now cache-buckets
 * `summary()` for every adopter, 5 minutes per {days, type, 5-minute clock
 * bucket} — hive/ss.systems already did this (a full-row scan over
 * `site_events` on every call); gsc/jpeterson previously answered
 * `summary()` from a cheap SQL aggregate with no cache at all, so moving
 * them onto this shared, `rowsSince()`-based implementation makes their
 * `summary()` responses up to 5 minutes stale where they used to be live —
 * a deliberate, minor behaviour change (flagged to the owner), not an
 * oversight: the alternative was two summary() bodies again.
 *
 * Assumes the host controller ALSO `use`s `BuildsApiResponses`
 * (`perPage()`/`paginatedResponse()`) — every existing `AnalyticsController`
 * already does.
 *
 * Duplicates fold into one row (2026-11-10): rows on the same day (this
 * site's calendar) that share the reader's `duplicate_key` (the same IP
 * and device: Pulse's per-day `vhash` with city, device and payload;
 * TrackedEvent's ip_address, user_agent and session_id) and match in every
 * field the screen shows (type, label, page, referrer, tags, country,
 * channel, source, landing page) are ONE row: the first event's own fields
 * plus `count` and `last_at`. It folds BEFORE pagination and before every
 * count, so the events() table, the tiles (current and prior window), the
 * trend series, top pages and top sources always agree. A row without a
 * duplicate_key never folds, and the key never reaches the API.
 * dawnsellshomes.com applies the same rule in its own controller.
 *
 * "Make lead" (2026-11-10): a controller whose analyticsLeadMaker() returns
 * one gets `lead_id`, `lead_contact` and `can_make_lead` on every events()
 * row, and lead() answers POST analytics/events/{event}/lead: the team
 * fills in who reached out after a call, text or email tap and the site's
 * AnalyticsLeadMaker makes the lead the way its own form does. Asking again
 * answers the lead already made. Without a maker the rows carry none of
 * those keys (the hub then shows no lead column) and lead() answers 404.
 *
 * Two hooks a using controller MUST implement:
 *
 * ```php
 * protected function analyticsEventReader(): AnalyticsEventReader
 * {
 *     return new TrackedEventReader(\App\Models\TrackedEvent::class);
 * }
 *
 * // Every site's own effective zone — gsc/jpeterson/hive/ss.systems all
 * // currently read 'America/Chicago', but the kit itself must never
 * // hardcode that; a site with no analytics-specific config value simply
 * // defaults to the same string it already used.
 * protected function analyticsTimezone(): string
 * {
 *     return config('services.analytics.timezone', 'America/Chicago');
 * }
 * ```
 */
trait BuildsAnalyticsScreen
{
    /** The row source — see AnalyticsEventReader's own docblock for the two real implementations. */
    abstract protected function analyticsEventReader(): AnalyticsEventReader;

    /**
     * The IANA zone the screen's day boundaries, the trend chart's daily
     * buckets and the summary cache's 5-minute clock bucket are all read
     * in — this site's own effective timezone, never a kit constant.
     */
    abstract protected function analyticsTimezone(): string;

    /** @return array<int,int> the windows the range picker offers — identical on every adopting site today. */
    /**
     * The cache key summary() stores under. Single-tenant sites keep it as
     * is; a multi-tenant site prefixes the current tenant (gsc:
     * Tenancy::cacheKey()), because a shared cache store would otherwise
     * hand one tenant another tenant's numbers for up to five minutes.
     */
    protected function analyticsCacheKey(string $key): string
    {
        return $key;
    }

    protected function analyticsSpans(): array
    {
        return [7, 14, 28, 60, 90, 180, 360];
    }

    protected function analyticsDefaultSpan(): int
    {
        return 28;
    }

    /**
     * The site's own leads, for "Make lead" — null (the default) keeps the
     * screen without it.
     */
    protected function analyticsLeadMaker(): ?AnalyticsLeadMaker
    {
        return null;
    }

    /** @return list<string> the row types a lead can be made from: the visitor reached out off the site */
    protected static function analyticsLeadTapTypes(): array
    {
        return array_keys(AnalyticsLeadMessage::TAPS);
    }

    public function events(Request $request): JsonResponse
    {
        $days = $this->analyticsDays($request);
        $start = $this->analyticsWindowStart($days);
        $type = $this->analyticsTypeFilter($request);

        $rows = $this->analyticsCollapseRepeats($this->analyticsEventReader()->rowsSince($start))
            ->when($type !== null, fn (Collection $rows) => $rows->where('type', $type))
            ->values();

        $perPage = $this->perPage($request);
        $page = max(1, (int) $request->integer('page', 1));

        $items = $rows->forPage($page, $perPage)->values();
        $maker = $this->analyticsLeadMaker();
        if ($maker !== null) {
            $items = $this->analyticsWithLeads($items, $maker);
        }

        $paginator = new LengthAwarePaginator(
            items: $items,
            total: $rows->count(),
            perPage: $perPage,
            currentPage: $page,
            options: ['path' => $request->url(), 'query' => $request->query()],
        );

        return $this->paginatedResponse($paginator, fn (array $row) => $this->analyticsToApiArray($row));
    }

    /**
     * POST analytics/events/{event}/lead — "Make lead" on a call, text or
     * email tap (the hub's Analytics screen). 201 with the new lead, 200
     * with the one already made from it, 404 when the site makes no leads
     * here or the event is not a tap in the last year.
     */
    public function lead(Request $request, string $event): JsonResponse
    {
        $maker = $this->analyticsLeadMaker();
        if ($maker === null) {
            return new JsonResponse(['message' => 'This site does not make leads from analytics events.'], 404);
        }

        $input = $request->validate([
            'name' => ['nullable', 'string', 'max:255'],
            'phone' => ['nullable', 'required_without:email', 'string', 'max:40'],
            'email' => ['nullable', 'required_without:phone', 'email', 'max:255'],
            'note' => ['nullable', 'string', 'max:2000'],
        ], [
            'phone.required_without' => 'Add the phone number or the email address they used.',
            'email.required_without' => 'Add the phone number or the email address they used.',
        ]);

        $made = $this->analyticsMakeLead($event, $input, $maker);
        if ($made === null) {
            return new JsonResponse(['message' => 'No call, text or email tap with that id.'], 404);
        }

        return new JsonResponse(['data' => $made['lead'] + ['event_id' => $made['event_id']]], $made['created'] ? 201 : 200);
    }

    /**
     * Finds the tap (any event of a folded row) in the last year, answers
     * the lead already made from it, or has the site make one.
     *
     * @param  array<string, mixed>  $input  validated name/phone/email/note
     * @return array{lead: array{id: int|string, contact: ?string}, event_id: string, created: bool}|null
     */
    protected function analyticsMakeLead(string $eventId, array $input, AnalyticsLeadMaker $maker): ?array
    {
        $eventId = trim($eventId);
        $start = $this->analyticsWindowStart(max($this->analyticsSpans()));
        $row = $this->analyticsCollapseRepeats($this->analyticsEventReader()->rowsSince($start))
            ->first(fn (array $row) => in_array($eventId, $row['event_ids'] ?? [(string) $row['id']], true));

        if ($row === null || ! in_array($row['type'], static::analyticsLeadTapTypes(), true)) {
            return null;
        }

        $eventIds = $row['event_ids'] ?? [(string) $row['id']];
        $existing = collect($maker->leadsForEvents($eventIds))->first();
        if ($existing !== null) {
            return ['lead' => $existing, 'event_id' => (string) $row['id'], 'created' => false];
        }

        $clean = fn (string $key): ?string => isset($input[$key]) && trim((string) $input[$key]) !== '' ? trim((string) $input[$key]) : null;
        $lead = $maker->makeLead($this->analyticsToApiArray($row) + ['event_ids' => $eventIds], [
            'name' => $clean('name'),
            'phone' => $clean('phone'),
            'email' => $clean('email'),
            'note' => $clean('note'),
        ]);

        return ['lead' => $lead, 'event_id' => (string) $row['id'], 'created' => true];
    }

    /**
     * Marks a page of rows with the lead made from each (from any of its
     * folded events) and whether one can still be made.
     *
     * @param  Collection<int, array<string, mixed>>  $rows
     * @return Collection<int, array<string, mixed>>
     */
    protected function analyticsWithLeads(Collection $rows, AnalyticsLeadMaker $maker): Collection
    {
        $eventIds = $rows->flatMap(fn (array $row) => $row['event_ids'] ?? [(string) $row['id']])->values()->all();
        $leads = $eventIds === [] ? [] : $maker->leadsForEvents($eventIds);
        $tapTypes = static::analyticsLeadTapTypes();

        return $rows->map(function (array $row) use ($leads, $tapTypes) {
            $lead = collect($row['event_ids'] ?? [(string) $row['id']])->map(fn (string $id) => $leads[$id] ?? null)->filter()->first();
            $row['lead_id'] = $lead['id'] ?? null;
            $row['lead_contact'] = $lead['contact'] ?? null;
            $row['can_make_lead'] = $lead === null && in_array($row['type'], $tapTypes, true);

            return $row;
        });
    }

    public function summary(Request $request): JsonResponse
    {
        $days = $this->analyticsDays($request);
        $type = $this->analyticsTypeFilter($request);

        $bucket = intdiv(Carbon::now()->getTimestamp(), 300);
        // A multi-tenant site MUST fold its tenant into this key (gs.construction
        // does, through analyticsCacheKey()): one cache store serves every
        // tenant, and Eloquent scopes protect queries, not cache entries.
        $cacheKey = $this->analyticsCacheKey("analytics-summary:{$days}:{$type}:{$bucket}");

        $data = Cache::remember($cacheKey, 300, fn () => $this->analyticsSummaryData($days, $type));

        return new JsonResponse(['data' => $data]);
    }

    /**
     * Everything summary() caches — kept out of the Cache::remember()
     * closure so the tiles can be pinned without a cache store. Each
     * window is folded on its own (analyticsCollapseRepeats()), so the
     * current window's tiles count exactly the rows events() pages.
     *
     * @return array<string,mixed>
     */
    protected function analyticsSummaryData(int $days, ?string $type): array
    {
        $start = $this->analyticsWindowStart($days);
        $priorStart = $start->copy()->subDays($days);

        $rows = $this->analyticsEventReader()->rowsSince($priorStart);
        $current = $this->analyticsCollapseRepeats($rows->filter(fn (array $row) => $row['created_at']->gte($start)));
        $prior = $this->analyticsCollapseRepeats($rows->filter(fn (array $row) => $row['created_at']->lt($start)));

        // The tiles are the per-type breakdown of the window, so they
        // never narrow by type — the selected type is highlighted on
        // the screen instead of the other three collapsing to zero.
        $stats = $this->analyticsCountsByType($current);
        $statsPrev = $this->analyticsCountsByType($prior);

        $topPages = $current
            ->when($type !== null, fn (Collection $rows) => $rows->where('type', $type))
            ->filter(fn (array $row) => $row['page_path'] !== null)
            ->groupBy('page_path')
            ->map(fn (Collection $rows) => $rows->count())
            ->sortDesc()
            ->take(8);

        return [
            'days' => $days,
            'stats' => $stats,
            'stats_prev' => $statsPrev,
            'top_pages' => $topPages,
            'trend' => $this->analyticsTrendChartData($days, $current),
            // Where the window's calls, texts, emails and forms came from
            // (2026-10-26), named by Traffic\SourceClassifier.
            'top_sources' => $this->analyticsTopSources($current, $type),
            'sources_recorded' => $rows->contains(fn (array $row) => ($row['channel'] ?? null) !== null),
        ];
    }

    /**
     * Folds duplicates into one row before anything counts or pages them:
     * rows that share a duplicate_key, fall on the same day of this site's
     * calendar and match in every field the screen shows. The row that
     * comes out is the FIRST of them (its id, created_at and source fields)
     * plus `count` and `last_at`; a row with no duplicate has count 1 and
     * last_at = created_at. A row without a duplicate_key never folds, and
     * the result is newest first by the first event's time.
     *
     * @param  Collection<int,array<string,mixed>>  $rows
     * @return Collection<int,array<string,mixed>>
     */
    protected function analyticsCollapseRepeats(Collection $rows): Collection
    {
        $timezone = $this->analyticsTimezone();
        $collapsed = [];
        $rowIndexByKey = [];

        foreach ($rows->sortBy('created_at') as $row) {
            $duplicateKey = trim((string) ($row['duplicate_key'] ?? ''));
            $key = $duplicateKey === '' ? null : hash('sha256', (string) json_encode([
                $duplicateKey,
                $row['created_at']->copy()->timezone($timezone)->toDateString(),
                $row['type'],
                $row['label'] ?? null,
                $row['page_path'] ?? null,
                $row['referrer'] ?? null,
                $row['utm_source'] ?? null,
                $row['utm_medium'] ?? null,
                $row['utm_campaign'] ?? null,
                $row['country'] ?? null,
                $row['channel'] ?? null,
                $row['source'] ?? null,
                $row['landing_path'] ?? null,
            ]));

            if ($key !== null && isset($rowIndexByKey[$key])) {
                $index = $rowIndexByKey[$key];
                $collapsed[$index]['count']++;
                $collapsed[$index]['last_at'] = $row['created_at'];
                $collapsed[$index]['event_ids'][] = (string) $row['id'];

                continue;
            }

            $row['count'] = 1;
            $row['last_at'] = $row['created_at'];
            // Every event the row stands for, for Make lead; never in the API output.
            $row['event_ids'] = [(string) $row['id']];
            $collapsed[] = $row;

            if ($key !== null) {
                $rowIndexByKey[$key] = array_key_last($collapsed);
            }
        }

        return collect($collapsed)->sortByDesc('created_at')->values();
    }

    /**
     * How many rows of these types the Analytics screen shows from $start
     * (up to $before when given), duplicates folded exactly as in the table:
     * the hub dashboard's contacts tile reads this so the two always agree.
     *
     * @param  list<string>  $types
     */
    public function analyticsFoldedCount(Carbon $start, ?Carbon $before = null, array $types = ['phone_click', 'text_click', 'email_click', 'form_submit']): int
    {
        $rows = $this->analyticsEventReader()->rowsSince($start)
            ->when($before !== null, fn (Collection $rows) => $rows->filter(fn (array $row) => $row['created_at']->lt($before)));

        return $this->analyticsCollapseRepeats($rows)->whereIn('type', $types)->count();
    }

    protected function analyticsDays(Request $request): int
    {
        $days = (int) $request->integer('days', $this->analyticsDefaultSpan());

        return in_array($days, $this->analyticsSpans(), true) ? $days : $this->analyticsDefaultSpan();
    }

    /**
     * "Last N days" is today plus the N-1 days before it, on this site's
     * own calendar, converted to UTC so it compares correctly against
     * UTC-stored created_at values.
     */
    protected function analyticsWindowStart(int $days): Carbon
    {
        return Carbon::now($this->analyticsTimezone())->subDays($days - 1)->startOfDay()->utc();
    }

    protected function analyticsTypeFilter(Request $request): ?string
    {
        $type = $request->string('type_filter')->toString();

        return ($type !== '' && $type !== 'all') ? $type : null;
    }

    /**
     * @param  Collection<int,array<string,mixed>>  $rows
     * @return array<string,int>
     */
    protected function analyticsCountsByType(Collection $rows): array
    {
        $counts = [
            'phone' => $rows->where('type', 'phone_click')->count(),
            'email' => $rows->where('type', 'email_click')->count(),
            'form' => $rows->where('type', 'form_submit')->count(),
            'cta' => $rows->where('type', 'cta_click')->count(),
            // sms: taps ("Text Josh" on dawnsellshomes.com), a type of their own since 2026-10-25.
            'text' => $rows->where('type', 'text_click')->count(),
        ];
        $counts['total'] = array_sum($counts);

        return $counts;
    }

    /**
     * Daily per-type event counts for the window, every type in every row:
     * the screen draws only the selected type's line, so one series serves
     * every type filter. Grouped by this site's own calendar day in PHP so
     * DST transitions stay correct and the same code runs against SQLite
     * in tests.
     *
     * @param  Collection<int,array<string,mixed>>  $rows  rows already scoped to the window
     * @return array<int,array<string,mixed>>
     */
    protected function analyticsTrendChartData(int $days, Collection $rows): array
    {
        $tz = $this->analyticsTimezone();
        $byDay = $rows->groupBy(fn (array $row) => $row['created_at']->copy()->timezone($tz)->toDateString());

        return collect(range($days - 1, 0))->map(function ($ago) use ($byDay, $tz) {
            $date = Carbon::now($tz)->subDays($ago)->toDateString();
            $dayRows = $byDay->get($date, collect());
            $types = $dayRows->countBy('type');

            return [
                'date' => Carbon::parse($date)->format('M j'),
                'day' => $date,
                'phone' => (int) ($types['phone_click'] ?? 0),
                'email' => (int) ($types['email_click'] ?? 0),
                'form' => (int) ($types['form_submit'] ?? 0),
                'cta' => (int) ($types['cta_click'] ?? 0),
                'text' => (int) ($types['text_click'] ?? 0),
                'total' => $dayRows->count(),
            ];
        })->values()->all();
    }

    /** @param  array<string,mixed>  $row */
    protected function analyticsToApiArray(array $row): array
    {
        $channel = $row['channel'] ?? null;

        return [
            'id' => $row['id'],
            'type' => $row['type'],
            'type_label' => static::analyticsTypeLabel($row['type']),
            'label' => $row['label'],
            'page_path' => $row['page_path'],
            'referrer' => $row['referrer'],
            'utm_source' => $row['utm_source'],
            'utm_medium' => $row['utm_medium'],
            'utm_campaign' => $row['utm_campaign'],
            'country' => $row['country'],
            'channel' => $channel,
            'channel_label' => $channel !== null ? SourceClassifier::channelLabel($channel) : null,
            'source' => $row['source'] ?? null,
            'landing_path' => $row['landing_path'] ?? null,
            'created_at' => $row['created_at']->toIso8601String(),
            // Folded duplicates (analyticsCollapseRepeats()): how many events
            // this row stands for and when the last of them happened. The
            // duplicate_key that folded them is deliberately NOT here.
            'count' => (int) ($row['count'] ?? 1),
            'last_at' => ($row['last_at'] ?? $row['created_at'])->toIso8601String(),
        ] + (array_key_exists('can_make_lead', $row) ? [
            // Only on a site with an AnalyticsLeadMaker (analyticsWithLeads()).
            'lead_id' => $row['lead_id'] ?? null,
            'lead_contact' => $row['lead_contact'] ?? null,
            'can_make_lead' => (bool) $row['can_make_lead'],
        ] : []);
    }

    /**
     * The window's events by named source, most first.
     *
     * @return list<array{source: string, channel: string, channel_label: string, count: int}>
     */
    protected function analyticsTopSources(Collection $rows, ?string $type): array
    {
        return $rows
            ->when($type !== null, fn (Collection $rows) => $rows->where('type', $type))
            ->filter(fn (array $row) => ($row['channel'] ?? null) !== null)
            ->groupBy(fn (array $row) => $row['channel'].'|'.($row['source'] ?? 'Direct'))
            ->map(function (Collection $group, string $key) {
                [$channel, $source] = explode('|', $key, 2);

                return ['source' => $source, 'channel' => $channel, 'channel_label' => SourceClassifier::channelLabel($channel), 'count' => $group->count()];
            })
            ->sortByDesc('count')
            ->take(10)
            ->values()
            ->all();
    }

    public static function analyticsTypeLabel(string $type): string
    {
        return match ($type) {
            'phone_click' => 'Phone click',
            'email_click' => 'Email click',
            'form_submit' => 'Form submission',
            'cta_click' => 'CTA click',
            'text_click' => 'Text click',
            default => ucfirst(str_replace('_', ' ', $type)),
        };
    }
}
