<?php

namespace SsSystems\Platform\Google;

use Illuminate\Http\Client\ConnectionException;
use Illuminate\Http\Client\Factory;
use SsSystems\Platform\Auth\OAuthState;

/**
 * THE Google OAuth client — one for every tenant (owner's call, 2026-09-28):
 * gs.construction's Google Cloud project (31627704418), the one with
 * Business Profile API access, issues every site's Google sign-in. Each
 * tenant adds only its own callback URI to that client
 * (`/admin-oauth/{provider}/callback` on its own host, see
 * `redirectUri()`); nothing about the client is per site any more.
 *
 * Replaces six `App\Support\GoogleOAuthApp` variants that overlaid a
 * per-site client from `platform_settings` onto config at boot — there is
 * no database overlay here, by design: the client is server configuration,
 * the same on every tenant, and never typed into an admin. (No platform-
 * admin override path either: no tenant has a reason to sign in through a
 * different Google Cloud project, and a per-site client is exactly what
 * made every refresh token die the day a site's client changed.)
 *
 * One config shape, read by the site's binding (the kit never calls
 * `config()`): `services.google.oauth.client_id` / `client_secret` (and an
 * optional `project_id`, shown to platform admins). For ONE release, when
 * that pair is absent, `fromConfig()` falls back — read-only — to the pair
 * each site already has: `services.google.business_profile.client_id/
 * client_secret` (fed by GOOGLE_BUSINESS_PROFILE_CLIENT_ID/SECRET on
 * gs.construction, jpeterson-design, deerfield-furniture, dawnsellshomes,
 * and by GOOGLE_CLIENT_ID/SECRET on hive.contractors and ss.systems), then
 * `services.google.search_console.*`. `source()` says which one is live, so
 * a tenant still on the old keys shows up (`legacy_config: true` in its
 * platforms/status `google` block). See docs/GOOGLE.md.
 *
 * Every HTTP call goes through the injected factory (tests fake it; they
 * never reach Google). Nothing here logs or returns the secret.
 */
final class OAuthClient
{
    public const AUTH_ENDPOINT = 'https://accounts.google.com/o/oauth2/v2/auth';

    public const TOKEN_ENDPOINT = 'https://oauth2.googleapis.com/token';

    public const USERINFO_ENDPOINT = 'https://www.googleapis.com/oauth2/v3/userinfo';

    /** The route name every site's `/admin-oauth/{provider}/callback` is registered under. */
    public const CALLBACK_ROUTE = 'admin-oauth.callback';

    /** Every Business Profile call needs this; the identity scopes alone sign in and nothing else. */
    public const SCOPE_BUSINESS_PROFILE = 'https://www.googleapis.com/auth/business.manage';

    /** Full webmasters (not .readonly): sitemaps.submit needs it — gs.construction/jpeterson-design's OAuth Search Console. */
    public const SCOPE_SEARCH_CONSOLE = 'https://www.googleapis.com/auth/webmasters';

    /** @var list<string> who granted it, for the Platforms card's "Authorized as" */
    public const SCOPES_IDENTITY = ['openid', 'email'];

    public function __construct(
        private readonly ?string $clientId,
        private readonly ?string $clientSecret,
        private readonly Factory $http,
        private readonly ?string $projectId = null,
        private readonly ?string $source = 'config',
    ) {}

    /**
     * Build the client from a site's `config('services.google')` array — the
     * one place the config shape (and its one-release legacy fallback) is
     * decided. A pair is taken whole or not at all: a new id is never mixed
     * with an old secret.
     *
     * @param  array<string, mixed>  $google
     */
    public static function fromConfig(array $google, Factory $http): self
    {
        $pair = static fn (mixed $block): ?array => is_array($block)
            && trim((string) ($block['client_id'] ?? '')) !== ''
            && trim((string) ($block['client_secret'] ?? '')) !== ''
                ? [trim((string) $block['client_id']), trim((string) $block['client_secret'])]
                : null;

        $oauth = is_array($google['oauth'] ?? null) ? $google['oauth'] : [];
        $projectId = trim((string) ($oauth['project_id'] ?? '')) ?: null;

        if ($current = $pair($google['oauth'] ?? null)) {
            return new self($current[0], $current[1], $http, $projectId, 'config');
        }

        foreach (['business_profile', 'search_console'] as $legacyKey) {
            if ($legacy = $pair($google[$legacyKey] ?? null)) {
                return new self($legacy[0], $legacy[1], $http, $projectId, 'legacy');
            }
        }

        return new self(null, null, $http, $projectId, null);
    }

    public function isConfigured(): bool
    {
        return trim((string) $this->clientId) !== '' && trim((string) $this->clientSecret) !== '';
    }

    public function clientId(): ?string
    {
        return $this->isConfigured() ? $this->clientId : null;
    }

    /** 'config' (services.google.oauth), 'legacy' (a pre-0.14 key, one release only), or null when unconfigured. */
    public function source(): ?string
    {
        return $this->isConfigured() ? $this->source : null;
    }

    /** The configured Cloud project id, else the project NUMBER every client id starts with. */
    public function projectId(): ?string
    {
        return $this->projectId ?? $this->projectNumber();
    }

    /** "31627704418" out of "31627704418-abc….apps.googleusercontent.com". */
    public function projectNumber(): ?string
    {
        return preg_match('/^(\d+)-/', (string) $this->clientId, $m) ? $m[1] : null;
    }

    /** "1234567890-abc…apps.googleusercontent.com" — enough to recognise which client, not enough to reuse. */
    public function hint(): ?string
    {
        $clientId = (string) $this->clientId;

        if ($clientId === '') {
            return null;
        }

        return strlen($clientId) <= 24
            ? substr($clientId, 0, 6).'…'
            : substr($clientId, 0, 14).'…'.substr($clientId, -28);
    }

    /** The path half of a callback URI: `/admin-oauth/{provider}/callback`. */
    public static function callbackPath(string $provider): string
    {
        return '/admin-oauth/'.$provider.'/callback';
    }

    /**
     * The redirect URI to register on the shared client for one tenant and
     * provider — the tenant's own public base URL plus callbackPath(). A site
     * inside a request uses `route(OAuthClient::CALLBACK_ROUTE, …)`, which
     * produces the same string on the host ss.systems called.
     */
    public static function redirectUri(string $baseUrl, string $provider): string
    {
        return rtrim($baseUrl, '/').self::callbackPath($provider);
    }

    /**
     * The consent-screen URL, carrying a freshly minted, signed
     * `Auth\OAuthState` for $provider — the callback verifies it before any
     * code is exchanged, which is what protects a session-less callback.
     * Always offline + prompt=consent: Google only hands out a refresh token
     * on a consent it has just shown.
     *
     * @param  list<string>  $scopes
     */
    public function authorizeUrl(string $provider, string $redirectUri, array $scopes): string
    {
        return $this->authorizeUrlWithState($redirectUri, $scopes, OAuthState::make($provider));
    }

    /**
     * authorizeUrl() with the state supplied by the caller — the shape every
     * site's `getOAuthUrl($redirectUri, $state)` already had.
     *
     * @param  list<string>  $scopes
     */
    public function authorizeUrlWithState(string $redirectUri, array $scopes, ?string $state): string
    {
        return self::AUTH_ENDPOINT.'?'.http_build_query(array_filter([
            'client_id' => $this->clientId,
            'redirect_uri' => $redirectUri,
            'response_type' => 'code',
            'scope' => implode(' ', $scopes),
            'access_type' => 'offline',
            'prompt' => 'consent',
            'state' => $state,
        ], static fn ($value) => $value !== null && $value !== ''));
    }

    /**
     * Trade an authorization code for tokens. Never throws: a refusal or a
     * Google that did not answer comes back as `ok: false` with Google's own
     * `error`/`error_description` (status 0 when nothing answered).
     *
     * `scopes` is what Google GRANTED (its `scope` field) — the consent
     * screen lets someone untick Business Profile, and recording the
     * requested set instead once showed "Authorisation on file" over a grant
     * that could do nothing. Null when Google did not say.
     *
     * @return array{ok: true, refresh_token: ?string, access_token: ?string, expires_in: int, scopes: ?list<string>, email: ?string}|array{ok: false, status: int, error: ?string, error_description: ?string}
     */
    public function exchangeCode(string $code, string $redirectUri, bool $fetchEmail = true): array
    {
        try {
            $response = $this->http->asForm()->timeout(20)->post(self::TOKEN_ENDPOINT, [
                'client_id' => $this->clientId,
                'client_secret' => $this->clientSecret,
                'code' => $code,
                'grant_type' => 'authorization_code',
                'redirect_uri' => $redirectUri,
            ]);
        } catch (ConnectionException) {
            return ['ok' => false, 'status' => 0, 'error' => null, 'error_description' => 'Google did not answer.'];
        }

        if (! $response->successful()) {
            return [
                'ok' => false,
                'status' => $response->status(),
                'error' => is_string($response->json('error')) ? $response->json('error') : null,
                'error_description' => is_string($response->json('error_description'))
                    ? $response->json('error_description')
                    : mb_substr((string) $response->body(), 0, 300),
            ];
        }

        $data = (array) $response->json();
        $accessToken = is_string($data['access_token'] ?? null) ? $data['access_token'] : null;

        $email = null;
        if ($fetchEmail && $accessToken !== null) {
            try {
                $email = $this->http->withToken($accessToken)->timeout(10)->get(self::USERINFO_ENDPOINT)->json('email');
            } catch (\Throwable) {
                // Who granted it is a nicety for the Platforms card, never a reason to fail the connect.
            }
        }

        return [
            'ok' => true,
            'refresh_token' => is_string($data['refresh_token'] ?? null) && $data['refresh_token'] !== '' ? $data['refresh_token'] : null,
            'access_token' => $accessToken,
            'expires_in' => (int) ($data['expires_in'] ?? 3600),
            'scopes' => self::scopeList($data['scope'] ?? null),
            'email' => is_string($email) && $email !== '' ? $email : null,
        ];
    }

    /**
     * One refresh-token round trip. Never throws. On success Google may also
     * return a ROTATED refresh token (`refresh_token`) and always states the
     * scopes the grant carries (`scopes`) — the caller persists both.
     *
     * @return array{ok: true, access_token: string, expires_in: int, scopes: ?list<string>, refresh_token: ?string}|array{ok: false, status: int, error: ?string, error_description: ?string, body: string}
     */
    public function refresh(string $refreshToken): array
    {
        try {
            $response = $this->http->asForm()->timeout(20)->post(self::TOKEN_ENDPOINT, [
                'client_id' => $this->clientId,
                'client_secret' => $this->clientSecret,
                'refresh_token' => $refreshToken,
                'grant_type' => 'refresh_token',
            ]);
        } catch (ConnectionException $e) {
            return ['ok' => false, 'status' => 0, 'error' => null, 'error_description' => 'Google did not answer.', 'body' => mb_substr($e->getMessage(), 0, 300)];
        }

        $accessToken = $response->json('access_token');

        if (! $response->successful() || ! is_string($accessToken) || $accessToken === '') {
            return [
                'ok' => false,
                'status' => $response->status(),
                'error' => is_string($response->json('error')) ? $response->json('error') : null,
                'error_description' => is_string($response->json('error_description')) ? $response->json('error_description') : null,
                'body' => mb_substr((string) $response->body(), 0, 2000),
            ];
        }

        $rotated = $response->json('refresh_token');

        return [
            'ok' => true,
            'access_token' => $accessToken,
            'expires_in' => (int) ($response->json('expires_in') ?? 3600),
            'scopes' => self::scopeList($response->json('scope')),
            'refresh_token' => is_string($rotated) && $rotated !== '' ? $rotated : null,
        ];
    }

    /**
     * The `google` block of a site's platforms/status: presence and
     * provenance only — never the secret, only a hint of the id. `source` is
     * 'env' whenever a client is configured (the admin's card reads that as
     * "from the server configuration" — which, since 0.14.0, is the only
     * place a client can come from); `shared` says it is the one client
     * every tenant uses, and `legacy_config` that the tenant still reads it
     * from its pre-0.14 keys.
     *
     * @param  array<string, string>  $redirectUris  provider => this tenant's callback URI
     * @return array{configured: bool, source: ?string, shared: bool, legacy_config: bool, client_id_hint: ?string, project_id: ?string, redirect_uris: array<string, string>}
     */
    public function status(array $redirectUris): array
    {
        return [
            'configured' => $this->isConfigured(),
            'source' => $this->isConfigured() ? 'env' : null,
            'shared' => true,
            'legacy_config' => $this->source() === 'legacy',
            'client_id_hint' => $this->hint(),
            'project_id' => $this->projectId(),
            'redirect_uris' => $redirectUris,
        ];
    }

    /** @return list<string>|null */
    private static function scopeList(mixed $scope): ?array
    {
        if (! is_string($scope) || trim($scope) === '') {
            return null;
        }

        return array_values(array_filter(explode(' ', $scope), static fn (string $s) => $s !== ''));
    }
}
