<?php

namespace SsSystems\Platform\Seo\IndexNow\Contracts;

/**
 * An {@see IndexNowKey} that can say what its key is WITHOUT making one.
 *
 * On every site today `IndexNowKey::key()` invents a key and stores it the
 * first time anything asks (the key is the site's own token, not a
 * credential someone issues). That is right for the collector, which needs
 * one — and wrong for a question: `GET seo/status` asking "is IndexNow set
 * up here?" must not be what sets it up. So the status feed never calls
 * `key()`. A binding that implements this is asked {@see existingKey()}
 * instead; one that does not is taken as set up, because its collector
 * would simply make the key on its next run.
 *
 * Optional, and a separate interface, like
 * {@see \SsSystems\Platform\Seo\Bing\Contracts\CountsSitemapUrls}: every
 * site carries its own key class, and a new method on IndexNowKey itself
 * would break each of them on the day the kit is updated.
 */
interface PeeksIndexNowKey
{
    /**
     * The key as it stands — configured or already stored — or null when
     * there is none yet. Reads only: never generates, never writes.
     */
    public function existingKey(): ?string;
}
