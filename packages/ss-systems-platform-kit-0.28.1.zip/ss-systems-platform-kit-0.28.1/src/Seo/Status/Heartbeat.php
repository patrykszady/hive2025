<?php

namespace SsSystems\Platform\Seo\Status;

use Illuminate\Container\Container;
use Illuminate\Support\Carbon;
use Symfony\Component\Console\Input\InputInterface;

/**
 * Where a collector says how its run went — the write side of
 * `GET seo/status`. Until 2026-11-12 only the Search Console sync left any
 * trace of having run; Bing, PageSpeed, Clarity, the DataForSEO tools, the
 * FAQ bank and the rest recorded nothing, so a collector that had been
 * failing for a week looked exactly like one that was fine.
 *
 * TWO WAYS IN.
 *
 *   1. A collector that knows its own outcome reports it:
 *      {@see succeeded()}, {@see failed()}, {@see skipped()}, or
 *      {@see fromSummary()} with the summary array it already builds. The
 *      row is written at once.
 *   2. Every other collector is reported by its command's exit
 *      ({@see CommandHeartbeat}, one listener on Laravel's console
 *      events). Code underneath such a command can still hand in what only
 *      it knows, without knowing which command it is running under:
 *      counts ({@see note()}, {@see add()}), item outcomes
 *      ({@see tally()}, {@see counted()}) and a refusal ({@see refused()}).
 *      Those are kept on the open run and written once, when it finishes.
 *
 * NOTHING HERE MAY BREAK A COLLECTOR. Every public method swallows whatever
 * goes wrong underneath it (a missing table, a lost connection, a registry
 * typo) and hands the exception to the site's log; a sync never fails
 * because its heartbeat could not be kept. With no store to write to — a
 * site without `seo_sync_runs` that bound nothing — every call is a no-op.
 *
 * Static, like the collectors that call it (BingSync::run(),
 * FaqBankBuilder::run()): they are handed a client and a writer, not a
 * container, and must not grow a third argument on six sites to say "I ran".
 */
final class Heartbeat
{
    /** @var list<HeartbeatRun> commands running now, outermost first */
    private static array $runs = [];

    /** @var list<array{source: string, jobs: list<string>, at: string, said: string, detail: array<string, mixed>, since: float}> failures just recorded with no reason of their own */
    private static array $unexplained = [];

    /** How long after a failure the next error counts as its reason. */
    private const EXPLAIN_WITHIN_SECONDS = 2.0;

    private static bool $shutdownRegistered = false;

    private static ?\Throwable $lastException = null;

    /**
     * The run finished and collected what it set out to.
     *
     * @param  array<string, mixed>  $detail  the run's own counts
     */
    public static function succeeded(string $source, array $detail = [], ?string $at = null): void
    {
        self::report($source, HeartbeatRecord::OK, null, $detail, $at);
    }

    /**
     * The run did not collect: the vendor refused, the balance was short,
     * every item failed. $error is the raw reason, kept to 500 characters.
     *
     * @param  array<string, mixed>  $detail
     */
    public static function failed(string $source, mixed $error, array $detail = [], ?string $at = null): void
    {
        self::report($source, HeartbeatRecord::FAILED, $error, $detail, $at);
    }

    /**
     * The run decided there was nothing for it to do (no key, today's
     * allowance already spent). Not a failure and not a success.
     *
     * @param  array<string, mixed>  $detail
     */
    public static function skipped(string $source, ?string $reason = null, array $detail = [], ?string $at = null): void
    {
        self::report($source, HeartbeatRecord::SKIPPED, $reason, $detail, $at);
    }

    /**
     * From the summary a kit sync already returns (`status`, `finished_at`,
     * `error`): `ok`, `error` / `failed` / `stopped`, `skipped`. A dry run
     * is not an attempt and leaves nothing.
     *
     * @param  array<string, mixed>  $summary
     * @param  array<string, mixed>  $detail
     */
    public static function fromSummary(string $source, array $summary, array $detail = []): void
    {
        $status = HeartbeatRecord::status($summary['status'] ?? null);

        if ($status === null) {
            return;
        }

        $at = is_string($summary['finished_at'] ?? null) && $summary['finished_at'] !== '' ? $summary['finished_at'] : null;

        self::report($source, $status, $summary['error'] ?? null, $detail, $at);
    }

    /**
     * Counts for the run now open that feeds $source, written when its
     * command finishes. Dropped when no such command is running.
     *
     * @param  array<string, mixed>  $detail
     */
    public static function note(string $source, array $detail): void
    {
        self::quietly(static function () use ($source, $detail): void {
            if (($run = self::runFeeding($source)) !== null) {
                $run->notes[$source] = array_replace($run->notes[$source] ?? [], $detail);
            }
        });
    }

    /** Adds to one count of the run now open that feeds $source. */
    public static function add(string $source, string $count, int $by = 1): void
    {
        self::quietly(static function () use ($source, $count, $by): void {
            if (($run = self::runFeeding($source)) !== null) {
                $run->notes[$source][$count] = (int) ($run->notes[$source][$count] ?? 0) + $by;
            }
        });
    }

    /**
     * One item of the run now open that feeds $source: it came back, or it
     * did not and why. A run that ends with items tried and none back is
     * recorded as failed whatever its exit code says — `seo:psi-sync` exits
     * 0 with ok=0 failed=60.
     */
    public static function tally(string $source, bool $ok, ?string $error = null): void
    {
        self::quietly(static function () use ($source, $ok, $error): void {
            if (($run = self::runFeeding($source)) !== null) {
                self::count($run, $source, $ok, $error);
            }
        });
    }

    /** {@see tally()} for code that does not know which source it is collecting for: whichever the running command feeds. */
    public static function counted(bool $ok, ?string $error = null): void
    {
        self::quietly(static function () use ($ok, $error): void {
            if (($run = self::current()) !== null) {
                self::count($run, '*', $ok, $error);
            }
        });
    }

    /**
     * The run now open was refused before it spent anything — the
     * DataForSEO balance cannot cover it, the estimate is over budget. It
     * is recorded as a failed attempt with this reason when its command
     * finishes; before 2026-11-12 a refused run recorded nothing at all.
     */
    public static function refused(string $reason): void
    {
        self::quietly(static function () use ($reason): void {
            if (($run = self::current()) !== null) {
                $run->refusal = $reason;
            }
        });
    }

    /** The innermost command running now that feeds a source, or null. */
    public static function current(): ?HeartbeatRun
    {
        return self::$runs === [] ? null : self::$runs[count(self::$runs) - 1];
    }

    /**
     * A command that feeds a source has started ({@see CommandHeartbeat}).
     * Null for a command no source knows. $typed is the whole line where
     * there is no console input to read it from (a command another command
     * runs): without it the run was known by its bare name, and a collector
     * reporting itself inside `seo:track-rankings --collect` was filed
     * under the weekly `seo:track-rankings`.
     */
    public static function open(string $command, ?InputInterface $input = null, ?Container $container = null, ?CommandLine $typed = null): ?HeartbeatRun
    {
        try {
            $sources = SourceRegistry::sourcesOf($command, $container);

            if ($sources === []) {
                return null;
            }

            // Whatever failed before this without saying why has had its
            // chance to be explained.
            self::$unexplained = [];

            // A command does not run inside itself: one of the same name
            // still open is a run that never got to finish.
            foreach (self::$runs as $depth => $run) {
                if ($run->command === $command) {
                    self::abandon($depth);

                    break;
                }
            }

            if (! self::$shutdownRegistered) {
                self::$shutdownRegistered = true;
                register_shutdown_function(static function (): void {
                    $fatal = error_get_last();

                    self::abandon(0, is_array($fatal) && in_array($fatal['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR], true) ? (string) $fatal['message'] : null);
                });
            }

            return self::$runs[] = new HeartbeatRun($command, $sources, $input, Carbon::now()->toIso8601String(), $typed);
        } catch (\Throwable $e) {
            self::caught($e);

            return null;
        }
    }

    /**
     * The command has finished: its run comes off the stack. Runs opened
     * after it that are still there never finished and are recorded so.
     */
    public static function close(string $command): ?HeartbeatRun
    {
        for ($depth = count(self::$runs) - 1; $depth >= 0; $depth--) {
            if (self::$runs[$depth]->command === $command) {
                self::abandon($depth + 1);

                return array_pop(self::$runs);
            }
        }

        return null;
    }

    /**
     * Every run deeper than $depth never finished — the process is ending
     * under it (a fatal error, a time limit, an `exit`) — and is recorded as
     * a failed attempt with $reason, or the last error logged while it ran.
     * A command that merely throws does finish (see CommandHeartbeat).
     */
    public static function abandon(int $depth = 0, ?string $reason = null): void
    {
        while (count(self::$runs) > max(0, $depth)) {
            $run = array_pop(self::$runs);

            self::quietly(static function () use ($run, $reason): void {
                $why = HeartbeatRecord::error($reason ?? $run->loggedError);
                $error = 'The run stopped before it finished'.($why === null ? '.' : ': '.$why);

                foreach (SourceRegistry::match($run->line()) as $source => $jobs) {
                    if (! in_array($source, $run->reported, true)) {
                        self::write($source, $jobs, HeartbeatRecord::FAILED, $error);
                    }
                }
            });
        }
    }

    /**
     * A failure the listener has just recorded with nothing but an exit
     * code to go on. When a command throws, Laravel reports the exception
     * (or the queue fails the job with it) only AFTER the command has
     * finished, so the reason arrives a moment later — {@see explain()}.
     *
     * @param  list<string>  $jobs
     * @param  array<string, mixed>  $detail
     */
    public static function unexplained(string $source, array $jobs, string $at, string $said, array $detail = []): void
    {
        self::$unexplained[] = ['source' => $source, 'jobs' => $jobs, 'at' => $at, 'said' => $said, 'detail' => $detail, 'since' => microtime(true)];
    }

    /**
     * The reason for the failure(s) just recorded without one: the same
     * run is written again with it — one failure still, not two.
     */
    public static function explain(string $reason): void
    {
        $failures = self::$unexplained;
        self::$unexplained = [];

        foreach ($failures as $failure) {
            if (microtime(true) - $failure['since'] <= self::EXPLAIN_WITHIN_SECONDS && trim($reason) !== '') {
                self::write($failure['source'], $failure['jobs'], HeartbeatRecord::FAILED, rtrim($failure['said'], '.').': '.$reason, $failure['detail'], $failure['at']);
            }
        }
    }

    /**
     * An error was logged. While a run is open it is the likely reason,
     * should that run never finish. Right after a failure recorded without
     * a reason, an exception being reported ($thrown) is that reason — the
     * next one reported, which is as close as Laravel lets a listener get:
     * CommandFinished does not carry the exception that ended the command.
     */
    public static function logged(string $message, bool $thrown = false): void
    {
        if (($run = self::current()) !== null) {
            $run->loggedError = $message;
        } elseif ($thrown && self::$unexplained !== []) {
            self::quietly(static fn () => self::explain($message));
        }
    }

    /**
     * One finished run written to the store, under each of $jobs — the
     * call the listener makes; a collector uses succeeded() / failed().
     *
     * @param  list<string>  $jobs  job keys of {@see SourceRegistry}
     * @param  array<string, mixed>  $detail
     */
    public static function write(string $source, array $jobs, string $status, mixed $error = null, array $detail = [], ?string $at = null, ?Container $container = null): void
    {
        self::quietly(static function () use ($source, $jobs, $status, $error, $detail, $at, $container): void {
            $container ??= Container::getInstance();
            $store = HeartbeatStores::current($container);

            if ($store === null) {
                return;
            }

            // A source with one job keeps its heartbeat on the row itself.
            $several = count(SourceRegistry::all($container)[$source]['jobs'] ?? []) > 1;
            $at ??= Carbon::now()->toIso8601String();
            $summary = $store->read($source);

            foreach ($several && $jobs !== [] ? $jobs : [null] as $job) {
                $summary = HeartbeatRecord::apply($summary, $status, $at, HeartbeatRecord::error($error), $detail, $job);
            }

            $store->write($source, $summary);
        });
    }

    /** What went wrong the last time a heartbeat could not be kept — for the kit's own tests. */
    public static function lastException(): ?\Throwable
    {
        return self::$lastException;
    }

    /** Forgets every open run — for tests, which share one process. */
    public static function reset(): void
    {
        self::$runs = [];
        self::$unexplained = [];
        self::$lastException = null;
    }

    /** @param  array<string, mixed>  $detail */
    private static function report(string $source, string $status, mixed $error, array $detail, ?string $at): void
    {
        self::quietly(static function () use ($source, $status, $error, $detail, $at): void {
            $container = Container::getInstance();
            $run = self::runFeeding($source);
            $jobs = [];

            if ($run !== null) {
                $run->reported[] = $source;
                $jobs = SourceRegistry::match($run->line(), $container)[$source] ?? [];
            }

            if ($jobs === []) {
                $primary = SourceRegistry::all($container)[$source]['primary'] ?? null;
                $jobs = $primary === null ? [] : [$primary];
            }

            self::write($source, $jobs, $status, $error, $detail, $at, $container);
        });
    }

    private static function runFeeding(string $source): ?HeartbeatRun
    {
        for ($depth = count(self::$runs) - 1; $depth >= 0; $depth--) {
            if (in_array($source, self::$runs[$depth]->sources, true)) {
                return self::$runs[$depth];
            }
        }

        return null;
    }

    private static function count(HeartbeatRun $run, string $key, bool $ok, ?string $error): void
    {
        $tally = $run->tallies[$key] ?? ['ok' => 0, 'failed' => 0, 'error' => null];
        $tally[$ok ? 'ok' : 'failed']++;

        if (! $ok && $error !== null && $error !== '') {
            $tally['error'] = $error;
        }

        $run->tallies[$key] = $tally;
    }

    private static function quietly(\Closure $work): void
    {
        try {
            $work();
        } catch (\Throwable $e) {
            self::caught($e);
        }
    }

    /** Into the site's own log when there is one; the kit carries no logger of its own. */
    private static function caught(\Throwable $e): void
    {
        self::$lastException = $e;

        try {
            if (function_exists('report')) {
                report($e);
            }
        } catch (\Throwable) {
            // Nothing left to tell.
        }
    }
}
