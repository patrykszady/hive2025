<?php

namespace SsSystems\Platform\Seo\Status;

use Symfony\Component\Console\Input\InputInterface;

/**
 * One artisan command while it runs: what the collector underneath has
 * said about it so far. Opened by {@see CommandHeartbeat} when a command
 * that feeds a source starts, read when it finishes, kept on
 * {@see Heartbeat}'s stack in between.
 */
final class HeartbeatRun
{
    /** @var list<string> sources whose collector reported the run itself — the exit code adds nothing */
    public array $reported = [];

    /** @var array<string, array<string, mixed>> counts handed in for a source ({@see Heartbeat::note()}) */
    public array $notes = [];

    /** @var array<string, array{ok: int, failed: int, error: ?string}> items done and failed, per source, `*` for whichever the command feeds */
    public array $tallies = [];

    /** Why the run was refused before it began (a balance or budget check), when it was. */
    public ?string $refusal = null;

    /** The last error logged while the run was open — the reason given for a run that never finishes. */
    public ?string $loggedError = null;

    public ?OutputTail $tail = null;

    /**
     * @param  list<string>  $sources  the source keys this command feeds
     * @param  ?CommandLine  $typed  the line as a wrapper command typed it ({@see CommandHeartbeat::around()}), which has no console input to read
     */
    public function __construct(
        public readonly string $command,
        public readonly array $sources,
        public readonly ?InputInterface $input,
        public readonly string $startedAt,
        public readonly ?CommandLine $typed = null,
    ) {}

    /**
     * The invocation with its arguments and options — what decides which
     * job of a source this run is (`seo:track-rankings --collect` is not
     * `seo:track-rankings`).
     */
    public function line(): CommandLine
    {
        return $this->typed ?? CommandLine::fromInput($this->command, $this->input);
    }
}
