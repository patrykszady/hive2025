<?php

namespace SsSystems\Platform\Seo\Status\Contracts;

/**
 * A {@see HeartbeatStore} that can hand back everything it holds at once.
 *
 * Optional, and a separate interface, because a site's own store only has
 * to keep an array and give it back: without this `GET seo/status` and the
 * `status` block of `seo/summary` ask it for each source's key in turn —
 * nineteen single-row reads per answer on gs.construction, whose store is
 * its own because its rows are per tenant. A store that implements it is
 * asked once.
 *
 * The kit's own {@see \SsSystems\Platform\Seo\Status\TableHeartbeatStore}
 * implements it.
 */
interface ReadsAllHeartbeats
{
    /**
     * Every summary this store holds for the site as it is asked — the
     * current tenant on a multi-tenant site — by its key: the source keys
     * of {@see \SsSystems\Platform\Seo\Status\SourceRegistry} AND the
     * scheduler's ({@see \SsSystems\Platform\Seo\Status\SchedulerBeat::KEY}),
     * wherever the store keeps that one. Keys it holds nothing for are
     * simply absent. A store that is merely absent (no table yet) answers
     * [] — like read(), it never throws for that.
     *
     * @return array<string, array<string, mixed>>
     */
    public function all(): array;
}
