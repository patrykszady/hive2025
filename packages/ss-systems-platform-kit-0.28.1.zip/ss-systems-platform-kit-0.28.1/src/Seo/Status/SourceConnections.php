<?php

namespace SsSystems\Platform\Seo\Status;

use Illuminate\Container\Container;
use SsSystems\Platform\Seo\Bing\BingWebmasterClient;
use SsSystems\Platform\Seo\Bing\Contracts\BingCoverageClient;
use SsSystems\Platform\Seo\Clarity\Contracts\ClarityCredentials;
use SsSystems\Platform\Seo\Contracts\SeoSiteProfile;
use SsSystems\Platform\Seo\DataForSeo\Contracts\DataForSeoApi;
use SsSystems\Platform\Seo\Faq\Bank\Contracts\FaqBankSource;
use SsSystems\Platform\Seo\Faq\Bank\Contracts\TextGenerator;
use SsSystems\Platform\Seo\IndexNow\Contracts\IndexNowKey;
use SsSystems\Platform\Seo\IndexNow\Contracts\PeeksIndexNowKey;
use SsSystems\Platform\Seo\Inspection\Contracts\UrlInspector;
use SsSystems\Platform\Seo\PageSpeed\Contracts\PageSpeedCredentials;
use SsSystems\Platform\Seo\SearchConsoleSyncClient;
use SsSystems\Platform\Seo\Snapshot\Contracts\SeoSnapshotSource;

/**
 * Whether a source is CONNECTED on this site (it has the key, grant or
 * setup its collector needs) and whether it is APPLICABLE at all (a site
 * with no location never has a map pack).
 *
 * No second rule: each answer is the very question the collector asks
 * before it runs, put to the very binding it asks —
 * `ClarityCredentials::isConfigured()` is what `seo:clarity-sync` stops on,
 * `SeoSiteProfile::latitude()` what `seo:map-pack-grid` refuses without.
 * So a multi-tenant site answers per tenant with nothing added here: its
 * bindings already read the current tenant.
 *
 * One exception, because a status read must never write: IndexNow. Its
 * collector asks `IndexNowKey::key()`, which on every site makes and
 * stores a key when there is none; here the binding is asked
 * `PeeksIndexNowKey::existingKey()` when it has it, and otherwise taken as
 * set up without being asked at all.
 *
 * A binding the site does not have reads as not connected (the collector
 * could not run either). A check that throws reads as connected: an
 * unreadable credential must not hide a failing source behind "not set up".
 */
final class SourceConnections
{
    /** @param  array<string, mixed>  $source  one entry of SourceRegistry::all() */
    public static function connected(array $source, ?Container $container = null): bool
    {
        $container ??= Container::getInstance();

        return self::answer(static fn (): bool => match ((string) ($source['connected'] ?? 'always')) {
            'search_console' => self::ask($container, SearchConsoleSyncClient::class, static fn ($client): bool => (bool) $client->isConfigured()),
            // The sweep asks its inspector; a site that has not bound one
            // inspects through its Search Console client.
            'page_inspection' => $container->bound(UrlInspector::class)
                ? (bool) $container->make(UrlInspector::class)->isReady()
                : self::ask($container, SearchConsoleSyncClient::class, static fn ($client): bool => (bool) $client->isConfigured()),
            'bing' => self::ask($container, BingWebmasterClient::class, static fn ($client): bool => (bool) $client->isConfigured()),
            'bing_coverage' => self::ask($container, BingCoverageClient::class, static fn ($client): bool => (bool) $client->isConfigured()),
            'pagespeed' => self::ask($container, PageSpeedCredentials::class, static fn ($credentials): bool => (bool) $credentials->isConfigured()),
            'clarity' => self::ask($container, ClarityCredentials::class, static fn ($credentials): bool => (bool) $credentials->isConfigured()),
            'dataforseo' => self::ask($container, DataForSeoApi::class, static fn ($api): bool => (bool) $api->isConfigured()),
            // Never key(): on every site it makes and stores a key when
            // there is none, and a status read must not be what sets
            // IndexNow up. A binding that can peek says what it has; one
            // that cannot is taken as set up — its collector would make
            // the key on its next run.
            'indexnow' => self::ask($container, IndexNowKey::class, static fn ($key): bool => ! $key instanceof PeeksIndexNowKey
                || trim((string) $key->existingKey()) !== ''),
            'faq_bank' => self::ask($container, TextGenerator::class, static fn ($generator): bool => (bool) $generator->isConfigured()),
            default => true,
        });
    }

    /** @param  array<string, mixed>  $source  one entry of SourceRegistry::all() */
    public static function applicable(array $source, ?Container $container = null): bool
    {
        $container ??= Container::getInstance();

        return self::answer(static fn (): bool => match ((string) ($source['applicable'] ?? 'always')) {
            // seo:map-pack-grid: "The site profile needs latitude(), longitude() and mapsQueries()".
            'map_pack' => self::ask($container, SeoSiteProfile::class, static fn ($profile): bool => $profile->latitude() !== null
                && $profile->longitude() !== null
                && $profile->mapsQueries() !== []),
            'faq_bank' => $container->bound(FaqBankSource::class),
            'snapshot' => $container->bound(SeoSnapshotSource::class),
            default => true,
        });
    }

    /**
     * @param  class-string  $binding
     * @param  \Closure(object): bool  $question
     */
    private static function ask(Container $container, string $binding, \Closure $question): bool
    {
        return $container->bound($binding) && $question($container->make($binding));
    }

    /** @param  \Closure(): bool  $question */
    private static function answer(\Closure $question): bool
    {
        try {
            return $question();
        } catch (\Throwable) {
            return true;
        }
    }
}
