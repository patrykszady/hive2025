<?php

namespace SsSystems\Platform\Seo\Status;

use Illuminate\Container\Container;
use Illuminate\Support\Carbon;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * The heartbeat of every collector that does not report its own: one
 * listener on Laravel's CommandStarting and CommandFinished, which maps
 * the command to the jobs it feeds ({@see SourceRegistry}) and records
 * when it finished and how.
 *
 * WHEN LARAVEL FIRES THEM (12 and 13, read from the framework, not from
 * memory — it changed): the console kernel re-routes Symfony's own
 * `console.command` / `console.terminate` events, which Symfony raises
 * around every command run THROUGH THE ARTISAN APPLICATION. So:
 *
 *   - covered: a command the scheduler starts, one typed into a shell, and
 *     one started with `Artisan::call()` — from a queued job or a request
 *     too, since that goes through the same application;
 *   - covered: a command that THROWS. Symfony raises `console.terminate`
 *     with a failure exit before it rethrows, so the run is recorded; the
 *     exception itself is reported a moment later and becomes the reason
 *     ({@see Heartbeat::explain()});
 *   - NOT covered: a command another command runs with `$this->call()`,
 *     which goes straight to the command and raises nothing. A site that
 *     wraps its collectors that way (gs.construction's `tenants:run`)
 *     reports them through {@see around()};
 *   - NOT covered: a test suite. The kernel only re-routes the events when
 *     the app is not `runningUnitTests()`, so in a site's tests this
 *     listener never runs and a test wanting it calls
 *     `app(Kernel::class)->rerouteSymfonyCommandEvents()` first.
 *
 * HOW A RUN IS READ, in this order:
 *
 *   1. The collector reported the run itself (Heartbeat::succeeded() and
 *      friends, while the command was running): nothing is added.
 *   2. The run was refused before it started spending
 *      (Heartbeat::refused() — a DataForSEO balance or budget check):
 *      failed, with that reason.
 *   3. A failure exit: failed, with the last error line the command
 *      printed ({@see OutputTail}), or its exit code when it printed none.
 *   4. A clean exit with items tried and none back (Heartbeat::tally()):
 *      failed — a clean exit is not a success when nothing was collected.
 *   5. A clean exit on a site where the source is not connected: skipped —
 *      the command's own "no key, nothing to do" is not a success either.
 *   6. Otherwise: ok.
 *
 * A process that dies under a command (a fatal error, a time limit) never
 * reaches CommandFinished. Its run is still open at shutdown and is
 * recorded then as a failed attempt that "stopped before it finished"
 * ({@see Heartbeat::abandon()}).
 *
 * Runs that collect nothing by design (`--dry-run`, `--list`, …) leave no
 * heartbeat. Nothing in here can fail a command: every handler swallows
 * its own errors.
 */
final class CommandHeartbeat
{
    /** @param  object  $event  Illuminate\Console\Events\CommandStarting */
    public function starting(object $event): void
    {
        try {
            $command = (string) ($event->command ?? '');

            if ($command === '') {
                return;
            }

            $run = Heartbeat::open($command, $event->input ?? null);

            // Only where the output is plain text — a cron run into a log
            // file, an Artisan::call() into a buffer — which is every run
            // that matters here. A person at a coloured terminal sees the
            // error themselves, and their output is left entirely alone.
            if ($run !== null && ($event->output ?? null) instanceof OutputInterface && ! $event->output->isDecorated()) {
                $run->tail = new OutputTail($event->output->getFormatter());
                $event->output->setFormatter($run->tail);
            }
        } catch (\Throwable) {
            // The command runs whether or not its heartbeat could be set up.
        }
    }

    /** @param  object  $event  Illuminate\Console\Events\CommandFinished */
    public function finished(object $event): void
    {
        try {
            $command = (string) ($event->command ?? '');

            if ($command === '') {
                return;
            }

            $run = Heartbeat::close($command);

            if ($run?->tail !== null && ($event->output ?? null) instanceof OutputInterface && $event->output->getFormatter() === $run->tail) {
                $event->output->setFormatter($run->tail->inner());
            }

            self::record(CommandLine::fromInput($command, $event->input ?? null), (int) $event->exitCode, $run);
        } catch (\Throwable) {
            // Same rule.
        }
    }

    /**
     * Runs a command that fires no console events — one a wrapper command
     * starts with `$this->call()` — as a run of its own, and records it
     * exactly as the listener would:
     *
     * ```php
     * $code = Tenancy::for($site, fn () => CommandHeartbeat::around(
     *     $this->argument('cmd'),
     *     fn (): int => $this->call($name, $args),
     * ));
     * ```
     *
     * $run returns the exit code. An exception is recorded as a failed run
     * with its message, then thrown on.
     *
     * A failure exit is final here: it is NOT left waiting for an exception
     * to explain it ({@see Heartbeat::explain()}). Anything the wrapped
     * command throws is caught and recorded right here, so no reason can
     * still be on its way — and a wrapper that runs one command for many
     * tenants has moved on to the next tenant by the time some unrelated
     * error is logged, which would then have been written as this run's
     * reason on that other tenant's row.
     *
     * @param  \Closure(): int  $run
     */
    public static function around(string $commandLine, \Closure $run, ?Container $container = null): int
    {
        $line = CommandLine::parse($commandLine);
        $opened = Heartbeat::open($line->name, null, $container, $line);

        try {
            $exitCode = (int) $run();
        } catch (\Throwable $e) {
            if ($opened !== null) {
                self::quietly(static function () use ($line, $opened, $e, $container): void {
                    Heartbeat::close($line->name);

                    foreach (SourceRegistry::match($line, $container) as $source => $jobs) {
                        if (! in_array($source, $opened->reported, true)) {
                            Heartbeat::write($source, $jobs, HeartbeatRecord::FAILED, sprintf('%s threw: %s', $line, $e->getMessage()), [], null, $container);
                        }
                    }
                });
            }

            throw $e;
        }

        self::quietly(static function () use ($line, $exitCode, $container): void {
            self::record($line, $exitCode, Heartbeat::close($line->name), $container, awaitReason: false);
        });

        return $exitCode;
    }

    /**
     * @param  bool  $awaitReason  whether a failure known only by its exit code may still be explained by the exception Laravel reports next — true under the console listener, false in {@see around()}
     */
    private static function record(CommandLine $line, int $exitCode, ?HeartbeatRun $run, ?Container $container = null, bool $awaitReason = true): void
    {
        $container ??= Container::getInstance();
        $at = Carbon::now()->toIso8601String();

        foreach (SourceRegistry::match($line, $container) as $source => $jobs) {
            if ($run !== null && in_array($source, $run->reported, true)) {
                continue;
            }

            [$status, $error, $detail, $explained] = self::outcome($source, $line, $exitCode, $run, $container);

            Heartbeat::write($source, $jobs, $status, $error, $detail, $at, $container);

            if (! $explained && $awaitReason) {
                Heartbeat::unexplained($source, $jobs, $at, (string) $error, $detail);
            }
        }
    }

    /**
     * @return array{0: string, 1: ?string, 2: array<string, mixed>, 3: bool}  status, raw reason, counts, and whether that reason is the run's own (false: only an exit code, an exception may follow)
     */
    private static function outcome(string $source, CommandLine $line, int $exitCode, ?HeartbeatRun $run, Container $container): array
    {
        $tally = $run?->tallies[$source] ?? $run?->tallies['*'] ?? null;
        $detail = $run?->notes[$source] ?? [];

        if ($tally !== null) {
            $detail += ['ok' => $tally['ok'], 'failed' => $tally['failed']];
        }

        if ($run?->refusal !== null) {
            return [HeartbeatRecord::FAILED, $run->refusal, $detail, true];
        }

        if ($exitCode !== 0) {
            $reason = $run?->tail?->error() ?? $tally['error'] ?? null;
            $last = $run?->tail?->last();

            return [
                HeartbeatRecord::FAILED,
                $reason ?? sprintf('%s exited with code %d.', $line, $exitCode).($last === null ? '' : ' Last line: '.$last),
                $detail + ['exit_code' => $exitCode],
                $reason !== null,
            ];
        }

        if ($tally !== null && $tally['ok'] === 0 && $tally['failed'] > 0) {
            return [HeartbeatRecord::FAILED, $tally['error'] ?? sprintf('All %d items failed.', $tally['failed']), $detail, true];
        }

        $definition = SourceRegistry::all($container)[$source] ?? null;

        if ($definition !== null && ! SourceConnections::connected($definition, $container)) {
            return [HeartbeatRecord::SKIPPED, $run?->tail?->last() ?? $definition['vendor'].' is not connected on this site.', $detail, true];
        }

        return [HeartbeatRecord::OK, null, $detail, true];
    }

    private static function quietly(\Closure $work): void
    {
        try {
            $work();
        } catch (\Throwable) {
            // A heartbeat that could not be kept is never the command's problem.
        }
    }
}
