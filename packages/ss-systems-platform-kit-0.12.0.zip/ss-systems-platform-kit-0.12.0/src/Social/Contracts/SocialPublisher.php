<?php

namespace SsSystems\Platform\Social\Contracts;

use Illuminate\Support\Carbon;

/**
 * The actual dispatch mechanics — gsc shells out to its own `social:post`
 * Artisan command, jpeterson/dawn dispatch a queued publish job after
 * picking their own unposted subject — kept entirely on the site's side of
 * this boundary, exactly like `Reports\Contracts\ReportStorage` keeps
 * storage mechanics off the kit's algorithm classes.
 */
interface SocialPublisher
{
    /**
     * Actually publish (or queue) one platform's due post.
     *
     * $slot is the id `AutomationTickRunner` is dispatching — either a
     * regular `"Y-m-d H:i"` slot or a `"Y-m-d catch-up"` id (see
     * `AutomationTickRunner::maybeCatchUp()`). An adapter whose two
     * dispatch paths genuinely differ (gsc's regular slot always sends
     * `--yes`/`--random-delay=0`; its historic catch-up call never did) can
     * tell them apart the same way the settings row's own
     * `last_dispatched_slot` already does: the literal `' catch-up'`
     * suffix — see `KitSocialPublisher` on gsc/jpeterson for the exact
     * split. A catch-up call always passes `$options = []` (neither site's
     * original `maybeCatchUp()` forwarded the platform's saved options).
     *
     * @param  array<string, mixed>  $options  the platform's own settings-row
     *         'options' column for a REGULAR slot — gsc's historic
     *         `--via puppeteer` (instagram `location_tag`) / `--queue
     *         --themed` (google_business `themed`) flags travel through
     *         here unmodified; the adapter decides what they mean.
     */
    public function publish(string $platform, string $slot, array $options = []): void;

    /**
     * The last post that ACTUALLY published (status=published), or null if
     * none ever has — a real published-row lookup
     * (`ImageSocialPost::where('platform', $platform)->where('status',
     * 'published')->max('published_at')` on gsc/jpeterson today), never the
     * settings row's own `last_dispatched_at` (set the moment a slot is
     * marked spent, BEFORE the post is even attempted — see
     * `Contracts\AutomationSettingsRepository::markDispatched()`).
     *
     * This distinction is exactly what `AutomationTickRunner`'s catch-up
     * safety net depends on: a platform whose publish keeps silently
     * failing must read as stale here, so the net actually notices instead
     * of being fooled by a timestamp that advances on every attempt
     * regardless of whether it succeeded.
     */
    public function lastPublishedAt(string $platform): ?Carbon;
}
